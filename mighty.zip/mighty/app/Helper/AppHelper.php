<?php namespace App\Helper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Templates;
use App\Models\Templatecomponents;
use App\Models\Componentoptions;
use App\Models\Optionsdetails;
use App\Models\Servicecontent;
use App\Models\Formdetails;
use Illuminate\Support\Facades\Redirect;
use Auth;
use Config;
use DB;
use Session;
use Mail;


class AppHelper {
    public static function GetoptionResults($id) { 
		$result = Optionsdetails::where('options_details.delete_status',0)
		 ->join('component_options', 'component_options.id', '=', 'options_details.option_id')
		->join('template_components', 'template_components.id', '=', 'component_options.component_id')
          ->where('component_options.component_id',$id)
          ->where('component_options.type',1)
          ->where('component_options.options',"First")
            ->select('options_details.*','component_options.id as comid')
            ->get();			
		return $result;
	}
      public static function GetoptionResultsAll($id) { 
    $result = Optionsdetails::where('options_details.delete_status',0)
     ->join('component_options', 'component_options.id', '=', 'options_details.option_id')
    ->join('template_components', 'template_components.id', '=', 'component_options.component_id')
          ->where('component_options.component_id',$id)
          ->where('component_options.type',1)
           ->select('options_details.*','component_options.options')
            ->get()
         ;      
    return $result;

  }
      public static function GetoptionsFirstSecond($id) { 
    $result = Componentoptions::where('component_options.delete_status',0)
     ->join('options_details', 'options_details.option_id', '=', 'component_options.id')
    ->join('template_components', 'template_components.id', '=', 'component_options.component_id')
          ->where('component_options.component_id',$id)
          ->where('component_options.type',1)
          ->select(DB::raw('DISTINCT component_options.id,component_options.options'))
            ->get()
         ;      
    return $result;

  }
    public static function GetFormdetails() {
        $result = Formdetails::where('delete_status',0)
             ->where('user_id',Auth::user()->id)
            ->select('id','uuid','form_name')->get();
        return $result;

    }
     public static function GetServiceContent($id) { 
    $result = Servicecontent::where('service_block_id',$id)->get()
         ;      
    return $result;

  }
}
