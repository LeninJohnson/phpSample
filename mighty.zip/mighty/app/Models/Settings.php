<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Settings extends Model
{
   protected $table = 'settings';
	
	public  function getSettings($id=""){
		 
		$result = $this->where('delete_status',0);						
						if($id!=""){
							$result=$result->where('id',$id)->first();
						}
						else{
							$result=$result->get();
						}
		return $result; 
	}
}
