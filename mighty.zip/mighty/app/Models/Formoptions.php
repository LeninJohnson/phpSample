<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use DB;


class Formoptions extends Model {

	protected $table = 'form_options';
	
	public  function getFormoptions($id=""){
		/*
		$result = $this->where('delete_status',0);						
						if($id!=""){
							$result=$result->where('id',$id)->first();;
						}
						else{
							$result=$result->get();
						}
		return $result;*/
	}

}