<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Validator;
class Videolibrary extends Model
{
    protected $table = 'video_library';

	private $rules = array(
		'title' => 'required|alpha|min:3',
		'description'  => 'required',
		// .. more rules here ..
	);
	protected $errors;

	public function validate($data)
	{
		// make a new validator object
		$v = Validator::make($data, $this->rules);

		// check for failure
		if ($v->fails())
		{

			// set errors and return false
			$this->errors = $v->errors();
			return false;
		}

		// validation pass
		return true;
	}

	public function errors()
	{
		return $this->errors;
	}

    public  function getVideolibrary($id=""){
		 
		$result = $this->where('delete_status',0);						
						if($id!=""){
							$result=$result->where('id',$id)->first();
						}
						else{
							$result=$result->get();
						}
		return $result; 
	}
	public  function getVideolibraryapi($id=""){

		$result = $this->where('delete_status',0)->select('id as videoLibraryId','title as videoTitle','video_url as videoSource','description as videoDescription');
		if($id!=""){
			$result=$result->where('id',$id)->first();
		}
		else{
			$result=$result->get();
		}
		return $result;
	}
}
