<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use DB;


class Previewformdetails extends Model {

	protected $table = 'preview_form_details';
	
	public  function getFormdetails($id=""){
		 
		$result = $this->where('delete_status',0);						
						if($id!=""){
							$result=$result->where('form_id',$id)->first();
						}
						else{
							$result=$result->get();
						}
		return $result; 
	}
	public  function getFormdetailsbyuuid($id=""){

		$result = $this->where('delete_status',0);
		if($id!=""){
			$result=$result->where('uuid',$id)->first();
		}
		else{
			$result=$result->get();
		}
		return $result;
	}



}