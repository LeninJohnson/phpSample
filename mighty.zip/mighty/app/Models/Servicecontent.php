<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use DB;


class Servicecontent extends Model
{
    protected $table = 'services_content';
    protected $hidden = ['created_at','updated_at'];
}
