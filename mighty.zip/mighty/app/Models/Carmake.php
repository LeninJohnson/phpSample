<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Carmake extends Model
{
    protected $table = 'makes';
    public  function getCarmake($id=""){

        $result = $this->where('delete_status',0);
        if($id!=""){
            $result=$result->where('id',$id)->first();
        }
        else{
            $result=$result->get();
        }
        return $result;
    }
    public  function getCarmakeWithYear($years){
        $result = $this->where('delete_status',0)->where('make_year',$years);
        $result=$result->get();
        return $result;
    }
    public  function getCarmakeWithYearApi($years){
        $result = $this->where('delete_status',0)->where('make_year',$years);
        $result=$result->select('id','make_year as year','make','description')->get();
        return $result;
    }
}
