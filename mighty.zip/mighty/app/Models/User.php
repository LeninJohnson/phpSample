<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Foundation\Auth\Access\Authorizable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;

class User extends Model implements AuthenticatableContract,
                                    AuthorizableContract,
                                    CanResetPasswordContract
{
    use Authenticatable, Authorizable, CanResetPassword;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 'email', 'password'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['password', 'remember_token'];
	
	public function getAdmins($id=""){
		
		$result = $this->join('apartment_details as apd','apd.id','=','users.fkapt_id')
				->where('users.account_type',2)->where('users.account_status',1)->where('users.delete_status',0)
				->where('apd.del_status',0)->select('users.*','apd.apartment_name');
						if($id!=""){
							$result=$result->where('users.id',$id)->first();;
						}
						else{
							$result=$result->get();
						}
		return $result;
	}
	public function getUserbyAparment($fkapt_id){
		
		$result = $this
		->join('apartment_details as apd','apd.id','=','users.fkapt_id')
				->where('users.account_type',4)->where('users.account_status',1)->where('users.delete_status',0)
				->where('apd.del_status',0)
				->where('users.fkapt_id',$fkapt_id)
				->select('users.*','apd.apartment_name');
						$result=$result->get();
						
		return $result;
	}
	public function getAdminApartments($fkapt_id){
		
		$result = $this
		->join('apartment_details as apd','apd.id','=','users.fkapt_id')
		
				->where('account_type',2)->where('users.account_status',1)->where('users.delete_status',0)
				->where('apd.del_status',0)
				->where('users.fkapt_id',$fkapt_id)
				->select('users.*','apd.apartment_name');
						$result=$result->get();
						
		return $result;
	}
	public function getUsersById($users){
		 
		$result = $this->
		  where('users.account_status',1)
			 ->where('users.delete_status',0)
				  ->whereIn('users.id',$users)
				->select('users.*');
						$result=$result->get();
						
		return $result;
	}
	
}
