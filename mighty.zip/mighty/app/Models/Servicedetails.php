<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use DB;


class Servicedetails extends Model
{
    protected $table = 'services_details';

 		public  function getServicedetails($id){
 
		$result = $this->where('delete_status',0)->where('service_id',$id);						
						 $result=$result->get();
		return $result; 
	}
	public  function getServicedetailsApi($id){

		$result = $this->where('delete_status',0)->where('service_id',$id);
		$result=$result->select('id','service_id','block_name','title','sub_title','price','image')->get();
		return $result;

	}
	public  function getUserServicedetailsApi($id,$type,$mleage_type=0){

		$result = $this->where('delete_status',0)->where('service_id',$id)->where('type',$type)->where('mleage_type',$mleage_type);
		$result=$result->select('id','service_id','block_name','title','sub_title','price','image','notes')->get();
		return $result;

	}

}
