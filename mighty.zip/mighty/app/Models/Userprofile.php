<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use DB,Auth;


class Userprofile extends Model {

    protected $table = 'user_profile';

        public  function getUserprofiles($id=""){

            $result = $this->where('user_profile.delete_status',0)
               // ->join('form_details as form_details','form_details.id','=','users_details.template_id')
                ->select('user_profile.*');
            if($id!=''){
                $result=$result->first();
            }else{
                $result->leftJoin('form_details as form_details','form_details.id','=','user_profile.form_id')
                    ->leftJoin('models as models','models.id','=','user_profile.model_id')
                    ->leftJoin('makes as makes','makes.id','=','user_profile.make_id')
                    ->leftJoin('car_engine as ce','ce.id','=','user_profile.engine_id')
                    ->join('inspection_details as ind','ind.submision_id','=','user_profile.id')
                    ->where('user_profile.user_id',Auth::user()->userid)
                    ->select('user_profile.*','makes.make as make','models.model as model','ce.engine as engine','ind.inspection_date','ind.duration');
                $result=$result->get();
            }

            return $result;
        }
    public  function getInspectionVin($id=""){

        $result = $this->where('user_profile.delete_status',0)->where('user_profile.vin',$id)
             ->leftJoin('form_details as form_details','form_details.id','=','user_profile.form_id')
            ->leftJoin('models as models','models.id','=','user_profile.model_id')
            ->leftJoin('makes as makes','makes.id','=','user_profile.make_id')
            ->leftJoin('car_engine as ce','ce.id','=','user_profile.engine_id')
            ->select('user_profile.*','makes.make as make','models.model as model','ce.engine as engine');
        $result=$result->first();

        return $result;
    }
    public  function getInspectionMobile($id=""){

        $result = $this->where('user_profile.delete_status',0)
            ->whereRaw("REPLACE(user_profile.mobile_no, \")\", \"\") LIKE '%$id%'")
            ->leftJoin('form_details as form_details','form_details.id','=','user_profile.form_id')
            ->leftJoin('models as models','models.id','=','user_profile.model_id')
            ->leftJoin('makes as makes','makes.id','=','user_profile.make_id')
            ->leftJoin('car_engine as ce','ce.id','=','user_profile.engine_id')
            ->select('user_profile.*','makes.make as make','models.model as model','ce.engine as engine');

        $result=$result->get();

        return $result;
    }
    public  function activeInspection($id){

        $result = $this->where('user_profile.delete_status',0)
            ->where('user_profile.user_id',$id)
            ->leftJoin('form_details as form_details','form_details.id','=','user_profile.form_id')
            ->leftJoin('models as models','models.id','=','user_profile.model_id')
            ->leftJoin('makes as makes','makes.id','=','user_profile.make_id')
            ->leftJoin('car_engine as ce','ce.id','=','user_profile.engine_id')
            ->select('user_profile.*','makes.make as make','models.model as model','ce.engine as engine') 
            ->orderBy('user_profile.id', 'desc')
            ->take(15);
        $result=$result->get();

        return $result;
    }
     public  function getFormResult($id){

        $result = $this->where('user_profile.id',$id)
            ->leftJoin('inspection_details as inspection_details','inspection_details.submision_id','=','user_profile.id')
            ->leftJoin('form_details as form_details','form_details.id','=','inspection_details.form_id')
            ->leftJoin('models as models','models.id','=','user_profile.model_id')
            ->leftJoin('makes as makes','makes.id','=','user_profile.make_id')
            ->leftJoin('car_engine as ce','ce.id','=','user_profile.engine_id')
            ->select('user_profile.*','makes.make as make','models.model as model','ce.engine as engine','inspection_details.form_templates','inspection_details.comments','inspection_details.inspection_date','inspection_details.duration','inspection_details.services as ins_services','inspection_details.carImage','inspection_details.damagImage','inspection_details.signature','form_details.form_content as form_content','form_details.form_api as form_api','form_details.imageType');
        $result=$result->first();

        return $result;
    }
    /*
       public  function getuserServices($id=""){
           $result = $this->where('users_details.user_id',$id)
               ->select('users_details.service_id');
           $result=$result->first();
           return $result;
       }

   */

}