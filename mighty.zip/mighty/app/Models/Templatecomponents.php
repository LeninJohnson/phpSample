<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use DB;


class Templatecomponents extends Model {

	protected $table = 'template_components';

	public  function getTemplatecomponents($id=""){
		return $this->test;
		$result = $this->where('delete_status',0);						
						if($id!=""){
							$result=$result->where('id',$id)->first();
						}
						else{
							$result=$result->get();
						}
		return $result;
	}

}