<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use DB;


class Formdetails extends Model {

	protected $table = 'form_details';
	
	public  function getFormdetails($id=""){
		 
		$result = $this;
						if($id!=""){
							$result=$result->where('uuid',$id)->first();
						}
						else{
							$result=$result->where('delete_status',0)
								->where('user_id',Auth::user()->id)
								->get();
						}
		return $result; 
	}
	public  function getFormdetailsByUser($id=""){

		$result = $this
			->join('users_details as users_details','users_details.template_id','=','form_details.id')
			->join('users as users','users.id','=','users_details.user_id')
			->where('users.userid',$id)
			->select('form_details.*','users.id as user_id');
		$result=$result->first();

		return $result;
	}

}