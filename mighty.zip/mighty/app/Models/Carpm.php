<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Carpm extends Model
{
    protected $table = 'car_pm';
    public  function getCarpm($id=""){

        $result = $this->where('delete_status',0);
        if($id!=""){
            $result=$result->where('id',$id)->first();
        }
        else{
            $result=$result->get();
        }
        return $result;
    }

    public  function getCarpmApi($mak,$mdl,$eng,$year){
        $result = $this
            ->where('delete_status',0)->where('make_id',$mak)->where('model_id',$mdl)
            /*->where('engine_id',$eng)*/
            ->where('year',$year);
        $result=$result
           // ->select('car_pm.*')
            ->selectRaw('DISTINCT make_id,model_id,year,intMo,intKm,action,item,qualifier,intMi,freq,recNo')
            ->get();
        return $result;
    }
}
