<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use DB;


class Usersdetails extends Model {

    protected $table = 'users_details';

    public  function getFormdetailsByUser($id=""){

$result = $this->join('users as users','users.id','=','users_details.user_id')
    ->where('users.userid',$id)
->join('form_details as form_details','form_details.id','=','users_details.template_id')
->select('form_details.form_name as form_name','form_details.id as form_id','users_details.user_id');
$result=$result->first();
return $result;
    }
    public  function getuserServices($id=""){
        $result = $this
            ->join('users as users','users.id','=','users_details.user_id')
            ->where('users.userid',$id)
            ->select('users_details.service_id','users.id as user_id');
        $result=$result->first();
        return $result;
    }



}