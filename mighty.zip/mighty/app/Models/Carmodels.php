<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Carmodels extends Model
{
    protected $table = 'models';
    public  function getCarmodels($id=""){

        $result = $this->where('models.delete_status',0)
        ->join('makes as makes','makes.id','=','models.make_id')
            ->where('makes.delete_status',0)
            ->select('models.*','makes.make_year as make_year','makes.make as make');
        if($id!=""){
            $result=$result->where('models.id',$id)->first();
        }
        else{
            $result=$result->get();
        }
        return $result;
    }
    public  function getCarmodelWithMake($make){

        $result = $this->where('delete_status',0)->where('make_id',$make)
            ->select('id','model','description');
        $result=$result->get();
        return $result;
    }

    protected $hidden = ['created_at', 'updated_at','delete_status'];
}
