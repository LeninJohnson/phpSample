<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use DB;


class Services extends Model {

	protected $table = 'services';
	
	 public  function getServices($id=""){
 
		$result = $this->where('delete_status',0);						
						if($id!=""){
							$result=$result->where('id',$id)->first();;
						}
						else{
							$result=$result->get();
						}
		return $result; 
	}
	public  function getActiveServices($id=""){
 
		$result = $this->where('delete_status',0)->where('active_service',1);						
						if($id!=""){
							$result=$result->where('id',$id)->first();;
						}
						else{
							$result=$result->get();
						}
		return $result; 
	}
	public  function getUserServices($sid=""){

		$result = $this->where('delete_status',0)->where('active_service',1);
		$result=$result->wherein('id',$sid)->get();
		return $result;
	}
	public  function getActiveServicesApi($id=""){

		$result = $this->where('services.delete_status',0)->where('services.active_service',1);
		if($id!=""){
			$result=$result->where('services.id',$id)->first();;
		}
		else{
			$result=$result->select('services.id as service_id','services.name as service_name')->get();
		}
		return $result;
	}
    public function services(){
        return $this->hasOne('App\Models\Servicedetails', 'service_id', 'id');

      //  $services = Services::find(2)->services;  call like tu
    }

	protected $hidden = ['created_at', 'updated_at'];

}