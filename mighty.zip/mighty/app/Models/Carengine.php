<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Carengine extends Model
{
    protected $table = 'car_engine';
    public  function getCarengine($id=""){

        $result = $this->where('car_engine.delete_status',0)
            ->join('models as models','models.id','=','car_engine.model_id')
            ->join('makes as makes','makes.id','=','models.make_id')
            ->where('models.delete_status',0)->where('makes.delete_status',0)
            ->select('car_engine.*','models.model','models.make_id','makes.make_year as make_year','makes.make as make');
        if($id!=""){
            $result=$result->where('car_engine.id',$id)->first();
        }
        else{
            $result=$result->get();
        }
        return $result;
    }
        public  function getCarengineWithModel($model){

            $result = $this->where('delete_status',0)->where('model_id',$model)
            ->select('id','engine','description');
            $result=$result->get();
            return $result;
        }

        protected $hidden = ['created_at', 'updated_at','delete_status'];

}
