<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Inspectiondetails extends Model
{
    protected $table = 'inspection_details';

    /*public  function getFormResult($id=""){


        $result = $this->where('inspection_details.submision_id',$id)
            ->leftJoin('form_details as form_details','form_details.id','=','inspection_details.form_id')
            ->leftJoin('user_profile as user_profile','user_profile.id','=','inspection_details.submision_id')
            ->select('inspection_details.*','form_details.form_content as form_content','form_details.form_api as form_api' )
            ->first();


        return $result;

    }*/

 /*   public  function getInspection($id=""){


        if($id!=""){
            $result=$this->where('id',$id)->first();
        }
        else{
            $result=$this->get();
        }
        return $result;
    }*/
}
