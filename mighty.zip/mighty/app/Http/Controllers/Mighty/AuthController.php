<?php
namespace App\Http\Controllers\Mighty;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;
use Hash;
use App\Models\User;
use App\Models\Formdetails;
use Carbon\Carbon;
use Config;
use Session;
use Image;
use Redirect;
use Response;
use Log;
use PDF,Uuid,Curl,Excel,Input,URL;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use League\Fractal;
use League\Fractal\Manager;
use Illuminate\Contracts\Encryption\DecryptException;
use League\Fractal\Resource\Collection as FractalCollection;
use League\Fractal\Resource\Collection;


class AuthController extends Controller
{
    public function __construct()
    {


        //$this->middleware('auth');


    }
    function myUrlEncode($string) {
        $entities = array('%21', '%2A', '%27', '%28', '%29', '%3B', '%3A', '%40', '%26', '%3D', '%2B', '%24', '%2C', '%2F', '%3F', '%25', '%23', '%5B', '%5D', ' ');
        $replacements = array('!', '*', "'", "(", ")", ";", ":", "@", "&", "=", "+", "$", ",", "/", "?", "%", "#", "[", "]", "");
        return str_replace($entities, $replacements, urlencode($string));
    }
    function myUrlEncode_($string) {
        $entities = array(' ');
        $replacements = array("");
        return str_replace($entities, $replacements, $string);
    }
    function loginto(){
        $url = 'https://mightyautoparts.com';
        Auth::logout();
        return Redirect::to($url);
    }
    function index(Request $request){
        if($request->isMethod('get')) {

            $param = $request->authtoken;

            $authtoken=$this->myUrlEncode($param);

           // $authtoken="4D7H1xdhLGFM+A+nAcubf7AeiJqiAcla6LJx7UbcFYHNB+AylhwboKG8Ne4KcTWPtZF2hVgyZ+ebzLw+UbxJsp2HGxJSbgLkBZX1G3dVR8KwBqaBVdWT1XTqOyIm03o+n0wyYUnPDuivo9O1VHc9ifaZkxwdCj2KMfTgypytej3Cof/QNQOVA26D8ttKOpF+zHfdZh7Eq2SxyRlCO2m281yvRJzK8SXv30TmkfCB79iM7OT/C7UxWf6XaXBNxgnyS9nyrDxwmPdPqddI+WBmg7QHytVuzrHPiuH846WPLWuapgxmmjb2w1iNq9MtwXzCsINsL4cCXjVtK6rUL3AeI6Rctc+tmqnbedME4FGrm56L/mw3v6LL6ifrcLTiAHQcOIX8TMA6arGKoHvEWd1m5zLmqoZuWRs8uy89yeYQe2blUnUwTJBa93QzJuLe8I/xi9ZZ0JNXKKkB+fMF0evB4Ns2nDgsi8Gdn6LpwBf1DemsvRNXh9fjZH87nG6CyJEjKLcCbh5dcyYDcJEfKl2VEybWifiFaOmR97huhKFYjo4p2KR4s9ZJb6HhSdXq6oPVFavXkAQw0/rOs6Tkd8pqM4d6FIxgwBxViH/R8IIkDoecIeiA5yvNbQYZW/WQABoyWUIngMejpfd7CuEiSgixww==";
            $key = 'Mightyauth123986';
            $iv='123986authMighty';
            Log::info($authtoken);
             $decryptxt=mcrypt_decrypt(MCRYPT_RIJNDAEL_128,$key,base64_decode($authtoken),MCRYPT_MODE_CBC,$iv);
            $decArray=explode("}",$decryptxt);
            $decryptxt=$decArray[0].'}';
            $decryptxt=json_decode($decryptxt);

            if(count($decryptxt)==1){

                 $check_user=User::where('username',$decryptxt->username)
                    ->where('email',$decryptxt->emailaddress)
                    ->where('micuserid',$decryptxt->micuserid)->first();
                if(count($check_user)==0){
                    $add=new User;
                    $add->username=$decryptxt->username;
                    $add->name=$decryptxt->fname;
                    $add->email=$decryptxt->emailaddress;
                    $add->user_password=$decryptxt->password;
                    $add->password=bcrypt("mighty123");
                    $add->micuserid=$decryptxt->micuserid;
                    $add->lname=$decryptxt->lname;
                    $add->fran_id=$decryptxt->fran_id;
                    $add->userid=$decryptxt->userid;
                    $add->franno=$decryptxt->franno;
                    $add->tempUsername=$decryptxt->tempUsername;
                    $add->salesid=(isset($decryptxt->salesid)) ? $decryptxt->salesid : 0;
                    $add->motoraccessstats=$decryptxt->motoraccessstats;
                    $add->franid=$decryptxt->franid;
                    $add->accessid=$decryptxt->accessid;
                    $add->franchise_number=$decryptxt->franchise_number;
                    $add->save();
                    for($i=1;$i<=5;$i++){

                        $tasks = Formdetails::find($i);
                        $newTask = $tasks->replicate(); // Make a copy of Form details
                        $newTask->uuid=Uuid::generate()->string;
                        $newTask->user_id=$add->id;
                        $newTask->save();
                    };
                }

                if (Auth::attempt(['username' =>$decryptxt->username, 'email' =>$decryptxt->emailaddress,'password' =>"mighty123"])) {

                    return redirect('/home');
                }


            }else{
                $url = 'https://mightyautoparts.com';
// redirects to http://google.com
                return Redirect::to($url);
            }




           //echo count($decryptxt);echo "<br>";
          //  return $decryptxt;


        }
    }
    function getLogout(){
        echo "Yes";
    }

}
