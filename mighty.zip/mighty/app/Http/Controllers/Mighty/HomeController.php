<?php
namespace App\Http\Controllers\Mighty;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;
use Hash;
use App\Models\User;
use App\Models\Templates;
use App\Models\Templatecomponents;
use App\Models\Componentoptions;
use App\Models\Optionsdetails;
use App\Models\Feldsmaster;
use App\Models\Formdetails;
use App\Models\Formfields;
use App\Models\Formoptions;
use App\Models\Services;
use App\Models\Servicedetails;
use App\Models\Servicecontent;
use App\Models\Videolibrary;
use App\Models\Carmodels;
use App\Models\Carmake;
use App\Models\Settings;
use App\Models\Carengine;
use App\Models\Carpm;
use App\Models\Cartsb;
use App\Models\Usersdetails;
use App\Models\Userprofile;
use App\Models\Previewformdetails;
use App\Models\Previewformoptions;
use App\Models\Previewformfields;
use App\Transformer\ModelTransformer;
use Carbon\Carbon;
use Config;
use Session;
use Image;
use Redirect;
use Response;
use PDF,Uuid,Curl,Excel,Input,URL;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use League\Fractal;
use League\Fractal\Manager;
use Illuminate\Contracts\Encryption\DecryptException;
use League\Fractal\Resource\Collection as FractalCollection;
use League\Fractal\Resource\Collection;


class HomeController extends Controller
{
	 public function __construct()
    {


         $this->middleware('auth');

    	$this->user = new User;
        $this->templates = new Templates;
        $this->templatecomponents = new Templatecomponents;
        $this->componentoptions = new Componentoptions;
        $this->optionsdetails = new Optionsdetails;
        $this->formdetails = new Formdetails;
        $this->services = new Services;
        $this->servicedetails = new Servicedetails;
        $this->servicecontent = new Servicecontent;
        $this->videolibrary = new Videolibrary;
        $this->carmodels = new Carmodels;
        $this->carmake = new Carmake;
        $this->settings = new Settings;
        $this->carengine = new Carengine;
        $this->Userprofile = new Userprofile;
        $this->previewformdetails = new Previewformdetails;
        $this->previewformoptions = new Previewformoptions;
        $this->previewformfields = new Previewformfields;
        $this->fractal = new Manager();
    }

    function authtoken($id){
        echo $id;
    }




    function testthis(){
        $flag=array();
        for($i=1;$i<=40;$i++){
            $flag[$i]=$i;
        }
       // $flag=array('1'=>1,'2'=>2,'3'=>3,'4'=>4,'5'=>5,'6'=>6,'7'=>7);

        echo "<pre>";
        print_r($flag);
        echo "<pre>";

        $replace=30;
        $to=4;
        $result=$flag;

        foreach($flag as $key=>$res){


                if($replace>$to){
                    if($res>=$to && $replace>$res){
                        $result[$key]=$res+1;
                    }
                }
                if($replace<$to){
                    if($res<=$to && $replace<$res){
                        $result[$key]=$res-1;
                    }
                }

        }
        if($replace>$to || $replace<$to) {
            $result[$replace] = $to;
        }

        echo "<pre>";
        print_r($result);
        echo "<pre>";

exit;

        $path =public_path().'/mighty/Redirects.xlsx';
            $data = Excel::load($path, function($reader) {})->get();
            if(!empty($data) && $data->count()){
                $arr=array();
                foreach ($data->toArray() as $key => $value) {
                    if(!empty($value)){
  foreach ($value as $index=>$v) {
                            $arr[$index]['source'] = $v['source'];
                            $arr[$index]['target'] = $v['target'];
                            $arr[$index]['count'] = substr_count($v['source'],'/');
                        //echo $result="Redirect 301 ".$v['source'].' '.$v['target']; echo "<br>";
                          }
                        usort($arr, function($a, $b){
                            return $b['count'] - $a['count'];
                        });
                        foreach($arr as $index=>$s){

                          //  if($index>=500 && $index<=1000){

                            // $result="Redirect 301 ".$s['source'].' '.$s['target']; echo "<br>";
                            $url="http://staging.collegehunkshaulingjunk.com".$s['source'];
                            $ch = curl_init($url);
                            curl_setopt($ch, CURLOPT_HEADER, true);
                            curl_setopt($ch, CURLOPT_NOBODY, true);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
                            curl_setopt($ch, CURLOPT_FOLLOWLOCATION,true);
                            curl_setopt($ch, CURLOPT_TIMEOUT,10);
                            $output = curl_exec($ch);
                            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                            curl_close($ch);
                            if($httpcode!=200){
                            echo $url;
                            echo ' HTTP code: ' . $httpcode; echo "<br>";

                            }
                           // }
                        }


                    }
                }

 exit;

            }



        return back()->with('error','Please Check your file, Something is wrong there.');
        exit;
        $client = new Client(); //GuzzleHttp\Client
        $url="https://avenger2016.mightyautoparts.com/josso/signon/usernamePasswordLogin.do";
        // $url="http://localhost/mighty/public/api/v1/inspection";

        $result = $client->post($url, [
            'form_params' => [
                'josso_username' => 'tech.central',
                'josso_password'=>'moa650',
                'josso_cmd'=>'login',
                'josso_back_to'=>'https://avenger2016.mightyautoparts.com/CVIFTabletApp/josso_security_check'
            ]
        ]);


        $result = json_decode($result->getBody(), true);


        print_r($result);
        exit;
    }
    function testthisX(){


        $encstr = "jriCNR9l5q6g5DO2aMNqco89hDg=";
        $key="Mightyvma1234567";
        $iv="1234567vmaMighty";


        echo base64_encode($encstr);
 /*       $key = hex2bin($key);
        $iv = hex2bin($iv);*/

        exit;



        $path =public_path().'/mighty/Redirectsx.xlsx';



        $data = Excel::load($path, function($reader) {})->get();

        if(!empty($data) && $data->count()){

            $arr=array();
            foreach ($data->toArray() as $key => $value) {

                if(!empty($value)){

                    $arr[$key]['source'] = $value['source'];
                    $arr[$key]['target'] = $value['target'];
                    $arr[$key]['count'] = substr_count($value['source'],'/');

                    /*
                                            foreach ($value as $index=>$v) {
                                                $arr[$index]['source'] = $v['source'];
                                                $arr[$index]['target'] = $v['target'];
                                                $arr[$index]['count'] = substr_count($v['source'],'/');
                                            echo $result="Redirect 301 ".$v['source'].' '.$v['target']; echo "<br>";

                                              }
                                            */
                 /*   usort($arr, function($a, $b){
                        return $b['count'] - $a['count'];
                    });
                    */




                }
            }
            foreach($arr as $index=>$s){
                if($s['source']==''){
                    exit;
                }
                $source=$s['source'];
                $target=$s['target'];
              //  echo  $result="RedirectMatch 302 ^".$source.".*$ ".$target."";echo "<br>";
              //  echo $result="RedirectMatch 302 ^".$s['source'].".*$ '.$s['target']; echo "<br>";
               //  echo  $result="Redirect 301 ".$s['source'].' '.$s['target']; echo "<br>";

                $url="http://staging.collegehunkshaulingjunk.com".$s['source'];
                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_HEADER, true);
                curl_setopt($ch, CURLOPT_NOBODY, true);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION,true);

                curl_setopt($ch, CURLOPT_TIMEOUT,10);
                $output = curl_exec($ch);
                $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                if($httpcode!=200){
                    echo $url;
                    echo ' HTTP code: ' . $httpcode; echo "<br>";
                }

            }
            exit;

        }



        return back()->with('error','Please Check your file, Something is wrong there.');
        exit;

        exit;
    }
    function testcurl(){
        DB::enableQueryLog();
        $addsmod=new Carengine;
        $addsmod=$addsmod
            ->join('models as models','models.id','=','car_engine.model_id')
            ->join('makes as makes','makes.id','=','models.make_id')
            ->select('car_engine.*','models.ModelId','makes.make_year as make_year','makes.makeID as makeID','makes.make_year as make_year')
            ->whereBetween('makes.make_year', array(2000 ,2000))->get();


           return   $queries = DB::getQueryLog();
        exit;



        foreach($addsmod as $rs){
echo $rs->id;echo "<br>";
            $ch = curl_init();
             $urlModl = 'http://192.168.14.165:8080/sampwebsers/munch/apiservices/servicesEngineConfigData/'.$rs->makeID.'/'.$rs->ModelId.'/'.$rs->make_year.'/';

            curl_setopt_array(
                $ch, array(
                CURLOPT_URL => $urlModl ,
                CURLOPT_RETURNTRANSFER => true,     // return web page
                CURLOPT_HEADER         => false,    // don't return headers
                CURLOPT_FOLLOWLOCATION => true,     // follow redirects
                CURLOPT_ENCODING       => "",       // handle all encodings
                CURLOPT_USERAGENT      => "spider", // who am i
                CURLOPT_AUTOREFERER    => true,     // set referer on redirect
                CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
                CURLOPT_TIMEOUT        => 120,      // timeout on response
                CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
                CURLOPT_SSL_VERIFYPEER => 0 ,    // Disabled SSL Cert checks
                CURLOPT_SSL_VERIFYHOST => 0     // Disabled SSL Cert checks
            ));

            $outputmdl = curl_exec($ch);
            $server_outputmdl=json_decode($outputmdl);

            if(count($server_outputmdl)!=0) {
                foreach ($server_outputmdl as $restmdl) {
                    foreach ($restmdl as $valmdl) {

                        $addeng = new Carengine;
                        $addeng = $addeng->where('make_id', $rs->make_id)->where('model_id', $rs->id)->where('engine', $valmdl->Value)->first();
                        if (count($addeng) == 0) {
                            $addeng = new Carengine;
                            $addeng->model_id = $rs->id;
                            $addeng->engine = $valmdl->Value;
                            $addeng->make_id = $rs->make_id;
                            $addeng->EngineBaseId = $valmdl->EngineBaseId;
                            $addeng->Engineconfigid = $valmdl->Engineconfigid;
                            $addeng->description = '';
                            $addeng->save();
                        }

//end
                        $urlPM = 'http://192.168.14.165:8080/sampwebsers/munch/apiservices/servicesPMData/'.$rs->makeID.'/'.$rs->ModelId.'/'.$rs->make_year.'/'.$valmdl->Engineconfigid.'/';


                        curl_setopt_array(
                            $ch, array(
                            CURLOPT_URL => $urlPM ,
                            CURLOPT_RETURNTRANSFER => true,     // return web page
                            CURLOPT_HEADER         => false,    // don't return headers
                            CURLOPT_FOLLOWLOCATION => true,     // follow redirects
                            CURLOPT_ENCODING       => "",       // handle all encodings
                            CURLOPT_USERAGENT      => "spider", // who am i
                            CURLOPT_AUTOREFERER    => true,     // set referer on redirect
                            CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
                            CURLOPT_TIMEOUT        => 120,      // timeout on response
                            CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
                            CURLOPT_SSL_VERIFYPEER => 0 ,    // Disabled SSL Cert checks
                            CURLOPT_SSL_VERIFYHOST => 0     // Disabled SSL Cert checks
                        ));

                        $outputPM = curl_exec($ch);
                        $server_outputPM=json_decode($outputPM);
                        if(count($server_outputPM)!=0){
                            foreach($server_outputPM as $restpm){
                                foreach($restpm as $valpm){


                                    $adds = new Carpm;
                                    $adds = $adds->where('make_id', $rs->make_id)
                                        ->where('model_id', $rs->id)
                                        ->where('engine_id', $addeng->id)
                                        ->where('item',$valpm->Item)
                                        ->where('action',$valpm->Action)
                                        ->where('recNo',$valpm->RecNo)
                                        ->first();

                                    if (count($adds) == 0) {
                                        $adds = new Carpm;
                                        $adds->intMo=$valpm->IntMo;
                                        $adds->intKm=$valpm->IntKm;
                                        $adds->action=$valpm->Action;
                                        $adds->item=$valpm->Item;
                                        $adds->qualifier=$valpm->Qualifier;
                                        $adds->intMi=$valpm->IntMi;
                                        $adds->freq=$valpm->Freq;
                                        $adds->recNo=$valpm->RecNo;
                                        $adds->make_id=$rs->make_id;
                                        $adds->model_id=$rs->id;
                                        $adds->engine_id=$addeng->id;
                                        $adds->year=$rs->make_year;
                                        $adds->save();
                                    }




                                }
                            }
                        }

                        //TSB
                        $urlTSB = 'http://192.168.14.165:8080/sampwebsers/munch/apiservices/servicesTSBData/'.$rs->makeID.'/'.$rs->ModelId.'/'.$rs->make_year.'/'.$valmdl->Engineconfigid.'/';



                        curl_setopt_array(
                            $ch, array(
                            CURLOPT_URL => $urlTSB ,
                            CURLOPT_RETURNTRANSFER => true,     // return web page
                            CURLOPT_HEADER         => false,    // don't return headers
                            CURLOPT_FOLLOWLOCATION => true,     // follow redirects
                            CURLOPT_ENCODING       => "",       // handle all encodings
                            CURLOPT_USERAGENT      => "spider", // who am i
                            CURLOPT_AUTOREFERER    => true,     // set referer on redirect
                            CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
                            CURLOPT_TIMEOUT        => 120,      // timeout on response
                            CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
                            CURLOPT_SSL_VERIFYPEER => 0 ,    // Disabled SSL Cert checks
                            CURLOPT_SSL_VERIFYHOST => 0     // Disabled SSL Cert checks
                        ));

                        $outputTSB = curl_exec($ch);
                        $server_outputTSB=json_decode($outputTSB);
                        if(count($server_outputTSB)!=0){
                            foreach($server_outputTSB as $resttsb){
                                foreach($resttsb as $valtsb){


                                    $addtbs=new Cartsb;
                                    $addtbs = $addtbs->where('make_id', $rs->make_id)
                                        ->where('model_id', $rs->id)
                                        ->where('engine_id', $addeng->id)
                                        ->where('issuer',$valtsb->Issuer)
                                        ->where('issuedate',$valtsb->Issuedate)
                                        ->where('vehicletoengineconfigid',$valtsb->Vehicletoengineconfigid)
                                        ->first();
                                    //echo count($addtbs); echo $valtsb->Issuer;

                                    if (count($addtbs) == 0) {
                                        $addtbs=new Cartsb;
                                        $addtbs->issuer=$valtsb->Issuer;
                                        $addtbs->issuedate=$valtsb->Issuedate;
                                        $addtbs->description=$valtsb->Description;
                                        $addtbs->vehicletoengineconfigid=$valtsb->Vehicletoengineconfigid;
                                        $addtbs->autosystemdescription=$valtsb->Autosystemdescription;
                                        $addtbs->type=$valtsb->Type;
                                        $addtbs->filenamepdf=$valtsb->Filenamepdf;
                                        $addtbs->manufacturernum=$valtsb->Manufacturernum;
                                        $addtbs->make_id=$rs->make_id;
                                        $addtbs->model_id=$rs->id;
                                        $addtbs->engine_id=$addeng->id;
                                        $addtbs->year=$rs->make_year;
                                        $addtbs->save();
                                    }



                                    echo "TSB"; echo "<br>";

                                }
                            }
                        }
                        //end
                    }
                }
            }




        }

 exit;
        $year=2011;
 for($year=2011;$year<=2017;$year++){

echo $year;echo "<br>";
        $url = 'http://192.168.14.160:8080/sampwebsers/munch/apiservices/servicesMakeDetails/'.$year.'/';
        $ch = curl_init();

        curl_setopt_array(
            $ch, array(
            CURLOPT_URL => $url ,
            CURLOPT_RETURNTRANSFER => true,     // return web page
            CURLOPT_HEADER         => false,    // don't return headers
            CURLOPT_FOLLOWLOCATION => true,     // follow redirects
            CURLOPT_ENCODING       => "",       // handle all encodings
            CURLOPT_USERAGENT      => "spider", // who am i
            CURLOPT_AUTOREFERER    => true,     // set referer on redirect
            CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
            CURLOPT_TIMEOUT        => 120,      // timeout on response
            CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
            CURLOPT_SSL_VERIFYPEER => 0 ,    // Disabled SSL Cert checks
            CURLOPT_SSL_VERIFYHOST => 0     // Disabled SSL Cert checks
        ));

        $output = curl_exec($ch);
        $server_output=json_decode($output);

        if(count($server_output)!=0){
        foreach($server_output as $rest){
            foreach($rest as $val){


                $addmk=new Carmake;
                $addmk=$addmk->where('make_year',$year)->where('make',$val->MakeName)->first();
                if(count($addmk)==0){
                    $addmk=new Carmake;
                    $addmk->make_year=$year;
                    $addmk->make=$val->MakeName;
                    $addmk->makeID=$val->MakeId;
                    $addmk->description="";
                    $addmk->save();
                }else{
                    $addmk->id;
                }

/*
                $urlMk = 'http://192.168.14.165:8080/sampwebsers/munch/apiservices/servicesModelDetails/'.$val->MakeId.'/'.$year.'/';


                curl_setopt_array(
                    $ch, array(
                    CURLOPT_URL => $urlMk ,
                    CURLOPT_RETURNTRANSFER => true,     // return web page
                    CURLOPT_HEADER         => false,    // don't return headers
                    CURLOPT_FOLLOWLOCATION => true,     // follow redirects
                    CURLOPT_ENCODING       => "",       // handle all encodings
                    CURLOPT_USERAGENT      => "spider", // who am i
                    CURLOPT_AUTOREFERER    => true,     // set referer on redirect
                    CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
                    CURLOPT_TIMEOUT        => 120,      // timeout on response
                    CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
                    CURLOPT_SSL_VERIFYPEER => 0 ,    // Disabled SSL Cert checks
                    CURLOPT_SSL_VERIFYHOST => 0     // Disabled SSL Cert checks
                ));

                $outputmk = curl_exec($ch);
                $server_outputmk=json_decode($outputmk);

                if(count($server_outputmk)!=0){
                 foreach($server_outputmk as $restmk){
                    foreach($restmk as $valmk){

                        $addsmod=new Carmodels;
                        $addsmod=$addsmod->where('make_id',$addmk->id)->where('model',$valmk->ModelName)->first();
                        if(count($addsmod)==0){
                            $addsmod=new Carmodels;
                            $addsmod->make_id=$addmk->id;
                            $addsmod->model=$valmk->ModelName;
                            $addsmod->ModelId=$valmk->ModelId;
                            $addsmod->description='';
                            $addsmod->save();
                        }else{
                            echo  $addsmod->id.'Model';
                        }

                        $urlModl = 'http://192.168.14.165:8080/sampwebsers/munch/apiservices/servicesEngineConfigData/'.$val->MakeId.'/'.$valmk->ModelId.'/'.$year.'/';


                        curl_setopt_array(
                            $ch, array(
                            CURLOPT_URL => $urlModl ,
                            CURLOPT_RETURNTRANSFER => true,     // return web page
                            CURLOPT_HEADER         => false,    // don't return headers
                            CURLOPT_FOLLOWLOCATION => true,     // follow redirects
                            CURLOPT_ENCODING       => "",       // handle all encodings
                            CURLOPT_USERAGENT      => "spider", // who am i
                            CURLOPT_AUTOREFERER    => true,     // set referer on redirect
                            CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
                            CURLOPT_TIMEOUT        => 120,      // timeout on response
                            CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
                            CURLOPT_SSL_VERIFYPEER => 0 ,    // Disabled SSL Cert checks
                            CURLOPT_SSL_VERIFYHOST => 0     // Disabled SSL Cert checks
                        ));

                        $outputmdl = curl_exec($ch);
                        $server_outputmdl=json_decode($outputmdl);

                        if(count($server_outputmdl)!=0){
                            foreach($server_outputmdl as $restmdl){
                                foreach($restmdl as $valmdl){

                                    $addeng=new Carengine;
                                    $addeng=$addeng->where('make_id',$addmk->id)->where('model_id',$addsmod->id)->where('engine',$valmdl->Value)->first();
                                    if(count($addeng)==0){
                                        $addeng=new Carengine;
                                        $addeng->model_id=$addsmod->id;
                                        $addeng->engine=$valmdl->Value;
                                        $addeng->make_id=$addmk->id;
                                        $addeng->EngineBaseId=$valmdl->EngineBaseId;
                                        $addeng->Engineconfigid=$valmdl->Engineconfigid;
                                        $addeng->description='';
                                        $addeng->save();
                                    }else{
                                        $addeng->id.'Eng';
                                    }


                                    $urlPM = 'http://192.168.14.165:8080/sampwebsers/munch/apiservices/servicesPMData/'.$val->MakeId.'/'.$valmk->ModelId.'/'.$year.'/'.$valmdl->Engineconfigid.'/';


                                    curl_setopt_array(
                                        $ch, array(
                                        CURLOPT_URL => $urlPM ,
                                        CURLOPT_RETURNTRANSFER => true,     // return web page
                                        CURLOPT_HEADER         => false,    // don't return headers
                                        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
                                        CURLOPT_ENCODING       => "",       // handle all encodings
                                        CURLOPT_USERAGENT      => "spider", // who am i
                                        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
                                        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
                                        CURLOPT_TIMEOUT        => 120,      // timeout on response
                                        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
                                        CURLOPT_SSL_VERIFYPEER => 0 ,    // Disabled SSL Cert checks
                                        CURLOPT_SSL_VERIFYHOST => 0     // Disabled SSL Cert checks
                                    ));

                                    $outputPM = curl_exec($ch);
                                    $server_outputPM=json_decode($outputPM);
                                    if(count($server_outputPM)!=0){
                                        foreach($server_outputPM as $restpm){
                                            foreach($restpm as $valpm){


                                               $adds=new Carpm;
                                                $adds->intMo=$valpm->IntMo;
                                                $adds->intKm=$valpm->IntKm;
                                                $adds->action=$valpm->Action;
                                                $adds->item=$valpm->Item;
                                                $adds->qualifier=$valpm->Qualifier;
                                                $adds->intMi=$valpm->IntMi;
                                                $adds->freq=$valpm->Freq;
                                                $adds->recNo=$valpm->RecNo;
                                                $adds->make_id=$addmk->id;
                                                $adds->model_id=$addsmod->id;
                                                $adds->engine_id=$addeng->id;
                                                $adds->year=$year;
                                                $adds->save();


                                            }
                                        }
                                    }

                                    //TSB
                                    $urlTSB = 'http://192.168.14.165:8080/sampwebsers/munch/apiservices/servicesTSBData/'.$val->MakeId.'/'.$valmk->ModelId.'/'.$year.'/'.$valmdl->Engineconfigid.'/';


                                    curl_setopt_array(
                                        $ch, array(
                                        CURLOPT_URL => $urlTSB ,
                                        CURLOPT_RETURNTRANSFER => true,     // return web page
                                        CURLOPT_HEADER         => false,    // don't return headers
                                        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
                                        CURLOPT_ENCODING       => "",       // handle all encodings
                                        CURLOPT_USERAGENT      => "spider", // who am i
                                        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
                                        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
                                        CURLOPT_TIMEOUT        => 120,      // timeout on response
                                        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
                                        CURLOPT_SSL_VERIFYPEER => 0 ,    // Disabled SSL Cert checks
                                        CURLOPT_SSL_VERIFYHOST => 0     // Disabled SSL Cert checks
                                    ));

                                    $outputTSB = curl_exec($ch);
                                    $server_outputTSB=json_decode($outputTSB);
                                    if(count($server_outputTSB)!=0){
                                        foreach($server_outputTSB as $resttsb){
                                            foreach($resttsb as $valtsb){


                                                $addtbs=new Cartsb;
                                                $addtbs->issuer=$valtsb->Issuer;
                                                $addtbs->issuedate=$valtsb->Issuedate;
                                                $addtbs->description=$valtsb->Description;
                                                $addtbs->vehicletoengineconfigid=$valtsb->Vehicletoengineconfigid;
                                                $addtbs->autosystemdescription=$valtsb->Autosystemdescription;
                                                $addtbs->type=$valtsb->Type;
                                                $addtbs->filenamepdf=$valtsb->Filenamepdf;
                                                $addtbs->manufacturernum=$valtsb->Manufacturernum;
                                                $addtbs->make_id=$addmk->id;
                                                $addtbs->model_id=$addsmod->id;
                                                $addtbs->engine_id=$addeng->id;
                                                $addtbs->year=$year;
                                                $addtbs->save();

                                                echo "TSB"; echo "<br>";

                                            }
                                        }
                                    }

                                }
                            }
                        }



                    }
                }
                } */
            }
        }
        }
      }












        exit;





        $username="tech.central";
        $password="moa650";

        $url = 'https://avenger.mightyautoparts.com/josso/signon/usernamePasswordLogin.do';
        $data = array('josso_username'=>$username,'josso_password'=>$password,'josso_cmd'=>'login','josso_back_to'=>'https://avenger.mightyautoparts.com/CVIFTabletApp/josso_security_check');

        $postData = "";
        foreach( $data as $key => $val ) {
            $postData .=$key."=".$val."&";
        }
        $post_data = rtrim($postData, "&");



        $login_url = 'https://avenger.mightyautoparts.com/josso/signon/usernamePasswordLogin.do';


//Create a curl object
        $ch = curl_init();

//Set the useragent
        $agent = $_SERVER["HTTP_USER_AGENT"];
        curl_setopt($ch, CURLOPT_USERAGENT, $agent);

//Set the URL
        curl_setopt($ch, CURLOPT_URL, $login_url );

//This is a POST query
        curl_setopt($ch, CURLOPT_POST, 1 );

//Set the post data
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);

//We want the content after the query
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);



//Follow Location redirects
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

        /*
        Set the cookie storing files
        Cookie files are necessary since we are logging and session data needs to be saved
        */

        curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookie.txt');

//Execute the action to login
        $postResult = curl_exec($ch);
        /*   print_r($postResult);*/

        //end
        exit;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_COOKIEJAR, "FileHere");
        curl_setopt($ch, CURLOPT_COOKIEFILE, "FileHere");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTP);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec ($ch);
        $url="http://avenger.mightyautoparts.com/CVIFTabletApp/munch/apiservices/servicesMakeDetails/2014/";
        $options = array(
            CURLOPT_URL => $url,     // return web page
            CURLOPT_RETURNTRANSFER => true,     // return web page
            CURLOPT_HEADER         => false,    // don't return headers
            CURLOPT_FOLLOWLOCATION => true,     // follow redirects
            CURLOPT_ENCODING       => "",       // handle all encodings
            CURLOPT_USERAGENT      => "spider", // who am i
            CURLOPT_AUTOREFERER    => true,     // set referer on redirect
            CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
            CURLOPT_TIMEOUT        => 120,      // timeout on response
            CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
            CURLOPT_SSL_VERIFYPEER => 0 ,    // Disabled SSL Cert checks
            CURLOPT_SSL_VERIFYHOST => 0     // Disabled SSL Cert checks
        );
        curl_setopt_array( $ch, $options );
        $content = curl_exec( $ch );
        $err     = curl_errno( $ch );
        $errmsg  = curl_error( $ch );
        $header  = curl_getinfo( $ch );

        $server_output = curl_exec ($ch);
        $server_output=json_decode($server_output);
        print_r($server_output);

        curl_close( $ch );

        $header['errno']   = $err;
        $header['errmsg']  = $errmsg;
        $header['content'] = $content;
        return $header;

        $server_output = curl_exec ($ch);
        $server_output=json_decode($server_output);



       $url="http://avenger.mightyautoparts.com/CVIFTabletApp/munch/apiservices/servicesMakeDetails/2014/";

//         $url ="http://localhost/mighty/public/api/v1/inspection/list/149565";
       $options = array(
           CURLOPT_RETURNTRANSFER => true,     // return web page
           CURLOPT_HEADER         => false,    // don't return headers
           CURLOPT_FOLLOWLOCATION => true,     // follow redirects
           CURLOPT_ENCODING       => "",       // handle all encodings
           CURLOPT_USERAGENT      => "spider", // who am i
           CURLOPT_AUTOREFERER    => true,     // set referer on redirect
           CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
           CURLOPT_TIMEOUT        => 120,      // timeout on response
           CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
           CURLOPT_SSL_VERIFYPEER => 0 ,    // Disabled SSL Cert checks
           CURLOPT_SSL_VERIFYHOST => 0     // Disabled SSL Cert checks
       );


       $ch      = curl_init( $url );
       curl_setopt_array( $ch, $options );
       $content = curl_exec( $ch );
       $err     = curl_errno( $ch );
       $errmsg  = curl_error( $ch );
       $header  = curl_getinfo( $ch );

       $server_output = curl_exec ($ch);
       $server_output=json_decode($server_output);
       print_r($server_output);

       curl_close( $ch );

       $header['errno']   = $err;
       $header['errmsg']  = $errmsg;
       $header['content'] = $content;
      return $header;

       exit;

       $client = new \GuzzleHttp\Client();
       $res = $client->request('GET', $url);
     //  echo $res->getStatusCode();
// 200
       echo $res->getHeaderLine('content-type');
// 'application/json; charset=utf8'
       echo $res->getBody();
         exit;
       // $url="http://localhost/mighty/public/api/v1/inspection";

       $result = $client->post($url, [
           'form_params' => [
               'josso_username' => 'tech.central',
               'josso_password'=>'moa650',
               'josso_cmd'=>'login',
               'josso_back_to'=>'https://avenger2016.mightyautoparts.com/CVIFTabletApp/josso_security_check'
           ]
       ]);


       $result = json_decode($result->getBody(), true);


       print_r($result);
       exit;


       $url = 'https://avenger.mightyautoparts.com/CVIFTabletApp/munch/apiservices/servicesMakeDetails/2014/';
       $options = array(
           CURLOPT_RETURNTRANSFER => true,     // return web page
           CURLOPT_HEADER         => false,    // don't return headers
           CURLOPT_FOLLOWLOCATION => true,     // follow redirects
           CURLOPT_ENCODING       => "",       // handle all encodings
           CURLOPT_USERAGENT      => "spider", // who am i
           CURLOPT_AUTOREFERER    => true,     // set referer on redirect
           CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
           CURLOPT_TIMEOUT        => 120,      // timeout on response
           CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
           CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
       );

       $ch      = curl_init( $url );
       curl_setopt_array( $ch, $options );


       $server_output = curl_exec ($ch);
       $server_output=json_decode($server_output);
       var_dump($server_output);
       curl_close($ch);


       /*$header['errno']   = $err;
       $header['errmsg']  = $errmsg;
       $header['content'] = $content;*/
  exit;




        $url = 'https://avenger.mightyautoparts.com/CVIFTabletApp/munch/apiservices/servicesMakeDetails/2014/';
        $data = array('josso_username'=>'tech.central','josso_password'=>'moa650','josso_cmd'=>'login','josso_back_to'=>'https://avenger2016.mightyautoparts.com/CVIFTabletApp/josso_security_check');
        $postData = "";
        foreach( $data as $key => $val ) {
            $postData .=$key."=".$val."&";
        }
        $postData = rtrim($postData, "&");


        $ch = curl_init();



        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_COOKIEJAR, "FileHere");
        curl_setopt($ch, CURLOPT_COOKIEFILE, "FileHere");
        curl_setopt($ch, CURLOPT_GET, 1);
        /*curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);*/
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTP);
        curl_exec($ch);
        $server_output = curl_exec ($ch);

//print_r(curl_exec ($ch));

        $server_output = curl_exec ($ch);
        $server_output=json_decode($server_output);
        var_dump($server_output);
        curl_close($ch);

        /*$url = 'https://avenger2016.mightyautoparts.com/josso/signon/usernamePasswordLogin.do';
        $data = array('josso_username'=>'tech.central','josso_password'=>'moa650','josso_cmd'=>'login','josso_back_to'=>'https://avenger2016.mightyautoparts.com/CVIFTabletApp/josso_security_check');
        $postData = "";
        foreach( $data as $key => $val ) {
            $postData .=$key."=".$val."&";
        }
        $postData = rtrim($postData, "&");


        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_COOKIEJAR, "FileHere");
        curl_setopt($ch, CURLOPT_COOKIEFILE, "FileHere");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTP);
        curl_exec($ch);
        $server_output = curl_exec ($ch);

//print_r(curl_exec ($ch));
        var_dump($server_output);

        curl_close($ch);*/
    }
   function home(Request $request){
       if($request->isMethod('post')) {

echo $request->authtoken;
           echo '<br><br><br><br>';

           echo $authtoken=urlencode($request->authtoken);
           //echo   htmlspecialchars($authtoken, ENT_QUOTES);
//           echo $authtoken=urlencode($authtoken);

//           exit;
//           $authtoken=htmlentities($authtoken, ENT_QUOTES);
//
//
//           echo $authtoken;
//           exit;

//          $authtoken="4D7H1xdhLGFM+A+nAcubf7AeiJqiAcla6LJx7UbcFYHNB+AylhwboKG8Ne4KcTWPtZF2hVgyZ+ebzLw+UbxJsp2HGxJSbgLkBZX1G3dVR8KwBqaBVdWT1XTqOyIm03o+n0wyYUnPDuivo9O1VHc9ifaZkxwdCj2KMfTgypytej3Cof/QNQOVA26D8ttKOpF+zHfdZh7Eq2SxyRlCO2m281yvRJzK8SXv30TmkfCB79iM7OT/C7UxWf6XaXBNxgnyS9nyrDxwmPdPqddI+WBmg7QHytVuzrHPiuH846WPLWuapgxmmjb2w1iNq9MtwXzCsINsL4cCXjVtK6rUL3AeI6Rctc+tmqnbedME4FGrm56L/mw3v6LL6ifrcLTiAHQcOIX8TMA6arGKoHvEWd1m5zLmqoZuWRs8uy89yeYQe2blUnUwTJBa93QzJuLe8I/xi9ZZ0JNXKKkB+fMF0evB4Ns2nDgsi8Gdn6LpwBf1DemsvRNXh9fjZH87nG6CyJEjKLcCbh5dcyYDcJEfKl2VEybWifiFaOmR97huhKFYjo4p2KR4s9ZJb6HhSdXq6oPVFavXkAQw0/rOs6Tkd8pqM4d6FIxgwBxViH/R8IIkDoecIeiA5yvNbQYZW/WQABoyWUIngMejpfd7CuEiSgixww==";

          // $authtoken=$authtoken=urlencode($request->authtoken);
           $key = 'Mightyauth123986';
           $iv='123986authMighty';

           echo $decryptxt=mcrypt_decrypt(MCRYPT_RIJNDAEL_128,$key,base64_decode($authtoken),MCRYPT_MODE_CBC,$iv);
           exit;



        //   $password = '3sc3RLrpd17';
           $method = 'aes-256-cbc';

// Must be exact 32 chars (256 bit)
           $password = substr(hash('sha256', $password, true), 0, 32);
           echo "Password:" . $password . "\n";

// IV must be exact 16 chars (128 bit)
          // $iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);

// av3DYGLkwBsErphcyYp+imUW4QKs19hUnFyyYcXwURU=
        //   $encrypted = base64_encode(openssl_encrypt($plaintext, $method, $password, OPENSSL_RAW_DATA, $iv));

// My secret message 1234
           $decrypted = openssl_decrypt(base64_decode($authtoken), $method, $password, OPENSSL_RAW_DATA, $iv);

           echo 'plaintext=' . $authtoken . "\n";echo "<br>";
           echo 'cipher=' . $method . "\n";echo "<br>";
        //   echo 'encrypted to: ' . $encrypted . "\n";
           echo 'decrypted to: ' . $decrypted . "\n\n";echo "<br>";
           exit;
       }

         $formdetails=$this->formdetails->getFormdetails();
         return view('mighty.home')->with(array('formdetails'=>$formdetails));
     }
    function createTemplate101(){
        $templatecomponents=$this->templatecomponents->getTemplatecomponents();
        return view('mighty.createTemplate101')->with(array("templatecomponents"=>$templatecomponents));
    }
    protected function pkcs5_pad($text) {
        $size = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
        $pad = $size - (strlen($text) % $size);
        return $text . str_repeat(chr($pad), $pad);
    }

    protected function pkcs5_unpad($text) {
        $pad = ord($text{strlen($text) - 1});
        if ($pad > strlen($text)) return false;
        if (strspn($text, $text{strlen($text) - 1}, strlen($text) - $pad) != $pad) {
            return false;
        }
        return substr($text, 0, -1 * $pad);
    }
    function template101(){

        return view('mighty.template101');
    }

    function createTemplate102(){
        return view('mighty.createTemplate102');
    }
    function createTemplate103(){
        return view('mighty.createTemplate103');
    }
    function createTemplate104(){
        return view('mighty.createTemplate104');
    }
    function createTemplate105(){
        return view('mighty.createTemplate105');
    }
     function cvif(){



                    /*
    $data = array();
    $name="Lenin";
   $data['result']='success';
   $data['message']='User Logged in successfully';
   $data['name']=$name;
   return Response::json($data,200);
                                      */
         	 return view('mighty.cvif');
    }
    function cvifTemplate(){
       $formdetails=$this->formdetails->getFormdetails();

        if(count($formdetails)!=0){
            return redirect('/cvif/template/'.$formdetails[0]->uuid.'');
        }
        else{

          return redirect('/cvif/create-template');
        }
              return view('mighty.cvifTemplate');
    }

    function createTemplate(Request $request){
if($request->isMethod('post'))
{

    $form_name=$request->form_name;
    $form_desc=$request->form_desc;
    $form_content=$request->formToken;


    $fileFlag=0;

    $addform=new Formdetails;
    $addform->form_desc=$form_desc;
    $addform->form_name=$form_name;
    $addform->form_content=$form_content;
    $addform->uuid=Uuid::generate()->string;
    $addform->user_id=Auth::user()->id;
    $addform->imageType=$request->imageType;
    $addform->save();
    $form_id=$addform->id;
    $formToken=$request->formToken;
    $ftk_array=json_decode($formToken);
        foreach ($ftk_array as $pages) {
            $res_array=$pages;
            foreach ($res_array as $res) {

            $res_result=$res;
            $remove=count($res_result)-1;
            unset($res_result[$remove]);
                $api_set=array();
                $api_row=0;
                $api_rowflag=0;

                    foreach ($res_result as $key=> $rows) {
                          $row=$key;

                        $api_col=0;
                            foreach ($rows as $index=>$cols) {
                              $col=$index;

                  $addfrmfild=new Formfields;
                  $addfrmfild->form_id=$form_id;
                  $addfrmfild->page=0;
                  $addfrmfild->row=$row;
                  $addfrmfild->col=$col;
                  if($cols->fieldid==11 || $cols->fieldid==26 || $cols->fieldid==27 || $cols->fieldid==28 || $cols->fieldid==29 || $cols->fieldid==31){
                        //image upload start
                      $imagefile = $request->file($cols->filename);
                  if($imagefile!='')
{

                         // if(is_array($imagefile) && !empty($imagefile[$fileFlag]) && isset($imagefile[$fileFlag])){

						 	$i = 0;

$destination =public_path().'/mighty/images/template/';
                                                                $newname = str_random(5);
								$ext = $imagefile->getClientOriginalExtension();
								$filename = $newname.'-original.'.$ext;
								$newFilename = $newname.'.'.$ext;
                                                                if($imagefile->move($destination, $filename)){
									copy($destination . $filename, $destination . $newFilename);
                                                                    if(isset($cols->width) && $cols->width!='' && $cols->height!=''){
                                                                       /* $img = Image::make($destination . $newFilename)->resize($cols->width,$cols->height);
                                                                        $img->save($destination . $newFilename);*/
                                                                    }




						 		     $addfrmfild->file_path=$newFilename;
                                                                          $cols->filepath = $newFilename;
                                                                          $fileFlag++;
								}
					//	}
                                                else{
                                                $addfrmfild->file_path='';
                                                }
} else{
    $addfrmfild->file_path='';
}



                      //image upload end

                     }
                     else{
    $addfrmfild->file_path='';
}
                                // tire components start
                                if(($cols->fieldid==28 || $cols->fieldid==29) && $request->file($cols->imagesecond)){



                                    //image upload start
                                    $imagefile = $request->file($cols->imagesecond);
                                    if($imagefile!='')
                                    {

                                        // if(is_array($imagefile) && !empty($imagefile[$fileFlag]) && isset($imagefile[$fileFlag])){

                                        $i = 0;

                                        $destination =public_path().'/mighty/images/template/';
                                        $newname = str_random(5);
                                        $ext = $imagefile->getClientOriginalExtension();
                                        $filename = $newname.'-original.'.$ext;
                                        $newFilename = $newname.'.'.$ext;
                                        if($imagefile->move($destination, $filename)){
                                            copy($destination . $filename, $destination . $newFilename);
                                            $addfrmfild->file_path=$newFilename;
                                            $cols->imgsecondpath = $newFilename;
                                            $fileFlag++;
                                        }
                                        //	}
                                        else{
                                            $addfrmfild->file_path='';
                                        }
                                    } else{
                                        $addfrmfild->file_path='';
                                    }



                                    //image upload end

                                }
                                else{
                                    $addfrmfild->file_path='';
                                }
                                // tire components end
                  $addfrmfild->field_id=$cols->fieldid;
                  $addfrmfild->question=$cols->title;
                  $addfrmfild->save();
                  $form_fields_id=$addfrmfild->id;

                  $cols->formfieldid = $form_fields_id;

                                  if(isset($cols->choices)){
                                    $choice_array=$cols->choices;
                                            if(count($choice_array)!=0)    {
                                      foreach ($choice_array as $chres) {
                  $addfo=new Formoptions;
                  $addfo->form_fields_id=$form_fields_id;
                  $addfo->option_name=$chres->title;
                  $addfo->option_value=$chres->title;
                  $addfo->save();
                                      }
                                            }
                                  }
                                if($cols->fieldid!=18 && $cols->fieldid!=17 && $cols->fieldid!=11 && $cols->fieldid!=1 && $cols->fieldid!=20 && $cols->fieldid!=19 && $cols->fieldid!=30 && $cols->fieldid!=33 && $cols->fieldid!=32){
                                    if($cols->fieldid==26 || $cols->fieldid==23 || $cols->fieldid==27 || $cols->fieldid==28 || $cols->fieldid==29  || $cols->fieldid==31){
                                        $api_row++;
                                        $api_col=0;
                                    }
                                    else{

                                        $api_col++;
                                    }
                                    $api_rowflag=0;
                                    $api_set[$api_row][$api_col]=$cols;
                                }else{
                                    $api_rowflag=1;
                                }
                          }
                        if($api_rowflag==0){
                            $api_row++;
                        }
                    }

            }

    }
     $json = json_encode($ftk_array) ;
    $api_set = json_encode($api_set) ;
    $updform=Formdetails::find($form_id);
    $updform->form_content=$json;
    $updform->form_api=$api_set;
    $updform->save();

    return redirect('cvif/template/view/'.$updform->uuid)->with('true_msg','Successfully created');

   // return redirect('/cvif/create-template')->with('true_msg','Successfully created');
}

      /*
      $users = User::orderBy('users.id', 'desc')
                ->select('users.id')->first();
                return $users;
                */
         	 return view('mighty.createTemplate');
    }
    function templates($id,Request $request){
        /*
        $data='';
$pdf = \App::make('dompdf.wrapper');
$data.='<html>';
$data.='<head>';
$data.='<title>:: CVIF ::</title>';
        $data.='<style type="text/css"></style>';
        $data.='</head>';
        $data.='<body>';
        $data.='<br clear="all"/>';
$data.='<p>(SALIM NAMATH)</p>';
$data.='</body>';
$data.='</html>';
$pdf->loadHTML($data);
return $pdf->stream();
        */

        if($request->isMethod('post'))
        {

            //return Redirect::back()->with('true_msg','Work In Progress');



            $formdets=$this->formdetails->getFormdetails($id);
            $id=$formdets->id;
            $form_name=$request->form_name;
            $form_desc=$request->form_desc;
            $form_content=$request->formToken;


            // delete exits data for update ((start))
            $formfiles=Formfields::where('form_id',$id)->get();
            foreach($formfiles as $res){
                $formopts=Formoptions::where('form_fields_id',$res->id)->delete();
            }
            $formfilesDel=Formfields::where('form_id',$id)->delete();
            // delete exits data for update ((End))
            $imagefile = $request->file('file_name');
            $fileFlag=0;

            $addform=Formdetails::find($id);
            $addform->form_desc=$form_desc;
            $addform->form_name=$form_name;
            $addform->form_content=$form_content;
            $addform->delete_status=0;
            $addform->imageType=$request->imageType;
            $addform->save();
            $form_id=$addform->id;

            $formToken=$request->formToken;
            $ftk_array=json_decode($formToken);
            foreach ($ftk_array as $pages) {
                $res_array=$pages;
                foreach ($res_array as $res) {

                    $res_result=$res;
                    $remove=count($res_result)-1;
                    unset($res_result[$remove]);
                    $api_set=array();
                    $api_row=0;
                    $api_rowflag=0;
                    foreach ($res_result as $key=> $rows) {
                        $row=$key;
                        $api_col=0;
                        foreach ($rows as $index=>$cols) {
                            $col=$index;


                            $addfrmfild=new Formfields;
                            $addfrmfild->form_id=$form_id;
                            $addfrmfild->page=0;
                            $addfrmfild->row=$row;
                            $addfrmfild->col=$col;

                            if($cols->fieldid==11 || $cols->fieldid==26 || $cols->fieldid==27 || $cols->fieldid==28 || $cols->fieldid==29 || $cols->fieldid==31){
                                //image upload start
                                $imagefile = $request->file($cols->filename);
                                if($imagefile!='')
                                {

                                    // if(is_array($imagefile) && !empty($imagefile[$fileFlag]) && isset($imagefile[$fileFlag])){

                                    $i = 0;

                                    $destination =public_path().'/mighty/images/template/';
                                    $newname = str_random(5);
                                    $ext = $imagefile->getClientOriginalExtension();
                                    $filename = $newname.'-original.'.$ext;
                                    $newFilename = $newname.'.'.$ext;
                                    if($imagefile->move($destination, $filename)){
                                        copy($destination . $filename, $destination . $newFilename);
                                        if(isset($cols->width) && $cols->width!='' && $cols->height!=''){
                                          /*  $img = Image::make($destination . $newFilename)->resize($cols->width,$cols->height);
                                            $img->save($destination . $newFilename);*/
                                        }
                                        $addfrmfild->file_path=$newFilename;
                                        $cols->filepath = $newFilename;
                                        $fileFlag++;
                                    }
                                    //	}
                                    else{
                                        $addfrmfild->file_path=$cols->filepath;
                                    }
                                } else{
                                    $addfrmfild->file_path=$cols->filepath;
                                }



                                //image upload end

                            }
                            else{
                                $addfrmfild->file_path='';
                            }
                            // tire components start
                            if(($cols->fieldid==28 || $cols->fieldid==29) && $request->file($cols->imagesecond)){



                                //image upload start
                                $imagefile = $request->file($cols->imagesecond);
                                if($imagefile!='')
                                {

                                    // if(is_array($imagefile) && !empty($imagefile[$fileFlag]) && isset($imagefile[$fileFlag])){

                                    $i = 0;

                                    $destination =public_path().'/mighty/images/template/';
                                    $newname = str_random(5);
                                    $ext = $imagefile->getClientOriginalExtension();
                                    $filename = $newname.'-original.'.$ext;
                                    $newFilename = $newname.'.'.$ext;
                                    if($imagefile->move($destination, $filename)){
                                        copy($destination . $filename, $destination . $newFilename);
                                        $addfrmfild->file_path=$newFilename;
                                        $cols->imgsecondpath = $newFilename;
                                        $fileFlag++;
                                    }
                                    //	}
                                    else{
                                        $addfrmfild->file_path=$cols->imgsecondpath;
                                    }
                                } else{
                                    $addfrmfild->file_path=$cols->imgsecondpath;
                                }



                                //image upload end

                            }
                            else{
                                $addfrmfild->file_path='';
                            }
                            // tire components end
                            $addfrmfild->field_id=$cols->fieldid;
                            $addfrmfild->question=(isset($cols->title) && !empty($cols->title))
                                ? $cols->title : '';

                            $addfrmfild->save();
                            $form_fields_id=$addfrmfild->id;

                            $cols->formfieldid = $form_fields_id;

                            if(isset($cols->choices)){
                                $choice_array=$cols->choices;

                                foreach ($choice_array as $chres) {
                                    $addfo=new Formoptions;
                                    $addfo->form_fields_id=$form_fields_id;
                                    $addfo->option_name=$chres->title;
                                    $addfo->option_value=$chres->title;
                                    $addfo->save();
                                }
                            }

    if($cols->fieldid!=18 && $cols->fieldid!=17 && $cols->fieldid!=11 && $cols->fieldid!=1 && $cols->fieldid!=20 && $cols->fieldid!=19 && $cols->fieldid!=30 && $cols->fieldid!=33  && $cols->fieldid!=32){
        if($cols->fieldid==26 || $cols->fieldid==23 || $cols->fieldid==27 || $cols->fieldid==28 || $cols->fieldid==29  || $cols->fieldid==31){
            $api_row++;
            $api_col=0;
        }
        else{

            $api_col++;
        }
        $api_rowflag=0;
        $api_set[$api_row][$api_col]=$cols;
    }else{
        $api_rowflag=1;
    }


                        }
                        if($api_rowflag==0){
                            $api_row++;
                        }

                    }

                }

            }
            $json = json_encode($ftk_array) ;
            $api_set = json_encode($api_set) ;

            $updform=Formdetails::find($form_id);
            $updform->form_content=$json;
            $updform->form_api=$api_set;
            $updform->save();
            return redirect('cvif/template/view/'.$updform->uuid)->with('true_msg','Successfully updated');

            //return Redirect::back()->with('true_msg','Successfully updated');

        }
        $formdetails=$this->formdetails->getFormdetails($id);
      /*  $pageContent=array();
        $genericElements=array();
        $content=array();

        $ftk_array=json_decode($formdetails->form_content);
        $ftk_array=$ftk_array->fields;
        $pageContent=array();

        foreach($ftk_array[0] as $key=>$res){
            if($key>=3 && $key<=10){

                $content['genericElements'][]=$res;
            }
        }
        $pageContent['componentId']=1;
        $pageContent['content'][]=$content;
        $data=array();
        $data['pageContent']=$pageContent;
          echo $json = json_encode($data) ;
        exit;

        $pageContent=array();
        $pageContent['componentId']=1;

        $content=array();
        $formelement=array();
        $formelement['fieldId']=3;
        $formelement['formFieldId']=3;
        $formelement['title']='ch';
        $formelement['choice']=array();

        $content['formElement'][0]=$formelement;
        $content['formElement'][1]=$formelement;
        $pageContent['content'][]=$content;
        $pageContent['content'][]=$content;
        return $pageContent;

        exit;*/

         $fd_alls=$this->formdetails->getFormdetails();
       
        //  DB::enableQueryLog();
        $templatecomponents=$this->templatecomponents->getTemplatecomponents();
        //    return   $queries = DB::getQueryLog();



        return view('mighty.templates')->with(array("templatecomponents"=>$templatecomponents,"formdetails"=>$formdetails,"fd_alls"=>$fd_alls));
    }
    function templatespreview($id,Request $request){

        if($request->isMethod('post'))
        {
            $formdets=$this->formdetails->getFormdetails($id);
            $id=$formdets->id;
            $form_name=$request->form_name;
            $form_desc=$request->form_desc;
            $form_content=$request->formToken;


            // delete exits data for update ((start))
            $formfiles=Formfields::where('form_id',$id)->get();
            foreach($formfiles as $res){
                $formopts=Formoptions::where('form_fields_id',$res->id)->delete();
            }
            $formfilesDel=Formfields::where('form_id',$id)->delete();
            // delete exits data for update ((End))
            $imagefile = $request->file('file_name');
            $fileFlag=0;

            $addform=Formdetails::find($id);
            $addform->form_desc=$form_desc;
            $addform->form_name=$form_name;
            $addform->form_content=$form_content;
            $addform->delete_status=0;
            $addform->imageType=$request->imageType;
            $addform->save();
            $form_id=$addform->id;

            $formToken=$request->formToken;
            $ftk_array=json_decode($formToken);
            foreach ($ftk_array as $pages) {
                $res_array=$pages;
                foreach ($res_array as $res) {

                    $res_result=$res;
                    $remove=count($res_result)-1;
                    unset($res_result[$remove]);

                    foreach ($res_result as $key=> $rows) {
                        $row=$key;
                        foreach ($rows as $index=>$cols) {
                            $col=$index;


                            $addfrmfild=new Formfields;
                            $addfrmfild->form_id=$form_id;
                            $addfrmfild->page=0;
                            $addfrmfild->row=$row;
                            $addfrmfild->col=$col;

                            if($cols->fieldid==11 || $cols->fieldid==26 || $cols->fieldid==27 || $cols->fieldid==28 || $cols->fieldid==29 || $cols->fieldid==31){
                                //image upload start
                                $imagefile = $request->file($cols->filename);
                                if($imagefile!='')
                                {

                                    // if(is_array($imagefile) && !empty($imagefile[$fileFlag]) && isset($imagefile[$fileFlag])){

                                    $i = 0;

                                    $destination =public_path().'/mighty/images/template/';
                                    $newname = str_random(5);
                                    $ext = $imagefile->getClientOriginalExtension();
                                    $filename = $newname.'-original.'.$ext;
                                    $newFilename = $newname.'.'.$ext;
                                    if($imagefile->move($destination, $filename)){
                                        copy($destination . $filename, $destination . $newFilename);
                                        if(isset($cols->width) && $cols->width!='' && $cols->height!=''){
                                            /*$img = Image::make($destination . $newFilename)->resize($cols->width,$cols->height);
                                            $img->save($destination . $newFilename);*/
                                        }
                                        $addfrmfild->file_path=$newFilename;
                                        $cols->filepath = $newFilename;
                                        $fileFlag++;
                                    }
                                    //	}
                                    else{
                                        $addfrmfild->file_path=$cols->filepath;
                                    }
                                } else{
                                    $addfrmfild->file_path=$cols->filepath;
                                }



                                //image upload end

                            }
                            else{
                                $addfrmfild->file_path='';
                            }
                            // tire components start
                            if(($cols->fieldid==28 || $cols->fieldid==29) && $request->file($cols->imagesecond)){



                                //image upload start
                                $imagefile = $request->file($cols->imagesecond);
                                if($imagefile!='')
                                {

                                    // if(is_array($imagefile) && !empty($imagefile[$fileFlag]) && isset($imagefile[$fileFlag])){

                                    $i = 0;

                                    $destination =public_path().'/mighty/images/template/';
                                    $newname = str_random(5);
                                    $ext = $imagefile->getClientOriginalExtension();
                                    $filename = $newname.'-original.'.$ext;
                                    $newFilename = $newname.'.'.$ext;
                                    if($imagefile->move($destination, $filename)){
                                        copy($destination . $filename, $destination . $newFilename);
                                        $addfrmfild->file_path=$newFilename;
                                        $cols->imgsecondpath = $newFilename;
                                        $fileFlag++;
                                    }
                                    //	}
                                    else{
                                        $addfrmfild->file_path=$cols->imgsecondpath;
                                    }
                                } else{
                                    $addfrmfild->file_path=$cols->imgsecondpath;
                                }



                                //image upload end

                            }
                            else{
                                $addfrmfild->file_path='';
                            }
                            // tire components end
                            $addfrmfild->field_id=$cols->fieldid;
                            $addfrmfild->question=$cols->title;
                            $addfrmfild->save();
                            $form_fields_id=$addfrmfild->id;

                            $cols->formfieldid = $form_fields_id;

                            if(isset($cols->choices)){
                                $choice_array=$cols->choices;

                                foreach ($choice_array as $chres) {
                                    $addfo=new Formoptions;
                                    $addfo->form_fields_id=$form_fields_id;
                                    $addfo->option_name=$chres->title;
                                    $addfo->option_value=$chres->title;
                                    $addfo->save();
                                }
                            }

                        }
                    }

                }

            }
            $json = json_encode($ftk_array) ;
            $updform=Formdetails::find($form_id);
            $updform->form_content=$json;
            $updform->save();

            return redirect('cvif/template/view/'.$updform->uuid)->with('true_msg','Successfully updated');


            //return Redirect::back()->with('true_msg','Successfully updated');

        }

        $formdetails=$this->previewformdetails->getFormdetailsbyuuid($id);
        $fd_alls=$this->previewformdetails->getFormdetails();

        //  DB::enableQueryLog();
        $templatecomponents=$this->templatecomponents->getTemplatecomponents();
        //    return   $queries = DB::getQueryLog();


        //    return view('mighty.templatespreview')->with(array("templatecomponents"=>$templatecomponents,"formdetails"=>$formdetails,"fd_alls"=>$fd_alls));
         return view('mighty.previewTemplates')->with(array("templatecomponents"=>$templatecomponents,"formdetails"=>$formdetails,"fd_alls"=>$fd_alls));


    }
    function templatesEditpreview($id,Request $request){

        if($request->isMethod('post'))
        {
            $formdets=$this->formdetails->getFormdetails($id);
            $id=$formdets->id;
            $form_name=$request->form_name;
            $form_desc=$request->form_desc;
            $form_content=$request->formToken;


            // delete exits data for update ((start))
            $formfiles=Formfields::where('form_id',$id)->get();
            foreach($formfiles as $res){
                $formopts=Formoptions::where('form_fields_id',$res->id)->delete();
            }
            $formfilesDel=Formfields::where('form_id',$id)->delete();
            // delete exits data for update ((End))
            $imagefile = $request->file('file_name');
            $fileFlag=0;

            $addform=Formdetails::find($id);
            $addform->form_desc=$form_desc;
            $addform->form_name=$form_name;
            $addform->form_content=$form_content;
            $addform->delete_status=0;
            $addform->imageType=$request->imageType;
            $addform->save();
            $form_id=$addform->id;

            $formToken=$request->formToken;
            $ftk_array=json_decode($formToken);
            foreach ($ftk_array as $pages) {
                $res_array=$pages;
                foreach ($res_array as $res) {

                    $res_result=$res;
                    $remove=count($res_result)-1;
                    unset($res_result[$remove]);

                    foreach ($res_result as $key=> $rows) {
                        $row=$key;
                        foreach ($rows as $index=>$cols) {
                            $col=$index;


                            $addfrmfild=new Formfields;
                            $addfrmfild->form_id=$form_id;
                            $addfrmfild->page=0;
                            $addfrmfild->row=$row;
                            $addfrmfild->col=$col;

                            if($cols->fieldid==11 || $cols->fieldid==26 || $cols->fieldid==27 || $cols->fieldid==28 || $cols->fieldid==29 || $cols->fieldid==31){
                                //image upload start
                                $imagefile = $request->file($cols->filename);
                                if($imagefile!='')
                                {

                                    // if(is_array($imagefile) && !empty($imagefile[$fileFlag]) && isset($imagefile[$fileFlag])){

                                    $i = 0;

                                    $destination =public_path().'/mighty/images/template/';
                                    $newname = str_random(5);
                                    $ext = $imagefile->getClientOriginalExtension();
                                    $filename = $newname.'-original.'.$ext;
                                    $newFilename = $newname.'.'.$ext;
                                    if($imagefile->move($destination, $filename)){
                                        copy($destination . $filename, $destination . $newFilename);
                                        if(isset($cols->width) && $cols->width!='' && $cols->height!=''){
                                            /*$img = Image::make($destination . $newFilename)->resize($cols->width,$cols->height);
                                            $img->save($destination . $newFilename);*/
                                        }
                                        $addfrmfild->file_path=$newFilename;
                                        $cols->filepath = $newFilename;
                                        $fileFlag++;
                                    }
                                    //	}
                                    else{
                                        $addfrmfild->file_path=$cols->filepath;
                                    }
                                } else{
                                    $addfrmfild->file_path=$cols->filepath;
                                }



                                //image upload end

                            }
                            else{
                                $addfrmfild->file_path='';
                            }
                            // tire components start
                            if(($cols->fieldid==28 || $cols->fieldid==29) && $request->file($cols->imagesecond)){



                                //image upload start
                                $imagefile = $request->file($cols->imagesecond);
                                if($imagefile!='')
                                {

                                    // if(is_array($imagefile) && !empty($imagefile[$fileFlag]) && isset($imagefile[$fileFlag])){

                                    $i = 0;

                                    $destination =public_path().'/mighty/images/template/';
                                    $newname = str_random(5);
                                    $ext = $imagefile->getClientOriginalExtension();
                                    $filename = $newname.'-original.'.$ext;
                                    $newFilename = $newname.'.'.$ext;
                                    if($imagefile->move($destination, $filename)){
                                        copy($destination . $filename, $destination . $newFilename);
                                        $addfrmfild->file_path=$newFilename;
                                        $cols->imgsecondpath = $newFilename;
                                        $fileFlag++;
                                    }
                                    //	}
                                    else{
                                        $addfrmfild->file_path=$cols->imgsecondpath;
                                    }
                                } else{
                                    $addfrmfild->file_path=$cols->imgsecondpath;
                                }



                                //image upload end

                            }
                            else{
                                $addfrmfild->file_path='';
                            }
                            // tire components end
                            $addfrmfild->field_id=$cols->fieldid;
                            $addfrmfild->question=$cols->title;
                            $addfrmfild->save();
                            $form_fields_id=$addfrmfild->id;

                            $cols->formfieldid = $form_fields_id;

                            if(isset($cols->choices)){
                                $choice_array=$cols->choices;

                                foreach ($choice_array as $chres) {
                                    $addfo=new Formoptions;
                                    $addfo->form_fields_id=$form_fields_id;
                                    $addfo->option_name=$chres->title;
                                    $addfo->option_value=$chres->title;
                                    $addfo->save();
                                }
                            }

                        }
                    }

                }

            }
            $json = json_encode($ftk_array) ;
            $updform=Formdetails::find($form_id);
            $updform->form_content=$json;
            $updform->save();

            return redirect('cvif/template/view/'.$updform->uuid)->with('true_msg','Successfully updated');


            //return Redirect::back()->with('true_msg','Successfully updated');

        }

        $formdetails=$this->previewformdetails->getFormdetailsbyuuid($id);
        $fd_alls=$this->previewformdetails->getFormdetails();

        //  DB::enableQueryLog();
        $templatecomponents=$this->templatecomponents->getTemplatecomponents();
        //    return   $queries = DB::getQueryLog();


       return view('mighty.templatespreview')->with(array("templatecomponents"=>$templatecomponents,"formdetails"=>$formdetails,"fd_alls"=>$fd_alls));
        //    return view('mighty.previewTemplates')->with(array("templatecomponents"=>$templatecomponents,"formdetails"=>$formdetails,"fd_alls"=>$fd_alls));


    }
    function previewtemplates(Request $request){

        if($request->isMethod('post')) {

            //return Redirect::back()->with('true_msg','Work In Progress');
            $uuid = $request->uuid;

            $form_name = $request->form_name;
            $form_desc = $request->form_desc;
            $form_content = $request->formToken;


            if($uuid==0){
                $formdets=new Formdetails;
                $formdets->form_desc=$form_desc;
                $formdets->form_name=$form_name;
                $formdets->form_content=$form_content;
                $formdets->delete_status=1;
                $formdets->uuid=Uuid::generate()->string;
                $formdets->imageType=$request->imageType;
                $formdets->save();
                $form_id=$formdets->id;
                $uuid= $formdets->uuid;
            }
            $formdets = $this->formdetails->getFormdetails($uuid);
            $id = $formdets->id;


            $previewformdets = $this->previewformdetails->getFormdetails($id);
            if (count($previewformdets) != 0){
                // delete exits data for update ((start))
                $formfiles = Previewformfields::where('form_id', $previewformdets->id)->get();
            foreach ($formfiles as $res) {
                $formopts = Previewformoptions::where('form_fields_id', $res->id)->delete();
            }
            $formfilesDel = Previewformfields::where('form_id', $id)->delete();
            }
            // delete exits data for update ((End))
            $imagefile = $request->file('file_name');
            $fileFlag=0;
            if (count($previewformdets) != 0){
                $addform=Previewformdetails::find($previewformdets->id);
            }else{
                $addform=new Previewformdetails;
                $addform->form_id=$id;
                $addform->uuid=$formdets->uuid;
            }

            $addform->form_desc=$form_desc;
            $addform->form_name=$form_name;
            $addform->form_content=$form_content;
            $addform->imageType=$request->imageType;
            $addform->save();
            $form_id=$addform->id;

            $formToken=$request->formToken;
            $ftk_array=json_decode($formToken);
            foreach ($ftk_array as $pages) {
                $res_array=$pages;
                foreach ($res_array as $res) {

                    $res_result=$res;
                    $remove=count($res_result)-1;
                    unset($res_result[$remove]);

                    foreach ($res_result as $key=> $rows) {
                        $row=$key;
                        foreach ($rows as $index=>$cols) {
                            $col=$index;


                            $addfrmfild=new Previewformfields;
                            $addfrmfild->form_id=$form_id;
                            $addfrmfild->page=0;
                            $addfrmfild->row=$row;
                            $addfrmfild->col=$col;

                            if($cols->fieldid==11 || $cols->fieldid==26 || $cols->fieldid==27 || $cols->fieldid==28 || $cols->fieldid==29 || $cols->fieldid==31){
                                //image upload start
                                $imagefile = $request->file($cols->filename);
                                if($imagefile!='')
                                {

                                    // if(is_array($imagefile) && !empty($imagefile[$fileFlag]) && isset($imagefile[$fileFlag])){

                                    $i = 0;

                                    $destination =public_path().'/mighty/images/template/';
                                    $newname = str_random(5);
                                    $ext = $imagefile->getClientOriginalExtension();
                                    $filename = $newname.'-original.'.$ext;
                                    $newFilename = $newname.'.'.$ext;
                                    if($imagefile->move($destination, $filename)){
                                        copy($destination . $filename, $destination . $newFilename);
                                        $addfrmfild->file_path=$newFilename;
                                        $cols->filepath = $newFilename;
                                        $fileFlag++;
                                    }
                                    //	}
                                    else{
                                        $addfrmfild->file_path=$cols->filepath;
                                    }
                                } else{
                                    $addfrmfild->file_path=$cols->filepath;
                                }



                                //image upload end

                            }
                            else{
                                $addfrmfild->file_path='';
                            }
                            // tire components start
                            if(($cols->fieldid==28 || $cols->fieldid==29) && $request->file($cols->imagesecond)){



                                //image upload start
                                $imagefile = $request->file($cols->imagesecond);
                                if($imagefile!='')
                                {

                                    // if(is_array($imagefile) && !empty($imagefile[$fileFlag]) && isset($imagefile[$fileFlag])){

                                    $i = 0;

                                    $destination =public_path().'/mighty/images/template/';
                                    $newname = str_random(5);
                                    $ext = $imagefile->getClientOriginalExtension();
                                    $filename = $newname.'-original.'.$ext;
                                    $newFilename = $newname.'.'.$ext;
                                    if($imagefile->move($destination, $filename)){
                                        copy($destination . $filename, $destination . $newFilename);
                                        $addfrmfild->file_path=$newFilename;
                                        $cols->imgsecondpath = $newFilename;
                                        $fileFlag++;
                                    }
                                    //	}
                                    else{
                                        $addfrmfild->file_path=$cols->imgsecondpath;
                                    }
                                } else{
                                    $addfrmfild->file_path=$cols->imgsecondpath;
                                }



                                //image upload end

                            }
                            else{
                                $addfrmfild->file_path='';
                            }
                            // tire components end
                            $addfrmfild->field_id=$cols->fieldid;
                            $addfrmfild->question=$cols->title;
                            $addfrmfild->save();
                            $form_fields_id=$addfrmfild->id;

                            $cols->formfieldid = $form_fields_id;

                            if(isset($cols->choices)){
                                $choice_array=$cols->choices;

                                foreach ($choice_array as $chres) {
                                    $addfo=new Previewformoptions;
                                    $addfo->form_fields_id=$form_fields_id;
                                    $addfo->option_name=$chres->title;
                                    $addfo->option_value=$chres->title;
                                    $addfo->save();
                                }
                            }

                        }
                    }

                }

            }
            $json = json_encode($ftk_array) ;
            $updform=Previewformdetails::find($form_id);
            $updform->form_content=$json;
            $updform->save();
            return redirect('cvif/template/preview/'.$updform->uuid);

        }



        return view('mighty.templates')->with(array("templatecomponents"=>$templatecomponents,"formdetails"=>$formdetails,"fd_alls"=>$fd_alls));
    }
    function viewTemplates($id,Request $request){
    // $filename="http://localhost/mighty/public/mighty/images/template/svPzW.png";
  //   $size = getimagesize($filename);
  //   echo($size[0]);

        $formdetails=$this->formdetails->getFormdetails($id);
        $fd_alls=$this->formdetails->getFormdetails();
        $templatecomponents=$this->templatecomponents->getTemplatecomponents();

        return view('mighty.viewTemplates')->with(array("templatecomponents"=>$templatecomponents,"formdetails"=>$formdetails,"fd_alls"=>$fd_alls));
    }
    function generatePdf($id){


        $formdetails=$this->formdetails->getFormdetails($id);
        $data['formdetails'] = $formdetails;
        $pdf = \App::make('dompdf.wrapper');

         $view =  \View::make('mighty.generatePdf', compact('formdetails'))->render();
        // echo $view;exit;
        $pdf = \PDF::loadView('mighty.generatePdf',$data);

        return $pdf->stream('Report.pdf');
    }

    // Mighty Assist start
    function setActiveForm(Request $request){

        if($request->isMethod('post')) {
            $form_name = $request->form_name;
             $forms=Formdetails::find($form_name);
            $apiform=json_decode($forms->form_api,true);
       if(count($apiform)==0){
           return Redirect::back()->with('error_msg','This form does not contain Mighty components so can\'t set as active');
       }

            $usdets=Usersdetails::where('user_id',Auth::user()->id)->count();

            if($usdets==0){
                $add=new Usersdetails;
                $add->user_id=Auth::user()->id;
                $add->template_id=$form_name;
                $add->save();
            }else{
                $updrform=Usersdetails::where('user_id',Auth::user()->id)
                    ->update(['template_id' => $form_name]);
            }

            return Redirect::back()->with('true_msg','Successfully updated');

        }else{
            $formdetails=$this->formdetails->getFormdetails();
            $usdets=Usersdetails::where('user_id',Auth::user()->id)->first();
            if(count($usdets)==0){
                $settemplate=0;
            }else{
                $settemplate=$usdets->template_id;
            }
            return view('mighty.setActiveForm')->with(array("formdetails"=>$formdetails,"settemplate"=>$settemplate));
        }
    }
    function setActiveServices(Request $request){

        if($request->isMethod('post')) {
           $service_name = $request->service_name;
          //  $updrseract=Services::whereIn('id', $service_name)->update(['active_service' => 1]);
           // $updrserdea=Services::whereNotIn('id', $service_name)->update(['active_service' => 0]);

           $service_name =$request->service_name;
            $service_name = implode (",", $service_name);
            $usdets=Usersdetails::where('user_id',Auth::user()->id)->count();

            if($usdets==0){
                $add=new Usersdetails;
                $add->user_id=Auth::user()->id;
                $add->service_id=$service_name;
                $add->save();
            }else{
                $updrform=Usersdetails::where('user_id',Auth::user()->id)
                    ->update(['service_id' => $service_name]);
            }

            return Redirect::back()->with('true_msg','Successfully updated');

        }else{
            $services=$this->services->getServices();
            $usdets=Usersdetails::where('user_id',Auth::user()->id)->first();
            if(count($usdets)==0){
                $service_id=0;
            }else{
                $service_id=$usdets->service_id;
            }
            return view('mighty.setActiveServices')->with(array("services"=>$services,"active_services"=>$service_id));
        }
    }
    function viewServices(){
         $services=$this->services->getActiveServices();
        return view('mighty.viewServices')->with(array("services"=>$services));
    }
    function editServices($id,Request $request){

        if($request->isMethod('post')) {


            $allowed    = array('jpg','JPG','jpeg','JPEG','png','PNG','gif','GIF');
            $error = 0;

            $ucount = $request->blockcount;
            for($u=1; $u<=$ucount; $u++) {
                $block_name = 'blockName' . $u;
                $image = 'image' . $u;
                if(isset($request->$block_name)) {
                    $block_name = $request->$block_name;

                    if (null !== $request->file($image)) {
                        $images = $request->file($image);

                        $extension  = $images->getClientOriginalExtension();
                        if(!in_array($extension,$allowed))
                        {
                            $error = 1;
                        }
                        $imagedata = getimagesize($images);
                        $width = $imagedata[0];
                        $height = $imagedata[1];
                        if($width!=1915 || $height!=1071){
                            //$error = 1;
                        }
                    }

                }
            }

            if($error==1){
                return Redirect::back()->withInput()->with('error_msg','Please upload valid file.');
            }


            $name = $request->name;
            $description = $request->description;

            $upd=services::find($id);
            $upd->name=$name;
            $upd->description=$description;
            $upd->save();

            $ucount = $request->blockcount;
            for($u=1; $u<=$ucount; $u++) {
                $block_name = 'blockName' . $u;
                if(isset($request->$block_name)){
                    $block_name = $request->$block_name;

                    $title = 'title' . $u;
                    $titles = $request->$title;
                    $subtitle= 'subtitle' . $u;
                    $subtitle = $request->$subtitle;
                    $price = 'price' . $u;
                    $price =round($request->$price, 2);
                    $blockId = 'blockId' . $u;
                    $blockId = $request->$blockId;
                    $image = 'image' . $u;
                    if($blockId==0){
                        $addSerDets=new Servicedetails;
                    }else{
                        $addSerDets=Servicedetails::find($blockId);
                    }

                    $addSerDets->service_id=$id;
                    $addSerDets->block_name=$block_name;
                    $addSerDets->title=$titles;
                    $addSerDets->price=$price;
                    $addSerDets->sub_title=$subtitle;
                    if (null !== $request->file($image)) {
                        $images = $request->file($image);
                            $destination =public_path().'/mighty/images/services/';
                            $newname = str_random(5);
                            $ext = $images->getClientOriginalExtension();
                            $filename = $newname.'-original.'.$ext;
                            $newFilename = $newname.'.'.$ext;
                            if($images->move($destination, $newFilename)){
                             //   copy($destination . $filename, $destination . $newFilename);
                                $addSerDets->image =$newFilename;
                            }

                    }
                    $addSerDets->save();
                    $service_block_id=$addSerDets->id;

                    $deleteSerc=Servicecontent::where('service_block_id',$service_block_id)->delete();

                    $content = 'content' . $u;
                    $content = $request->$content;
                    foreach ($content as $res){
                        $adcont=new Servicecontent;
                        $adcont->service_block_id=$service_block_id;
                        $adcont->content=$res;
                        $adcont->save();
                    }

                }


            }
            return redirect('mighty-assist/services/view-services')->with('true_msg','Successfully updated');

        }else{
            $services=$this->services->getServices($id);
            $servicedetails=$this->servicedetails->getServicedetails($id);

            return view('mighty.editServices')->with(array("services"=>$services,"servicedetails"=>$servicedetails));
        }
    }
    function addVideoLibrary(Request $request){
       if($request->isMethod('post'))
        {
            $title = $request->title;
            $video_url = $request->video_url;
            $description = $request->description;
/*
            $new = $request->all();
            $b = new Videolibrary();

            if ($b->validate($new))
            {
                // success code
                echo "s";
            }
            else
            {
                // failure, get errors
                $errors = $b->errors();
                return Redirect::back()->withInput()->with('error_msg',$errors);
            }
exit;

*/



            $adds=new Videolibrary;
            $adds->title=$title;
            $adds->video_url=$video_url;
            $adds->description=$description;
            $adds->save();
            return redirect('mighty-assist/video-library')->with('true_msg','Successfully added');

        }else{
            return view('mighty.addVideoLibrary');
        }
    }
    function deleteVideoLibrary($id){
        $upds=Videolibrary::find($id);
        $upds->delete_status=1;
        $upds->save();
        return redirect('mighty-assist/video-library')->with('true_msg','Successfully Deleted');
    }
    function editVideoLibrary($id,Request $request){

        if($request->isMethod('post'))
        {
            $title = $request->title;
            $video_url = $request->video_url;
            $description = $request->description;

            $upds=Videolibrary::find($id);
            $upds->title=$title;
            $upds->video_url=$video_url;
            $upds->description=$description;
            $upds->save();
            return redirect('mighty-assist/video-library')->with('true_msg','Successfully Updated');

        }else{
            $videolibrary=$this->videolibrary->getVideolibrary($id);
            return view('mighty.editVideoLibrary')->with(array("videolibrary"=>$videolibrary));

        }
    }
    function setSettings(Request $request){


        if($request->isMethod('post'))
        {

            $allowed    = array('jpg','JPG','jpeg','JPEG','png','PNG','gif','GIF');
            $error = 0;
            if($request->file('left_image')){
                $images = $request->file('left_image');
                $extension  = $images->getClientOriginalExtension();
            if(!in_array($extension,$allowed))
            {
                $error = 1;

            }
            $imagedata = getimagesize($images);
            $width = $imagedata[0];
            $height = $imagedata[1];
            if($width!=200 || $height!=100){
                $error = 1;
            }
            }
            if($request->file('middle_image')){
                $images = $request->file('middle_image');
                $extension  = $images->getClientOriginalExtension();
                if(!in_array($extension,$allowed))
                {
                    $error = 1;
                }
                $imagedata = getimagesize($images);
                $width = $imagedata[0];
                $height = $imagedata[1];
                if($width!=600 || $height!=100){
                    $error = 1;
                }
            }

            if($request->file('right_image')){
                $images = $request->file('right_image');
                $extension  = $images->getClientOriginalExtension();
                if(!in_array($extension,$allowed))
                {
                    $error = 1;
                }
                $imagedata = getimagesize($images);
                $width = $imagedata[0];
                $height = $imagedata[1];
                if($width!=160 || $height!=100){
                    $error = 1;
                }
            }
            if($request->file('customer_logo')){
                $images = $request->file('customer_logo');
                $extension  = $images->getClientOriginalExtension();
                if(!in_array($extension,$allowed))
                {
                    $error = 1;
                }
                $imagedata = getimagesize($images);
                $width = $imagedata[0];
                $height = $imagedata[1];
                if($width!=80 || $height!=80){
                     $error = 1;
                }
            }

            if($error==1){
                return Redirect::back()->withInput()->with('error_msg','Please upload valid file.');
            }
            $usdets=Settings::where('user_id',Auth::user()->id)->first();

            if($usdets==0){
                $upd=new Settings;
                $upd->user_id =Auth::user()->id;
            }else{
                $upd=Settings::find($usdets->id);
            }

            if($request->left_remove){
                $destination =public_path().'/mighty/images/settings/'.$upd->left_image;
                unlink($destination);
                $upd->left_image ='';
            }
            if($request->middle_remove){
                $destination =public_path().'/mighty/images/settings/'.$upd->middle_image;
                unlink($destination);
                $upd->middle_image ='';
            }
            if($request->right_remove){
                $destination =public_path().'/mighty/images/settings/'.$upd->right_image;
                unlink($destination);
                $upd->right_image ='';
            }
            if($request->customer_remove){
                $destination =public_path().'/mighty/images/settings/'.$upd->customer_image;
                unlink($destination);
                $upd->customer_logo ='';
            }
            if($request->file('left_image')){
                $images = $request->file('left_image');

                $destination =public_path().'/mighty/images/settings/';
                $newname = str_random(5);
                $ext = $images->getClientOriginalExtension();
                $filename = $newname.'-original.'.$ext;
                $newFilename = $newname.'.'.$ext;
                if($images->move($destination, $newFilename)){
                    //   copy($destination . $filename, $destination . $newFilename);
                    $upd->left_image =$newFilename;
                }
            }
            if($request->file('middle_image')){
                $images = $request->file('middle_image');

                $destination =public_path().'/mighty/images/settings/';
                $newname = str_random(5);
                $ext = $images->getClientOriginalExtension();
                $filename = $newname.'-original.'.$ext;
                $newFilename = $newname.'.'.$ext;
                if($images->move($destination, $newFilename)){
                    //   copy($destination . $filename, $destination . $newFilename);
                    $upd->middle_image =$newFilename;
                }
            }
            if($request->file('right_image')){
                $images = $request->file('right_image');

                $destination =public_path().'/mighty/images/settings/';
                $newname = str_random(5);
                $ext = $images->getClientOriginalExtension();
                $filename = $newname.'-original.'.$ext;
                $newFilename = $newname.'.'.$ext;
                if($images->move($destination, $newFilename)){
                    //   copy($destination . $filename, $destination . $newFilename);
                    $upd->right_image =$newFilename;
                }
            }
            if($request->file('customer_logo')){
                $images = $request->file('customer_logo');

                $destination =public_path().'/mighty/images/settings/';
                $newname = str_random(5);
                $ext = $images->getClientOriginalExtension();
                $filename = $newname.'-original.'.$ext;
                $newFilename = $newname.'.'.$ext;
                if($images->move($destination, $newFilename)){
                    //   copy($destination . $filename, $destination . $newFilename);
                    $upd->customer_logo =$newFilename;
                }
            }
            $upd->save();

            return Redirect::back()->withInput()->with('true_msg','Successfully Updated');

        }else{
            $settings=Settings::where('user_id',Auth::user()->id)->first();
            return view('mighty.setSettings')->with(array("settings"=>$settings));


        }
    }
    function viewVideoLibrary(){
        $videolibrary=$this->videolibrary->getVideolibrary();
        return view('mighty.viewVideoLibrary')->with(array("videolibrary"=>$videolibrary));
    }
    // make start
    function viewMake(){
        $carmake=$this->carmake->getCarmake();
        return view('mighty.viewMake')->with(array("carmake"=>$carmake));
    }
    function addMake(Request $request){
        if($request->isMethod('post'))
        {
            $year = $request->year;
            $make = $request->make;
            $description = $request->description;
            $adds=new Carmake;
            $adds->make_year=$year;
            $adds->make=$make;
            $adds->description=$description;
            $adds->save();
            return redirect('mighty-assist/make')->with('true_msg','Successfully added');

        }
    }
    function deleteMake($id){
        $upds=Carmake::find($id);
        $upds->delete_status=1;
        $upds->save();
        return redirect('mighty-assist/make')->with('true_msg','Successfully Deleted');

    }
    function deleteTemplate($id){
        $upds=Formdetails::find($id);
        $upds->delete_status=1;
        $upds->save();
        return redirect('/')->with('true_msg','Successfully Deleted');

    }
    function editMake($id,Request $request){

        if($request->isMethod('post'))
        {
            $year = $request->year;
            $make = $request->make;
            $description = $request->description;
            $upds=Carmake::find($id);
            $upds->make_year=$year;
            $upds->make=$make;
            $upds->description=$description;
            $upds->save();
            return redirect('mighty-assist/make')->with('true_msg','Successfully updated');

        }else{
            $carmake=$this->carmake->getCarmake($id);
            return view('mighty.editMake')->with(array("carmake"=>$carmake));

        }
    }
    //make end
    //model end
    function viewModel(){
        $carmodels=$this->carmodels->getCarmodels();
        return view('mighty.viewModel')->with(array("carmodels"=>$carmodels));
    }
    function getMake(Request $request){
        $year = $request->year;
       return $carmake=$this->carmake->getCarmakeWithYear($year);
    }

    function showModel(Request $request){
        $carmodels=$this->carmodels->getCarmodels();

       /* $carmodels=new Carmodels;
        $carmodels=$carmodels->whereBetween('id', array(2251 , 2262))->get();*/


        $resource = new FractalCollection($carmodels, new ModelTransformer);
        $models=$this->fractal->createData($resource)->toArray();
       //  return $models['data'];


        /* $actions="";
         foreach($carmodels as $rs){
             $edit=URL::to('/mighty-assist/model/edit/').'/'.$rs->id;
             $actions='<a href="'.$edit.'"  class="tabledit-edit-button btn btn-sm btn-primary" style="float: left;" ><i class="fa fa-edit"></i></a>
                                             <button type="button" class="tabledit-delete-button btn btn-sm btn-default confirm-delete" style="float: none;" onclick="confirmDelete(\''.$rs->id.'\');"  data-rid="'.$rs->id.'" ><span class="glyphicon glyphicon-trash"></span></button>';
             $list = array(
                 "id"=>$rs->id,
                 "make_year"=>$rs->make_year,
                 "make"=>$rs->make,
                 "model"=>$rs->model,
                 "description"=>$rs->description,
                 "actions"=>$actions
             );
             $data_open[] = $list;

             if(count($data_open) > 0){
                 $data_open_arr = $data_open;
             }else{
                 $data_open_arr=array();
             }
         }*/

        $results = array(
            "sEcho" => 1,
            "iTotalRecords" => count($carmodels),
            "iTotalDisplayRecords" => count($carmodels),
            "aaData"=>$models['data']);
        echo json_encode($results);
        exit;

    }
    function showMake(Request $request){
        $carmake=$this->carmake->getCarmake();
        $actions="";
        foreach($carmake as $rs){
            $edit=URL::to('/mighty-assist/make/edit/').'/'.$rs->id;
            $actions='<a href="'.$edit.'"  class="tabledit-edit-button btn btn-sm btn-primary" style="float: left;" ><i class="fa fa-edit"></i></a>
                                            <button type="button" class="tabledit-delete-button btn btn-sm btn-default confirm-delete" style="float: none;" onclick="confirmDelete(\''.$rs->id.'\');"  data-rid="'.$rs->id.'" ><span class="glyphicon glyphicon-trash"></span></button>';
            $list = array(
                "id"=>$rs->id,
                "make_year"=>$rs->make_year,
                "make"=>$rs->make,
                "description"=>$rs->description,
                "actions"=>$actions
            );
            $data_open[] = $list;

            if(count($data_open) > 0){
                $data_open_arr = $data_open;
            }else{
                $data_open_arr=array();
            }
        }

        $results = array(
            "sEcho" => 1,
            "iTotalRecords" => count($carmake),
            "iTotalDisplayRecords" => count($carmake),
            "aaData"=>$data_open_arr);
        echo json_encode($results);
        exit;

    }
    function showEngine(Request $request){
        $carengine=$this->carengine->getCarengine();
        $actions="";
        foreach($carengine as $rs){
            $edit=URL::to('/mighty-assist/engine/edit/').'/'.$rs->id;
            $actions='<a href="'.$edit.'"  class="tabledit-edit-button btn btn-sm btn-primary" style="float: left;" ><i class="fa fa-edit"></i></a>
                                            <button type="button" class="tabledit-delete-button btn btn-sm btn-default confirm-delete" style="float: none;" onclick="confirmDelete(\''.$rs->id.'\');"  data-rid="'.$rs->id.'" ><span class="glyphicon glyphicon-trash"></span></button>';
            $list = array(
                "id"=>$rs->id,
                "make_year"=>$rs->make_year,
                "make"=>$rs->make,
                "model"=>$rs->model,
                "engine"=>$rs->engine,
                "description"=>$rs->description,
                "actions"=>$actions
            );
            $data_open[] = $list;

            if(count($data_open) > 0){
                $data_open_arr = $data_open;
            }else{
                $data_open_arr=array();
            }
        }

        $results = array(
            "sEcho" => 1,
            "iTotalRecords" => count($carengine),
            "iTotalDisplayRecords" => count($carengine),
            "aaData"=>$data_open_arr);
        echo json_encode($results);
        exit;

    }

    function addModel(Request $request){
        if($request->isMethod('post'))
        {
            $year = $request->year;
            $make = $request->make;
            $model = $request->model;
            $description = $request->description;
            $adds=new Carmodels;
            $adds->make_id=$make;
            $adds->model=$model;
            $adds->description=$description;
            $adds->save();
            return redirect('mighty-assist/model')->with('true_msg','Successfully added');

        }
    }
    function deleteModel($id){
        $upds=Carmodels::find($id);
        $upds->delete_status=1;
        $upds->save();
        return redirect('mighty-assist/model')->with('true_msg','Successfully Deleted');

    }
    function editModel($id,Request $request){

        if($request->isMethod('post'))
        {
            $year = $request->year;
            $make = $request->make;
            $model = $request->model;
            $description = $request->description;
            $adds=Carmodels::find($id);
            $adds->make_id=$make;
            $adds->model=$model;
            $adds->description=$description;
            $adds->save();
            return redirect('mighty-assist/model')->with('true_msg','Successfully updated');

        }else{
            $carmodels=$this->carmodels->getCarmodels($id);
            $carmake=$this->carmake->getCarmakeWithYear($carmodels->make_year);
            return view('mighty.editModel')->with(array("carmodels"=>$carmodels,"carmake"=>$carmake));

        }
    }

    // model end
    //Engine end
    function viewEngine(){
         $carengine=$this->carengine->getCarengine();
        return view('mighty.viewEngine')->with(array("carengine"=>$carengine));
    }
    function getModel(Request $request){
        $make = $request->make;
        return $carmodel=$this->carmodels->getCarmodelWithMake($make);
    }
    function addEngine(Request $request){
        if($request->isMethod('post'))
        {
            $year = $request->year;
            $make = $request->make;
            $model = $request->model;
            $engine = $request->engine;
            $description = $request->description;
            $adds=new Carengine;
            $adds->model_id=$model;
            $adds->engine=$engine;
            $adds->make_id=$make;
            $adds->description=$description;
            $adds->save();
            return redirect('mighty-assist/engine')->with('true_msg','Successfully added');

        }
    }
    function deleteEngine($id){
        $upds=Carengine::find($id);
        $upds->delete_status=1;
        $upds->save();
        return redirect('mighty-assist/engine')->with('true_msg','Successfully Deleted');

    }
    function editEngine($id,Request $request){

        if($request->isMethod('post'))
        {
            $year = $request->year;
            $make = $request->make;
            $model = $request->model;
            $engine = $request->engine;
            $description = $request->description;
            $adds=Carengine::find($id);
            $adds->model_id=$model;
            $adds->make_id=$make;
            $adds->engine=$engine;
            $adds->description=$description;
            $adds->save();
            return redirect('mighty-assist/engine')->with('true_msg','Successfully updated');

        }else{
            $carengine=$this->carengine->getCarengine($id);
           $carmake=$this->carmake->getCarmakeWithYear($carengine->make_year);
             $carmodels=$this->carmodels->getCarmodelWithMake($carengine->make_id);
            return view('mighty.editEngine')->with(array("carengine"=>$carengine,"carmodels"=>$carmodels,"carmake"=>$carmake));

        }
    }
    // Engine end
    function inspectionReports(){

       $userprofile=$this->Userprofile->getUserprofiles();

        return view('mighty.inspectionReports')->with(array("userprofile"=>$userprofile));

    }
    function uploadImages(Request $request){

        if($request->isMethod('post')) {
            $images = $request->file('upload');
            $destination =public_path().'/mighty/images/template/';
            $newname = str_random(5);
            $ext = $images->getClientOriginalExtension();
            $filename = $newname.'-original.'.$ext;
            $newFilename = $newname.'.'.$ext;
            if($images->move($destination, $newFilename)){
                //   copy($destination . $filename, $destination . $newFilename);

            }
            $funcNum=1;
            $destination =URL::to('/mighty/images/template/');
            $url=$destination.'/'.$newFilename;
            $message="<p>Url:" .$destination.'/'.$newFilename."</p>";
            echo "<script type='text/javascript'>window.parent.CKEDITOR.tools.callFunction($funcNum, '$url',null);</script>";

        }
    }
    function browseImages(Request $request){
        return view('mighty.browseImages');
    }
    // Mighty Assist end
}
