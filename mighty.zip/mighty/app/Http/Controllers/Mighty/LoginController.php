<?php
namespace App\Http\Controllers\Mighty;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Hash;
use App\Models\User;
use Config;
use Session;
use Image;
use Redirect;



class LoginController extends Controller
{
	 public function __construct()
    {
    	$this->user = new User;
    }
     function index(){
              	 return view('mighty.index');
    }

} 
