<?php

namespace App\Http\Controllers\Auth;
use Illuminate\Http\Request;
use Session;
use Validator;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Redirect;
use Curl,Auth,Uuid;
use App\Models\User;
use App\Models\Formdetails;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request)
    {
        $this->middleware('guest', ['except' => 'logout']);

    }

    public function login(Request $request)
    {

        echo "Yes";exit;

        $this->validate($request, [
            'username' => 'required',
            'password' => 'required',
        ]);


        if (Auth::attempt(['username' =>$request->username, 'password' =>$request->password])) {

            return redirect('/');
        }


        /* $url = 'https://avenger2016.mightyautoparts.com/josso/signon/usernamePasswordLogin.do';*/
        $url = 'https://avenger.mightyautoparts.com/josso/signon/usernamePasswordLogin.do';
        $data = array('josso_username'=>$request->username,'josso_password'=>$request->password,'josso_cmd'=>'login','josso_back_to'=>'https://avenger.mightyautoparts.com/CVIFTabletApp/josso_security_check');

        $postData = "";
        foreach( $data as $key => $val ) {
            $postData .=$key."=".$val."&";
        }
        $postData = rtrim($postData, "&");
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_COOKIEJAR, "FileHere");
        curl_setopt($ch, CURLOPT_COOKIEFILE, "FileHere");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTP);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec ($ch);
        $server_output=json_decode($server_output);

// checking commit
        if(count($server_output)==0){
            return Redirect::back()->withInput()->with('false_msg','Please enter valid Username and password.');
        }
        else{
            $check_user=User::where('username',$request->username)
                ->where('email',$server_output->emailaddress)
                ->where('micuserid',$server_output->micuserid)->first();

               if(count($check_user)==0){

                   $data=[];
                   $data['email']=$server_output->emailaddress;

                   $validator = Validator::make($data, [
                       'email' => 'required|email|max:255|unique:users',
                   ]);
                   if($validator->fails()){
                       return Redirect::back()->withInput()->with('false_msg',$validator->errors());
                   }


                   $check_email=User::where('email',$server_output->emailaddress)->first();
                   if(count($check_email)!=0){
                       return Redirect::back()->withInput()->with('false_msg','Please enter valid Username and password.');
                   }

                $add=new User;
                $add->username=$request->username;
                $add->name=$server_output->fname;
                $add->email=$server_output->emailaddress;
                $add->password=bcrypt($request->password);
                $add->micuserid=$server_output->micuserid;
                $add->lname=$server_output->lname;
                $add->fran_id=$server_output->fran_id;
                $add->userid=$server_output->userid;
                $add->franno=$server_output->franno;
                $add->tempUsername=$server_output->tempUsername;
                $add->salesid=(isset($server_output->salesid)) ? $server_output->salesid : 0;
                $add->motoraccessstats=$server_output->motoraccessstats;
                $add->franid=$server_output->franid;
                $add->accessid=$server_output->accessid;
                $add->franchise_number=$server_output->franchise_number;
                $add->save();

                  for($i=1;$i<=5;$i++){

                       $tasks = Formdetails::find($i);
                       $newTask = $tasks->replicate(); // Make a copy of Form details
                       $newTask->uuid=Uuid::generate()->string;
                       $newTask->user_id=$add->id;
                       $newTask->save();
                   };





            }

        }
        if (Auth::attempt(['username' =>$request->username, 'password' =>$request->password])) {

            return redirect('/');
        }else{
            return redirect('auth/login');
        }


                    curl_close($ch);

    }
    public function logout()
    {
        $url = 'https://mightyautoparts.com';
        Auth::logout();
        return Redirect::to($url);
        Auth::logout();
        exit;
        $url = 'https://mightyautoparts.com';
// redirects to http://google.com
        return Redirect::to($url);
    }
    public function getLogout()
    {
        exit;
        Auth::logout();

        return redirect('auth/login');
    }
}
