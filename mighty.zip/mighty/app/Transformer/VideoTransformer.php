<?php
namespace App\Transformer;

use App\Models\Videolibrary;
use League\Fractal\TransformerAbstract;

class VideoTransformer extends TransformerAbstract
{
    public function transform(Videolibrary $videolibrary)
    {
        return [
            'videoSource'   => $videolibrary->video_url,
            'videoDescription'   => $videolibrary->description,
            'videoTitle'   => $videolibrary->title,
            'videoLibraryId'   => (int) $videolibrary->id,
        ];
    }
}

