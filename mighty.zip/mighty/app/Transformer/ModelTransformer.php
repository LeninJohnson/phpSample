<?php
namespace App\Transformer;

use App\Models\Carmodels;
use League\Fractal\TransformerAbstract;
use PDF,Uuid,URL;
class ModelTransformer extends TransformerAbstract
{
    public function transform(Carmodels $mdl)
    {

        $edit=URL::to('/mighty-assist/model/edit/').'/'.$mdl->id;
        $actions='<a href="'.$edit.'"  class="tabledit-edit-button btn btn-sm btn-primary" style="float: left;" ><i class="fa fa-edit"></i></a>
                                            <button type="button" class="tabledit-delete-button btn btn-sm btn-default confirm-delete" style="float: none;" onclick="confirmDelete(\''.$mdl->id.'\');"  data-rid="'.$mdl->id.'" ><span class="glyphicon glyphicon-trash"></span></button>';


        return [
            'id'      => (isset($mdl->id) && !empty($mdl->id))
                ? $mdl->id : null,
            'make_year'      => (isset($mdl->make_year) && !empty($mdl->make_year))
                ? $mdl->make_year : null,
            'make'      => (isset($mdl->make) && !empty($mdl->make))
                ? $mdl->make : null,
            'model'      => (isset($mdl->model) && !empty($mdl->model))
                ? $mdl->model : null,
            'description'   => (isset($mdl->description) && !empty($mdl->description))
                ? $mdl->description : null,
            'actions'   =>$actions,
        ];
    }
}



