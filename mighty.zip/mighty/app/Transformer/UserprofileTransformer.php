<?php
namespace App\Transformer;

use App\Models\Userprofile;
use League\Fractal\TransformerAbstract;

class UserprofileTransformer extends TransformerAbstract
{
    public function transform(Userprofile $user)
    {

        return [
            'SubmissionId'      => (isset($user->id) && !empty($user->id))
                ? $user->id : null,
            'userID'      => (isset($user->user_id) && !empty($user->user_id))
                ? $user->user_id : null,
            'formID'      => (isset($user->form_id) && !empty($user->form_id))
                ? $user->form_id : null,
            'franchiseId'      => (isset($user->fran_id) && !empty($user->fran_id))
                ? $user->fran_id : null,
            'firstName'   => (isset($user->first_name) && !empty($user->first_name))
                ? $user->first_name : null,
            'lastName'   => (isset($user->last_name) && !empty($user->last_name))
                ? $user->last_name : null,
            'mobileNumber'    =>(isset($user->mobile_no) && !empty($user->mobile_no))
                ? $user->mobile_no : null,
            'alternateNumber'    =>(isset($user->alternative_mobileno) && !empty($user->alternative_mobileno))
                ? $user->alternative_mobileno : null,
            'tagNumber'    =>(isset($user->tag) && !empty($user->tag))
                ? $user->tag : null,
            'vinNumber'    =>(isset($user->vin) && !empty($user->vin))
                ? $user->vin : null,
            'year'    =>(isset($user->year) && !empty($user->year))
                ? $user->year : null,
            'makeID'    =>(isset($user->make_id) && !empty($user->make_id))
                ? $user->make_id : null,
            'modelID'    =>(isset($user->model_id) && !empty($user->model_id))
                ? $user->model_id : null,
            'engineID'    =>(isset($user->engine_id) && !empty($user->engine_id))
                ? $user->engine_id : null,
            'make'    =>(isset($user->make) && !empty($user->make))
                ? $user->make : null,
            'model'    =>(isset($user->model) && !empty($user->model))
                ? $user->model : null,
            'engine'    =>(isset($user->engine) && !empty($user->engine))
                ? $user->engine : null,
            'mileage'    =>(isset($user->mileage) && !empty($user->mileage))
                ? $user->mileage : null,
            'email'    =>(isset($user->email) && !empty($user->email))
                ? $user->email : null,
            'duration'    =>(isset($user->duration) && !empty($user->duration))
                ? $user->duration : null,
            'status'    =>intval($user->status),
        ];
    }
}



