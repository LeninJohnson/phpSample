<?php
namespace App\Transformer;

use App\Models\Cartsb;
use League\Fractal\TransformerAbstract;
use URL;
class CartsbTransformer extends TransformerAbstract
{
    public function transform(Cartsb $cartsb)
    {
        $filepdf =URL::asset('tsb_data/'.$cartsb->filenamepdf);
        //$filepdf ='https://www.mightyautoparts.com/CVIFTabletApp/tsbpdf/'.$cartsb->filenamepdf;
      //  $filepdf ='http://cvif.enterpriseapplicationdevelopers.com/tsb_data/'.$cartsb->filenamepdf;

        return [
/*            'Id'      => (isset($cartsb->id) && !empty($cartsb->id))
                ? $cartsb->id : null,*/
            'Id'      => mt_rand(),
            'Issuer'      => (isset($cartsb->issuer) && !empty($cartsb->issuer))
                ? $cartsb->issuer : null,
            'Issuedate'      => (isset($cartsb->issuedate) && !empty($cartsb->issuedate))
                ? $cartsb->issuedate : null,
            'Description'      => (isset($cartsb->description) && !empty($cartsb->description))
                ? $cartsb->description : null,
            'Vehicletoengineconfigid'      => (isset($cartsb->vehicletoengineconfigid) && !empty($cartsb->vehicletoengineconfigid))
                ? $cartsb->vehicletoengineconfigid : null,
            'Autosystemdescription'      => (isset($cartsb->autosystemdescription) && !empty($cartsb->autosystemdescription))
                ? $cartsb->autosystemdescription : null,
            'Type'      => (isset($cartsb->type) && !empty($cartsb->type))
                ? $cartsb->type : null,
            'Filenamepdf'      => (isset($cartsb->filenamepdf) && !empty($cartsb->filenamepdf))
                ? $filepdf : null,
            'Manufacturernum'      => (isset($cartsb->manufacturernum) && !empty($cartsb->manufacturernum))
                ? $cartsb->manufacturernum : null,
        ];
    }
}



