<?php
namespace App\Transformer;

use App\Models\User;
use League\Fractal\TransformerAbstract;

class UserTransformer extends TransformerAbstract
{
    public function transform(User $user)
    {
        return [
            'id'      => (int) $user->id,
            'name'   => $user->name,
            'email'   => $user->email,
            'micuserId'    =>$user->micuserid,
            'lname'    =>$user->lname,
            'franId'    =>$user->fran_id,
            'userId'    =>$user->userid,
            'franNo'    =>$user->franno,
            'lname'    =>$user->lname,
            'tempUsername'    =>$user->tempUsername,
            'userName'    =>$user->username,
            'salesId'    =>$user->salesid,
            'motoraccessstats'    =>$user->motoraccessstats,
            'franId'    =>$user->franid,
            'accessId'    =>$user->accessid,
        ];
    }
}

