<?php
namespace App\Transformer;

use App\Models\Carpm;
use League\Fractal\TransformerAbstract;

class CarpmTransformer extends TransformerAbstract
{
    public function transform(Carpm $carpms)
    {

        return [
            /*'Id'      => (isset($carpms->id) && !empty($carpms->id))
                ? $carpms->id : null,*/
            'Id'      => mt_rand(),
            'IntMo'      => (isset($carpms->intMo) && !empty($carpms->intMo))
                ? $carpms->intMo : null,
            'IntKm'      => (isset($carpms->intKm) && !empty($carpms->intKm))
                ? $carpms->intKm : null,
            'Action'      => (isset($carpms->action) && !empty($carpms->action))
                ? $carpms->action : null,
            'Item'   => (isset($carpms->item) && !empty($carpms->item))
                ? $carpms->item : null,
            'Qualifier'   => (isset($carpms->qualifier) && !empty($carpms->qualifier))
                ? $carpms->qualifier : null,
            'IntMi'   => (isset($carpms->intMi) && !empty($carpms->intMi))
                ? $carpms->intMi : null,
            'Freq'   => (isset($carpms->freq) && !empty($carpms->freq))
                ? $carpms->freq : null,
            'RecNo'   => (isset($carpms->recNo) && !empty($carpms->recNo))
                ? $carpms->recNo : null,
        ];
    }
}



