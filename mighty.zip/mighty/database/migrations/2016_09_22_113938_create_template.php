<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTemplate extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		
 Schema::create('template', function (Blueprint $table) {
		$table->increments('id');
		$table->string('title');
		$table->string('header');
		$table->string('form_name');
		$table->string('image_path_center');
		$table->string('image_size_center');
		$table->string('image_path_left');
		$table->string('image_size_left');
		$table->string('image_path_right');
		$table->string('image_size_right');
		$table->string('customer_details');
		$table->string('comments');
		$table->string('inspected_by');
		$table->string('dates');
		$table->rememberToken();
		$table->timestamps();
		});


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('template');
    }
}
