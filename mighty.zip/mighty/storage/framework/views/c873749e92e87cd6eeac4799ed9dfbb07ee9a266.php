<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(project_name); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <!--<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">-->
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/bootstrap/css/custom.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/dist/css/AdminLTE.min.css')); ?>">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/dist/css/skins/_all-skins.min.css')); ?>">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/plugins/iCheck/flat/blue.css')); ?>">
    <!-- Morris chart -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/plugins/morris/morris.css')); ?>">
    <!-- jvectormap -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/plugins/jvectormap/jquery-jvectormap-1.2.2.css')); ?>">
    <!-- Date Picker -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/plugins/datepicker/datepicker3.css')); ?>">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/plugins/daterangepicker/daterangepicker.css')); ?>">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>">
    <?php echo $__env->yieldContent('customCss'); ?>
</head>
<style type="text/css">
    body {
        font-family: 'Helvetica';
        overflow-x: auto !important;
    }
    body,
    * {
        margin: 0;
        padding: 0;
    }
    h1 {
        width: 100% !important;
        height: 44px !important;
        background-image: url(<?php echo e(URL::asset('mighty/images/tile_img.png')); ?>);
        line-height: 44px !important;
        color: #FFF !important;
        font-size: 18px !important;
        text-align: center !important;
        font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif !important;
    }
    #wrapper {
        width: 100%;
        background-color: #FFF;
        margin: auto;
    }
    .inner-head {
        text-align: center;
        width: 960px;
        height: 40px;
    }
    .inner-logo {
        border: 1px solid #000;
        width: 385px;
        height: 100px;
        text-align: center;
        float: left;
        position: relative;
        left: 290px;
    }
    .profile {
        text-align: left;
        padding-left: 20px;
        width: 940px;
        height: 35px;
        color: #000;
        font-size: 15px;
        font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif;
        background-color: #e8e8e8;
        margin-top: 10px;
        line-height: 35px;
    }
    .profile_title {
        width: 100%;
        text-align: left;
        padding-left: 25px;
        height: 35px;
        color: #000;
        font-size: 15px;
        font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif;
        background-color: #e8e8e8;
        margin-top: 10px;
        line-height: 35px;
    }
    .profile_title span {
        font-weight: bold;
        text-align: left;
        font-size: 15px;
    }
    .profile-form-left ul {
        float: left;
        text-align: left;
        padding-left: 25px;
        width: 50%;
        padding-top: 10px;
    }
    .profile-form-left ul li {
        list-style: none;
        height: 50px;
    }
    .profile-form-left ul li label {
        width: 150px;
        font-size: 14px;
        display: inline-block;
    }
    .profile-form-right ul {
        float: right;
        width: 50%;
        text-align: left;
        padding-top: 10px;
    }
    .profile-form-right ul li {
        list-style: none;
        height: 50px;
        font-size: 14px;
    }
    .profile-form-right ul li label {
        width: 150px;
        font-size: 14px;
        display: inline-block;
    }
    .photo-slider {
        text-align: left;
        float: left;
        padding-left: 50px;
        width: 100%;
        background-color: #e8e8e8;
        height: 35px;
        line-height: 35px;
        font-weight: bold;
        font-size: 14px;
    }
    .photo {
        float: left;
        padding-top: 20px;
        padding-left: 50px;
        width: 910px;
    }
    .photo img {
        float: left;
        padding-right: 10px;
        padding-bottom: 10px;
        width: 150px;
        height: 100px;
    }
    .cars{
        width: 150px;
        height: 100px;
    }
    .mileage {
        float: left;
        width: 960px;
        height: 20px;
        position: relative;
        top: 5px;
        text-align: center;
    }

    .comments {
        float: left;
        font-size: 14px;
        font-weight: bold;
        margin-top: 10px;
        width: 100%;
        padding-left: 50px;
        background-color: #e8e8e8;
        height: 35px;
        line-height: 35px;
        text-align: left;
        margin-bottom: 10px;
    }
    .inspire {
        width: 960px;
        float: left;
        padding: 20px 0 0 30px;
    }
    .ins {
        width: 400px;
        height: 50px;
        float: left;
    }
    .dat {
        width: 369px;
        line-height: 35px;
        height: 50px;
        float: left;
    }
    p > input {
        float: left;
        height: 16px;
        left: 0;
        margin: 0;
        padding: 0;
        width: 16px;
    }
    p > label {
        color: #000000;
        float: left;
        line-height: 16px;
        font-size: 15px;
    }

    div > label {
        bottom: 7px;
        padding-left: 5px;
        position: relative;
        text-align: center;
    }
    .inn-lefts {
        height: 500px;
        width: 300px;
        position: relative;
        left: 100px;
        top: 20px;
        float: left;
    }
    .inn-rights {
        height: 500px;
        left: 110px;
        position: relative;
        top: 20px;
        width: 400px;
        float: left;
    }

    .wear {
        float: left;
        width: 100px;
    }
    .sign {
        font-size: 15px;
        padding: 5px 1px;
        width: 339px;
        float: left;
        padding-left: 30px;
    }
    .tech {
        float: left;
        font-size: 15px;
        font-weight: bold;
        margin-top: 10px;
        width: 100%;
        padding-left: 50px;
        background-color: #e8e8e8;
        height: 35px;
        line-height: 35px;
        text-align: left;
    }
    .header {
        height: 100px;
        width: 960px;
        display: flex;
    }
    .userlist {
        font-size: 13px;
        font-weight: bold;
    }
    .usercontent {
        font-size: 14px;
        line-height: 25px;
        padding-left: 50px;
    }
</style>
    <?php
    $form_name =$formdetails->form_name;
    $string = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $form_name)));
    ?>

    <script src="<?php echo e(URL::asset('mighty/plugins/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('mighty/plugins/kendo.all.min.js')); ?>"></script>

    <script type="text/javascript">
        var generatePDF = function() {
            kendo.drawing
                    .drawDOM($("#content_right"))
                    .then(function(group){

                        kendo.drawing.pdf.saveAs(group, "<?php echo e($string); ?>.pdf");
                    });
            return false;
            var draw = kendo.drawing;

            draw.drawDOM($("#content_right"), {
                        avoidLinks: true,
                        pdf: {
                            allPages: true,
                            paperSize: "A4",
                            landscape: false
                        },
                        margin: {
                            left   : "210mm",
                            top    : "297mm",
                            right  : "210mm",
                            bottom : "297mm"
                        },
                        landscape: false,
                        repeatHeaders: false
                    })
                    .then(function(root) {
                        return draw.exportPDF(root);
                    })
                    .done(function(data) {
                        kendo.saveAs({
                            dataURI: data,
                            fileName: "<?php echo e($string); ?>.pdf"
                        });
                    });
            return false;
        }
    </script>
    <style>
        #test {
            font-family: "Times New Roman", serif;
            padding: 20px;
            background: #234;
            color: #ffc;
            width: 400px;
            text-align: center;
        }
        .input_line{
            display: table-cell;
            border-top: 0px;
            border-left: 0px;
            border-right: 0px;
            border-bottom: 1px solid #333;
            width: 100% !important;
        }
        .uk-table {
            font-size: 17px !important;
            font-weight: 700;
            border: 2px solid #222 !important;
        }

        .uk-table td,.uk-table th {
            border: 2px solid #222 !important;
            padding:6px !important;
        }

    </style>

    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(URL::asset('mighty/plugins/form-builder.min.css')); ?>">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(URL::asset('mighty/plugins/main.min.css')); ?>">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(URL::asset('mighty/plugins/uikit.almost-flat.min.css')); ?>">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(URL::asset('mighty/plugins/formpro1.css')); ?>">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(URL::asset('mighty/plugins/jquery_ui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/plugins/template3.css')); ?>">
    <style>
        .content {
        // min-height: 1811px;
        }
    </style>
    <style>
        li.rows{
            min-height:50px;
        }
        li.columns{
            float:left;
            height:75px;
            list-style: none;
        }
        li.highlight{
            min-height: 70px;
        }
        .dropovers{
            /*  border:1px solid #ccc;
              border-right-color:red;*/
        }
        body{
            /*overflow: hidden;
            height: 100%;*/
        }
        .content{
            padding-left: 0px !important;
        }
        body {
            padding-top: 0px !important;
        }
        .uk-grid > * {
            float: none;
        }
        .cmdline{
            width:90%;margin-top: 6%;color: rgb(12, 12, 12);border: 0.1px solid;
        }
        .th{
        // padding: 6px 22px 13px 1px;
            border: 1px solid;
        }
        .row1Title {
            background: none repeat scroll 0 0 #005AAB;
            border-bottom: 1px solid #000000;
            color: #FFFFFF;
            /* font-family: 'MyriadProBold'; */
            font-size: 12pt;
            height: 30px;

            text-align: center;
        }
        .svgTable{
            /* margin-left: 30px;*/
            margin-left: 14px;
            margin-top: 7px;
        }
        .uk-h2, h2 {
            font-size: 24px;
            line-height: normal;
        }
        .click-edit-icons {
            background-image: url("<?php echo e(URL::asset('mighty/images/clicktoedit.png')); ?>");
            background-size: 15px;
            width: 15px;
            height: 15px;
            float: right;
        }
        .spanlable{
            max-width: 100%;
            font-weight: 700;
            display: block;
            text-align: center;
            margin: 4px 0px 8px;
            font-size: 20px;
        }
        .comp4boxi{
            width: 145px !important;
        }
        .optionbox{
            float:left;
        }
        .lrchange
        {
            background: url('<?php echo e(URL::asset('mighty/images/leftright.png')); ?>');
            width: 18px;
            height: 18px;
            background-size: 19px;
            display: block;
            margin-top: -2px;
            margin-right: 10px;
        }
        .add_morerow{
            background: url('<?php echo e(URL::asset('mighty/images/add2.png')); ?>');
            background-size: 15px;
            display: block;
            width: 15px;
            height: 15px;
            float: right;
            cursor: pointer;
            padding-left: 0px;
        }
        .uncheck-grey,.check-red{
            display: none;
        }
        .inspectionTable {

        }
        .fontF {
            font-family: 'MyriadProBold';
            font-size: 20px !important;
            font-style: italic;
        }
        .interior_inspec h2 {
            font-size: 18px !important;
            font-weight: 700;
            color: black;
        }
        .floatLeft,.fontF,.txt_bold_lower_case ,.bottomtext ,.txt_bold {
            font-family: serif;
        }
        img {
            max-width: none;
        }
        .txtFont {

            font-size: 20px !important;
            line-height: 23px;

        }
        .check-box{
            width: 25px;
            height: 25px;
            background: #f8f8f8;
            display: inline-block;
            vertical-align: middle;
            border: 1px solid #222;
        }
        .check-value,.check-title{
            font:400 20px/1.42857143 Roboto,sans-serif !important;
        }.check-value{
             margin-right: 35px;
         }
        .tire-condition{
            display: block;
            width: 100%;
            float: left;
        }
        .tire-lflr{
            display: block;
            width: 100%;
            float: left;
            margin-top: 10px;
        }
        .interior_inspec1 {
            width: 168px;
            /*width: 175px;*/
        }
        .txt_bold_lower_case {
            font-size: 20px !important;
        }
        .txt_bold {
            font-size: 20px !important;
        }
        .interior_inspec {
            width: 160px;
        }
        .white_box{
            width: 50px;
            height: 30px;
        }
        .white_box_rectangle {
            height: 62px;
        }
        .beforeAfter{
            width:100% !important;
            text-align: left;
        }

        .md-card {
              box-shadow: 0 0px 0px rgba(0,0,0,.12), 0 0px 0px rgba(0,0,0,.24);
             }

        /*.condition-box.widthzero li {
            width: 33% !important;
        }*/
        .condition-box li strong.title_value {
            font-size: 11px;
            line-height: 20px;
            margin-left: 5px;
            width: 110px;
            display: inline-block;
            vertical-align: top;
        }
        .condition-box li {
            display: inline-block;
            padding-right: 0px !important;
            width: 31% !important;
            
        }
        .condition-box.widthzero li {
            width: inherit !important;
            float:left  !important;
            margin:0px 5px  !important;
        }
         
    </style>

    <!-- <script src="<?php echo e(URL::asset('mighty/plugins/jquery.min.js')); ?>"></script> -->



            <!-- Content Header (Page header) -->

                <!-- Main content -->
        <section class="content">

            <?php
            if($formdetails->imageType==0){
                $imgclrg="greenCircle";
                $imgclry="yellowCircle";
                $imgclrr="redCircle";


                $imgclrgs="greenCircleset";
                $imgclrys="yellowCircleset";
                $imgclrrs="redCircleset";

                $smlimgclrg="smallGreenCircle";
                $smlimgclry="smallYellowCircle";
                $smlimgclrr="smallRedCircle";


                $smlimgclrgs="smallGreenCircleset";
                $smlimgclrys="smallYellowCircleset";
                $smlimgclrrs="smallRedCircleset";
            }else{
                $imgclrg="green";
                $imgclry="yellow";
                $imgclrr="red";


                $imgclrgs="greenset";
                $imgclrys="yellowset";
                $imgclrrs="redset";

                $smlimgclrg="smallGreen";
                $smlimgclry="smallYellow";
                $smlimgclrr="smallRed";

                $smlimgclrgs="smallGreenset";
                $smlimgclrys="smallYellowset";
                $smlimgclrrs="smallRedset";

            }
            ?>

            <body>

            <div id="page_content">
                <div id="page_content_inner">
                    <div class="uk-grid" style="display: block;padding-left:0px !important"; data-uk-grid-margin data-uk-grid-match id="wizard_forms">
                        <ul id="rows_1" style="height: 115px;width: 100%;margin: 0 auto;" class="connected">
                            <li style="height: 115px;text-align: center;" class="uk-width-1-3 columns" id="columns_1">
                                <?php if(isset($formdetails->formImg[1])): ?>
                                    <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($formdetails->formImg[1]); ?>"  style="height: 90px;">
                                <?php endif; ?>
                            </li>
                            <li style="height: 115px;text-align: center;" class="uk-width-1-3 columns" id="columns_2">
                                <?php if(isset($formdetails->formImg[0])): ?>
                                    <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($formdetails->formImg[0]); ?>"  style="height: 90px;">
                                <?php endif; ?>
                            </li>
                            <li style="height: 115px;text-align: center;" class="uk-width-1-3 columns" id="columns_3">
                                <?php if(isset($formdetails->formImg[2])): ?>
                                    <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($formdetails->formImg[2]); ?>"  style="height: 90px;">
                                <?php endif; ?>
                            </li>
                        </ul>
                      
                        <div class="uk-width-large-2-10"  id="sidebar" style="float: left;width:20%;display:none">


                        </div>

                        <form class="uk-form-stacked" id="wizard_advanced_form" method="post" enctype="multipart/form-data" >
                            <div class="uk-width-large-8-10"  id="content_right" style="/*float:left;*/min-height: 900px;padding-left:12px;width:100%;margin: 0 auto;">
                                <div class="md-card" style="height: 1200px !important;">
                                    <div id="wrapper">

                                        <h1><?php echo e($formdetails->formTitle); ?></h1>

                                        <div class="profile_title">
                                            <span class="profile_title"> PROFILE</span>

                                            <div class="profile-form-left">
                                                <ul>
                                                    <li><label><b>First name </b></label> <label><?php echo e($formdetails->first_name); ?></label></li>
                                                    <li><label><b>Last name </b></label> <label><?php echo e($formdetails->last_name); ?></label></li>
                                                    <li><label><b>Moblie Phone </b></label> <label><?php echo e($formdetails->mobile_no); ?></label></li>
                                                    <li><label><b>Alternate Phone </b></label> <label><?php echo e($formdetails->alternative_mobileno); ?></label></li>
                                                    <li><label><b>VIN </b></label> <label><?php echo e($formdetails->vin); ?></label></li>
                                                    <li><label><b></b></label> <label></label></li>
                                                </ul>
                                            </div>

                                            <div class="profile-form-right">
                                                <ul>

                                                    <li><label><b>Year </b></label> <label><?php echo e((isset($formdetails->year) && !empty($formdetails->year))
                                                    ? $formdetails->year : ''); ?></label></li>
                                                    <li><label><b>Make </b></label> <label><?php echo e($formdetails->make); ?></label></li>
                                                    <li><label><b>Model </b></label> <label><?php echo e($formdetails->model); ?></label></li>
                                                    <li><label><b>Engine </b></label> <label><?php echo e($formdetails->engine); ?></label></li>
                                                    <li><label><b>Mileage </b></label> <label><?php echo e((isset($formdetails->mileage) && !empty($formdetails->mileage))
                                                    ? $formdetails->mileage : ''); ?></label></li>
                                                    <li><label><b>Tag Number </b></label> <label><?php echo e($formdetails->tag); ?></label></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <br><br>
                                    </div>
                                    <div class="form md-card-content" style="<?php echo e(($formdetails->id==1) ? 'padding: 11px 130px!important;' : 'padding: 11px 64px!important;'); ?>">
                                        <div id="forms" data-form_id ="1" style="width:100%;height: 100%;padding-bottom: 53px;padding-top: 53px;">
                                            <ul id="pages" style="height: 100%;">
                                                <!--<li class="rows" id="rows_1"></li>-->
                                                <?php
                                                $edFlag=1;
                                                $options=0;
                                                $formToken=$formdetails->formapi;
                                                $ftk_array=json_decode($formToken);

                                                /*foreach ($ftk_array as $pages) {
                                                $res_array=$pages;*/
                                                /*   foreach ($ftk_array as $res) {

                                                  $res_result=$res;
                                                $remove=count($res_result)-1;
                                                 unset($res_result[$remove]);*/
                                                if(!empty($ftk_array)){

                                                $ftk_array =  (array) $ftk_array;
                                               foreach ($ftk_array as $key=> $rows) {
                                                $row=$key;
                                                $rows =  (array) $rows;
                                               /*  dd($rows);
                                                    echo $rows->"1"->rowheight;

                                                foreach($rows as $in=>$kes){
                                                    echo ($in);echo "<br>";
                                                    print_r($kes->rowheight);echo "<br>";
                                                }
                                                exit; height: {{$rows[1]->rowheight}}px; */

                                                ?>
                                                <li class="rows uk-width-1-1 ui-droppable" id="rows_<?php echo e($row+1); ?>">
                                                    <ul id="rows_<?php echo e($row+1); ?>" style="" class="connected" >
                                                        <?php

                                                        foreach ($rows as $index=>$cols) {
                                                        $col=$index;
                                                        if(isset($cols->choices)){
                                                            $options++;
                                                        }


                                                        ?>

                                                        <li style="height:100%" class="uk-width-1-<?php echo e(count($rows)); ?> columns" id="columns_<?php echo e($col+1); ?>">

                                                            <div class="cols uk-width-1-1 <?php echo e($cols->type); ?>_undefined">
                                                                <div class="uk-panel config_<?php echo e($cols->type); ?> portlet">
                                                                    <div class="portlet-header" data-type="<?php echo e($cols->type); ?>" data-fieldid="<?php echo e($cols->fieldid); ?>">
                                                                        <!--Start -->
                                                                        <?php if($cols->type=="text"): ?>
                                                                                <!--<input type="text" />-->
                                                                        <div class="uk-grid">
                                                                            <div class="titl-field1 left_setting" style="width:100%;display: inherit;">
                                                                                <label class="title_label" style="font-size: 20px;display:table-cell;white-space: nowrap;"><?php echo e($cols->title); ?> :</label>
                                                                                <input type="text" class="input_line" readonly  />
                                                                            </div>

                                                                        </div>
                                                                        <?php elseif($cols->type=="heading"): ?>
                                                                                <!-- Heading Templates-->

                                                                        <!--<input type="text" />-->
                                                                        <div class="uk-grid">
                                                                            <div class="titl-field1 left_setting" style="width:100%;text-align: center;">
                                                                                <label class="title_label heading_title"><?php echo e($cols->title); ?></label>
                                                                            </div>
                                                                        </div>

                                                                        <?php elseif($cols->type=="email"): ?>
                                                                                <!-- Email Controls -->

                                                                        <div class="uk-grid">
                                                                            <div class="titl-field1 left_setting" style="width:100%;">
                                                                                <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                                                                                <input type="email" readonly style="display:table" />
                                                                            </div>
                                                                        </div>

                                                                        <?php elseif($cols->type=="number"): ?>
                                                                                <!-- Number Controls -->

                                                                        <div class="uk-grid">
                                                                            <div class="titl-field1 left_setting" style="width:100%;">
                                                                                <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                                                                                <input type="number" readonly style="display:table" />
                                                                            </div>
                                                                        </div>

                                                                        <!-- Date controls -->
                                                                        <?php elseif($cols->type=="date"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting">
                                                                                    <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                                                                                    <input type="text"  readonly style="display:table" />
                                                                                    <input type = "hidden" id="date_format"  value ="" />
                                                                                </div>
                                                                                <div class="options" id="choices" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <select style="padding:4px 6px;"  class="uk-form-select" name="date_format" id="date_formats">
                                                                                            <option value="MM/dd/yyyy">MM/DD/YYYY</option>
                                                                                            <option value="dd/MM/yyyy">DD/MM/YYYY</option>
                                                                                            <option value="yyyy/MM/dd">YYYY/MM/DD</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <!-- Time controls -->
                                                                        <?php elseif($cols->type=="time"): ?>

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                                                                                    <input type="text" readonly style="display:table">
                                                                                    <input type = "hidden" id="time_format"  value ="" />
                                                                                </div>
                                                                                <div class="options" id="choices" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <select style="padding:4px 6px;"  class="uk-form-select" name="time_format" id="time_formats">
                                                                                            <option value="hh:mm:ss">12 Hrs</option>
                                                                                            <option value="HH:mm:ss">24 Hrs</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <!-- Signature -->
                                                                        <?php elseif($cols->type=="signature"): ?>

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label"><?php echo e($cols->title); ?></label>
                                                                                    <br/>
                                                                                    <input type="text" readonly style="display:table">
                                                                                </div>
                                                                            </div>

                                                                            <?php elseif($cols->type=="radio"): ?>
                                                                                    <!-- Radio Button Templates -->

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                                                                                    <div class="title_radio select">
                                                                                        <?php if(isset($cols->choices)): ?>
                                                                                            <?php
                                                                                            $choice_array=$cols->choices;
                                                                                            ?>
                                                                                            <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                <input type="radio" name="radio" value="<?php echo e($chres->title); ?>" /> <span class="title_value" data-optionid="0"><?php echo e($chres->title); ?></span>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="options" id="choices_<?php echo e($cols->formfieldid); ?>" style="display:none">

                                                                                    <div class="input_fields_wrap">
                                                                                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                        </a> -->
                                                                                        <element>
                                                                                            <?php
                                                                                            $choice_array=$cols->choices;
                                                                                            ?>
                                                                                            <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chindex=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                <p>
                                                                                                    <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                           value="<?php echo e($chres->title); ?>"/>
                                                                                                    <?php if($chindex==0): ?>
                                                                                                        <span class="add-option add_field_button"></span>
                                                                                                    <?php else: ?>
                                                                                                        <span class="delete-option remove_field"></span>
                                                                                                    <?php endif; ?>
                                                                                                </p>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                                        </element>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="<?php echo e($cols->type); ?>";
                                                                                //// comptField="<?php echo e($options); ?>";
                                                                                row_id="rows_<?php echo e($row+1); ?>";
                                                                                collength="<?php echo e($col+1); ?>";
                                                                                dialog = popup_initialize('choices_<?php echo e($cols->formfieldid); ?>','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_<?php echo e($cols->formfieldid); ?>',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                            <!--Check Box Templates -->
                                                                        <?php elseif($cols->type=="checkbox"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label" style="font-size: 20px;"><?php echo e($cols->title); ?></label><br/>
                                                                                    <label class="title_label1 check-title" style="<?php echo e((isset($cols->subtitle) && !empty($cols->subtitle))
                        ? '' : 'display:none'); ?>"><?php echo e($cols->subtitle); ?></label>
                                                                                    <div class="title_checkbox select">
                                                                                        <?php if(isset($cols->choices)): ?>
                                                                                            <?php
                                                                                            $choice_array=$cols->choices;
                                                                                            ?>
                                                                                            <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                <div style="display:inline-block;">
                                                                                                    <?php if($chres->checked==1): ?>
                                                                                                        <img src="<?php echo e(URL::asset('mighty/images/tick-box.png')); ?>"  />

                                                                                                    <?php else: ?>
                                                                                                    <strong class="check-box"></strong>
                                                                                                    <?php endif; ?>
                                                                                                    <span class="title_value check-value" data-optionid="0"><?php echo e($chres->title); ?></span>
                                                                                                </div>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                    <div class="options" id="choices_<?php echo e($cols->formfieldid); ?>" style="display:none">
                                                                                        <div class="input_fields_wrap">
                                                                                            <!--  <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                             <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                             </a> -->
                                                                                            <element>

                                                                                                <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chindex=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                    <p>
                                                                                                        <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                               value="<?php echo e($chres->title); ?>"/>
                                                                                                        <?php if($chindex==0): ?>
                                                                                                            <span class="add-option add_field_button"></span>
                                                                                                        <?php else: ?>
                                                                                                            <span class="delete-option remove_field"></span>
                                                                                                        <?php endif; ?>
                                                                                                    </p>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                            </element>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="<?php echo e($cols->type); ?>";
                                                                                //// comptField="<?php echo e($options); ?>";
                                                                                row_id="rows_<?php echo e($row+1); ?>";
                                                                                collength="<?php echo e($col+1); ?>";
                                                                                dialog = popup_initialize('choices_<?php echo e($cols->formfieldid); ?>','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_<?php echo e($cols->formfieldid); ?>',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                            <!-- start checkbox -->

                                                                            <!-- end checkbox -->

                                                                            <?php elseif($cols->type=="select"): ?>
                                                                                    <!-- Select dropdown Templates -->

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                                                                                    <div class="title_checkbox select">
                                                                                        <select>

                                                                                            <?php if(isset($cols->choices)): ?>
                                                                                                <?php
                                                                                                $choice_array=$cols->choices;
                                                                                                ?>
                                                                                                <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                    <option>
                                                                  <span class="title_value" data-optionid="0">
                                                                         <?php echo e($chres->title); ?>

                                                                  </span>      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                                            <?php endif; ?>
                                                                                        </select>
                                                                                    </div>
                                                                                    <div class="options" id="choices_<?php echo e($cols->formfieldid); ?>" style="display:none">
                                                                                        <div class="input_fields_wrap">
                                                                                            <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                            </a> -->
                                                                                            <element>
                                                                                                <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chindex=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                    <p>
                                                                                                        <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                               value="<?php echo e($chres->title); ?>"/>
                                                                                                        <?php if($chindex==0): ?>
                                                                                                            <span class="add-option add_field_button"></span>
                                                                                                        <?php else: ?>
                                                                                                            <span class="delete-option remove_field"></span>
                                                                                                        <?php endif; ?>
                                                                                                    </p>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                            </element>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                            <script>
                                                                                type ="<?php echo e($cols->type); ?>";
                                                                                //// comptField="<?php echo e($options); ?>";
                                                                                row_id="rows_<?php echo e($row+1); ?>";
                                                                                collength="<?php echo e($col+1); ?>";
                                                                                dialog = popup_initialize('choices_<?php echo e($cols->formfieldid); ?>','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_<?php echo e($cols->formfieldid); ?>',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                            <?php elseif($cols->type=="textarea"): ?>
                                                                                    <!-- TextArea Templates -->

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                                                                                    <textarea style="resize: none;height: 40px; width: 200px;" readonly></textarea>
                                                                                </div>
                                                                            </div>

                                                                            <?php elseif($cols->type=="file"): ?>
                                                                                    <!-- File Select Templates -->

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;text-align: center;">
                                                                                    <!-- <label class="title_label"><?php echo e($cols->title); ?></label> -->
                                                                                    <?php if(isset($cols->filepath) && ($cols->filepath!='undefined') && ($cols->filepath!='')): ?>
                                                                                        <?php
                                                                                        $filename=URL::asset('mighty/images/template/').'/'.$cols->filepath;
                                                                                        $size = getimagesize($filename);
                                                                                        ?>
                                                                                        <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($cols->filepath); ?>"  <?php if(($size[1]>111 || $size[0]>360)): ?> style="height: 90px;" <?php endif; ?> />

                                                                                        <?php endif; ?>
                                                                                                <!--
                                                                                             
                                                                                                <p>
                                                                                          <input type="text" class="height" name="height"  style="height: 22px;width: 78px;"
                                                                                                 maxlength="3" minlength="1" value="<?php echo e($cols->height); ?>" required/><span style="color:red;font-size:10px;">Height</span>
                                                                                        <input type="text" class="width" name="width"  style="height: 22px;width: 78px;"
                                                                                               maxlength="3" minlength="1" value="<?php echo e($cols->width); ?>" required/><span style="color:red;font-size:10px;">Width</span>
                                                                                    </p> -->
                                                                                </div>

                                                                            </div>

                                                                            <?php elseif($cols->type=="placepicker"): ?>
                                                                                    <!-- Place picker -->

                                                                            <div class="uk-grid">
                                                                                <div class="uk-width-1-2" style="width:100%;">
                                                                                    <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                                                                                </div>
                                                                            </div>

                                                                        <?php elseif($cols->type=="line"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label" style="display: none;"></label>
                                                                                    <input type="text" class="input_line" readonly="">
                                                                                </div>
                                                                            </div>
                                                                        <?php elseif($cols->type=="textwithline"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;display:inherit;">
                                                                                    <label class="title_label" style="display: table-cell;white-space: nowrap;"><?php echo e($cols->title); ?></label>
                                                                                    <input type="text" class="input_line" readonly="">
                                                                                </div>
                                                                            </div>
                                                                        <?php elseif($cols->type=="emptyspace"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="left_setting" style="width:100%;">
                                                                                    <label class="title_label" style="display: none;">Empty space</label><br/>
                                                                                </div>
                                                                            </div>
                                                                        <?php elseif($cols->type=="component1"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field2 left_setting inspectionTable" style="width:100%;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>
                                                                                    <div class="title_component1 select">

                                                                                        <?php
                                                                                        $choice_array=$cols->choices;
                                                                                        ?>
                                                                                        <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                            <div class="clear row1">
                                                                                                <input type="hidden" name="component1"/>
                                                                                                <span class="optionbox" <?php if($cols->lrtype==1): ?> style="float:right" <?php else: ?> style="float:left" <?php endif; ?> >
                                                                                                    <b class="<?php echo e(($chres->checked==0 && $chres->checked!= '')  ? $imgclrgs : $imgclrg); ?>"></b>
                                                                                                    <b class="<?php echo e(($chres->checked==1)  ? $imgclrys : $imgclry); ?>"></b>
                                                                                                    <b class="<?php echo e(($chres->checked==2)  ? $imgclrrs : $imgclrr); ?>"></b>
                                                                                                </span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" ><?php echo e($chres->title); ?></span>
                                                                                            </div>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                    </div>
                                                                                    <div class="options" id="choices_<?php echo e($cols->formfieldid); ?>" style="display:none">
                                                                                        <div class="input_fields_wrap">
                                                                                            <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                            </a> -->
                                                                                            <element>
                                                                                                <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chindex=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                    <p>
                                                                                                        <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                               value="<?php echo e($chres->title); ?>"/>
                                                                                                        <?php if($chindex==0): ?>
                                                                                                            <span class="add-option add_field_button"></span>
                                                                                                        <?php else: ?>
                                                                                                            <span class="delete-option remove_field"></span>
                                                                                                        <?php endif; ?>
                                                                                                    </p>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                                            </element>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <input type="hidden" style="display:none" name="component1_style" id="component1_style" value="<?php echo e($cols->lrtype); ?>" />

                                                                            </div>
                                                                            <script>
                                                                                type ="<?php echo e($cols->type); ?>";
                                                                                //// comptField="<?php echo e($options); ?>";
                                                                                row_id="rows_<?php echo e($row+1); ?>";
                                                                                collength="<?php echo e($col+1); ?>";
                                                                                dialog = popup_initialize('choices_<?php echo e($cols->formfieldid); ?>','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_<?php echo e($cols->formfieldid); ?>',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                        <?php elseif($cols->type=="component2"): ?>
                                                                            <div class="uk-grid ">
                                                                                <div class="titl-field2 left_setting inspectionTable" style="width:100%;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>
                                                                                    <div class="title_component2 selects">
                                                                                        <div class="clear row1">
                                                                                            <input type="hidden" name="component2"/>
                                                                                            <label class="title_label1"><?php echo e($cols->subtitle); ?></label>
                                                                                        </div>
                                                                                    </div>
                                                                                    <input type="hidden" style="display:none" name="component2_style" id="component2_style" value="<?php echo e($cols->lrtype); ?>" />
                                                                                    <div class="title_component2 selects">
                                                                                        
                                                                                    </div>
                                                                                    <?php if(isset($cols->filepath)): ?>
                                                                                        <input type="hidden" class="filepath" value="<?php echo e($cols->filepath); ?>" />
                                                                                    <?php endif; ?>
                                                                                    <div class="title_component2 select">

                                                                                        <?php
                                                                                        $choice_array=$cols->choices;
                                                                                        ?>
                                                                                        <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                            <div class="clear row1">
                                                                                                <input type="hidden" name="component2"/>
                                                                                                <span class="optionbox" <?php if($cols->lrtype==1): ?> style="float:right" <?php else: ?> style="float:left" <?php endif; ?> >

                                                                                                    <b class="<?php echo e(($chres->checked==0 && $chres->checked!= '')  ? $imgclrgs : $imgclrg); ?>"></b>
                                                                                                    <b class="<?php echo e(($chres->checked==1)  ? $imgclrys : $imgclry); ?>"></b>
                                                                                                    <b class="<?php echo e(($chres->checked==2)  ? $imgclrrs : $imgclrr); ?>"></b>

                                                                                                </span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" ><?php echo e($chres->title); ?></span>
                                                                                            </div>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                    </div>

                                                                                </div>

                                                                                <div class="options" id="choices_<?php echo e($cols->formfieldid); ?>" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                        </a> -->
                                                                                        <element>

                                                                                            <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chindex=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                <p>
                                                                                                    <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                           value="<?php echo e($chres->title); ?>"/>
                                                                                                    <?php if($chindex==0): ?>
                                                                                                        <span class="add-option add_field_button"></span>
                                                                                                    <?php else: ?>
                                                                                                        <span class="delete-option remove_field"></span>
                                                                                                    <?php endif; ?>
                                                                                                </p>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                        </element>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="<?php echo e($cols->type); ?>";
                                                                                //// comptField="<?php echo e($options); ?>";
                                                                                row_id="rows_<?php echo e($row+1); ?>";
                                                                                collength="<?php echo e($col+1); ?>";
                                                                                dialog = popup_initialize('choices_<?php echo e($cols->formfieldid); ?>','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_<?php echo e($cols->formfieldid); ?>',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                        <?php elseif($cols->type=="component3"): ?>
                                                                            <div class="uk-grid ">
                                                                                <div class="titl-field2 left_setting inspectionTable" style="width:100%;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>
                                                                                    <div class="title_component3 select">
                                                                                        <?php
                                                                                        $choice_array=$cols->choices;
                                                                                        $choicecount=count($choice_array)-3;

                                                                                        ?>
                                                                                        <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                            <?php if($choicecount>$index): ?>
                                                                                                <div class="clear row1">
                                                                                                    <input type="hidden" name="component3"/>
                                                                                                    <span class="optionbox"  >

<b class="<?php echo e(($chres->checked==0  && $chres->checked!= '')  ? $imgclrgs : $imgclrg); ?>"  ></b>
<b class="<?php echo e(($chres->checked==1)  ? $imgclrys : $imgclry); ?>"></b>
<b class="<?php echo e(($chres->checked==2)  ? $imgclrrs : $imgclrr); ?>"></b>
                                                                                                    </span>
                                                                                                    <span class="inspectionTxt title_value" data-optionid="0" ><?php echo e($chres->title); ?></span>
                                                                                                </div>
                                                                                            <?php endif; ?>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


                                                                                    </div>


                                                                                    <div class="title_component3 selects">
                                                                                        <div class="clear row1">
                                                                                            <input type="hidden" name="component3"/>
                                                                                            <p>
                                                                                                <span >
                                                                                            <b class="<?php echo e(($choice_array[count($choice_array)-3]->checked==0 && $choice_array[count($choice_array)-3]->checked!= '')  ? $imgclrgs : $imgclrg); ?>"></b>
                                                                                            <b class="<?php echo e(($choice_array[count($choice_array)-3]->checked==1)  ? $imgclrys : $imgclry); ?>"></b>
                                                                                            <b class="<?php echo e(($choice_array[count($choice_array)-3]->checked==2)  ? $imgclrrs : $imgclrr); ?>"></b>
                                                                                                </span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" ><?php echo e($choice_array[count($choice_array)-3]->title); ?></span>
                                                                                            </p><p>
                                                                                                <span>
                                                                                            <b class="<?php echo e(($choice_array[count($choice_array)-2]->checked==0 && $choice_array[count($choice_array)-2]->checked!= '')  ? $imgclrgs : $imgclrg); ?>"></b>
                                                                                            <b class="<?php echo e(($choice_array[count($choice_array)-2]->checked==1)  ? $imgclrys : $imgclry); ?>"></b>
                                                                                            <b class="<?php echo e(($choice_array[count($choice_array)-2]->checked==2)  ? $imgclrrs : $imgclrr); ?>"></b>
                                                                                                </span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" ><?php echo e($choice_array[count($choice_array)-2]->title); ?></span>
                                                                                            </p><p>
                                                                                                <span>
                                                                                                   <b class="<?php echo e(($choice_array[count($choice_array)-1]->checked==0 && $choice_array[count($choice_array)-1]->checked!= '')  ? $imgclrgs : $imgclrg); ?>"></b>
                                                                                            <b class="<?php echo e(($choice_array[count($choice_array)-1]->checked==1)  ? $imgclrys : $imgclry); ?>"></b>
                                                                                            <b class="<?php echo e(($choice_array[count($choice_array)-1]->checked==2)  ? $imgclrrs : $imgclrr); ?>"></b>
                                                                                                </span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" ><?php echo e($choice_array[count($choice_array)-1]->title); ?></span>
                                                                                            </p><div style="float: right;margin-top: -14%;width: 91px;">

                                                                                                <?php if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!='')): ?>
                                                                                                    <img src="<?php echo e($cols->filepath); ?>" style="max-width: 92px;max-height: 60px;" />
                                                                                                <?php else: ?>
                                                                                                    <img src="<?php echo e(URL::asset('mighty/images/Might99171.PNG')); ?>" style="max-width: 92px;max-height: 60px;">
                                                                                                <?php endif; ?>

                                                                                                <?php if(isset($cols->filepath)): ?>
                                                                                                    <input type="hidden" class="filepath" value="<?php echo e($cols->filepath); ?>" />
                                                                                                <?php endif; ?>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="options" id="choices_<?php echo e($cols->formfieldid); ?>" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                        </a> -->
                                                                                        <element>

                                                                                            <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                <?php if($choicecount>$index): ?>
                                                                                                    <p>
                                                                                                        <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                               value="<?php echo e($chres->title); ?>"/>
                                                                                                        <?php if($index==0): ?>
                                                                                                            <span class="add-option add_field_button"></span>
                                                                                                        <?php else: ?>
                                                                                                            <span class="delete-option remove_field"></span>
                                                                                                        <?php endif; ?>
                                                                                                    </p>
                                                                                                <?php endif; ?>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                        </element>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="<?php echo e($cols->type); ?>";
                                                                                //// comptField="<?php echo e($options); ?>";
                                                                                row_id="rows_<?php echo e($row+1); ?>";
                                                                                collength="<?php echo e($col+1); ?>";
                                                                                dialog = popup_initialize('choices_<?php echo e($cols->formfieldid); ?>','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_<?php echo e($cols->formfieldid); ?>',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                        <?php elseif($cols->type=="component4"): ?>
                                                                            <?php
                                                                            $tireresult=$cols->tireresult;

                                                                            ?>
                                                                            <div class="uk-grid ">
                                                                                <div class="titl-field2 left_setting inspectionTable" style="width: 100%; border-bottom: 1px solid #000; ">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>
                                                                                    <div class="title_component4 select">
                                                                                        <div class="clear row1x">
                                                                                            <input type="hidden" name="component4"/>
                                                                                            <span class="comp4boxl spanlable title_label1"  ><?php echo e($cols->subtitle); ?></span>
                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($cols->subtitle); ?>" />
                                                                                            <div class="clear paddingBottom" style="height:30px;">
                                                                                                <!-- start -->
                                                                                                <div class="tire-condition">
        <span style="width:170px; float:left;">
	<b style="margin-left: 15px;" class="<?php echo e($imgclrg); ?>"></b>
<strong class="comp4boxl option1" style="display: block;font-size: 17px;" ><?php echo e($cols->option1); ?></strong>
<input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($cols->option1); ?>" />
	</span>
	<span style="width:170px; float:left;">
	<b style="margin-left: 15px;" class="<?php echo e($imgclry); ?>"></b>
	 <strong class="comp4boxl option2"  style="font-size: 17px;" ><?php echo e($cols->option2); ?></strong>
<input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($cols->option2); ?>" />
	</span>
	<span style="width:165px; float:left;">
	<b class="<?php echo e($imgclrr); ?>"></b>

        <strong class="comp4boxl option3"  style="font-size: 17px;" ><?php echo e($cols->option3); ?></strong>
<input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($cols->option3); ?>" />
	</span>
                                                                                                </div>

                                                                                                <?php
                                                                                                $choice_array=$cols->cm4rows;
                                                                                                ?>
                                                                                                <div class="tire-lflr">
                                                                                                    <div class="comp4rows"><div class="bordernone interior_inspec1 interior_inspecLeft">
<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">

<span style="display:block;width:20px;font-weight: bold;" class="comp4boxl fontF title_value4"  ><?php echo e($choice_array[0][0][0]->title); ?></span>
<input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][0][0]->title); ?>" />
</span>
<?php 
                                                                                                            $lf32=explode("/",$choice_array[0][0][1]->title);
                                                                                                            $lr32=explode("/",$choice_array[0][0][3]->title);
                                                                                                            $rf32=explode("/",$choice_array[0][1][1]->title);
                                                                                                            $rr32=explode("/",$choice_array[0][1][3]->title);
                                                                                                             ?>
                                                                                                            <span class="txt_bold_lower_case comp4boxl fontF title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px" ><?php echo e($tireresult->lf32); ?>/<?php echo e($lf32[1]); ?></span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][0][1]->title); ?>" />
                                                                                                            <span style="display:block;float:right;">
                                                                                                                <b class="<?php echo e(($tireresult->tdlf==0)  ? $smlimgclrgs : $smlimgclrg); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->tdlf==1)  ? $smlimgclrys : $smlimgclry); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->tdlf==2)  ? $smlimgclrrs : $smlimgclrr); ?>"></b>

                                                                                                            </span>
                                                                                                        </div>
                                                                                                        <div class="bordernone interior_inspec1 interior_inspecRight">
<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
<span style="display:block;width:20px;font-weight: bold;" class="comp4boxl fontF title_value4"  ><?php echo e($choice_array[0][0][2]->title); ?></span>
<input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][0][2]->title); ?>" />
</span>
                                                                                                            <span class="comp4boxl txt_bold_lower_case title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px"><?php echo e($tireresult->lr32); ?>/<?php echo e($lr32[1]); ?></span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][0][3]->title); ?>" />
                                                                                                            <span style="display:block;float:right;">
                                                                                                                      <b class="<?php echo e(($tireresult->tdlr==0)  ? $smlimgclrgs : $smlimgclrg); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->tdlr==1)  ? $smlimgclrys : $smlimgclry); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->tdlr==2)  ? $smlimgclrrs : $smlimgclrr); ?>"></b>

                                                                                                            </span>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="comp4rows">
                                                                                                        <div class="bordernone interior_inspec1 interior_inspecLeft">
                                                                                                        <span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
                                                                                                            <span style="display:block;width:20px;font-weight: bold;" class="comp4boxl fontF title_value4"  ><?php echo e($choice_array[0][1][0]->title); ?></span>
<input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][1][0]->title); ?>" />
</span>

                                                                                                            <span class="comp4boxl txt_bold_lower_case title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px"><?php echo e($tireresult->rf32); ?>/<?php echo e($rf32[1]); ?></span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][1][1]->title); ?>" />
                                                                                                            <span style="display:block;float:right;">
                                                                                                                <b class="<?php echo e(($tireresult->tdrf==0)  ? $smlimgclrgs : $smlimgclrg); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->tdrf==1)  ? $smlimgclrys : $smlimgclry); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->tdrf==2)  ? $smlimgclrrs : $smlimgclrr); ?>"></b>
                                                                                                            </span>
                                                                                                        </div>
                                                                                                        <div  class="bordernone interior_inspec1 interior_inspecRight">
                                                                                                        <span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
<strong style="display:block;width:20px;"> <span class="comp4boxl fontF title_value4" style="position:relative; float:right;right: -5px;display:block;width:67px"><?php echo e($choice_array[0][1][2]->title); ?></span><input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][1][2]->title); ?>" /></strong></span>
                                                                                                            <span class="comp4boxl txt_bold_lower_case title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px"><?php echo e($tireresult->rr32); ?>/<?php echo e($rr32[1]); ?></span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][1][3]->title); ?>" />
                                                                                                            <span style="display:block;float:right;">
                                                                                                               <b class="<?php echo e(($tireresult->tdrr==0)  ? $smlimgclrgs : $smlimgclrg); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->tdrr==1)  ? $smlimgclrys : $smlimgclry); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->tdrr==2)  ? $smlimgclrrs : $smlimgclrr); ?>"></b>
                                                                                                            </span>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>

                                                                                                <!-- end -->
                                                                                            </div></div>
                                                                                        <div class="clear row1x">
                                                                                            <div class="comp4rows" style="float: left">
                               <span style="margin-top: 15px;margin-left: 3px;text-align: center;padding:0px;width:100px;float:left;">
                                    <?php if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!='')): ?>
                                       <img src="<?php echo e($cols->filepath); ?>"   style="max-height: 200px;max-width: 100px;" />
                                   <?php else: ?>
                                       <img src="<?php echo e(URL::asset('mighty/images/rght_tire.png')); ?>" style="max-height: 200px;max-width: 100px;">
                                   <?php endif; ?>

								</span>
                                                                                                <?php if(isset($cols->filepath)): ?>
                                                                                                    <input type="hidden" class="filepath" value="<?php echo e($cols->filepath); ?>" />
                                                                                                <?php endif; ?>
                                                                                                <div class="bordernone interior_inspec padding_reset lessWidth" style="padding:0px;float:right; padding-top:15px;width:130px !important;">
                                                                                                    <div style="height:30px;margin-bottom:10px;">
                                                                                                        <h2 style="text-align:center;"><?php echo e($choice_array[0][2][0]->title); ?></h2>
                                                                                                        <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][2][0]->title); ?>" />
                                                                                                    </div>
                                                                                                    <div class="clear" id="c1" style="margin-top: 35px;text-align:right;width:110px; margin-bottom:10px;height:20px;">
                                                                                                        <span style="width:75px; display:block;float:right;">
                                                                                                            <b class="<?php echo e(($tireresult->wlf==0)  ? $smlimgclrgs : $smlimgclrg); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->wlf==1)  ? $smlimgclrys : $smlimgclry); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->wlf==2)  ? $smlimgclrrs : $smlimgclrr); ?>"></b>
                                                                                                        </span>
                      						<span width="29" class="txt_bold txtLeft">

                                                <span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;"><?php echo e($choice_array[0][2][1]->title); ?></span>
                                       <input type="text"  class="comp4boxi" style="display: none; " value="<?php echo e($choice_array[0][2][1]->title); ?>" />

                      						</span>

                                                                                                    </div>

                                                                                                    <div class="clear" id="c2" style="text-align:right;width:110px; margin-bottom:10px;height:20px;">
                                                                                                        <span style="width:75px; display:block;float:right;">
                                                                                                           <b class="<?php echo e(($tireresult->wrf==0)  ? $smlimgclrgs : $smlimgclrg); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->wrf==1)  ? $smlimgclrys : $smlimgclry); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->wrf==2)  ? $smlimgclrrs : $smlimgclrr); ?>"></b>
                                                                                                        </span>
                      						<span class="txt_bold txtLeft">
                      							                   <span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;"><?php echo e($choice_array[0][2][2]->title); ?></span>
                                       <input type="text"  class="comp4boxi" style="display: none; " value="<?php echo e($choice_array[0][2][2]->title); ?>" />
                      						</span>

                                                                                                    </div>

                                                                                                    <div class="clear" id="c3" style="text-align:right;width:110px; margin-bottom:10px;height:20px;">
                                                                                                        <span style="width:75px; display:block;float:right;">
                                                                                                            <b class="<?php echo e(($tireresult->wlr==0)  ? $smlimgclrgs : $smlimgclrg); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->wlr==1)  ? $smlimgclrys : $smlimgclry); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->wlr==2)  ? $smlimgclrrs : $smlimgclrr); ?>"></b>
                                                                                                        </span>
                      						<span class="txt_bold txtLeft">
                      							<span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;"><?php echo e($choice_array[0][2][3]->title); ?></span>
                                       <input type="text"  class="comp4boxi" style="display: none; " value="<?php echo e($choice_array[0][2][3]->title); ?>" />
                      						</span>

                                                                                                    </div>
                                                                                                    <div class="clear" id="c4" style="text-align:right;width:110px; margin-bottom:10px;height:20px;">
                                                                                                        <span style="width:75px; display:block;float:right;">
                                                                                                             <b class="<?php echo e(($tireresult->wrr==0)  ? $smlimgclrgs : $smlimgclrg); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->wrr==1)  ? $smlimgclrys : $smlimgclry); ?>"></b>
                                                                                                <b class="<?php echo e(($tireresult->wrr==2)  ? $smlimgclrrs : $smlimgclrr); ?>"></b>
                                                                                                        </span>
                      						<span class="txt_bold txtLeft">
                      							<span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;"><?php echo e($choice_array[0][2][4]->title); ?></span>
                                       <input type="text"  class="comp4boxi" style="display: none; " value="<?php echo e($choice_array[0][2][4]->title); ?>" />
                      						</span>

                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div style="float: left">
                                                                                                <div class="comp4rows interior_inspec" style="border-right: 2px solid #0e62af !important;border-left: 2px solid #0e62af !important;padding:0px;width:160px; padding:0 3px; float:left;">
                                                                                                    <div cellspacing="0" class="bordernone padding_reset" style="">
                                                                                                        <div style="text-align:center;margin-top:10px;">
                                                                                                            <h2 style="text-align:center;margin: 0 0 0px;"><?php echo e($choice_array[0][3][0]->title); ?></h2>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][0]->title); ?>" />
                                                                                                        </div>
                                                                                                        <div id="redBlock">
                                                                                                            <span style="float:left; width:16px;margin-right:2px;">
                                                                                                                <b class="<?php echo e($smlimgclrr); ?>"></b>
                                                                                                            </span>
                                                                                                            <h2 style="text-align:center;margin-top: 2px;margin: 0 0 0px;"><?php echo e($choice_array[0][3][1]->title); ?></h2>

                                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][1]->title); ?>" />
                                                                                                            <?php if(isset($cols->imgsecondpath)): ?>
                                                                                                                <input type="hidden" class="imgsecondpath" value="<?php echo e($cols->imgsecondpath); ?>" />
                                                                                                            <?php endif; ?>
                                                                                                            <div id="imgBottomMid" class="imgBottomMid" style="width:40px; height:36px;">
                                                                                                                <?php if(isset($cols->imgsecondpath) && ($cols->imgsecondpath!='undefined' && $cols->imgsecondpath!='')): ?>
                                                                                                                    <img src="<?php echo e($cols->imgsecondpath); ?>"style="max-height: 36px;max-width: 40px;" />
                                                                                                                <?php else: ?>
                                                                                                                    <img src="<?php echo e(URL::asset('mighty/images/symbol.png')); ?>" alt="symbol" style="max-width:40px;max-height: 36px;" id="image">
                                                                                                                <?php endif; ?>

                                                                                                            </div>

                                                                                                        </div>
                                                                                                        <div class="bordernone interior_inspec">
                                                                                                            <div class="beforeAfter">
                                                                                                                <strong  class="comp4boxl"  style="position:relative; left:30px;font-size: 12px;"><?php echo e($choice_array[0][3][2]->title); ?></strong>
                                                                                                                <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][2]->title); ?>" />
                                                                                                                &nbsp;&nbsp;

                                                                                                                <strong  class="comp4boxl"  style="position:relative; left:30px;font-size: 12px;"><?php echo e($choice_array[0][3][3]->title); ?></strong>
                                                                                                                <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][3]->title); ?>" />

                                                                                                            </div>
                                                                                                            <div style="width:100%;" class="clear">
                                                                                                                <div style="float:left;width:20px;">
                                 				<span style="width:20px;display:block; float:left; height:27px;">
                                 			<span class="comp4boxl txt_bold" colspan="2" style=""><?php echo e($choice_array[0][3][4]->title); ?></span>
                                           <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][4]->title); ?>" />

                                 				</span>
								 				<span style="width:20px;display:block; float:left; height:27px;">
								 					<span class="comp4boxl txt_bold" colspan="2" style=""><?php echo e($choice_array[0][3][5]->title); ?></span>
                                           <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][5]->title); ?>" />
								 				</span>
                                                                                                                </div>
                                                                                                                <div style="width:50px; float:left;margin-right:10px;margin-left: 10px">
                                                                                                                    <span class="white_box">&nbsp;<?php echo e($tireresult->before_lf); ?></span><br>
                                                                                                                    <span class="white_box">&nbsp;<?php echo e($tireresult->before_rf); ?></span></div>

                                                                                                                    <span class="white_box">&nbsp;<?php echo e($tireresult->oemspec_lf); ?></span><br>
                                                                                                                    <span class="white_box">&nbsp;<?php echo e($tireresult->oemspec_rf); ?></span>

                                                                                                            </div>
                                                                                                            <div style="width:100%;" class="clear">
                                                                                                                <div style="float:left;width:20px;">
                                 					<span style="width:20px;display:block; float:left; height:27px;">
                                 						<span class="comp4boxl txt_bold" colspan="2" style=""><?php echo e($choice_array[0][3][6]->title); ?></span>
                                           <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][6]->title); ?>" />
                                 					</span>
								 					<span style="width:20px;display:block; float:left; height:27px;">
								 					<span class="comp4boxl txt_bold" colspan="2" style=""><?php echo e($choice_array[0][3][7]->title); ?></span>
                                           <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][7]->title); ?>" />
								 					</span>
                                                                                                                </div>
                                                                                                                <div style="width:50px; float:left;margin-right:10px;margin-left: 10px">
                                                                                                                    <span class="white_box">&nbsp;<?php echo e($tireresult->before_lr); ?></span><br>
                                                                                                                    <span class="white_box">&nbsp;<?php echo e($tireresult->before_rr); ?></span>
                                                                                                                </div>&nbsp;
                                                                                                                <span class="white_box">&nbsp;<?php echo e($tireresult->oemspec_lr); ?></span><br>
                                                                                                                <span class="white_box">&nbsp;<?php echo e($tireresult->oemspec_rr); ?></span>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div style="float: left">
                                                                                                <div class="comp4rows interior_inspec" style="padding:0px;width:113px;float:left; padding: 0px 3px 10px 5px;">
                                                                                                    <div style="margin-top:15px;">

                                                                                                        <h2 class="comp4boxl titleFont" colspan="2" style="padding:0px;word-wrap: break-word !important;"><?php echo e($choice_array[0][4][0]->title); ?></h2>
                                                                                                        <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][4][0]->title); ?>" />

                                                                                                    </div>
                                                                                                    <div class="bordernone interior_inspec" style="width: 120px;">
                                                                                                        <div class="clear" id="b1" style="height:20px; margin-bottom:5px;">
                                                                                                            <span class="white_box_square" style="float:left;margin-right:5px;"><?php echo e($tireresult->alignment); ?></span>
                                                                                                            <span class="comp4boxl txtFont" ><?php echo e($choice_array[0][4][1]->title); ?></span>
                                                                                                            <input  class="comp4boxi" name="editComp_65" value="<?php echo e($choice_array[0][4][1]->title); ?>" style="width:45px;display:none;" maxlength="9" type="text">
                                                                                                        </div>
                                                                                                        <div class="clear" id="b2" style="height:20px; margin-bottom:5px;">
                                                                                                            <span class="white_box_square" style="float:left;margin-right:5px;"><?php echo e($tireresult->balance); ?></span>
                                                                                                            <span class="comp4boxl txtFont"  ><?php echo e($choice_array[0][4][2]->title); ?></span>
                                                                                                            <input class="comp4boxi" name="editComp_66" value="<?php echo e($choice_array[0][4][2]->title); ?>" style="width:45px;display:none;" maxlength="9" type="text">
                                                                                                        </div>
                                                                                                        <div class="clear" id="b3" style="height:20px; margin-bottom:5px;">
                                                                                                            <span><span class="white_box_square" style="float:left;margin-right:5px;"><?php echo e($tireresult->rotation); ?></span> </span>
                                                                                                            <span class="txtFont comp4boxl" id="comp_67"><?php echo e($choice_array[0][4][3]->title); ?></span>
                                                                                                            <input class="comp4boxi" name="editComp_67" value="<?php echo e($choice_array[0][4][3]->title); ?>" style="width:45px;display:none;" maxlength="9" type="text">
                                                                                                        </div>
                                                                                                        <div class="clear" id="b4" style="height:20px; margin-bottom:5px;">
                                                                                                            <span class="white_box_square" style="float:left;vertical-align:-3px;margin-right:5px;"><?php echo e($tireresult->newtire); ?></span>
                                                                                                            <span class="txtFont comp4boxl"><?php echo e($choice_array[0][4][4]->title); ?></span>
                                                                                                            <input class="comp4boxi"  value="<?php echo e($choice_array[0][4][4]->title); ?>" style="width:45px;display:none;" maxlength="9" type="text">
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>

                                                                                    </div>
                                                                                </div>

                                                                                <div class="options" id="choices" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                        </a> -->
                                                                                        <element>
                                                                                            <p>
                                                                                                <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                       value="Brakes (Pads / Shoes)"/>
                                                                                                <span class="add-option add_field_button"></span>
                                                                                            </p>
                                                                                        </element>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        <?php elseif($cols->type=="component5"): ?>
                                                                            <div class="uk-grid ">
                                                                                <div class="left_setting inspectionTable" style="width: 100%;border-bottom: 1px solid #000;padding-bottom: 28px;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>
                                                                                    <div class="title_component5 select">
                                                                                        <div class="clear " style="border-bottom:0px;">
                                                                                            <div style="padding: 0px 0px 0px 21px; border:0px;width:161px; float:left;">
                                                                                                <div class="bordernone interior_inspec">
                                                                                                    <div class="alignCenter clear paddingBottom" style="width:360px;">
                                                                                                        <span class="comp4boxl spanlable title_label1"  ><?php echo e($cols->subtitle); ?></span>
                                                                                                        <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($cols->subtitle); ?>" />
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="clear paddingBottom" style="width:310px; height:40px;">

<span class="clear"><b class="<?php echo e($imgclrg); ?>"></b>
<span class="txtFont comp4boxl option1" style="display:block;font-size: 20px !important;"><?php echo e($cols->option1); ?></span>

</span>
                                                                                                    <span class="clear"><b class="<?php echo e($imgclry); ?>"></b>
<span class="txtFont comp4boxl option2" style="line-height: 32px;display:block;font-size: 20px !important;" ><?php echo e($cols->option2); ?></span>

</span>
                                                                                                    <span class="clear"><b class="<?php echo e($imgclrr); ?>"></b>
<span class="txtFont comp4boxl option3" style="line-height: 32px;display:block;font-size: 20px !important;"  ><?php echo e($cols->option3); ?></span>

</span>
                                                                                                </div>
                                                                                                <div id="img" style="float: left;width: 70px;height: 70px;position: absolute;top: 60px;margin-left: 280px;; " align="center">

               		 	<span style=" position:relative;">
                             <?php if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!='')): ?>
                                <img src="<?php echo e($cols->filepath); ?>" style="margin-top: 22px;position:relative;top:20px;max-height: 95px;
max-width: 85px; " alt=""/>
                            <?php else: ?>
                                <img src="<?php echo e(URL::asset('mighty/images/inspect_Brakes.png')); ?>" style="position:relative;top:20px;" alt="">
                            <?php endif; ?>

                            <?php if(isset($cols->filepath)): ?>
                                <input type="hidden" class="filepath" value="<?php echo e($cols->filepath); ?>" />
                            <?php endif; ?>
						</span>
                                                                                                </div>
                                                                                                <?php
                                                                                                $choice_array=$cols->choices;

                                                                                                ?>
                                                                                                <div style="height:240px;top: 25px;position: relative;">
                                                                                                    <div class="clear" style="margin-top: 20px;text-align:right;width:160px; margin-bottom:10px;height:20px;">
<span style="width:120px; display:block;float:right;">
<b class="<?php echo e(($choice_array[0]->checked==0 && $choice_array[0]->checked!= '')  ? $imgclrgs : $imgclrg); ?>"></b>
<b class="<?php echo e(($choice_array[0]->checked==1)  ? $imgclrys : $imgclry); ?>"></b>
<b class="<?php echo e(($choice_array[0]->checked==2)  ? $imgclrrs : $imgclrr); ?>"></b>
</span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;"><?php echo e($choice_array[0]->title); ?></span>
<input class="comp4boxi" style="display: none;" value="<?php echo e($choice_array[0]->title); ?>" type="text">
</span>
                                                                                                    </div>
                                                                                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:160px; margin-bottom:10px;height:20px;">
<span style="width:120px; display:block;float:right;">
<b class="<?php echo e(($choice_array[1]->checked==0 && $choice_array[1]->checked!= '')  ? $imgclrgs : $imgclrg); ?>"></b>
<b class="<?php echo e(($choice_array[1]->checked==1)  ? $imgclrys : $imgclry); ?>"></b>
<b class="<?php echo e(($choice_array[1]->checked==2)  ? $imgclrrs : $imgclrr); ?>"></b>
</span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;"><?php echo e($choice_array[1]->title); ?></span>
<input class="comp4boxi" style="display: none;" value="<?php echo e($choice_array[1]->title); ?>" type="text">
</span>
                                                                                                    </div>
                                                                                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:160px; margin-bottom:10px;height:20px;">
<span style="width:120px; display:block;float:right;">
<b class="<?php echo e(($choice_array[2]->checked==0 && $choice_array[2]->checked!= '')  ? $imgclrgs : $imgclrg); ?>"></b>
<b class="<?php echo e(($choice_array[2]->checked==1)  ? $imgclrys : $imgclry); ?>"></b>
<b class="<?php echo e(($choice_array[2]->checked==2)  ? $imgclrrs : $imgclrr); ?>"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;"><?php echo e($choice_array[2]->title); ?></span>
<input class="comp4boxi" style="display: none;" value="<?php echo e($choice_array[2]->title); ?>" type="text">
</span>
                                                                                                    </div>
                                                                                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:160px; margin-bottom:10px;height:20px;">
<span style="width:120px; display:block;float:right;">
<b class="<?php echo e(($choice_array[3]->checked==0 && $choice_array[3]->checked!= '')  ? $imgclrgs : $imgclrg); ?>"></b>
<b class="<?php echo e(($choice_array[3]->checked==1)  ? $imgclrys : $imgclry); ?>"></b>
<b class="<?php echo e(($choice_array[3]->checked==2)  ? $imgclrrs : $imgclrr); ?>"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;"><?php echo e($choice_array[3]->title); ?></span>
<input class="comp4boxi" style="display: none;" value="<?php echo e($choice_array[3]->title); ?>" type="text">
</span>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="clear" style="width:500px;position: relative;top: 30px;">
							<span class="fontF" style="float:left;display:block; margin-left:11px;"> <strong>
                                    <span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;"><?php echo e($choice_array[4]->title); ?></span>
                                    <input class="comp4boxi" style="display: none;" value="<?php echo e($choice_array[4]->title); ?>" type="text">
                                </strong>

					  	</span>
					  	<span style="padding:0px;width:150px;float:left;display:block;margin-right:5px;margin-left:5px;">
							<div id="imgBottomLast" class="imgBottomLast" style="margin-top:-6px;margin-bottom: 5px;width: 150px;" align="center">
                                <?php if(isset($cols->imgsecondpath) && ($cols->imgsecondpath!='undefined' && $cols->imgsecondpath!='')): ?>
                                    <img src="<?php echo e($cols->imgsecondpath); ?>"alt="brands" style="max-height: 45px;max-width: 150px;" id="image" />
                                <?php else: ?>
                                    <img src="<?php echo e(URL::asset('mighty/images/brands.png')); ?>" alt="brands" style="max-height: 45px;max-width: 150px;" id="image">
                                <?php endif; ?>                           </div>
 						</span>
                                                                                                    <?php if(isset($cols->imgsecondpath)): ?>
                                                                                                        <input type="hidden" class="imgsecondpath" value="<?php echo e($cols->imgsecondpath); ?>" />
                                                                                                    <?php endif; ?>
                                                                                                    <span class="fontF" style="float:left;display:block"> <strong>
                                                                                                            <span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;"><?php echo e($choice_array[5]->title); ?></span>
                                                                                                            <input class="comp4boxi" style="display: none;" value="<?php echo e($choice_array[5]->title); ?>" type="text">
                                                                                                        </strong>
							</span>
                                                                                                    <span class="fontF" style="float:left;"> </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>

                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        <?php elseif($cols->type=="component6"): ?>
                                                                            <div class="uk-grid ">
                                                                                <div class="left_setting inspectionTable" style="width:100%;border-bottom: 1px solid #000;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>
                                                                                    <div class="title_component6 select">
                                                                                        <div class="clear ">
                                                                                            <input type="hidden" name="component6"/>
                                                                                            <div class="clear row1" style="height:27px;">
                                                                                            </div>
                                                                                            <div class="clear row1" style="height:27px;">
                                                                                            </div>
                                                                                            <div class="clear row1" style="height:27px;">
                                                                                            </div>
                                                                                            <div class="clear " style="height:27px;">
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        <?php elseif($cols->type=="component7"): ?>
                                                                            <div class="uk-grid ">
                                                                                <div class="titl-field2 left_setting inspectionTable" style="width:100%;border-bottom: 1px solid #000;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>

                                                                                    <div class="title_component7 selects">
                                                                                        <div class="clear ">
                                                                                            <input type="hidden" name="component7"/>
                                                                                            <?php
                                                                                            $chocies_array=$cols->choices;
                                                                                            ?>
                                                                                            <p style="margin-left: 5px; display: inline-block; ">
                                                                                                <span class="comp4boxl inspectionTxt title_value"data-optionid="0" ><?php echo e($chocies_array[0]->title); ?></span>
                                                                                                <input class="comp4boxi" style="display: none;height:40px;width: 300px !important;" value="<?php echo e($chocies_array[0]->title); ?>" type="text">
                                                                                                <br>
                                                                                                <span style="margin: 10px 40px; display: block;">
                                                                                                    <b class="<?php echo e(($chocies_array[0]->checked==0 && $chocies_array[0]->checked!= '')  ? $imgclrgs : $imgclrg); ?>"></b>
                                                                                                    <b class="<?php echo e(($chocies_array[0]->checked==1)  ? $imgclrys : $imgclry); ?>"></b>
                                                                                                    <b class="<?php echo e(($chocies_array[0]->checked==2)  ? $imgclrrs : $imgclrr); ?>"></b>
                                                                                                </span>
                                                                                            </p><div style="float: right;    margin: 20px;">
                                                                                                <?php if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!='')): ?>
                                                                                                    <img src="<?php echo e($cols->filepath); ?>"style="max-width: 92px;max-height: 60px;"/>
                                                                                                <?php else: ?>
                                                                                                    <img src="<?php echo e(URL::asset('mighty/images/Might99171.PNG')); ?>" style="max-width: 92px;max-height: 60px;">
                                                                                                <?php endif; ?>


                                                                                                <?php if(isset($cols->filepath)): ?>
                                                                                                    <input type="hidden" class="filepath" value="<?php echo e($cols->filepath); ?>" />
                                                                                                <?php endif; ?>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        <?php elseif($cols->type=="condition"): ?>

                                                                            <?php
                                                                            $choice_array=$cols->choices;
                                                                            ?>

                                                                            <div class="uk-grid">
                                                                                <div class="left_setting" style="width:100%;">
                                                                                    <div class="svgTable">

                                                                                        <ul class="condition-box widthzero">
                                                                                            <li>
                                                                                                <span><b class="green_checkbox"></b></span>
                                                                                                <strong class="floatLeft title_value" data-optionid="0"   style=""><?php echo e($choice_array[0]->title); ?></strong>
                                                                                            </li>
                                                                                            <li>
                                                                                                <span><b class="yellow_checkbox"></b></span>
                                                                                                <strong  class="floatLeft title_value" data-optionid="0"  style="" ><?php echo e($choice_array[1]->title); ?></strong>
                                                                                            </li>
                                                                                            <li>
                                                                                                <span><b class="red_checkbox"></b></span>
                                                                                                <strong class="floatLeft title_value" data-optionid="0"   style="" ><?php echo e($choice_array[2]->title); ?></strong>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        <?php elseif($cols->type=="condition2"): ?>
                                                                            <?php
                                                                            $choice_array=$cols->choices;
                                                                            ?>
                                                                            <div class="uk-grid">
                                                                                <div class="left_setting" style="width:100%;">
                                                                                    <div class="svgTable">

                                                                                        <ul class="condition-box">
                                                                                            <li>
                                                                                                <span><b class="<?php echo e($imgclrg); ?>"></b></span>
                                                                                                <strong class="floatLeft title_value" data-optionid="0"   style=""><?php echo e($choice_array[0]->title); ?></strong>
                                                                                            </li>
                                                                                            <li>
                                                                                                <span><b class="<?php echo e($imgclry); ?>"></b></span>
                                                                                                <strong  class="floatLeft title_value" data-optionid="0"  style="" ><?php echo e($choice_array[1]->title); ?></strong>
                                                                                            </li>
                                                                                            <li>
                                                                                                <span><b class="<?php echo e($imgclrr); ?>"></b></span>
                                                                                                <strong class="floatLeft title_value" data-optionid="0"   style="" ><?php echo e($choice_array[2]->title); ?></strong>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        <?php elseif($cols->type=="tablehead"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="uk-width-1-2" style="width:100%;">
                                                                                    <?php
                                                                                    $choice_array=$cols->choices;
                                                                                    ?>

                                                                                    <table class="tables_<?php echo e($col); ?> uk-table">
                                                                                        <tr>
                                                                                            <th class="th">ITEMS</th>
                                                                                            <th class="th table_content">CONDITION</th>
                                                                                        </tr>
                                                                                        <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                            <tr id="cnt_<?php echo e($ind); ?>rw<?php echo e($col); ?>">
                                                                                                <td class="th">
                                                                                                    <div class="title_tablehead select">
                                                                                                        <span><?php echo e($chres->title); ?></span>
                                                                                                    </div>
                                                                                                </td>
                                                                                                <td class="th">
                                                                                                    <span>
                                                                                                        <?php if($chres->checked==0 && $chres->checked != ''): ?>
                                                                                                            <img class="green_checkbox" src="<?php echo e(URL::asset('mighty/images/green_t.png')); ?>" style="max-width: 92px;max-height: 60px;">
                                                                                                            <?php else: ?>
                                                                                                            <b class="green_checkbox"></b>
                                                                                                            <?php endif; ?>
                                                                                                            <?php if($chres->checked==1): ?>
                                                                                                            <img class="yellow_checkbox" src="<?php echo e(URL::asset('mighty/images/yellow_t.png')); ?>" style="max-width: 92px;max-height: 60px;">
                                                                                                            <?php else: ?>
                                                                                                                <b class="yellow_checkbox"></b>
                                                                                                            <?php endif; ?>
                                                                                                            <?php if($chres->checked==2): ?>
                                                                                                                <img class="red_checkbox" src="<?php echo e(URL::asset('mighty/images/red_t.png')); ?>" style="max-width: 92px;max-height: 60px;">
                                                                                                            <?php else: ?>
                                                                                                                <b class="red_checkbox"></b>
                                                                                                            <?php endif; ?>
                                                                                                    </span>
                                                                                                </td>
                                                                                            </tr>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                    </table>
                                                                                </div>
                                                                            </div>

                                                                            <?php endif; ?>
                                                                                    <!--End -->
                                                                    </div>
                                                                </div>

                                                            </div></li>



                                                        <?php

                                                        $edFlag++;

                                                        }
                                                        ?>
                                                    </ul></li>
                                                <?php
                                                }
                                                }

                                                /*    }

                                                         }*/
                                                ?>

                                            </ul>
                                        </div>
                                    </div>
                                    <div id="wrapper">

                                        <div class="inn">
                                            <div class="inn-left">
                                                <ul></ul>
                                            </div>

                                            <div class="inn-right">
                                                <ul></ul>
                                            </div>

                                            <div class="comments">COMMENTS </div>

                                            <div style="float:left;">
                                                <p class="usercontent"><?php echo e($formdetails->comments); ?></p>
                                            </div>

                                            <div class="comments">SERVICES </div>

                                            <div style="float:left;">
                                                <p class="usercontent">
                                                    <?php if(isset($formdetails->service_results)): ?>
                                                    <?php $__currentLoopData = $formdetails->service_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                                        <?php echo e((isset($rs['serviceName'])) ? $rs['serviceName'] : ''); ?><?php echo e((isset($rs['packageName'])) ? ' ('.$rs['packageName'].'-'.$rs['packagePrice'].')' : ''); ?><br>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                     <?php endif; ?>
                                                </p>
                                            </div>

                                            <div class="photo-slider"><span> PHOTOS</span></div>
<?php
                                            $formdetails->damagImage;
                                            $damagImage=json_decode($formdetails->damagImage,true);

                                           ?>
                                            <div class="photo">
                                                <?php if($damagImage): ?>
                                                    <?php $__currentLoopData = $damagImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                        <img src="<?php echo e(URL::to('/mighty/images/car-image/'.$img.'')); ?>" />
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                <?php endif; ?>


                                            </div>
                                            <?php
                                            $carImage=json_decode($formdetails->carImage,true);
                                            ?>
                                            <?php if($carImage): ?>
                                            <div class="photo">


                                                    <?php $__currentLoopData = $carImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                        <p>   <img  style="float:none !important;" src="<?php echo e(URL::to('/mighty/images/car-image/'.$img['image'].'')); ?>" /><?php echo e($img['comments']); ?></p>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                            </div>
                                            <?php endif; ?>
                                            <div class="tech">
                                                <span style="float:left;">TECHNICIAN  &nbsp;</span>
                                                <span style="float:right; padding-right:50px;">DATE  &nbsp;</span>
                                            </div>

                                            <div class="sign">
                                                <img src="<?php echo e(URL::to('/mighty/images/car-image/'.$formdetails->signature.'')); ?>" width="150px" height="100px">
                                            </div>

                                            <div style="float:right; width:450px; text-align:right;">
                                                <div class="dat"><?php echo e(date("d-m-Y",strtotime($formdetails->inspection_date))); ?></div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>

                                <!-- </form> -->
                    </div>
                </div>
        </section>

</body>


</html>