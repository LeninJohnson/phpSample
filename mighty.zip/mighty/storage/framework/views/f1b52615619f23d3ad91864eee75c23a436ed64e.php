<?php $__env->startSection('customCss'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/plugins/select2/select2.min.css')); ?>">

    <style>
        .content {
        //   min-height: 1811px;
        }
    </style>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>

            <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Report
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(URL::to('')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="#">Mighty Assist</a></li>
            <li class="active">Report</li>
        </ol>
    </section>

    <?php if(Session::has('true_msg')): ?>
        <div style="padding: 4px;" class="row">
            <div class="col-md-6">
                <div   class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                    <?php echo e(Session::get('true_msg')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('error_msg')): ?>
        <div style="padding: 4px;" class="row">
            <div class="col-md-6">
                <div class="alert alert-danger">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    <?php echo e(Session::get('error_msg')); ?>

                </div> <!-- /.alert -->
            </div>
        </div>
        <?php endif; ?>
                <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">

                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Report Id</th>
                                    <th>Date</th>
                                    <th>Customer Name</th>
                                    <th>Technician Name</th>
                                    <th>Time</th>
                                    <th>VIN</th>
                                    <th>Make</th>
                                    <th>Model</th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $userprofile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$vals): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><a style="letter-spacing: 1px;text-decoration: underline;" href="<?php echo e(URL::to('api/v1/inspection-form/'.$vals->id.'')); ?>" target="_blank"><?php echo e($vals->id); ?></a></td>
                                        <td><?php echo e(date('d-m-Y',strtotime($vals->inspection_date))); ?></td>
                                        <td><?php echo e($vals->first_name); ?></td>
                                        <td><?php echo e($vals->technician); ?></td>
                                        <td><?php echo e($vals->duration); ?></td>
                                        <td><?php echo e($vals->vin); ?></td>
                                        <td><?php echo e($vals->make); ?></td>
                                        <td><?php echo e($vals->model); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tbody>

                            </table>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->


                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>


    <script src="<?php echo e(URL::asset('mighty/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('mighty/plugins/select2/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('mighty/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>


    <script>
        $(function () {
            $(".select2").select2();
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
            $('.confirm-delete').click(function(){
                var id = $(this).data('rid');
                var confirmMsg = confirm("Are you sure want to delete this Engine? You cannot undo this action");
                if(confirmMsg) {
                    window.location.href = "<?php echo e(URL::to('mighty-assist/engine/delete')); ?>/"+id;
                }
            });
            $('.addvideo').click(function(){
                $("#addrow").css('display','block');
            });
            $('#cancelvideo').click(function(){
                $("#addrow").css('display','none');
            });

            $("#year").on("change",function(e){
                var year = $("#year").val();
                if(year!='')
                {
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(URL::to('/mighty-assist/get-make')); ?>",
                        data: {
                            "year": year,

                        },
                        success: function(html)
                        {
                            var options='<option value="">Select</option>';
                            $.each(html,function(e,val){
                                options+='<option value="'+val.id+'">'+val.make+'</option>';
                            });
                            $("#make").html(options);
                        }
                    });
                }else{
                    var options='<option value="">Select</option>';
                    $("#make").html(options);
                }

            });

            $("#make").on("change",function(e){
                var make = $("#make").val();
                if(make!='')
                {
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(URL::to('/mighty-assist/get-model')); ?>",
                        data: {
                            "make": make,

                        },
                        success: function(html)
                        {
                            var options='<option value="">Select</option>';
                            $.each(html,function(e,val){
                                options+='<option value="'+val.id+'">'+val.model+'</option>';
                            });
                            $("#model").html(options);
                        }
                    });
                }else{
                    var options='<option value="">Select</option>';
                    $("#model").html(options);
                }

            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mighty.layout.tpl', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>