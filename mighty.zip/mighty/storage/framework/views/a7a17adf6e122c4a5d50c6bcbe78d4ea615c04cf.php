<?php $__env->startSection('customCss'); ?>
    <style>
        .content {
        //    min-height: 1811px;
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            View Active Services
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(URL::to('')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="#">Services</a></li>
            <li class="active">View Services</li>
        </ol>
    </section>

    <?php if(Session::has('true_msg')): ?>
        <div style="padding: 4px;" class="row">
            <div class="col-md-6">
            <div   class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                <?php echo e(Session::get('true_msg')); ?>

            </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('error_msg')): ?>
        <div style="padding: 4px;" class="row">
            <div class="col-md-6">
                <div class="alert alert-danger">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    <?php echo e(Session::get('error_msg')); ?>

                </div> <!-- /.alert -->
            </div>
        </div>
    <?php endif; ?>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">View Active Services</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Service</th>
                                <th>Description</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$vals): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($vals->name); ?>

                                </td>
                                <td><?php echo e($vals->description); ?>

                                </td>
                                <td>
                             <a href="<?php echo e(URL::to('/mighty-assist/services/edit')); ?>/<?php echo e($vals->id); ?>" class="tabledit-edit-button btn btn-sm btn-primary"  ><i class="fa fa-edit"></i>
                                    </a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->


                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>


    <script src="<?php echo e(URL::asset('mighty/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('mighty/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>


    <script>
        $(function () {
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mighty.layout.tpl', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>