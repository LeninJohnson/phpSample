<?php $__env->startSection('customCss'); ?>
    <style>
        .content {
        // min-height: 1811px;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/plugins/select2/select2.min.css')); ?>">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>

            <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Model
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(URL::to('')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="#">Mighty Assist</a></li>
            <li class="active">Edit Model</li>
        </ol>
    </section>
    <?php if(Session::has('true_msg')): ?>
        <div style="padding: 4px;"  class="row">
            <div class="col-md-6">
                <div class="alert alert-success">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    <?php echo e(Session::get('true_msg')); ?>

                </div> <!-- /.alert -->
            </div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('error_msg')): ?>
        <div class="row">
            <div class="col-md-6">
                <div class="alert alert-danger">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    <?php echo e(Session::get('error_msg')); ?>

                </div> <!-- /.alert -->
            </div>
        </div>
    <?php endif; ?>
    <section class="content">
        <div   class="row">
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Model</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" method="post" enctype="multipart/form-data" >
                        <div class="box-body">
                            <div class="form-group">
                                <label>Year</label>
                                <select class="form-control select2"  name="year" id="year" style="width: 100%;" required>
                                    <option value="">Select</option>
                                    <?php for($a=0;$a<=95;$a++): ?>
                                        <option value="<?php echo e(date("Y")-$a); ?>" <?php if($carmodels->make_year==date("Y")-$a): ?> selected <?php endif; ?> ><?php echo e(date("Y")-$a); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Make</label>
                                <select class="form-control select2"  name="make" id="make" style="width: 100%;" required>
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = $carmake; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <option value="<?php echo e($res->id); ?>" <?php if($carmodels->make_id==$res->id): ?> selected <?php endif; ?> ><?php echo e($res->make); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="model">Model</label>
                                <input class="form-control" name="model" maxlength="20" type="text" value="<?php echo e($carmodels->model); ?>"required />
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea class="form-control" name="description"  ><?php echo e($carmodels->description); ?></textarea>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-default">Cancel</a>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>

    <script src="<?php echo e(URL::asset('mighty/plugins/select2/select2.full.min.js')); ?>"></script>

    <script>
        $(function () {
            $(".select2").select2();

            $("#year").on("change",function(e){
                var year = $("#year").val();
                if(year!='')
                {
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(URL::to('/mighty-assist/get-make')); ?>",
                        data: {
                            "year": year,

                        },
                        success: function(html)
                        {
                            var options='<option value="">Select</option>';
                            $.each(html,function(e,val){
                                options+='<option value="'+val.id+'">'+val.make+'</option>';
                            });
                            $("#make").html(options);
                        }
                    });
                }else{
                    var options='<option value="">Select</option>';
                    $("#make").html(options);
                }

            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mighty.layout.tpl', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>