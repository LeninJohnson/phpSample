<?php $__env->startSection('customCss'); ?>
    <style>
        .content {
        // min-height: 1811px;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/plugins/select2/select2.min.css')); ?>">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>

            <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Make
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(URL::to('')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="#">Mighty Assist</a></li>
            <li class="active">Edit Make</li>
        </ol>
    </section>
    <?php if(Session::has('true_msg')): ?>
        <div style="padding: 4px;"  class="row">
            <div class="col-md-6">
                <div class="alert alert-success">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    <?php echo e(Session::get('true_msg')); ?>

                </div> <!-- /.alert -->
            </div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('error_msg')): ?>
        <div class="row">
            <div class="col-md-6">
                <div class="alert alert-danger">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    <?php echo e(Session::get('error_msg')); ?>

                </div> <!-- /.alert -->
            </div>
        </div>
    <?php endif; ?>
    <section class="content">
        <div   class="row">
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Make</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" method="post"  enctype="multipart/form-data" >
                        <div class="box-body">
                            <div class="form-group">
                                <label>Year</label>
                                <select class="form-control select2"  name="year" style="width: 100%;">
                                    <option value="">Select</option>
                                    <?php for($a=0;$a<=95;$a++): ?>
                                        <option value="<?php echo e(date("Y")-$a); ?>" <?php if($carmake->make_year==date("Y")-$a): ?> selected <?php endif; ?>><?php echo e(date("Y")-$a); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="model">Make</label>
                                <input class="form-control" name="make" maxlength="20" type="text" value="<?php echo e($carmake->make); ?>" required />
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea class="form-control" name="description"  ><?php echo e($carmake->description); ?></textarea>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-default">Cancel</a>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>


    <script src="<?php echo e(URL::asset('mighty/plugins/select2/select2.full.min.js')); ?>"></script>


    <script>
        $(function () {
            $(".select2").select2();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mighty.layout.tpl', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>