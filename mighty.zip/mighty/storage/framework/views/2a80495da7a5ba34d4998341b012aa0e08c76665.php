<div id="templates">
    <!-- Text Box Templates-->
    <div id="config_text" style="display : none">
        <div class="portlet-header" data-type="text" data-fieldid="1">
            <!--<input type="text" />-->
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label" style="width:100%;display:table">Single Line Text</label>
                    <input type="text" readonly style="display:table"/>
                </div>
                <div class="action hover-icons right_setting" style="display:none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="uncheck-grey check "></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>
    <!-- Heading Templates-->
    <div id="config_heading" style="display : none">
        <div class="portlet-header" data-type="heading" data-fieldid="17">
            <!--<input type="text" />-->
            <div class="uk-grid" style="text-align: center;">
                <div class="left_setting">
                    <label class="title_label">Heading</label>
                </div>
                <div class="action hover-icons right_setting" style="display:none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>
    <!-- Email Controls -->
    <div id="config_email" style="display : none">
        <div class="portlet-header" data-type="email" data-fieldid="10">
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label" style="width:100%;display:table">Email</label>
                    <input type="email" readonly style="display:table"/>
                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="uncheck-grey check "></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>
    <!-- Number Controls -->
    <div id="config_number" style="display : none">
        <div class="portlet-header" data-type="number" data-fieldid="18">
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label" style="width:100%;display:table">Number</label>
                    <input type="number" readonly style="display:table"/>
                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="uncheck-grey check "></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>
    <!-- Date controls -->
    <div id="config_date" style="display : none">
        <div class="portlet-header" data-type="date" data-fieldid="4">
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label" style="width:100%;display:table">Date</label>
                    <input type="text" readonly style="display:table"/>
                    <input type="hidden" id="date_format" value=""/>
                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="open_options options-icon"></span>
                    <span class="uncheck-grey check "></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
                <div class="options" id="choices" style="display:none">
                    <div class="input_fields_wrap">
                        <select style="padding:4px 6px;" class="uk-form-select" name="date_format" id="date_formats">
                            <option value="MM/dd/yyyy">MM/DD/YYYY</option>
                            <option value="dd/MM/yyyy">DD/MM/YYYY</option>
                            <option value="yyyy/MM/dd">YYYY/MM/DD</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Time controls -->
    <div id="config_time" style="display : none">
        <div class="portlet-header" data-type="time" data-fieldid="5">
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label" style="width:100%;display:table">Time</label>
                    <input type="text" readonly style="display:table">
                    <input type="hidden" id="time_format" value=""/>
                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="open_options options-icon"></span>
                    <span class="uncheck-grey check "></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
                <div class="options" id="choices" style="display:none">
                    <div class="input_fields_wrap">
                        <select style="padding:4px 6px;" class="uk-form-select" name="time_format" id="time_formats">
                            <option value="hh:mm:ss">12 Hrs</option>
                            <option value="HH:mm:ss">24 Hrs</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Signature -->
    <div id="config_signature" style="display : none">
        <div class="portlet-header" data-type="signature" data-fieldid="16">
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label">Signature</label>
                    <br/>
                    <input type="text" readonly style="display:table">
                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="uncheck-grey check "></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>

    <!-- Radio Button Templates -->
    <div id="config_radio" style="display : none">
        <div class="portlet-header" data-type="radio" data-fieldid="2">
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label">Radio</label><br/>
                    <div class="title_radio select">
                        <input type="radio" name="radio"/><span class="title_value" data-optionid="0">Yes</span>
                        <input type="radio" name="radio"/><span class="title_value" data-optionid="0">No</span>
                    </div>
                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="open_options options-icon"></span>
                    <span class="uncheck-grey check "></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
                <div class="options" id="choices" style="display:none">
                    <div class="input_fields_wrap">
                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                        </a> -->
                        <element>
                            <p>
                                <input type="text" name="select[]" class="select_label" data-optionid="0" value="Yes"/>
                            </p>
                            <p>
                                <input type="text" name="select[]" class="select_label" data-optionid="0"
                                       value="No"/><span class="add-option add_field_button"></span>
                            </p>
                        </element>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Check Box Templates -->
    <div id="config_checkbox" style="display : none">
        <div class="portlet-header" data-type="checkbox" data-fieldid="3">
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label">Multi choice</label><br/>
                    <label class="title_label1">Sub heading</label>
                    <div class="title_checkbox select">
                        <input type="checkbox"/>
                        <span class="title_value" data-optionid="0">First Option</span>
                    </div>
                    <div class="options" id="choices" style="display:none">
                        <div class="input_fields_wrap">
                            <!--  <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                             <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                             </a> -->
                            <element>
                                <p>
                                    <input type="text" name="select[]" class="select_label" data-optionid="0"
                                           value="First Option"/><span class="add-option add_field_button"></span>
                                </p>
                            </element>
                        </div>
                    </div>
                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="open_options options-icon"></span>
                    <span class="uncheck-grey check "></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>
    <!-- Select dropdown Templates -->
    <div id="config_select" style="display : none">
        <div class="portlet-header" data-type="select" data-fieldid="8">
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label">Single Select Label</label><br/>
                    <div class="select">
                        <select>
                            <option>
                                    <span class="title_value" data-optionid="0">
                                    First Option
                                    </span>
                            </option>
                            <option>
                                    <span class="title_value" data-optionid="0">
                                    Second Option
                                    </span>
                            </option>
                        </select>
                    </div>
                    <div class="options" id="choices" style="display:none">
                        <div class="input_fields_wrap">
                            <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                            </a> -->
                            <element>
                                <p>
                                    <input type="text" name="select[]" class="select_label" data-optionid="0"
                                           value="First Option"/>
                                </p>
                                <p>
                                    <input type="text" name="select[]" class="select_label" data-optionid="0"
                                           value="Second Option"/>
                                    <span class="add-option add_field_button"></span>
                                </p>
                            </element>
                        </div>
                    </div>
                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <input type="hidden" class="formfieldid" value="0"/>
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="open_options options-icon"></span>
                    <span class="uncheck-grey check "></span>
                </div>
            </div>
        </div>
    </div>
    <!-- TextArea Templates -->
    <div id="config_textarea" style="display : none">
        <div class="portlet-header" data-type="textarea" data-fieldid="6">
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label">Multi Line Text</label><br/>
                    <textarea style="resize: none;height: 40px; width: 200px;" readonly></textarea>
                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="uncheck-grey check "></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>
    <!-- File Select Templates -->
    <div id="config_file" style="display : none">
        <div class="portlet-header" data-type="file" data-fieldid="11">
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label">File Upload</label><br/>
                    <!-- image popip start -->
                     <button style="float:left" type="button" class="btn btn-default" data-toggle="modal" data-target="#imagefiles">
                         Choose image
                    </button>
                    <div class="dirimgs"> <img class="fileshow" /></div>
                    <div class="modal fade" id="imagefiles" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Choose image</h4>
                                </div>
                                <div class="modal-body" style="height: 200px;
    overflow-y: auto;">
                                    <div>

                                           <div>
                                               <label  style="display: block;">Upload your own image</label>
                                               <input  style="float:left;" type="file" class="imagefiles files" onchange="readURL(this,'showing','removeicon');" name="imagefiles"  />

                                           </div>
                                        <button style="display:none;" type="button" id="removeicon"  onclick="removeFile('imagefiles',this,'showing');" class="tabledit-delete-button btn btn-sm btn-default">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </button>


                                    </div>
                                    <div style="clear:both;"></div>
                                    <br>
                                    <div>
                                        <div style="float: left;margin-right: 23px;
">
                                            <button type="button" class="btn btn-default" data-toggle="modal" onclick="setShowimage('showing');" data-target="#myModal">
                                                Choose from existing images:
                                            </button>
                                        </div>

                                        <div id="showing" data-show="fileshow" data-fname="imagefiles" data-remov="removeicon" style="float: left">

                                        </div>

                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- image popup end -->

                    <br>
                    <p style="padding: 14px;">
                        <input type="hidden" class="height" name="height"  style="height: 22px;width: 78px;"
                               maxlength="3" minlength="1" value="75" required/><span style="display:none;color:red;font-size:10px;">Height</span>
                        <input type="hidden" class="width" name="width"  style="height: 22px;width: 78px;"
                               maxlength="3" minlength="1" value="75" required/><span style="display:none;color:red;font-size:10px;">Width</span>
                    </p>
                    <!--                 <input type="file" disabled="true" />name="file_name[]"-->
                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="uncheck-grey check "></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                    <input type="hidden" class="filepath showing" value="">
                </div>
            </div>
        </div>
    </div>
    <!-- Comment Line Templates-->
    <div id="config_line" style="display : none">
        <div class="portlet-header" data-type="line" data-fieldid="19">
            <!--<input type="text" />-->
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label" style="display: none;">Comment Line</label>
                    <hr class="cmdline"></hr>
                </div>
                <div class="action hover-icons right_setting" style="display:none;" id="edits">
                    <span class="delete_field"></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>
    <!-- Text with line Templates-->
    <div id="config_textwithline" style="display : none">
        <div class="portlet-header" data-type="textwithline" data-fieldid="20">
            <!--<input type="text" />-->
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label">Text With line</label>
                    <hr class="cmdline"></hr>
                </div>
                <div class="action hover-icons right_setting" style="display:none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>
    <!-- emptyspace Templates-->
    <div id="config_emptyspace" style="display : none">
        <div class="portlet-header" data-type="emptyspace" data-fieldid="18">
            <!--<input type="text" />-->
            <div class="uk-grid">
                <div class="left_setting">
                    <label class="title_label" style="display: none;">Empty space</label><br/>
                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>

    <!-- Place picker -->
    <div id="config_placepicker" style="display : none">
        <div class="portlet-header" data-type="placepicker" data-fieldid="15">
            <div class="uk-grid">
                <div class="uk-width-1-2">
                    <label class="title_label">Place picker</label><br/>
                </div>
                <div class="uk-width-1-2 action" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <!--<i class="uk-icon-edit edit_field"></i>--> <input type="hidden" class="formfieldid" value="0"/>
                    <input type="checkbox" id="placepicker_check" class="required" data-type=class="required"
                           data-type=/>Required
                </div>
            </div>
        </div>
    </div>
    <!-- UNDER VEHICLE row -->
    <div id="config_component1" style="display : none">
        <div class="portlet-header" data-type="component1" data-fieldid="23">
            <div class="uk-grid ">
                <div class="left_setting inspectionTable">
                    <div class="clear row1 row1Title"> <label class="title_label">UNDER VEHICLE </label><br/> </div>
                    <div class="title_component1 select">
                        <div class="clear row1">
                            <input type="hidden" name="component1"/>
                            <span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
                            <span class="inspectionTxt title_value" data-optionid="0" >Brakes (Pads / Shoes)</span>
                        </div>
                     </div>
                </div> <input type="hidden" style="display:none" name="component1_style" id="component1_style" value="0" />
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="open_options options-icon"></span>
                    <span class="uncheck-grey check "></span>
                    <span class="lrchange" data-vals="component1_style" style="cursor: pointer"></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
                <div class="options" id="choices" style="display:none">
                    <div class="input_fields_wrap">
                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                        </a> -->
                        <element>
                          <p>
                                <input type="text" name="select[]" class="select_label" data-optionid="0"
                                       value="Brakes (Pads / Shoes)"/>
                                <span class="add-option add_field_button"></span>
                            </p>
                        </element>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="config_component2" style="display : none">
        <div class="portlet-header" data-type="component2" data-fieldid="26">
            <div class="uk-grid ">
                <div class="left_setting titl-field2  inspectionTable">
                    <div class="clear row1 row1Title"><label class="title_label">INTERIOR/EXTERIOR</label><br/> </div>
                    <div class="title_component2 selects">
                        <div class="clear row1">
                            <input type="hidden" name="component2"/>
                            <label class="title_label1">NOTE ANY EXISTING EXTERIOR BODY DAMAGE OR DEFECTS ON DIAGRAM</label>
                        </div>
                    </div>
                    <input type="hidden" style="display:none" name="component2_style" id="component2_style" value="0" />
                    <div class="title_component2 selects">
                        <div class="clear row1">
                            <input type="hidden" name="component2"/>
                            <span class="alignCenter" style="display:block; height:120px;">
											<img class="fileshow" src="<?php echo e(URL::asset('mighty/images/car_3view.png')); ?>" alt="" style="max-width: 247px;max-height:116px;">
										</span>
                            <!-- image popip start -->
                            <button type="button" class="btn btn-default" data-toggle="modal" data-target="#imagefiles">
                                Choose image
                            </button>
                            <div class="modal fade" id="imagefiles" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title" id="myModalLabel">Choose image</h4>
                                        </div>
                                        <div class="modal-body" style="height: 200px;
    overflow-y: auto;">
                                            <div>

                                                <div>
                                                    <label  style="display: block;">Upload your own image</label>
                                                    <input  style="float:left;" type="file" class="imagefiles files" onchange="readURL(this,'showing','removeicon');" name="imagefiles"  />

                                                </div>
                                                <button style="display:none;" type="button" id="removeicon"  onclick="removeFile('imagefiles',this,'showing');" class="tabledit-delete-button btn btn-sm btn-default">
                                                    <span class="glyphicon glyphicon-trash"></span>
                                                </button>


                                            </div>
                                            <div style="clear:both;"></div>
                                            <br>
                                            <div>
                                                <div style="float: left;margin-right: 23px;
">
                                                    <button type="button" class="btn btn-default" data-toggle="modal" onclick="setShowimage('showing');" data-target="#myModal">
                                                        Choose from existing images:
                                                    </button>
                                                </div>

                                                <div id="showing" data-show="fileshow" data-fname="imagefiles" data-remov="removeicon" style="float: left">

                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!-- image popup end -->[247 x 116]
                        </div>
                    </div>
                    <div class="title_component2 select">
                        <div class="clear row1">
                            <input type="hidden" name="component2"/>
                            <span class="optionbox"><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
                            <span class="inspectionTxt title_value" data-optionid="0" >Exterior Body</span>
                        </div>
                    </div>

                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="open_options options-icon"></span>

                    <span class="uncheck-grey check "></span>
                    <span class="lrchange" data-vals="component2_style" style="cursor: pointer"></span>
                    <input type="hidden" class="formfieldid" value="0"/>
                    <input type="hidden" class="filepath showing" value="">
                </div>
                <div class="options" id="choices" style="display:none">
                    <div class="input_fields_wrap">
                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                        </a> -->
                        <element>
                            <p>
                                <input type="text" name="select[]" class="select_label" data-optionid="0"
                                       value="Exterior Body"/> </p>

                            <p>   <input type="text" name="select[]" class="select_label" data-optionid="0"
                                       value="Windshield / Glass"/>
                                <span class="add-option add_field_button"></span>
                            </p>
                        </element>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="config_component3" style="display : none">
        <div class="portlet-header" data-type="component3" data-fieldid="27">
            <div class="uk-grid ">
                <div class="left_setting inspectionTable">
                    <div class="clear row1 row1Title"> <label class="title_label">UNDERHOOD</label><br/> </div>
                    <div class="title_component3 select">
                        <div class="clear row1">
                            <input type="hidden" name="component3"/>
                            <span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
                            <span class="inspectionTxt title_value" data-optionid="0" >Engine Oil</span>
                        </div>
                    </div>
                    <div class="title_component3 selects">
                        <div class="clear row1">
                            <input type="hidden" name="component3"/>
                            <p>
                            <span ><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
                            <span class="inspectionTxt title_value" data-optionid="0" >Battery Charge</span>
                            </p><p>
                            <span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
                            <span class="inspectionTxt title_value" data-optionid="0" >Battery Condition</span>
                            <div style="float: right;margin-top: -11%;width: 91px;margin-right: 21px;">
                                <img class="fileshow" src="<?php echo e(URL::asset('mighty/images/Might99171.PNG')); ?>" style="max-width: 92px;max-height: 60px;margin-left: 29px;">
                                <!-- image popip start -->
                                <button type="button" class="btn btn-default" data-toggle="modal" data-target="#imagefiles">
                                    Choose image
                                </button>
                                <div class="modal fade" id="imagefiles" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                <h4 class="modal-title" id="myModalLabel">Choose image</h4>
                                            </div>
                                            <div class="modal-body" style="height: 200px;
    overflow-y: auto;">
                                                <div>

                                                    <div>
                                                        <label  style="display: block;">Upload your own image</label>
                                                        <input  style="float:left;" type="file" class="imagefiles files" onchange="readURL(this,'showing','removeicon');" name="imagefiles"  />

                                                    </div>
                                                    <button style="display:none;" type="button" id="removeicon"  onclick="removeFile('imagefiles',this,'showing');" class="tabledit-delete-button btn btn-sm btn-default">
                                                        <span class="glyphicon glyphicon-trash"></span>
                                                    </button>


                                                </div>
                                                <div style="clear:both;"></div>
                                                <br>
                                                <div>
                                                    <div style="float: left;margin-right: 23px;
">
                                                        <button type="button" class="btn btn-default" data-toggle="modal" onclick="setShowimage('showing');" data-target="#myModal">
                                                            Choose from existing images:
                                                        </button>
                                                    </div>

                                                    <div id="showing" data-show="fileshow" data-fname="imagefiles" data-remov="removeicon" style="float: left">

                                                    </div>

                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <!-- image popup end -->[92 x 62]
                            </div>
                            </p><p>
                            <span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
                            <span class="inspectionTxt title_value" data-optionid="0" >Cables & Connections</span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="hover-icons action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                    <span class="open_options options-icon"></span>
                    <span class="uncheck-grey check "></span>

                    <input type="hidden" class="formfieldid" value="0"/>
                    <input type="hidden" class="filepath showing" value="">
                </div>
                <div class="options" id="choices" style="display:none">
                    <div class="input_fields_wrap">
                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                        </a> -->
                        <element>
                            <p>   <input type="text" name="select[]" class="select_label" data-optionid="0"
                                         value="Engine Oil"/> </p>
                             <p>
                                <input type="text" name="select[]" class="select_label" data-optionid="0"
                                       value="Brake Fluid"/>
                                <span class="add-option add_field_button"></span>
                            </p>
                        </element>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="config_component4" style="display : none">
        <div class="portlet-header" data-type="component4" data-fieldid="28">
            <div class="uk-grid ">
                <div class="left_setting inspectionTable" style="width: 97%;border-bottom: 1px solid #000;">
                    <div class="clear row1 row1Title"> <label class="title_label">TIRES</label><br/> </div>
                    <div class="title_component4 select">
                        <div class="clear row1x">
                            <input type="hidden" name="component4"/>
                            <span class="comp4boxl spanlable title_label1"  >Tread Depth</span>
                            <input type="text"  class="comp4boxi" style="display:none;height: 20px;width: 350px !important;" value="Tread Depth" />
                            <div class="clear paddingBottom" style="width:400px; height:30px;">
                                <!-- start -->
	<span style="width:135px; float:left;">
	<b class="greenCircle"></b>
<span class="comp4boxl fontF option1"  >7/32" or greater</span>
<input type="text"  class="comp4boxi" style="display:none;height: 20px;width: 98px !important;" value="7/32 or greater" />
	</span>
	<span style="width:127px; float:left;">
	<b class="yellowCircle"></b>
	 <span class="comp4boxl fontF option2"  >3/32 to 6/32</span>
<input type="text"  class="comp4boxi" style="display:none; height:20px;width: 98px !important;" value="3/32 to 6/32" />
	</span>
	<span style="width:129px; float:left;">
	<b class="redCircle"></b>

        <span class="comp4boxl fontF option3"  >2/32  or less</span>
<input type="text"  class="comp4boxi" style="display:none; height:20px;width: 98px !important;" value="2/32  or less" />
	</span>
                                <div class="comp4rows"><div class="bordernone interior_inspec1 interior_inspecLeft">
<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">

<span style="display:block;width:20px;font-weight: bold;" class="comp4boxl fontF title_value4"  >LF</span>
<input type="text"  class="comp4boxi" style="display:none; height:20px;width: 30px !important;" value="LF" />
</span>

                                        <span class="txt_bold_lower_case comp4boxl fontF title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px" >____/32</span>
                                        <input type="text"  class="comp4boxi" style="display:none;position:relative; left:-5px;float:right; height:20px;width: 65px !important;" value="____/32" />
                                        <span style="display:block;float:right;"><b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b></span>
                                    </div>
                                    <div class="bordernone interior_inspec1 interior_inspecRight">
<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
<span style="display:block;width:20px;font-weight: bold;" class="comp4boxl fontF title_value4"  >LR</span>
<input type="text"  class="comp4boxi" style="display:none;height:20px;width: 30px !important;" value="LR" />
</span>
                                        <span class="comp4boxl txt_bold_lower_case title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px">____/32</span>
                                        <input type="text"  class="comp4boxi" style="display:none;position:relative; left:-5px;float:right;width:65px !important; height:20px;" value="____/32" />
                                        <span style="display:block;float:right;"><b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b></span>
                                    </div>
                                </div>
                                <div class="comp4rows">
                                    <div class="bordernone interior_inspec1 interior_inspecLeft">
<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
<span style="display:block;width:20px;font-weight: bold;" class="comp4boxl fontF title_value4"  >RF</span>
<input type="text"  class="comp4boxi" style="display:none; height:20px;width: 30px !important;" value="RF" />
</span>

                                        <span class="comp4boxl txt_bold_lower_case title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px;">____/32"</span>
                                        <input type="text"  class="comp4boxi" style="display:none; height:20px;position:relative; left:-5px;float:right;width:65px !important;" value="____/32" />
                                        <span style="display:block;float:right;"><b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b></span>
                                    </div>
                                    <div class="bordernone interior_inspec1 interior_inspecRight">
<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
<strong style="display:block;width:20px;"> <span class="comp4boxl title_value4" style="position:relative; left:-5px;float:right;display:block;width:67px">RR</span><input type="text"  class="comp4boxi" style="display:none; height:20px;width: 30px !important;" value="RR" /></strong>


</span>
                                        <span class="comp4boxl txt_bold_lower_case title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px">____/32"</span>
                                        <input type="text"  class="comp4boxi" style="display:none; height:20px;position:relative; left:-5px;float:right;width:65px !important;" value="____/32" />
                                        <span style="display:block;float:right;"><b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b></span>
                                    </div>
                                </div>

                                <!-- end -->
                            </div></div>
                        <div class="clear row1x">
                            <div class="comp4rows" style="float: left;margin-bottom: 46px;">
                               <span style="padding:0px;width:100px;float:left;margin-top: 28px;">
				 							<img class="fileshow" src="<?php echo e(URL::asset('mighty/images/rght_tire.png')); ?>" style="max-height: 200px;max-width: 100px;">
                                   <!-- image popip start -->
                     <button type="button" class="btn btn-default" data-toggle="modal" data-target="#imagefiles">
                         Choose image
                     </button>
                    <div class="modal fade" id="imagefiles" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Choose image</h4>
                                </div>
                                <div class="modal-body" style="height: 200px;
    overflow-y: auto;">
                                    <div>

                                        <div>
                                            <label  style="display: block;">Upload your own image</label>
                                            <input  style="float:left;" type="file" class="imagefiles files" onchange="readURL(this,'showing','removeicon');" name="imagefiles"  />

                                        </div>
                                        <button style="display:none;" type="button" id="removeicon"  onclick="removeFile('imagefiles',this,'showing');" class="tabledit-delete-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon-trash"></span>
                                        </button>


                                    </div>
                                    <div style="clear:both;"></div>
                                    <br>
                                    <div>
                                        <div style="float: left;margin-right: 23px;
">
                                            <button type="button" class="btn btn-default" data-toggle="modal" onclick="setShowimage('showing');" data-target="#myModal">
                                                Choose from existing images:
                                            </button>
                                        </div>

                                        <div id="showing"  data-show="fileshow" data-fname="imagefiles" data-remov="removeicon" style="float: left">

                                        </div>

                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                                   <!-- image popup end -->
                    <input type="hidden" class="filepath showing" value="">
								</span>
                                <div class="bordernone interior_inspec padding_reset lessWidth" style="padding:0px;float:right; padding-top:15px;width:100px !important;">
                                    <div style="height:30px;margin-bottom:10px;width: 99px;">
                                        <span class="comp4boxl" colspan="2" style="padding:0px;word-wrap: break-word !important;">Wear Pattern/ Damage</span>
                                        <textarea  class="comp4boxi" style="display:none; height:48px;width:99px !important;" >Wear Pattern/ Damage</textarea>
                                    </div>
                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
                                        <span style="width:75px; display:block;float:right;"><b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b></span>
                      						<span width="29" class="txt_bold txtLeft">

                                                <span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;">LF</span>
                                       <input type="text"  class="comp4boxi" style="display: none;height:20px;width: 23px !important; " value="LF" />

                      						</span>

                                    </div>

                                    <div class="clear" id="c2" style="text-align:right;width:100px; margin-bottom:10px;height:20px;">
                                        <span style="width:75px; display:block;float:right;"><b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b></span>
                      						<span class="txt_bold txtLeft">
                      							                   <span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;">RF</span>
                                       <input type="text"  class="comp4boxi" style="display: none;height:20px;width: 23px !important; " value="RF" />
                      						</span>

                                    </div>

                                    <div class="clear" id="c3" style="text-align:right;width:100px; margin-bottom:10px;height:20px;">
                                        <span style="width:75px; display:block;float:right;"><b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b></span>
                      						<span class="txt_bold txtLeft">
                      							<span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;">LR</span>
                                       <input type="text"  class="comp4boxi" style="display: none; height:20px;width: 23px !important;" value="LR" />
                      						</span>

                                    </div>
                                    <div class="clear" id="c4" style="text-align:right;width:100px; margin-bottom:10px;height:20px;">
                                        <span style="width:75px; display:block;float:right;"><b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b></span>
                      						<span class="txt_bold txtLeft">
                      							<span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;">RR</span>
                                       <input type="text"  class="comp4boxi" style="display: none;height:20px;width: 23px !important; " value="RR" />
                      						</span>

                                    </div>
                                </div>
                            </div>
                            <div style="float: left">
                                <div class="comp4rows interior_inspec" style="height:215px;border-right: 2px solid #0e62af !important;border-left: 2px solid #0e62af !important;padding:0px;width:124px; padding:0 3px; float:left;">
                                    <div cellspacing="0" class="bordernone padding_reset" style="">
                                        <div style="text-align:center;margin-top:15px;">
                                            <span class="comp4boxl" colspan="2" style="padding:0px;word-wrap: break-word !important;">Air Pressure</span>
                                            <input type="text"  class="comp4boxi" style="display:none; height:20px;width: 85px !important;" value="Air Pressure" />
                                        </div>
                                        <div id="redBlock">
                              				<span style="float:left; width:16px;margin-right:2px;">
                              					<b class="smallRedCircle"></b>
                              				</span>

                                            <span class="comp4boxl" colspan="2" style="padding:0px;word-wrap: break-word !important;">TPMS Warning System</span>
                                            <input type="text"  class="comp4boxi" style="display:none; height:20px;width: 67px !important;" value="TPMS Warning System" />
                                            <!-- sec image popip start -->
                                            <button type="button" class="btn btn-default" data-toggle="modal" data-target="#imagesecfiles">
                                                Choose image
                                            </button>
                                            <div class="modal fade" id="imagesecfiles" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                            <h4 class="modal-title" id="myModalLabel">Choose image</h4>
                                                        </div>
                                                        <div class="modal-body" style="height: 200px;
    overflow-y: auto;">
                                                            <div>

                                                                <div>
                                                                    <label  style="display: block;">Upload your own image</label>
                                                                    <input  style="float:left;" type="file" class="imagesecond imagesecfiles files" onchange="readURL(this,'secshowing','secremoveicon');" name="imagesecond28"  />





                                                                </div>
                                                                <button style="display:none;" type="button" id="secremoveicon"  onclick="removeFile('imagesecfiles',this,'secshowing');" class="tabledit-delete-button btn btn-sm btn-default">
                                                                    <span class="glyphicon glyphicon-trash"></span>
                                                                </button>


                                                            </div>
                                                            <div style="clear:both;"></div>
                                                            <br>
                                                            <div>
                                                                <div style="float: left;margin-right: 23px;
">
                                                                    <button type="button" class="btn btn-default" data-toggle="modal" onclick="setShowimage('secshowing');" data-target="#myModal">
                                                                        Choose from existing images:
                                                                    </button>
                                                                </div>

                                                                <div id="secshowing" data-show="secfileshow" data-fname="imagesecfiles" data-remov="secremoveicon" style="float: left">

                                                                </div>

                                                            </div>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <!-- sec image popup end -->
                                            <input type="hidden" class="imgsecondpath secshowing" value="">

                                            <div id="imgBottomMid" class="imgBottomMid" style="width:40px; height:36px;">
                                                <img class="secfileshow" src="<?php echo e(URL::asset('mighty/images/symbol.png')); ?>" alt="symbol" style="max-width:40px;max-height: 36px;" id="image">
                                            </div>

                                        </div>
                                        <div class="bordernone interior_inspec">
                                            <div class="beforeAfter">
                                                <span  class="comp4boxl"  style="position:relative; left:11px;">BEFORE</span>
                                                <input type="text"  class="comp4boxi" style="display:none; height:20px;height:20px;width: 30px !important;" value="BEFORE" />
                                                &nbsp;&nbsp;

                                                <span  class="comp4boxl"  style="position:relative; left:11px;">OEM SPEC</span>
                                                <input type="text"  class="comp4boxi" style="display:none; height:20px;;width: 30px !important;" value="OEM SPEC" />

                                            </div>
                                            <div style="width:100%;" class="clear">
                                                <div style="float:left;width:20px;">
                                 				<span style="width:20px;display:block; float:left; height:27px;">
                                 			<span class="comp4boxl txt_bold" colspan="2" style="">LF</span>
                                           <input type="text"  class="comp4boxi" style="display:none; height:20px;width: 23px !important;" value="LF" />

                                 				</span>
								 				<span style="width:20px;display:block; float:left; height:27px;">
								 					<span class="comp4boxl txt_bold" colspan="2" style="">RF</span>
                                           <input type="text"  class="comp4boxi" style="display:none; height:20px;width: 23px !important;" value="RF" />
								 				</span>
                                                </div>
                                                <div style="width:30px; float:left;margin-right:3px;">
                                                    <span class="white_box">&nbsp;</span><br>
                                                    <span class="white_box">&nbsp;</span></div>
                                                <span class="white_box_rectangle">&nbsp;</span>
                                            </div>
                                            <div style="width:100%;" class="clear">
                                                <div style="float:left;width:20px;">
                                 					<span style="width:20px;display:block; float:left; height:27px;">
                                 						<span class="comp4boxl txt_bold" colspan="2" style="">LR</span>
                                           <input type="text"  class="comp4boxi" style="display:none; height:20px;width: 23px !important;" value="LR" />
                                 					</span>
								 					<span style="width:20px;display:block; float:left; height:27px;">
								 					<span class="comp4boxl txt_bold" colspan="2" style="">RR</span>
                                           <input type="text"  class="comp4boxi" style="display:none; height:20px;width: 23px !important;" value="RR" />
								 					</span>
                                                </div>
                                                <div style="width:30px; float:left;margin-right:3px;">
                                                    <span class="white_box">&nbsp;</span><br>
                                                    <span class="white_box">&nbsp;</span>
                                                </div>&nbsp;
                                                <span class="white_box_rectangle">&nbsp;</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div style="float: left">
                                <div class="comp4rows interior_inspec" style="padding:0px;width:74px;float:left; padding:0 3px;">
                                    <div style="margin-top:15px;">

                                        <span class="comp4boxl titleFont" colspan="2" style="padding:0px;word-wrap: break-word !important;">Tire Check/ OE Interval Suggests:</span>
                                        <input type="text"  class="comp4boxi" style="display:none; height:20px;width: 136px !important;" value="Tire Check/ OE Interval Suggests:" />

                                    </div>
                                    <div class="bordernone interior_inspec" style="width:80px;">
                                        <div class="clear" id="b1" style="height:20px; margin-bottom:5px;">
                                            <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                            <span class="comp4boxl txtFont" style="vertical-align:-3px;">Alignment</span>
                                            <input  class="comp4boxi" name="editComp_65" value="Alignment" style="height:20px;width: 136px !important;display:none;" maxlength="9" type="text">
                                        </div>
                                        <div class="clear" id="b2" style="height:20px; margin-bottom:5px;">
                                            <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                            <span class="comp4boxl txtFont"  style="vertical-align:-3px;">Balance</span>
                                            <input class="comp4boxi" name="editComp_66" value="Balance" style="height:20px;width: 136px !important;display:none;" maxlength="9" type="text">
                                        </div>
                                        <div class="clear" id="b3" style="height:20px; margin-bottom:5px;">
                                            <span><span class="white_box_square" style="float:left;margin-right:5px;"></span> </span>
                                            <span class="txtFont comp4boxl" id="comp_67" style="vertical-align:-3px;">Rotation</span>
                                            <input class="comp4boxi" name="editComp_67" value="Rotation" style="height:20px;width: 136px !important;display:none;" maxlength="9" type="text">
                                        </div>
                                        <div class="clear" id="b4" style="height:20px; margin-bottom:5px;">
                                            <span class="white_box_square" style="float:left;vertical-align:-3px;margin-right:5px;"></span>
                                            <span class="txtFont comp4boxl">New Tire</span>
                                            <input class="comp4boxi"  value="New Tire" style="height:20px;width: 136px !important;display:none;" maxlength="9" type="text">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="hover-icons action right_setting" style="display: none;width: 3%;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icons"></span>
                    <a class="click-upd-icons" style="float:right;display:none">
                        <img id="iok" src="<?php echo e(URL::asset('mighty/images/iok.jpg')); ?>" height="17px" width="16px">
                    </a>
                    <span style="display: none;" class="open_options options-icon"></span>
                    <!--  <span class="uncheck-grey check "></span>-->
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
                <div class="options" id="choices" style="display:none">
                    <div class="input_fields_wrap">
                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                        </a> -->
                        <element>
                            <p>
                                <input type="text" name="select[]" class="select_label" data-optionid="0"
                                       value="Brakes (Pads / Shoes)"/>
                                <span class="add-option add_field_button"></span>
                            </p>
                        </element>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="config_component5" style="display : none">
        <div class="portlet-header" data-type="component5" data-fieldid="29">
            <div class="uk-grid ">
                <div class="left_setting inspectionTable" style="width: 88%;border-bottom: 1px solid #000;">
                    <div class="clear row1 row1Title"> <label class="title_label">BRAKES</label><br/> </div>
                    <div class="title_component5 select">
                        <div class="clear " style="border-bottom:0px;">
                            <div style="padding:0px; border:0px;width:161px; float:left;">
                                <div class="bordernone interior_inspec">
                                    <div class="alignCenter clear paddingBottom" style="width:360px;">
                                        <span class="comp4boxl spanlable title_label1"  >BRAKE PADS / SHOES</span>
                                        <input type="text"  class="comp4boxi" style="display:none; height:20px;width: 176px !important;" value="BRAKE PADS / SHOES" />
                                    </div>
                                </div>
                                <div class="clear paddingBottom" style="width:375px; height:30px;">

<span class="clear"><b class="greenCircle"></b>
<span class="txtFont comp4boxl option1" style="display:block;">Over 5 mm (Disc) or 2 mm (Drum)</span>
      <input type="text"  class="comp4boxi" style="display:none; height:20px;width: 176px !important;" value="Over 5 mm (Disc) or 2 mm (Drum)" />
</span>
                                    <br><span class="clear"><b class="yellowCircle"></b>
<span class="txtFont comp4boxl option2" style="display:block;" >3-5 mm (Disc)
 or 1.01-2 mm(Drum)</span>
      <input type="text"  class="comp4boxi" style="display:none;height:20px;width: 176px !important;" value="3-5 mm (Disc) or 1.01-2 mm(Drum)" />
</span>
                                    <br><span class="clear"><b class="redCircle"></b>
<span class="txtFont comp4boxl option3" style="display:block;"  >Less than 3 mm(Disc) or 1 mm (Drum)</span>
      <input type="text"  class="comp4boxi" style="display:none;height:20px;width: 176px !important;" value="Less than 3 mm(Disc) or 1 mm (Drum)" />
</span>
                                </div>
                                <div id="img" style="float: left;width: 70px;height: 70px;position: absolute;top: 18px;margin-left: 246px;; " align="center">

               		 	<span style=" position:relative;">
							<img class="fileshow" src="<?php echo e(URL::asset('mighty/images/inspect_Brakes.png')); ?>" style="position:relative;top:51px;max-height: 95px;
max-width: 85px; " alt="">
                            <!-- image popip start -->
                     <button style="margin-top:59px" type="button" class="btn btn-default" data-toggle="modal" data-target="#imagefiles">
                         Choose image
                     </button>
                    <div class="modal fade" id="imagefiles" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Choose image</h4>
                                </div>
                                <div class="modal-body" style="height: 200px;
    overflow-y: auto;">
                                    <div>

                                        <div>
                                            <label  style="display: block;">Upload your own image</label>
                                            <input  style="float:left;" type="file" class="imagefiles files" onchange="readURL(this,'showing','removeicon');" name="imagefiles"  />



                                        </div>
                                        <button style="display:none;" type="button" id="removeicon"  onclick="removeFile('imagefiles',this,'showing');" class="tabledit-delete-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon-trash"></span>
                                        </button>


                                    </div>
                                    <div style="clear:both;"></div>
                                    <br>
                                    <div>
                                        <div style="float: left;margin-right: 23px;
">
                                            <button type="button" class="btn btn-default" data-toggle="modal" onclick="setShowimage('showing');" data-target="#myModal">
                                                Choose from existing images:
                                            </button>
                                        </div>

                                        <div id="showing" data-show="fileshow" data-fname="imagefiles" data-remov="removeicon" style="float: left">

                                        </div>

                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                            <!-- image popup end -->
                    <input type="hidden" class="filepath showing" value="">
                                       <span style="font-size: 10px;"> Change Image[205 x 196]</span>
						</span>
                                </div>
                                <div style="height:162px; ">
                                    <div class="clear" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
<span style="width:75px; display:block;float:right;">
<b class="smallGreenCircle"></b>
<b class="smallYellowCircle"></b>
<b class="smallRedCircle"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;">LF</span>
<input class="comp4boxi" style="display: none;height:20px;width: 25px !important;" value="LF" type="text">
</span>
                                    </div>
                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
<span style="width:75px; display:block;float:right;">
<b class="smallGreenCircle"></b>
<b class="smallYellowCircle"></b>
<b class="smallRedCircle"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;">RF</span>
<input class="comp4boxi" style="display: none;height:20px;width: 25px !important;" value="RF" type="text">
</span>
                                    </div>
                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
<span style="width:75px; display:block;float:right;">
<b class="smallGreenCircle"></b>
<b class="smallYellowCircle"></b>
<b class="smallRedCircle"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;">LR</span>
<input class="comp4boxi" style="display: none;height:20px;width: 25px !important;" value="LR" type="text">
</span>
                                    </div>
                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
<span style="width:75px; display:block;float:right;">
<b class="smallGreenCircle"></b>
<b class="smallYellowCircle"></b>
<b class="smallRedCircle"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;">RR</span>
<input class="comp4boxi" style="display: none;height:20px;width: 25px !important;" value="RR" type="text">
</span>
                                    </div>
                                </div>
                                <div class="clear" style="width:400px;">
							<span class="fontF" style="float:left;display:block; margin-left:11px;"> <strong>
                                    <span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;">We feature</span>
                                    <input class="comp4boxi" style="display: none;height:20px;width: 77px !important;" value="We feature" type="text">
                                </strong>

					  	</span>
					  	<span style="padding:0px;width:150px;float:left;display:block;margin-right:5px;margin-left:5px;">
							<div id="imgBottomLast" class="imgBottomLast" style="margin-top:10px;width: 150px;" align="center">
                                <img class="secfileshow" src="<?php echo e(URL::asset('mighty/images/brands.png')); ?>" alt="brands" style="max-height: 45px;max-width: 150px;" id="image">
                            </div>
                            <!-- sec image popip start -->
                     <button type="button" class="btn btn-default" data-toggle="modal" data-target="#imagesecfiles">
                         Choose image
                     </button>
                            <span style="font-size: 10px;">Change Image [150 x 45]</span>
                    <div class="modal fade" id="imagesecfiles" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Choose image</h4>
                                </div>
                                <div class="modal-body" style="height: 200px;
    overflow-y: auto;">
                                    <div>

                                        <div>
                                            <label  style="display: block;">Upload your own image</label>
                                            <input  style="float:left;" type="file" class="imagesecond imagesecfiles files" onchange="readURL(this,'secshowing','secremoveicon');" name="imagesecond29"  />





                                        </div>
                                        <button style="display:none;" type="button" id="secremoveicon"  onclick="removeFile('imagesecfiles',this,'secshowing');" class="tabledit-delete-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon-trash"></span>
                                        </button>


                                    </div>
                                    <div style="clear:both;"></div>
                                    <br>
                                    <div>
                                        <div style="float: left;margin-right: 23px;
">
                                            <button type="button" class="btn btn-default" data-toggle="modal" onclick="setShowimage('secshowing');" data-target="#myModal">
                                                Choose from existing images:
                                            </button>
                                        </div>

                                        <div id="secshowing"  data-show="secfileshow" data-fname="imagesecfiles" data-remov="secremoveicon" style="float: left">

                                        </div>

                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                            <!-- sec image popup end -->
                    <input type="hidden" class="imgsecondpath secshowing" value="">

 						</span>
							<span class="fontF" style="float:left;display:block"> <strong>
                                    <span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;">Brakes</span>
                                    <input class="comp4boxi" style="display: none;padding: 0px;height:20px;width: 77px !important;" value="Brakes" type="text">
                                </strong>
							</span>
                                    <span class="fontF" style="float:left;"> </span>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="hover-icons action right_setting" style="display: none;width: 12%;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icons"></span>
                    <a class="click-upd-icons" style="float:right;display:none">
                        <img id="iok" src="<?php echo e(URL::asset('mighty/images/iok.jpg')); ?>" height="17px" width="16px">
                    </a>
                    <span style="display:none;" class="open_options options-icon"></span>
                   <!-- <span class="uncheck-grey check "></span>-->
                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>
    <div id="config_component6" style="display : none">
        <div class="portlet-header" data-type="component6" data-fieldid="30">
            <div class="uk-grid ">
                <div class="left_setting inspectionTable" style="width: 80%;">
                    <div class="clear row1 row1Title"> <label class="title_label">COMMENTS</label><br/> </div>
                    <div class="title_component6 select">
                        <div class="clear ">
                            <input type="hidden" name="component6"/>
                            <div class="clear row1" style="height:27px;">
                            </div>
                            <div class="clear row1" style="height:27px;">
                            </div>
                            <div class="clear row1" style="height:27px;">
                            </div>
                            <div class="clear row1" style="height:27px;">
                            </div>
                            <!--<div class="bottomtext" style="width: 393px;overflow:hidden;">
                                <div style="width:400px;margin-top:10px;">
                                    <div style="float:left;width:279px;overflow:hidden;">
            <span style="float: left;">
            <span  class="comments">Inspected by:</span>
            </span>
                                        <span style="display:block;overflow:hidden;margin-top: 19px;"><hr class="cmtLine" id="cmtLine2" style="width: 276px;"></span>
                                    </div>

                                    <div style="float:right;width: 120px;">
                                        <span  class="comments" style="float: left;">Date:</span>
                                        <span style="display:block;overflow:hidden;margin-top: 19px;"><hr class="cmtLine" id="cmtLine3" style="width: 125px"></span>
                                    </div>
                                </div>
                            </div>-->
                        </div>
                    </div>
                </div>
                <div class="hover-icons action right_setting" style="display: none;width:20%" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icon"></span>
                </div>

            </div>
        </div>
    </div>
    <div id="config_component7" style="display : none">
        <div class="portlet-header" data-type="component7" data-fieldid="31">
            <div class="uk-grid ">
                <div class="titl-field2 left_setting inspectionTable " style="border-bottom: 1px solid #000;">
                    <div class="clear row1 row1Title"> <label class="title_label">BATTERY</label><br/> </div>

                    <div class="title_component7 selects " >
                        <div class="clear"  >
                            <input type="hidden" name="component7"/>
                          <p>
                              <span class="comp4boxl inspectionTxt title_value"data-optionid="0" >SEE ATTACHED PRINTOUT</span>
                              <input class="comp4boxi" style="display: none;height:40px;width: 300px !important;" value="SEE ATTACHED PRINTOUT" type="text">
                              <br>
                                <span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
                                </p><div style="float: right;">
                                <img class="fileshow" src="<?php echo e(URL::asset('mighty/images/Might99171.PNG')); ?>" style="max-width: 92px;max-height: 60px;">
                                <!-- image popip start -->
                                <button type="button" class="btn btn-default" data-toggle="modal" data-target="#imagefiles">
                                    Choose image
                                </button>
                                <div class="modal fade" id="imagefiles" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                <h4 class="modal-title" id="myModalLabel">Choose image</h4>
                                            </div>
                                            <div class="modal-body" style="height: 200px;
    overflow-y: auto;">
                                                <div>

                                                    <div>
                                                        <label  style="display: block;">Upload your own image</label>
                                                        <input  style="float:left;" type="file" class="imagefiles files" onchange="readURL(this,'showing','removeicon');" name="imagefiles"  />

                                                    </div>
                                                    <button style="display:none;" type="button" id="removeicon"  onclick="removeFile('imagefiles',this,'showing');" class="tabledit-delete-button btn btn-sm btn-default">
                                                        <span class="glyphicon glyphicon-trash"></span>
                                                    </button>


                                                </div>
                                                <div style="clear:both;"></div>
                                                <br>
                                                <div>
                                                    <div style="float: left;margin-right: 23px;
">
                                                        <button type="button" class="btn btn-default" data-toggle="modal" onclick="setShowimage('showing');" data-target="#myModal">
                                                            Choose from existing images:
                                                        </button>
                                                    </div>

                                                    <div id="showing"  data-show="fileshow" data-fname="imagefiles" data-remov="removeicon" style="float: left">

                                                    </div>

                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <!-- image popup end -->
                                <input type="hidden" class="filepath showing" value="">
                                [115 x 90]
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hover-icons2 action right_setting" style="display: none;" id="edits">
                    <span class="delete_field"></span>
                     <span style="display: block;" class="click-edit-icons"></span>
                    <a class="click-upd-icons" style="float:right;display:none">
                        <img id="iok" src="<?php echo e(URL::asset('mighty/images/iok.jpg')); ?>" height="17px" width="16px">
                    </a>
                   <!-- <span class="uncheck-grey check "></span>-->
              <input type="hidden" class="formfieldid" value="0"/>
                </div>

            </div>
        </div>
    </div>
    <div id="config_component8" style="display : none">
        <div class="portlet-header" data-type="component8" data-fieldid="32">
            <div class="uk-grid ">
                <div class="left_setting" style="width: 80%;">
                    <div class="clear row1 row1Title" style="display: none;"> <label class="title_label"></label><br/> </div>
                    <div class="title_component8 select">
                        <div class="clear ">
                            <input type="hidden" name="component8"/>
<span class="profiletext" >
<span class="comp4boxl title_value" data-optionid="0"  colspan="2" style="font-size: 19px;font-weight: bold;padding:0px;">Name</span>
<input type="text"  class="comp4boxi" style="display: none;" value="Name" />
</span>
                            <div class="clear row1" style="height:5px;margin-bottom: 12px;padding-top: 0;border-bottom: 1px solid #333;">
                            </div>
<span class="profiletext" >
<span class="comp4boxl title_value" data-optionid="0" colspan="2" style="font-size: 19px;font-weight: bold;padding:0px;">Mileage</span>
<input type="text"  class="comp4boxi" style="display: none;" value="Mileage" />
</span>
                            <div class="clear row1" style="height:5px;margin-bottom: 12px;padding-top: 0;border-bottom: 1px solid #333;">
                            </div>

<span class="profiletext" >
<span class="comp4boxl title_value" data-optionid="0" colspan="2" style="font-size: 19px;font-weight: bold;padding:0px;">Year/Make/Model</span>
<input type="text"  class="comp4boxi" style="display: none;" value="Year/Make/Model" />
</span>
                            <div class="clear row1" style="height:5px;margin-bottom: 12px;padding-top: 0;border-bottom: 1px solid #333;">
                            </div>
<span class="profiletext" >
<span class="comp4boxl title_value" data-optionid="0" colspan="2" style="font-size: 19px;font-weight: bold;padding:0px;">Email</span>
<input type="text"  class="comp4boxi" style="display: none;" value="Email" />
</span>
                            <div class="clear row1" style="height:5px;margin-bottom: 12px;padding-top: 0;border-bottom: 1px solid #333;">
                            </div>

 <span class="profiletext" >
<span class="comp4boxl title_value" colspan="2" data-optionid="0" style="font-size: 19px;font-weight: bold;padding:0px;">License</span>
<input type="text"  class="comp4boxi" style="display: none;" value="License" />
</span>
                            <div class="clear row1" style="height:5px;margin-bottom: 12px;padding-top: 0;border-bottom: 1px solid #333;">
                            </div>

                            <span class="profiletext" >
<span class="comp4boxl title_value" colspan="2" data-optionid="0" style="font-size: 19px;font-weight: bold;padding:0px;">VIN</span>
<input type="text"  class="comp4boxi" style="display: none;" value="VIN" />
</span>
                            <div class="clear row1" style="height:5px;margin-bottom: 12px;padding-top: 0;border-bottom: 1px solid #333;">
                            </div>

                            <span class="profiletext" >
<span class="comp4boxl title_value" colspan="2" data-optionid="0" style="font-size: 19px;font-weight: bold;padding:0px;">RO#</span>
<input type="text"  class="comp4boxi" style="display: none;" value="RO#" />
</span>
                            <div class="clear row1" style="height:5px;margin-bottom: 12px;padding-top: 0;border-bottom: 1px solid #333;">
                            </div>
                            <!--<div class="bottomtext" style="width: 393px;overflow:hidden;">
                                <div style="width:400px;margin-top:10px;">
                                    <div style="float:left;width:279px;overflow:hidden;">
            <span style="float: left;">
            <span  class="comments">Inspected by:</span>
            </span>
                                        <span style="display:block;overflow:hidden;margin-top: 19px;"><hr class="cmtLine" id="cmtLine2" style="width: 276px;"></span>
                                    </div>

                                    <div style="float:right;width: 120px;">
                                        <span  class="comments" style="float: left;">Date:</span>
                                        <span style="display:block;overflow:hidden;margin-top: 19px;"><hr class="cmtLine" id="cmtLine3" style="width: 125px"></span>
                                    </div>
                                </div>
                            </div>-->
                        </div>
                    </div>
                </div>
                <div class="hover-icons action right_setting" style="display: none;width:20%" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icons"></span>
                    <a class="click-upd-icons" style="float:right;display:none">
                        <img id="iok" src="<?php echo e(URL::asset('mighty/images/iok.jpg')); ?>" height="17px" width="16px">
                    </a>
                </div>

            </div>
        </div>
    </div>
    <div id="config_component9" style="display : none">
        <div class="portlet-header" data-type="component9" data-fieldid="33">
            <div class="uk-grid ">
                <div class="left_setting" style="width: 80%;">
                    <div class="clear row1 row1Title" style="display: none;"> <br/> </div>
                    <div class="title_component9 select">
                        <div class="clear ">
                            <input type="hidden" name="component9"/>
 <div class="title_label cke_editable texteditor " id="texteditor" name="texteditor" style="/*width: 350px !important;*/"  ></div>
                        </div>
                    </div>
                </div>
                <div class="hover-icons action right_setting" style="display: none;width:20%" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-editer"  onclick="showTxtEditor('texteditor',this)" ></span>
                    <a class="click-upd-icons" style="float:right;display:none">
                        <img id="iok" src="<?php echo e(URL::asset('mighty/images/iok.jpg')); ?>" height="17px" width="16px">
                    </a>
                </div>

            </div>
        </div>
    </div>

    <div id="config_condition" style="display : none">
        <div class="portlet-header" data-type="condition" data-fieldid="24">
            <!--<input type="text" />-->
            <div class="uk-grid">
                <div class="left_setting condition_boxleft"  >
                    <div class="svgTable" style="margin-left: 0px;">
                        <span style="display: inline-block;"><b class="green_checkbox"></b></span>
<span style="display: inline-block;" width="29" class="txt_bold ">
<span class="floatLeft comp4boxl title_value" colspan="2" style="font-size: 14px;font-weight: bold; padding: 0px; display: block;">NO IMMEDIATE ATTENTION</span>
<input type="text" name="cnd1" class="floatLeft  comp4boxi" data-optionid="0" value="NO IMMEDIATE ATTENTION" style="min-width: 200px;display: none;width: 174px;height: 30px;"/>
</span>
                        <span style="display: inline-block;"><b class="yellow_checkbox"></b></span>
<span style="display: inline-block;" width="29" class="txt_bold ">
<span class="floatLeft comp4boxl title_value" colspan="2" style="font-size: 14px;font-weight: bold; padding: 0px; display: block;">MAY REQUIRE FUTURE ATTENTION</span>
<input type="text" name="cnd2" class="floatLeft  comp4boxi" data-optionid="0" value="MAY REQUIRE FUTURE ATTENTION" style="min-width: 200px;display: none;width: 174px;height: 30px;"/>
</span>  <span style="display: inline-block;"><b class="red_checkbox"></b></span>
                        <span style="display: inline-block;" width="29" class="txt_bold ">
<span class="comp4boxl title_value" colspan="2" style="display: inline-block;font-weight: bold; padding: 0px; display: block;">IMMEDIATE ATTENTION</span>
<input type="text" name="cnd3" class="floatLeft  comp4boxi" data-optionid="0" value="IMMEDIATE ATTENTION" style="display: none;width: 174px;height: 30px;"/>
</span>   </div>
                </div>
                <div class="action  hover-icons  right_setting " style="display:none;width: 3% !important;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icons"></span>
                    <a class="click-upd-icons" style="float:right;display:none">
                        <img id="iok" src="<?php echo e(URL::asset('mighty/images/iok.jpg')); ?>" height="17px" width="16px">
                    </a>

                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>
    <div id="config_condition2" style="display : none">
        <div class="portlet-header" data-type="condition2" data-fieldid="24">
            <!--<input type="text" />-->
            <div class="uk-grid">
                <div class="left_setting">
                    <div class="svgTable" style="margin-left: 0px;">
                        <span style="display: inline-block;"><b class="greenCircle"></b></span>
<span style="display: inline-block;" width="29" class="txt_bold ">
<span class="floatLeft comp4boxl title_value" colspan="2" style="font-size: 14px;font-weight: bold; padding: 0px; display: block;">CHECKED AND OK</span>
<input type="text" name="cnd1" class="floatLeft  comp4boxi" data-optionid="0" value="CHECKED AND OK" style="min-width: 200px;display: none;width: 174px;height: 30px;"/>
</span>
                        <span style="display: inline-block;"><b class="yellowCircle"></b></span>
<span style="display: inline-block;" width="29" class="txt_bold ">
<span class="floatLeft comp4boxl title_value" colspan="2" style="font-size: 14px;font-weight: bold; padding: 0px; display: block;">MAY REQUIRE ATTENTION</span>
<input type="text" name="cnd2" class="floatLeft  comp4boxi" data-optionid="0" value="MAY REQUIRE ATTENTION" style="min-width: 200px;display: none;width: 174px;height: 30px;"/>
</span>  <span style="display: inline-block;"><b class="redCircle"></b></span>
                        <span style="display: inline-block;" width="29" class="txt_bold ">
<span class="comp4boxl title_value" colspan="2" style="display: inline-block;font-weight: bold; padding: 0px; display: block;">REQUIRES IMMEDIATE ATTENTION</span>
<input type="text" name="cnd3" class="floatLeft  comp4boxi" data-optionid="0" value="REQUIRES IMMEDIATE ATTENTION" style="display: none;width: 174px;height: 30px;"/>
</span>   </div>
                </div>
                <div class="action hover-icons right_setting" style="display:none;" id="edits">
                    <span class="delete_field"></span>
                    <span class="click-edit-icons"></span>
                    <a class="click-upd-icons" style="float:right;display:none">
                        <img id="iok" src="<?php echo e(URL::asset('mighty/images/iok.jpg')); ?>" height="17px" width="16px">
                    </a>

                    <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>
    <!-- Table row -->
    <div id="config_tablehead" style="display : none">
        <div class="portlet-header" data-type="tablehead" data-fieldid="21">
            <div class="uk-grid">
                <div class="uk-width-1-2"  style="width:88%;">
                    <table class="tables uk-table">
                        <tr>
                            <th class="th">ITEMS</th>
                            <th class="th">CONDITION</th>
                        </tr>
                        <tr>
                            <td class="th">
                                <div class="title_tablehead select">
                                <input type="text" name="tables[]" class="title_value" data-optionid="0" style="height: 34px;width:100%;"/>
                                </div>
                            </td>
                            <td class="th">
                                 <span><b class="green_checkbox"></b><b class="yellow_checkbox"></b><b class="red_checkbox"></b></span>
                        <!--  <div class="svgTable">
                                    <img alt="" src="<?php echo e(URL::asset('mighty/images/green_large.png')); ?>" height="41" width="41">
                                    <img alt="" src="<?php echo e(URL::asset('mighty/images/yellow_large.png')); ?>" height="41" width="41">
                                    <img alt="" src="<?php echo e(URL::asset('mighty/images/red_large.png')); ?>" height="41" width="41">
                                </div>-->
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="uk-width-1-2 action" style="display: none;width:12%;" id="edits">
                    <span class="delete_field"></span>
                    <span class="add_morerow" onclick="addMorerow(this)"  data-vals="tables"></span>
                        <!--<button type="button" class="btn bg-navy margin add_morerow" onclick="addMorerow(this)"  data-vals="tables">Add row</button>-->
                    <!--<i class="uk-icon-edit edit_field"></i>--> <input type="hidden" class="formfieldid" value="0"/>
                </div>
            </div>
        </div>
    </div>
    <!-- Table row -->
    <div id="config_tablerow" style="display : none">
        <div class="uk-width-1-2">
            <tr>
                <td class="th">Item</td>
                <td class="th">
                    <div class="svgTable">
                        <img alt="" src="<?php echo e(URL::asset('mighty/images/green_large.png')); ?>" height="41" width="41">
                        <img alt="" src="<?php echo e(URL::asset('mighty/images/yellow_large.png')); ?>" height="41" width="41">
                        <img alt="" src="<?php echo e(URL::asset('mighty/images/red_large.png')); ?>" height="41" width="41">
                    </div>
                </td>
            </tr>
            <span class="delete_field"></span>
        </div>
    </div>
</div>