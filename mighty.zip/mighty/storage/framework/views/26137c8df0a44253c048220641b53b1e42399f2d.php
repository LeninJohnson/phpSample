<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mighty</title>

<?php
$listing='';
$listing .= '<style>'.file_get_contents(URL::asset("mighty/plugins/template3.css")).'</style>';
        echo $listing;
?>
<style>
    .content {
    // min-height: 1811px;
    }
</style>
<style>
    li.rows{
        min-height:80px;
    }
    li.columns{
        float:left;
        height:75px;
        list-style: none;
    }
    li.highlight{
        min-height: 70px;
    }
    .dropovers{
        /*  border:1px solid #ccc;
          border-right-color:red;*/
    }
    body{
        /*overflow: hidden;
        height: 100%;*/
    }
    .content{
        padding-left: 0px !important;
    }
    body {
        padding-top: 0px !important;
    }
    .uk-grid > * {
        float: none;
    }
    .cmdline{
        width:90%;margin-top: 6%;color: rgb(12, 12, 12);border: 0.1px solid;
    }
    .th{
    // padding: 6px 22px 13px 1px;
        border: 1px solid;
    }
    .row1Title {
        background: none repeat scroll 0 0 #005AAB;
        border-bottom: 1px solid #000000;
        color: #FFFFFF;
    //  color: #000000 !important;
        font-family: 'MyriadProBold';
        font-size: 12pt;
        height: 23px;

        text-align: center;
    }
    .svgTable{
        margin-left: 30px;
        margin-top: 7px;
    }
    .uk-h2, h2 {
        font-size: 24px;
        line-height: normal;
    }
    .click-edit-icons {
        background-image: url("<?php echo e(URL::asset('mighty/images/clicktoedit.png')); ?>");
        background-size: 15px;
        width: 15px;
        height: 15px;
        float: right;
    }
    .spanlable{
        display: inline-block;
        max-width: 100%;
        margin-bottom: 5px;
        font-weight: 700;
    }
    .comp4boxi{
        width: 145px !important;
    }
    .optionbox{
        float:left;
    }
    .lrchange
    {
        background: url('<?php echo e(URL::asset('mighty/images/leftright.png')); ?>');
        width: 18px;
        height: 18px;
        background-size: 19px;
        display: block;
        margin-top: -2px;
        margin-right: 10px;
    }
    .add_morerow{
        background: url('<?php echo e(URL::asset('mighty/images/add2.png')); ?>');
        background-size: 15px;
        display: block;
        width: 15px;
        height: 15px;
        float: right;
        cursor: pointer;
        padding-left: 0px;
    }
    .uncheck-grey,.check-red{
        display: none;
    }
</style>
</head>
<body>
<div id="page_content_inner">
              <form class="uk-form-stacked" id="wizard_advanced_form" method="post" enctype="multipart/form-data" >
                <div class="uk-width-large-8-10"  id="content_right" style="float:left;height: 563px;padding-left:12px;width:80%;">
                    <div class="md-card">
                        <div class="md-card-content" >
                              <div id="forms" data-form_id ="1" style="width:100%;height: 550px;">
                                <ul id="pages" style="height: 520px;">
                                    <!--<li class="rows" id="rows_1"></li>-->
<?php
$edFlag=1;
$options=0;
$formToken=$formdetails->form_content;
    $ftk_array=json_decode($formToken);


        foreach ($ftk_array as $pages) {
            $res_array=$pages;
            foreach ($res_array as $res) {

            $res_result=$res;
            $remove=count($res_result)-1;
            unset($res_result[$remove]);

                    foreach ($res_result as $key=> $rows) {
                          $row=$key;


?>
<li class="rows uk-width-1-1 ui-droppable" id="rows_<?php echo e($row+1); ?>">
<ul id="rows_<?php echo e($row+1); ?>" class="connected">
<?php
                            foreach ($rows as $index=>$cols) {
                              $col=$index;
 if(isset($cols->choices)){
   $options++;
 }


?>

<li style="height: 54px;" class="uk-width-1-<?php echo e(count($rows)); ?> columns" id="columns_<?php echo e($col+1); ?>">

<div class="cols uk-width-1-1 <?php echo e($cols->type); ?>_undefined">
<div class="uk-panel config_<?php echo e($cols->type); ?> portlet">
<div class="portlet-header" data-type="<?php echo e($cols->type); ?>" data-fieldid="<?php echo e($cols->fieldid); ?>">
    <!--Start -->
    <?php if($cols->type=="text"): ?>
                <!--<input type="text" />-->
                <div class="uk-grid">
                    <div class="titl-field1 left_setting">
                        <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                        <input type="text" readonly style="display:table"/>
                    </div>

                    <div class="hover-icons1 right_setting hover-icons action" style="display:none;" id="edits_<?php echo e($edFlag); ?>">
                        <span class="delete_field"></span>
                        <span class="click-edit-icon" ></span>
                        <span class="uncheck-grey check "></span>
                        <input type="hidden" class="formfieldid" value="0" />
                    </div>
                </div>    <?php elseif($cols->type=="heading"): ?>
        <!-- Heading Templates-->

                <!--<input type="text" />-->
                <div class="uk-grid">
                    <div class="titl-field1 left_setting">
                        <label class="title_label"><?php echo e($cols->title); ?></label>
                    </div>
                    <div class="hover-icons1 right_setting hover-icons action" style="display:none;" id="edits_<?php echo e($edFlag); ?>" >
                        <span class="delete_field"></span>
                        <span class="click-edit-icon" ></span>
                        <input type="hidden" class="formfieldid" value="0" />
                    </div>
                </div>

        <?php elseif($cols->type=="email"): ?>
        <!-- Email Controls -->

                <div class="uk-grid">
                    <div class="titl-field1 left_setting">
                         <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                          <input type="email" readonly style="display:table" />
                    </div>
                    <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_<?php echo e($edFlag); ?>" >
                        <span class="delete_field"></span>
                        <span class="click-edit-icon" ></span>
                        <span class="uncheck-grey check"></span>
                        <input type="hidden" class="formfieldid" value="0" />
                    </div>
                </div>

        <?php elseif($cols->type=="number"): ?>
        <!-- Number Controls -->

                <div class="uk-grid">
                    <div class="titl-field1 left_setting">
                         <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                          <input type="number" readonly style="display:table" />
                    </div>
                    <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_<?php echo e($edFlag); ?>" >
                        <span class="delete_field"></span>
                        <span class="click-edit-icon" ></span>
                        <span class="uncheck-grey check "></span>
                        <input type="hidden" class="formfieldid" value="0" />
                    </div>
                </div>

        <!-- Date controls -->
        <?php elseif($cols->type=="date"): ?>

                <div class="uk-grid">
                    <div class="titl-field1 left_setting">
                        <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                        <input type="text"  readonly style="display:table" />
                        <input type = "hidden" id="date_format"  value ="" />
                    </div>
                    <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_<?php echo e($edFlag); ?>" >
                        <span class="delete_field"></span>
                        <span class="click-edit-icon" ></span>
                        <span class="open_options options-icon" ></span>
                        <span class="uncheck-grey check "></span>
                        <input type="hidden" class="formfieldid" value="0" />
                    </div>
                    <div class="options" id="choices" style="display:none">
                        <div class="input_fields_wrap">
                            <select style="padding:4px 6px;"  class="uk-form-select" name="date_format" id="date_formats">
                                    <option value="MM/dd/yyyy">MM/DD/YYYY</option>
                                    <option value="dd/MM/yyyy">DD/MM/YYYY</option>
                                    <option value="yyyy/MM/dd">YYYY/MM/DD</option>
                                </select>
                        </div>
                    </div>
                </div>

        <!-- Time controls -->
         <?php elseif($cols->type=="time"): ?>

                <div class="uk-grid">
                    <div class="titl-field1 left_setting">
                        <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                          <input type="text" readonly style="display:table">
                         <input type = "hidden" id="time_format"  value ="" />
                    </div>
                    <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_<?php echo e($edFlag); ?>">
                        <span class="delete_field"></span>
                        <span class="click-edit-icon" ></span>
                        <span class="open_options options-icon"></span>
                        <span class="uncheck-grey check "></span>
                        <input type="hidden" class="formfieldid" value="0" />
                    </div>
                    <div class="options" id="choices" style="display:none">
                        <div class="input_fields_wrap">
                            <select style="padding:4px 6px;"  class="uk-form-select" name="time_format" id="time_formats">
                                <option value="hh:mm:ss">12 Hrs</option>
                                <option value="HH:mm:ss">24 Hrs</option>
                            </select>
                        </div>
                    </div>
                </div>

        <!-- Signature -->
         <?php elseif($cols->type=="signature"): ?>
                <div class="uk-grid">
                    <div class="titl-field1 left_setting">
                        <label class="title_label"><?php echo e($cols->title); ?></label>
                        <br/>
                        <input type="text" readonly style="display:table">
                    </div>
                    <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_<?php echo e($edFlag); ?>">
                        <span class="delete_field"></span>
                        <span class="click-edit-icon" ></span>
                        <span class="uncheck-grey check "></span>
                        <input type="hidden" class="formfieldid" value="0" />
                    </div>
                </div>

        <?php elseif($cols->type=="radio"): ?>
        <!-- Radio Button Templates -->

                <div class="uk-grid">
                    <div class="titl-field1 left_setting">
                        <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                        <div class="title_radio select">
                        <?php
                           $choice_array=$cols->choices;
                           ?>
                            <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <input type="radio" name="radio" value="<?php echo e($chres->title); ?>" /> <span class="title_value" data-optionid="0"><?php echo e($chres->title); ?></span>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </div>
                    </div>
                    <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_<?php echo e($edFlag); ?>">
                        <span class="delete_field"></span>
                        <span class="click-edit-icon" ></span>
                        <span class="open_options_<?php echo e($options); ?> options-icon" data-opt="<?php echo e($options); ?>"></span>
                        <span class="uncheck-grey check "></span>
                        <input type="hidden" class="formfieldid" value="0" />
                    </div>
                    <div class="options" id="choices" style="display:none">
                        <div class="input_fields_wrap">
                            <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                            </a> -->
                            <element>
                                <?php
                                $choice_array=$cols->choices;
                                ?>
                                 <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                 <p>
                                     <input type="text" name="select[]" class="select_label" data-optionid="0" value="<?php echo e($chres->title); ?>" />
                                </p>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </element>
                        </div>
                    </div>
                </div>

        <!--Check Box Templates -->
        <?php elseif($cols->type=="checkbox"): ?>

                <div class="uk-grid">
                    <div class="titl-field1 left_setting">
                        <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                        <div class="title_checkbox select">
                            <?php
                                $choice_array=$cols->choices;
                                ?>
                                 <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                 <input type="checkbox" />
<span class="title_value" data-optionid="0"><?php echo e($chres->title); ?></span>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                        </div>
                        <div class="options" id="choices" style="display:none">
                            <div class="input_fields_wrap">
                               <!--  <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                </a> -->
                                <element>
                                    <p>
                                        <input type="text" name="select[]" class="select_label" data-optionid="0" value="First Option" /><span class="add-option add_field_button"></span>
                                    </p>
                                </element>
                            </div>
                        </div>
                    </div>
                    <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_<?php echo e($edFlag); ?>">
                        <span class="delete_field"></span>
                        <span class="click-edit-icon" ></span>
                        <span class="open_options_<?php echo e($options); ?> options-icon"></span>
                        <span class="uncheck-grey check "></span>
                        <input type="hidden" class="formfieldid" value="0" />
                    </div>
                </div>

        <?php elseif($cols->type=="select"): ?>
        <!-- Select dropdown Templates -->

                <div class="uk-grid">
                    <div class="titl-field1 left_setting">
                        <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                        <div class="select">
                            <select>
                                <?php
                                $choice_array=$cols->choices;
                                ?>
                                 <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <option>
                                <span class="title_value" data-optionid="0">
                                <?php echo e($chres->title); ?>

                                </span>
                                </option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </select>
                        </div>
                        <div class="options" id="choices" style="display:none">
                            <div class="input_fields_wrap">
                                <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                </a> -->
                                <element>
                                    <p>
                                    <input type="text" name="select[]" class="select_label" data-optionid="0" value="First Option"/></p>
                                    <p>
                                    <input type="text" name="select[]" class="select_label" data-optionid="0" value="Second Option"/>
                                    <span class="add-option add_field_button"></span>
                                    </p>
                                </element>
                            </div>
                        </div>
                    </div>
                    <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_<?php echo e($edFlag); ?>" >
                        <input type="hidden" class="formfieldid" value="0" />
                        <span class="delete_field"></span>
                        <span class="click-edit-icon" ></span>
                        <span class="open_options_<?php echo e($options); ?> options-icon"></span>
                        <span class="uncheck-grey check "></span>
                    </div>
                </div>

        <?php elseif($cols->type=="textarea"): ?>
        <!-- TextArea Templates -->

                <div class="uk-grid">
                    <div class="titl-field1 left_setting">
                        <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                        <textarea style="resize: none;height: 40px; width: 200px;" readonly></textarea>
                    </div>
                    <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_<?php echo e($edFlag); ?>" >
                        <span class="delete_field"></span>
                        <span class="click-edit-icon" ></span>
                        <span class="uncheck-grey check "></span>
                        <input type="hidden" class="formfieldid" value="0" />
                    </div>
                </div>

        <?php elseif($cols->type=="file"): ?>
        <!-- File Select Templates -->

                <div class="uk-grid">
                    <div class="titl-field1 left_setting">
                        <label class="title_label"><?php echo e($cols->title); ?></label><br/>

                        <?php if(isset($cols->filepath) && ($cols->filepath!='undefined')): ?>
                        <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($cols->filepath); ?>" style="width: 20px;
height: 20px;"/>
                        <?php endif; ?>

                    </div>
                    <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_<?php echo e($edFlag); ?>" >
                        <span class="delete_field"></span>
                        <span class="click-edit-icon" ></span>
                        <span class="uncheck-grey check "></span>
                        <input type="hidden" class="formfieldid" value="0" />
                         <?php if(isset($cols->filepath)): ?>
                        <input type="hidden" class="filepath" value="<?php echo e($cols->filepath); ?>" />
                        <?php endif; ?>
                    </div>
                </div>

        <?php elseif($cols->type=="placepicker"): ?>
        <!-- Place picker -->

                <div class="uk-grid">
                    <div class="uk-width-1-2">
                        <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                    </div>
                    <div class="uk-width-1-2 action" style="display: none;" id="edits_<?php echo e($edFlag); ?>" >
                        <span class="delete_field"></span>
                        <!--<i class="uk-icon-edit edit_field"></i>--> <input type="hidden" class="formfieldid" value="0" />
                        <input  type="checkbox" id="placepicker_check" class="required" data-type= class="required" data-type=/>Required
                    </div>
                </div>

        <?php endif; ?>
    <!--End -->
</div>
</div>

</div></li>



                                        <?php

                                  $edFlag++;

                          }
                          ?>
</ul></li>
<?php
                }

            }

    }
?>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>



        </div>
</body>
</html>