<?php $__env->startSection('customCss'); ?>
    <style>
        .content {
        //   min-height: 1811px;
        }
    </style>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>

            <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Settings
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(URL::to('')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="#">Mighty Assist</a></li>
            <li class="active">Update Settings</li>
        </ol>
    </section>
    <?php if(Session::has('true_msg')): ?>
        <div style="padding: 4px;"  class="row">
            <div class="col-md-6">
                <div class="alert alert-success">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    <?php echo e(Session::get('true_msg')); ?>

                </div> <!-- /.alert -->
            </div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('error_msg')): ?>
        <div class="row">
            <div class="col-md-6">
                <div class="alert alert-danger">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    <?php echo e(Session::get('error_msg')); ?>

                </div> <!-- /.alert -->
            </div>
        </div>
    <?php endif; ?>
    <section class="content">
        <div   class="row">
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Update Settings</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" name="mightysettings" id="mightysettings" method="post" enctype="multipart/form-data" >
                        <div class="box-body">
                            <div class="form-group">
                                <label for="left_image">Header Image - Left</label>
                                <input id="left_image" name="left_image" type="file">
                                <?php if(!empty($settings->left_image)): ?>
<img src="<?php echo e(URL::asset('mighty/images/settings/')); ?>/<?php echo e($settings->left_image); ?>" style="width: 70px;
height: 70px;"/>
                                    <div class="radio">
                                        <label>
                                            <input name="left_remove" id="left_remove" value="1"   type="checkbox">
                                            Remove Left Image
                                        </label>
                                    </div>
                                <?php endif; ?>
                                <p class="text-light-blue">Image Dimension should be  equal to: (200 X 100).</p>
                            </div>
                            <div class="form-group">
                                <label for="middle_image">Header Image - Middle</label>
                                <input id="middle_image" name="middle_image" type="file">
                                <?php if(!empty($settings->middle_image)): ?>
     <img src="<?php echo e(URL::asset('mighty/images/settings/')); ?>/<?php echo e($settings->middle_image); ?>" style="width: 70px;
height: 70px;" />
                                    <div class="radio">
                                        <label>
                                            <input name="middle_remove" id="middle_remove" value="1"   type="checkbox">
                                            Remove Middle Image
                                        </label>
                                    </div>
                                <?php endif; ?>
                                <p class="text-light-blue">Image Dimension should be  equal to: (600 X 100).</p>
                            </div>
                            <div class="form-group">
                                <label for="right_image">Header Image - Right</label>
                                <input id="right_image" name="right_image" type="file">
                                <?php if(!empty($settings->right_image)): ?>
<img src="<?php echo e(URL::asset('mighty/images/settings/')); ?>/<?php echo e($settings->right_image); ?>"  style="width: 70px;
height: 70px;" />
                                    <div class="radio">
                                        <label>
                                            <input name="right_remove" id="right_remove" value="1"   type="checkbox">
                                            Remove Right Image
                                        </label>
                                    </div>
                                <?php endif; ?>
                                <p class="text-light-blue">Image Dimension should be  equal to: (160 X 100).</p>
                            </div>
                            <div class="form-group">
                                <label for="customer_logo">Customer Logo</label>
                                <input id="customer_logo" name="customer_logo" type="file">
                                <?php if(!empty($settings->customer_logo)): ?>
 <img src="<?php echo e(URL::asset('mighty/images/settings/')); ?>/<?php echo e($settings->customer_logo); ?>"   style="width: 70px;
height: 70px;" />                   <div class="radio">
                                        <label>
                                            <input name="customer_remove" id="customer_remove" value="1"   type="checkbox">
                                            Remove Customer Image
                                        </label>
                                    </div>
                                <?php endif; ?>
                                <p class="text-light-blue">Image Dimension should be  equal to: (80 X 80).</p>
                            </div>


                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit"  name="submit" id="submit"   class="btn btn-primary">Submit</button>
                            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-default">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>
    <script src="<?php echo e(URL::asset('mighty/plugins/jquery.validate.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
    <script>
/*
        jQuery.validator.setDefaults({
            debug: true,
            success: "valid"
        });
        $(document).ready(function () {
            $( "#mightysettings" ).validate({
                rules: {
                    'left_image': {
                        extension: "png|jpg"
                    },
                    'middle_image': {

                        extension: "png|jpg"
                    },
                    'right_image': {

                        extension: "png|jpg"
                    },
                    'customer_logo': {
                        extension: "png|jpg"
                    }
                }
            });
            $( "#submit" ).click(function() {
                alert("T");
                if ($("#mightysettings").valid()) {
                    $("#mightysettings").submit();
                }
            });

        });
*/
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mighty.layout.tpl', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>