<?php
$template = Config::get('custom.template');
?>

<?php $__env->startSection('customCss'); ?>
    <?php
    $form_name =$formdetails->form_name;
    $string = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $form_name)));
    ?>

    <script src="<?php echo e(URL::asset('mighty/plugins/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('mighty/plugins/kendo.all.min.js')); ?>"></script>

    <script type="text/javascript">
        var generatePDF = function() {
            kendo.drawing
                    .drawDOM($("#content_right"))
                    .then(function(group){

                        kendo.drawing.pdf.saveAs(group, "<?php echo e($string); ?>.pdf");
                    });
            return false;
            var draw = kendo.drawing;

            draw.drawDOM($("#content_right"), {
                        avoidLinks: true,
                        pdf: {
                            allPages: true,
                            paperSize: "A4",
                            landscape: false
                        },
                        margin: {
                            left   : "210mm",
                            top    : "297mm",
                            right  : "210mm",
                            bottom : "297mm"
                        },
                        landscape: false,
                        repeatHeaders: false
                    })
                    .then(function(root) {
                        return draw.exportPDF(root);
                    })
                    .done(function(data) {
                        kendo.saveAs({
                            dataURI: data,
                            fileName: "<?php echo e($string); ?>.pdf"
                        });
                    });
            return false;
        }
    </script>
    <style>
        #test {
            font-family: "Times New Roman", serif;
            padding: 20px;
            background: #234;
            color: #ffc;
            width: 400px;
            text-align: center;
        }
        .input_line{
            display: table-cell;
            border-top: 0px;
            border-left: 0px;
            border-right: 0px;
            border-bottom: 1px solid #333;
            width: 100% !important;
        }
        .uk-table {
            font-size: 17px !important;
            font-weight: 700;
            border: 2px solid #222 !important;
        }

        .uk-table td,.uk-table th {
            border: 2px solid #222 !important;
            padding:6px !important;
        }

    </style>

    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(URL::asset('mighty/plugins/form-builder.min.css')); ?>">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(URL::asset('mighty/plugins/main.min.css')); ?>">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(URL::asset('mighty/plugins/uikit.almost-flat.min.css')); ?>">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(URL::asset('mighty/plugins/formpro1.css')); ?>">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(URL::asset('mighty/plugins/jquery_ui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('mighty/plugins/template3.css')); ?>">
    <style>
        .content {
        // min-height: 1811px;
        }
    </style>
    <style>
        li.rows{
            min-height:50px;
        }
        li.columns{
            float:left;
            height:75px;
            list-style: none;
        }
        li.highlight{
            min-height: 70px;
        }
        .dropovers{
            /*  border:1px solid #ccc;
              border-right-color:red;*/
        }
        body{
            /*overflow: hidden;
            height: 100%;*/
        }
        .content{
            padding-left: 0px !important;
        }
        body {
            padding-top: 0px !important;
        }
        .uk-grid > * {
            float: none;
        }
        .cmdline{
            width:90%;margin-top: 6%;color: rgb(12, 12, 12);border: 0.1px solid;
        }
        .th{
        // padding: 6px 22px 13px 1px;
            border: 1px solid;
        }
        .row1Title {
            background: none repeat scroll 0 0 #005AAB;
            border-bottom: 1px solid #000000;
            color: #FFFFFF;
            /* font-family: 'MyriadProBold'; */
            font-size: 12pt;
            height: 26px;

            text-align: center;
        }
        .svgTable{
            /* margin-left: 30px;*/
            margin-left: 14px;
            margin-top: 7px;
        }
        .uk-h2, h2 {
            font-size: 24px;
            line-height: normal;
        }
        .click-edit-icons {
            background-image: url("<?php echo e(URL::asset('mighty/images/clicktoedit.png')); ?>");
            background-size: 15px;
            width: 15px;
            height: 15px;
            float: right;
        }
        .spanlable{
            max-width: 100%;
            font-weight: 700;
            display: block;
            text-align: center;
            margin: 4px 0px 8px;
        }
        .comp4boxi{
            width: 145px !important;
        }
        .optionbox{
            float:left;
        }
        .lrchange
        {
            background: url('<?php echo e(URL::asset('mighty/images/leftright.png')); ?>');
            width: 18px;
            height: 18px;
            background-size: 19px;
            display: block;
            margin-top: -2px;
            margin-right: 10px;
        }
        .add_morerow{
            background: url('<?php echo e(URL::asset('mighty/images/add2.png')); ?>');
            background-size: 15px;
            display: block;
            width: 15px;
            height: 15px;
            float: right;
            cursor: pointer;
            padding-left: 0px;
        }
        .uncheck-grey,.check-red{
            display: none;
        }
        .inspectionTable {

        }
        .fontF {
            font-family: 'MyriadProBold';
            font-size: 13pt !important;
            font-style: italic;
        }
        .interior_inspec h2 {
            font-size: 11pt !important;
            font-weight: 700;
            color: black;
        }
        .floatLeft,.fontF,.txt_bold_lower_case ,.bottomtext ,.txt_bold {
            font-family: helvetica;
        }
        img {
            max-width: none;
        }
        .txtFont {

            font-size: 10pt !important;

        }
        .check-box{
            width: 25px;
            height: 25px;
            background: #f8f8f8;
            display: inline-block;
            vertical-align: middle;
            border: 1px solid #222;
        }
        .check-value,.check-title{
            font:400 20px/1.42857143 Roboto,sans-serif !important;
        }.check-value{
             margin-right: 35px;
         }
        .tire-condition{
            display: block;
            width: 100%;
            float: left;
        }
        .tire-lflr{
            display: block;
            width: 100%;
            float: left;
            margin-top: 10px;
        }


    </style>

    <!-- <script src="<?php echo e(URL::asset('mighty/plugins/jquery.min.js')); ?>"></script> -->



    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>

            <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Mighty Customizable Vehicle Inspection Forms
            <small>Control panel</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>

            <li class="active">Update Template</li>
        </ol>
    </section>
    <?php if(Session::has('true_msg')): ?>
        <div class="alert alert-success">
            <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
            <?php echo e(Session::get('true_msg')); ?>

        </div> <!-- /.alert -->
    <?php endif; ?>
    <?php if(Session::has('error_msg')): ?>
        <div class="alert alert-danger">
            <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
            <?php echo e(Session::get('error_msg')); ?>

        </div> <!-- /.alert -->
        <?php endif; ?>
                <!-- Main content -->
        <section class="content">
            <div class="col-md-12">
                <!-- Custom Tabs -->
                
            </div>
            <div class="row">
                <div class="col-md-7">
                </div>
                <div class="col-md-2">
                    <a class="btn btn-block btn-primary btn-xs" href="<?php echo e(url('/cvif/template/edit-preview/')); ?>/<?php echo e($formdetails->uuid); ?>">Edit this template </a>
                </div>
                <div class="col-md-2">
                    

                    <button  class="btn btn-block btn-primary btn-xs" onclick="generatePDF()">Generate Pdf</button>
                </div>
                <div id="img-out">

                </div>
            </div>
            <?php
            if($formdetails->imageType==0){
                $imgclrg="greenCircle";
                $imgclry="yellowCircle";
                $imgclrr="redCircle";

                $smlimgclrg="smallGreenCircle";
                $smlimgclry="smallYellowCircle";
                $smlimgclrr="smallRedCircle";
            }else{
                $imgclrg="green";
                $imgclry="yellow";
                $imgclrr="red";

                $smlimgclrg="smallGreen";
                $smlimgclry="smallYellow";
                $smlimgclrr="smallRed";
            }
            ?>
            <div id="page_content">
                <div id="page_content_inner">
                    <div class="uk-grid" style="display: block;padding-left:0px !important"; data-uk-grid-margin data-uk-grid-match id="wizard_forms">

                        <div class="uk-width-large-2-10"  id="sidebar" style="float: left;width:20%;display:none">
                            <div class="uk-width-1-1">
                                <div class="parsley-row">
                                    <div class="md-card  form-desc ">
                                        <label class="fn">Name your form<span class="req">*</span></label>
                                        <input type="text" class="md-input fn-field" id="form_name" name="form_name" value="<?php echo e($formdetails->form_name); ?>" data-parsley-trigger="change" required  />
                                        <label class="fd">Short description about your form </label>
                                        <textarea name="form_desc"  class="md-input" id="form_desc" style=""><?php echo e($formdetails->form_desc); ?></textarea>
                                    </div>
                                </div>
                                <div class="parsley-row">
                                    <div class="md-card  form-desc ">
                                        <label class="fn">Box Type</label>
                                        <div style="margin-left: 20px;">
                                            <div class="radio">
                                                <label>
                                                    <input name="imageTypes" id="imageType1" class="imageType" value="0" <?php if($formdetails->imageType==0): ?> checked <?php endif; ?>    type="radio">Circle
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input name="imageTypes" id="imageType2" class="imageType" value="1"  <?php if($formdetails->imageType==1): ?> checked <?php endif; ?>   type="radio">Square
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="md-card dragdrop-panel">
                                <div class="md-card-content">
                                    <div class="uk-panel">
                                        <div class="heading">Drag and drop for build new form</div>
                                        <div class="uk-accordion" data-uk-accordion>
                                            <h3 class="uk-accordion-title uk-accordion-title-primary">Basic</h3>
                                            <div class="uk-accordion-content">
                                                <ul id="basic">
                                                    <li><div class="singleline-icon" ></div><span value="heading">Heading</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="text">Single Line Text</span></li>
                                                    <li><div class="email-icon"></div><span value="email">Email</span></li>
                                                    <li><div class="multiline-icon"></div><span value="textarea">Multi Line Text</span></li>
                                                    <li><div class="multiline-icon"></div><span value="number">Number</span></li>
                                                    <li><div class="radio-icon"></div><span value="radio">Radio</span></li>
                                                    <li><div class="select-icon"></div><span value="select">Select</span></li>
                                                    <li><div class="checkbox-icon"></div><span value="checkbox">Checkbox</span></li>
                                                    <li><div class="date-icon"></div><span value="date">Date</span></li>
                                                    <li><div class="time-icon"></div><span value="time">Time</span></li>
                                                    <li><div class="file-icon"></div><span value="file">File</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="emptyspace">Empty space</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="line">Line</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="textwithline">Text with Line</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="condition">Condition Square</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="condition2">Condition Circle</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="tablehead">Item and Content (Table)</span></li>
                                                    <!-- <li><div class="singleline-icon" ></div><span value="tablerow">Table Row</span></li>-->
                                                    <li><div class="singleline-icon" ></div><span value="component2">INTERIOR/EXTERIOR</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="component1">UNDER VEHICLE </span></li>
                                                    <li><div class="singleline-icon" ></div><span value="component3">UNDERHOOD</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="component4">TIRES</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="component5">BRAKES</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="component6">COMMENTS</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="component7">BATTERY</span></li>
                                                </ul>
                                            </div>
                                            <h3 class="uk-accordion-title uk-accordion-title-primary">Advanced</h3>
                                            <div class="uk-accordion-content">
                                                <ul id="advanced">
                                                    <li><div class="sign-icon"></div><span value="signature">Signature</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <form class="uk-form-stacked" id="wizard_advanced_form" method="post" enctype="multipart/form-data" >
                            <div class="uk-width-large-8-10"   style="/*float:left;*/height: 100%;padding-left:12px;width: 1180px;margin: 0 auto;">
                                <div class="md-card" id="content_right">
                                    <div class="form md-card-content" style="">
                                        <div id="forms" data-form_id ="1" style="width:100%;height: 100%;padding-bottom: 53px;">
                                            <ul id="pages" style="height: 100%;">
                                                <!--<li class="rows" id="rows_1"></li>-->
                                                <?php
                                                $edFlag=1;
                                                $options=0;
                                                $formToken=$formdetails->form_content;
                                                $ftk_array=json_decode($formToken);


                                                foreach ($ftk_array as $pages) {
                                                $res_array=$pages;
                                                foreach ($res_array as $res) {

                                                $res_result=$res;
                                                $remove=count($res_result)-1;
                                                unset($res_result[$remove]);
                                                if(!empty($res_result)){
                                                foreach ($res_result as $key=> $rows) {
                                                $row=$key;


                                                ?>
                                                <li class="rows uk-width-1-1 ui-droppable" id="rows_<?php echo e($row+1); ?>">
                                                    <ul id="rows_<?php echo e($row+1); ?>" style="height: <?php echo e($rows[0]->rowheight); ?>px;" class="connected" >
                                                        <?php

                                                        foreach ($rows as $index=>$cols) {
                                                        $col=$index;
                                                        if(isset($cols->choices)){
                                                            $options++;
                                                        }


                                                        ?>

                                                        <li style="height: <?php echo e($cols->rowheight); ?>px;" class="uk-width-1-<?php echo e(count($rows)); ?> columns" id="columns_<?php echo e($col+1); ?>">

                                                            <div class="cols uk-width-1-1 <?php echo e($cols->type); ?>_undefined">
                                                                <div class="uk-panel config_<?php echo e($cols->type); ?> portlet">
                                                                    <div class="portlet-header" data-type="<?php echo e($cols->type); ?>" data-fieldid="<?php echo e($cols->fieldid); ?>">
                                                                        <!--Start -->
                                                                        <?php if($cols->type=="text"): ?>
                                                                                <!--<input type="text" />-->
                                                                        <div class="uk-grid">
                                                                            <div class="titl-field1 left_setting" style="width:100%;display: inherit;">
                                                                                <label class="title_label" style="font-size: 17px;display:table-cell;white-space: nowrap;"><?php echo e($cols->title); ?> :</label>
                                                                                <input type="text" class="input_line" readonly  />
                                                                            </div>

                                                                        </div>
                                                                        <?php elseif($cols->type=="heading"): ?>
                                                                                <!-- Heading Templates-->

                                                                        <!--<input type="text" />-->
                                                                        <div class="uk-grid">
                                                                            <div class="titl-field1 left_setting" style="width:100%;text-align: center;">
                                                                                <label class="title_label heading_title"><?php echo e($cols->title); ?></label>
                                                                            </div>
                                                                        </div>

                                                                        <?php elseif($cols->type=="email"): ?>
                                                                                <!-- Email Controls -->

                                                                        <div class="uk-grid">
                                                                            <div class="titl-field1 left_setting" style="width:100%;">
                                                                                <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                                                                                <input type="email" readonly style="display:table" />
                                                                            </div>
                                                                        </div>

                                                                        <?php elseif($cols->type=="number"): ?>
                                                                                <!-- Number Controls -->

                                                                        <div class="uk-grid">
                                                                            <div class="titl-field1 left_setting" style="width:100%;">
                                                                                <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                                                                                <input type="number" readonly style="display:table" />
                                                                            </div>
                                                                        </div>

                                                                        <!-- Date controls -->
                                                                        <?php elseif($cols->type=="date"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting">
                                                                                    <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                                                                                    <input type="text"  readonly style="display:table" />
                                                                                    <input type = "hidden" id="date_format"  value ="" />
                                                                                </div>
                                                                                <div class="options" id="choices" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <select style="padding:4px 6px;"  class="uk-form-select" name="date_format" id="date_formats">
                                                                                            <option value="MM/dd/yyyy">MM/DD/YYYY</option>
                                                                                            <option value="dd/MM/yyyy">DD/MM/YYYY</option>
                                                                                            <option value="yyyy/MM/dd">YYYY/MM/DD</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <!-- Time controls -->
                                                                        <?php elseif($cols->type=="time"): ?>

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label" style="width:100%;display:table"><?php echo e($cols->title); ?></label>
                                                                                    <input type="text" readonly style="display:table">
                                                                                    <input type = "hidden" id="time_format"  value ="" />
                                                                                </div>
                                                                                <div class="options" id="choices" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <select style="padding:4px 6px;"  class="uk-form-select" name="time_format" id="time_formats">
                                                                                            <option value="hh:mm:ss">12 Hrs</option>
                                                                                            <option value="HH:mm:ss">24 Hrs</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <!-- Signature -->
                                                                        <?php elseif($cols->type=="signature"): ?>

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label"><?php echo e($cols->title); ?></label>
                                                                                    <br/>
                                                                                    <input type="text" readonly style="display:table">
                                                                                </div>
                                                                            </div>

                                                                            <?php elseif($cols->type=="radio"): ?>
                                                                                    <!-- Radio Button Templates -->

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                                                                                    <div class="title_radio select">
                                                                                        <?php if(isset($cols->choices)): ?>
                                                                                            <?php
                                                                                            $choice_array=$cols->choices;
                                                                                            ?>
                                                                                            <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                <input type="radio" name="radio" value="<?php echo e($chres->title); ?>" /> <span class="title_value" data-optionid="0"><?php echo e($chres->title); ?></span>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="options" id="choices_<?php echo e($cols->formfieldid); ?>" style="display:none">

                                                                                    <div class="input_fields_wrap">
                                                                                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                        </a> -->
                                                                                        <element>
                                                                                            <?php
                                                                                            $choice_array=$cols->choices;
                                                                                            ?>
                                                                                            <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chindex=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                <p>
                                                                                                    <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                           value="<?php echo e($chres->title); ?>"/>
                                                                                                    <?php if($chindex==0): ?>
                                                                                                        <span class="add-option add_field_button"></span>
                                                                                                    <?php else: ?>
                                                                                                        <span class="delete-option remove_field"></span>
                                                                                                    <?php endif; ?>
                                                                                                </p>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                                        </element>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="<?php echo e($cols->type); ?>";
                                                                                //// comptField="<?php echo e($options); ?>";
                                                                                row_id="rows_<?php echo e($row+1); ?>";
                                                                                collength="<?php echo e($col+1); ?>";
                                                                                dialog = popup_initialize('choices_<?php echo e($cols->formfieldid); ?>','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_<?php echo e($cols->formfieldid); ?>',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                            <!--Check Box Templates -->
                                                                        <?php elseif($cols->type=="checkbox"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label" style="font-size: 20px;"><?php echo e($cols->title); ?></label><br/>
                                                                                    <label class="title_label1 check-title" style="<?php echo e((isset($cols->subtitle) && !empty($cols->subtitle))
                        ? '' : 'display:none'); ?>"><?php echo e($cols->subtitle); ?></label>
                                                                                    <div class="title_checkbox select">
                                                                                        <?php if(isset($cols->choices)): ?>
                                                                                            <?php
                                                                                            $choice_array=$cols->choices;
                                                                                            ?>
                                                                                            <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                <div style="display:inline-block;"> <strong class="check-box"></strong>
                                                                                                    <span class="title_value check-value" data-optionid="0"><?php echo e($chres->title); ?></span>
                                                                                                </div>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                    <div class="options" id="choices_<?php echo e($cols->formfieldid); ?>" style="display:none">
                                                                                        <div class="input_fields_wrap">
                                                                                            <!--  <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                             <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                             </a> -->
                                                                                            <element>

                                                                                                <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chindex=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                    <p>
                                                                                                        <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                               value="<?php echo e($chres->title); ?>"/>
                                                                                                        <?php if($chindex==0): ?>
                                                                                                            <span class="add-option add_field_button"></span>
                                                                                                        <?php else: ?>
                                                                                                            <span class="delete-option remove_field"></span>
                                                                                                        <?php endif; ?>
                                                                                                    </p>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                            </element>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="<?php echo e($cols->type); ?>";
                                                                                //// comptField="<?php echo e($options); ?>";
                                                                                row_id="rows_<?php echo e($row+1); ?>";
                                                                                collength="<?php echo e($col+1); ?>";
                                                                                dialog = popup_initialize('choices_<?php echo e($cols->formfieldid); ?>','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_<?php echo e($cols->formfieldid); ?>',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                            <!-- start checkbox -->

                                                                            <!-- end checkbox -->

                                                                            <?php elseif($cols->type=="select"): ?>
                                                                                    <!-- Select dropdown Templates -->

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                                                                                    <div class="title_checkbox select">
                                                                                        <select>

                                                                                            <?php if(isset($cols->choices)): ?>
                                                                                                <?php
                                                                                                $choice_array=$cols->choices;
                                                                                                ?>
                                                                                                <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                    <option>
                                                                  <span class="title_value" data-optionid="0">
                                                                         <?php echo e($chres->title); ?>

                                                                  </span>      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                                            <?php endif; ?>
                                                                                        </select>
                                                                                    </div>
                                                                                    <div class="options" id="choices_<?php echo e($cols->formfieldid); ?>" style="display:none">
                                                                                        <div class="input_fields_wrap">
                                                                                            <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                            </a> -->
                                                                                            <element>
                                                                                                <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chindex=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                    <p>
                                                                                                        <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                               value="<?php echo e($chres->title); ?>"/>
                                                                                                        <?php if($chindex==0): ?>
                                                                                                            <span class="add-option add_field_button"></span>
                                                                                                        <?php else: ?>
                                                                                                            <span class="delete-option remove_field"></span>
                                                                                                        <?php endif; ?>
                                                                                                    </p>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                            </element>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                            <script>
                                                                                type ="<?php echo e($cols->type); ?>";
                                                                                //// comptField="<?php echo e($options); ?>";
                                                                                row_id="rows_<?php echo e($row+1); ?>";
                                                                                collength="<?php echo e($col+1); ?>";
                                                                                dialog = popup_initialize('choices_<?php echo e($cols->formfieldid); ?>','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_<?php echo e($cols->formfieldid); ?>',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                            <?php elseif($cols->type=="textarea"): ?>
                                                                                    <!-- TextArea Templates -->

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                                                                                    <textarea style="resize: none;height: 40px; width: 200px;" readonly></textarea>
                                                                                </div>
                                                                            </div>

                                                                            <?php elseif($cols->type=="file"): ?>
                                                                                    <!-- File Select Templates -->

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;text-align: center;">
                                                                                    <!-- <label class="title_label"><?php echo e($cols->title); ?></label> -->
                                                                                    <?php if(isset($cols->filepath) && ($cols->filepath!='undefined') && ($cols->filepath!='')): ?>
                                                                                        <?php
                                                                                        $filename=URL::asset('mighty/images/template/').'/'.$cols->filepath;
                                                                                        $size = getimagesize($filename);
                                                                                        ?>
                                                                                        <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($cols->filepath); ?>"  <?php if(($size[1]>111 || $size[0]>360)): ?> style="height: 90px;" <?php endif; ?> />

                                                                                        <?php endif; ?>
                                                                                                <!--
                                                                                             
                                                                                                <p>
                                                                                          <input type="text" class="height" name="height"  style="height: 22px;width: 78px;"
                                                                                                 maxlength="3" minlength="1" value="<?php echo e($cols->height); ?>" required/><span style="color:red;font-size:10px;">Height</span>
                                                                                        <input type="text" class="width" name="width"  style="height: 22px;width: 78px;"
                                                                                               maxlength="3" minlength="1" value="<?php echo e($cols->width); ?>" required/><span style="color:red;font-size:10px;">Width</span>
                                                                                    </p> -->
                                                                                </div>

                                                                            </div>

                                                                            <?php elseif($cols->type=="placepicker"): ?>
                                                                                    <!-- Place picker -->

                                                                            <div class="uk-grid">
                                                                                <div class="uk-width-1-2" style="width:100%;">
                                                                                    <label class="title_label"><?php echo e($cols->title); ?></label><br/>
                                                                                </div>
                                                                            </div>

                                                                        <?php elseif($cols->type=="line"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;">
                                                                                    <label class="title_label" style="display: none;"></label>
                                                                                    <input type="text" class="input_line" readonly="">
                                                                                </div>
                                                                            </div>
                                                                        <?php elseif($cols->type=="textwithline"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting" style="width:100%;display:inherit;">
                                                                                    <label class="title_label" style="display: table-cell;white-space: nowrap;"><?php echo e($cols->title); ?></label>
                                                                                    <input type="text" class="input_line" readonly="">
                                                                                </div>
                                                                            </div>
                                                                        <?php elseif($cols->type=="emptyspace"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="left_setting" style="width:100%;">
                                                                                    <label class="title_label" style="display: none;">Empty space</label><br/>
                                                                                </div>
                                                                            </div>
                                                                        <?php elseif($cols->type=="component1"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field2 left_setting inspectionTable" style="width:100%;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>
                                                                                    <div class="title_component1 select">

                                                                                        <?php
                                                                                        $choice_array=$cols->choices;
                                                                                        ?>
                                                                                        <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                            <div class="clear row1">
                                                                                                <input type="hidden" name="component1"/>
                                                                                                <span class="optionbox" <?php if($cols->lrtype==1): ?> style="float:right" <?php else: ?> style="float:left" <?php endif; ?> ><b class="<?php echo e($imgclrg); ?>"></b><b class="<?php echo e($imgclry); ?>"></b><b class="<?php echo e($imgclrr); ?>"></b></span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" ><?php echo e($chres->title); ?></span>
                                                                                            </div>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                    </div>
                                                                                    <div class="options" id="choices_<?php echo e($cols->formfieldid); ?>" style="display:none">
                                                                                        <div class="input_fields_wrap">
                                                                                            <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                            </a> -->
                                                                                            <element>
                                                                                                <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chindex=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                    <p>
                                                                                                        <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                               value="<?php echo e($chres->title); ?>"/>
                                                                                                        <?php if($chindex==0): ?>
                                                                                                            <span class="add-option add_field_button"></span>
                                                                                                        <?php else: ?>
                                                                                                            <span class="delete-option remove_field"></span>
                                                                                                        <?php endif; ?>
                                                                                                    </p>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                                            </element>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <input type="hidden" style="display:none" name="component1_style" id="component1_style" value="<?php echo e($cols->lrtype); ?>" />

                                                                            </div>
                                                                            <script>
                                                                                type ="<?php echo e($cols->type); ?>";
                                                                                //// comptField="<?php echo e($options); ?>";
                                                                                row_id="rows_<?php echo e($row+1); ?>";
                                                                                collength="<?php echo e($col+1); ?>";
                                                                                dialog = popup_initialize('choices_<?php echo e($cols->formfieldid); ?>','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_<?php echo e($cols->formfieldid); ?>',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                        <?php elseif($cols->type=="component2"): ?>
                                                                            <div class="uk-grid ">
                                                                                <div class="titl-field2 left_setting inspectionTable" style="width:100%;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>
                                                                                    <div class="title_component2 selects">
                                                                                        <div class="clear row1">
                                                                                            <input type="hidden" name="component2"/>
                                                                                            <label class="title_label1"><?php echo e($cols->subtitle); ?></label>
                                                                                        </div>
                                                                                    </div>
                                                                                    <input type="hidden" style="display:none" name="component2_style" id="component2_style" value="<?php echo e($cols->lrtype); ?>" />
                                                                                    <div class="title_component2 selects">
                                                                                        <div class="clear row1">
                                                                                            <input type="hidden" name="component2"/>
                            <span class="alignCenter" style="display:block; height:120px;">
                                <?php if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!='')): ?>
                                    <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($cols->filepath); ?>"  alt="" style="max-width: 247px;max-height:116px;" />
                                <?php else: ?>
                                    <img src="<?php echo e(URL::asset('mighty/images/car-top.png')); ?>" alt="" style="max-width: 247px;max-height:116px;">
                                <?php endif; ?>

										</span>

                                                                                        </div>
                                                                                    </div>
                                                                                    <?php if(isset($cols->filepath)): ?>
                                                                                        <input type="hidden" class="filepath" value="<?php echo e($cols->filepath); ?>" />
                                                                                    <?php endif; ?>
                                                                                    <div class="title_component2 select">

                                                                                        <?php
                                                                                        $choice_array=$cols->choices;
                                                                                        ?>
                                                                                        <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                            <div class="clear row1">
                                                                                                <input type="hidden" name="component2"/>
                                                                                                <span class="optionbox" <?php if($cols->lrtype==1): ?> style="float:right" <?php else: ?> style="float:left" <?php endif; ?> ><b class="<?php echo e($imgclrg); ?>"></b><b class="<?php echo e($imgclry); ?>"></b><b class="<?php echo e($imgclrr); ?>"></b></span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" ><?php echo e($chres->title); ?></span>
                                                                                            </div>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                    </div>

                                                                                </div>

                                                                                <div class="options" id="choices_<?php echo e($cols->formfieldid); ?>" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                        </a> -->
                                                                                        <element>

                                                                                            <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chindex=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                <p>
                                                                                                    <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                           value="<?php echo e($chres->title); ?>"/>
                                                                                                    <?php if($chindex==0): ?>
                                                                                                        <span class="add-option add_field_button"></span>
                                                                                                    <?php else: ?>
                                                                                                        <span class="delete-option remove_field"></span>
                                                                                                    <?php endif; ?>
                                                                                                </p>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                        </element>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="<?php echo e($cols->type); ?>";
                                                                                //// comptField="<?php echo e($options); ?>";
                                                                                row_id="rows_<?php echo e($row+1); ?>";
                                                                                collength="<?php echo e($col+1); ?>";
                                                                                dialog = popup_initialize('choices_<?php echo e($cols->formfieldid); ?>','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_<?php echo e($cols->formfieldid); ?>',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                        <?php elseif($cols->type=="component3"): ?>
                                                                            <div class="uk-grid ">
                                                                                <div class="titl-field2 left_setting inspectionTable" style="width:100%;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>
                                                                                    <div class="title_component3 select">
                                                                                        <?php
                                                                                        $choice_array=$cols->choices;
                                                                                        $choicecount=count($choice_array)-3;

                                                                                        ?>
                                                                                        <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                            <?php if($choicecount>$index): ?>
                                                                                                <div class="clear row1">
                                                                                                    <input type="hidden" name="component3"/>
                                                                                                    <span class="optionbox"  ><b class="<?php echo e($imgclrg); ?>"></b><b class="<?php echo e($imgclry); ?>"></b><b class="<?php echo e($imgclrr); ?>"></b></span>
                                                                                                    <span class="inspectionTxt title_value" data-optionid="0" ><?php echo e($chres->title); ?></span>
                                                                                                </div>
                                                                                            <?php endif; ?>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


                                                                                    </div>
                                                                                    <div class="title_component3 selects">
                                                                                        <div class="clear row1">
                                                                                            <input type="hidden" name="component3"/>
                                                                                            <p>
                                                                                                <span ><b class="<?php echo e($imgclrg); ?>"></b><b class="<?php echo e($imgclry); ?>"></b><b class="<?php echo e($imgclrr); ?>"></b></span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" ><?php echo e($choice_array[count($choice_array)-3]->title); ?></span>
                                                                                            </p><p>
                                                                                                <span><b class="<?php echo e($imgclrg); ?>"></b><b class="<?php echo e($imgclry); ?>"></b><b class="<?php echo e($imgclrr); ?>"></b></span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" ><?php echo e($choice_array[count($choice_array)-2]->title); ?></span>
                                                                                            </p><p>
                                                                                                <span><b class="<?php echo e($imgclrg); ?>"></b><b class="<?php echo e($imgclry); ?>"></b><b class="<?php echo e($imgclrr); ?>"></b></span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" ><?php echo e($choice_array[count($choice_array)-1]->title); ?></span>
                                                                                            </p><div style="float: right;margin-top: -23%;width: 91px;">

                                                                                                <?php if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!='')): ?>
                                                                                                    <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($cols->filepath); ?>" style="max-width: 92px;max-height: 60px;" />
                                                                                                <?php else: ?>
                                                                                                    <img src="<?php echo e(URL::asset('mighty/images/Might99171.PNG')); ?>" style="max-width: 92px;max-height: 60px;">
                                                                                                <?php endif; ?>

                                                                                                <?php if(isset($cols->filepath)): ?>
                                                                                                    <input type="hidden" class="filepath" value="<?php echo e($cols->filepath); ?>" />
                                                                                                <?php endif; ?>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="options" id="choices_<?php echo e($cols->formfieldid); ?>" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                        </a> -->
                                                                                        <element>

                                                                                            <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                                <?php if($choicecount>$index): ?>
                                                                                                    <p>
                                                                                                        <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                               value="<?php echo e($chres->title); ?>"/>
                                                                                                        <?php if($index==0): ?>
                                                                                                            <span class="add-option add_field_button"></span>
                                                                                                        <?php else: ?>
                                                                                                            <span class="delete-option remove_field"></span>
                                                                                                        <?php endif; ?>
                                                                                                    </p>
                                                                                                <?php endif; ?>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                        </element>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="<?php echo e($cols->type); ?>";
                                                                                //// comptField="<?php echo e($options); ?>";
                                                                                row_id="rows_<?php echo e($row+1); ?>";
                                                                                collength="<?php echo e($col+1); ?>";
                                                                                dialog = popup_initialize('choices_<?php echo e($cols->formfieldid); ?>','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_<?php echo e($cols->formfieldid); ?>',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                        <?php elseif($cols->type=="component4"): ?>
                                                                            <div class="uk-grid ">
                                                                                <div class="titl-field2 left_setting inspectionTable" style="width: 100%; border-bottom: 1px solid #000; ">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>
                                                                                    <div class="title_component4 select">
                                                                                        <div class="clear row1x">
                                                                                            <input type="hidden" name="component4"/>
                                                                                            <span class="comp4boxl spanlable title_label1"  ><?php echo e($cols->subtitle); ?></span>
                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($cols->subtitle); ?>" />
                                                                                            <div class="clear paddingBottom" style="height:30px;">
                                                                                                <!-- start -->
                                                                                                <div class="tire-condition">
        <span style="width:162px; float:left;">
	<b style="margin-left: 24px;" class="<?php echo e($imgclrg); ?>"></b>
<strong class="comp4boxl option1" style="display: block;line-height: 17px;" ><?php echo e($cols->option1); ?></strong>
<input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($cols->option1); ?>" />
	</span>
	<span style="width:160px; float:left;">
	<b style="margin-left: 14px;" class="<?php echo e($imgclry); ?>"></b>
	 <strong class="comp4boxl option2"  ><?php echo e($cols->option2); ?></strong>
<input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($cols->option2); ?>" />
	</span>
	<span style="width:160px; float:left;">
	<b class="<?php echo e($imgclrr); ?>"></b>

        <strong class="comp4boxl option3"  ><?php echo e($cols->option3); ?></strong>
<input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($cols->option3); ?>" />
	</span>
                                                                                                </div>

                                                                                                <?php
                                                                                                $choice_array=$cols->cm4rows;
                                                                                                ?>
                                                                                                <div class="tire-lflr">
                                                                                                    <div class="comp4rows"><div class="bordernone interior_inspec1 interior_inspecLeft">
<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">

<span style="display:block;width:20px;font-weight: bold;" class="comp4boxl fontF title_value4"  ><?php echo e($choice_array[0][0][0]->title); ?></span>
<input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][0][0]->title); ?>" />
</span>

                                                                                                            <span class="txt_bold_lower_case comp4boxl fontF title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px" ><?php echo e($choice_array[0][0][1]->title); ?></span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][0][1]->title); ?>" />
                                                                                                            <span style="display:block;float:right;"><b class="<?php echo e($smlimgclrg); ?>"></b><b class="<?php echo e($smlimgclry); ?>"></b><b class="<?php echo e($smlimgclrr); ?>"></b></span>
                                                                                                        </div>
                                                                                                        <div class="bordernone interior_inspec1 interior_inspecRight">
<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
<span style="display:block;width:20px;font-weight: bold;" class="comp4boxl fontF title_value4"  ><?php echo e($choice_array[0][0][2]->title); ?></span>
<input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][0][2]->title); ?>" />
</span>
                                                                                                            <span class="comp4boxl txt_bold_lower_case title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px"><?php echo e($choice_array[0][0][3]->title); ?></span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][0][3]->title); ?>" />
                                                                                                            <span style="display:block;float:right;"><b class="<?php echo e($smlimgclrg); ?>"></b><b class="<?php echo e($smlimgclry); ?>"></b><b class="<?php echo e($smlimgclrr); ?>"></b></span>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="comp4rows">
                                                                                                        <div class="bordernone interior_inspec1 interior_inspecLeft">
                                                                                                        <span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
                                                                                                            <span style="display:block;width:20px;font-weight: bold;" class="comp4boxl fontF title_value4"  ><?php echo e($choice_array[0][1][0]->title); ?></span>
<input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][1][0]->title); ?>" />
</span>

                                                                                                            <span class="comp4boxl txt_bold_lower_case title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px"><?php echo e($choice_array[0][1][1]->title); ?></span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][1][1]->title); ?>" />
                                                                                                            <span style="display:block;float:right;"><b class="<?php echo e($smlimgclrg); ?>"></b><b class="<?php echo e($smlimgclry); ?>"></b><b class="<?php echo e($smlimgclrr); ?>"></b></b></span>
                                                                                                        </div>
                                                                                                        <div class="bordernone interior_inspec1 interior_inspecRight">
                                                                                                        <span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
<strong style="display:block;width:20px;"> <span class="comp4boxl title_value4" style="position:relative; left:-5px;float:right;display:block;width:67px"><?php echo e($choice_array[0][1][2]->title); ?></span><input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][1][2]->title); ?>" /></strong></span>
                                                                                                            <span class="comp4boxl txt_bold_lower_case title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px"><?php echo e($choice_array[0][1][3]->title); ?></span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][1][3]->title); ?>" />
                                                                                                            <span style="display:block;float:right;"><b class="<?php echo e($smlimgclrg); ?>"></b><b class="<?php echo e($smlimgclry); ?>"></b><b class="<?php echo e($smlimgclrr); ?>"></b></span>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>

                                                                                                <!-- end -->
                                                                                            </div></div>
                                                                                        <div class="clear row1x">
                                                                                            <div class="comp4rows" style="float: left">
                               <span style="margin-top: 15px;text-align: center;padding:0px;width:100px;float:left;">
                                    <?php if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!='')): ?>
                                       <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($cols->filepath); ?>"   style="max-height: 200px;max-width: 100px;" />
                                   <?php else: ?>
                                       <img src="<?php echo e(URL::asset('mighty/images/rght_tire.png')); ?>" style="max-height: 200px;max-width: 100px;">
                                   <?php endif; ?>

								</span>
                                                                                                <?php if(isset($cols->filepath)): ?>
                                                                                                    <input type="hidden" class="filepath" value="<?php echo e($cols->filepath); ?>" />
                                                                                                <?php endif; ?>
                                                                                                <div class="bordernone interior_inspec padding_reset lessWidth" style="padding:0px;float:right; padding-top:15px;width:100px !important;">
                                                                                                    <div style="height:30px;margin-bottom:10px;width: 99px;">
                                                                                                        <h2 style="text-align:center;"><?php echo e($choice_array[0][2][0]->title); ?></h2>
                                                                                                        <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][2][0]->title); ?>" />
                                                                                                    </div>
                                                                                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
                                                                                                        <span style="width:75px; display:block;float:right;"><b class="<?php echo e($smlimgclrg); ?>"></b><b class="<?php echo e($smlimgclry); ?>"></b><b class="<?php echo e($smlimgclrr); ?>"></b></span>
                      						<span width="29" class="txt_bold txtLeft">

                                                <span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;"><?php echo e($choice_array[0][2][1]->title); ?></span>
                                       <input type="text"  class="comp4boxi" style="display: none; " value="<?php echo e($choice_array[0][2][1]->title); ?>" />

                      						</span>

                                                                                                    </div>

                                                                                                    <div class="clear" id="c2" style="text-align:right;width:100px; margin-bottom:10px;height:20px;">
                                                                                                        <span style="width:75px; display:block;float:right;"><b class="<?php echo e($smlimgclrg); ?>"></b><b class="<?php echo e($smlimgclry); ?>"></b><b class="<?php echo e($smlimgclrr); ?>"></b></span>
                      						<span class="txt_bold txtLeft">
                      							                   <span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;"><?php echo e($choice_array[0][2][2]->title); ?></span>
                                       <input type="text"  class="comp4boxi" style="display: none; " value="<?php echo e($choice_array[0][2][2]->title); ?>" />
                      						</span>

                                                                                                    </div>

                                                                                                    <div class="clear" id="c3" style="text-align:right;width:100px; margin-bottom:10px;height:20px;">
                                                                                                        <span style="width:75px; display:block;float:right;"><b class="<?php echo e($smlimgclrg); ?>"></b><b class="<?php echo e($smlimgclry); ?>"></b><b class="<?php echo e($smlimgclrr); ?>"></b></span>
                      						<span class="txt_bold txtLeft">
                      							<span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;"><?php echo e($choice_array[0][2][3]->title); ?></span>
                                       <input type="text"  class="comp4boxi" style="display: none; " value="<?php echo e($choice_array[0][2][3]->title); ?>" />
                      						</span>

                                                                                                    </div>
                                                                                                    <div class="clear" id="c4" style="text-align:right;width:100px; margin-bottom:10px;height:20px;">
                                                                                                        <span style="width:75px; display:block;float:right;"><b class="<?php echo e($smlimgclrg); ?>"></b><b class="<?php echo e($smlimgclry); ?>"></b><b class="<?php echo e($smlimgclrr); ?>"></b></span>
                      						<span class="txt_bold txtLeft">
                      							<span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;"><?php echo e($choice_array[0][2][4]->title); ?></span>
                                       <input type="text"  class="comp4boxi" style="display: none; " value="<?php echo e($choice_array[0][2][4]->title); ?>" />
                      						</span>

                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div style="float: left">
                                                                                                <div class="comp4rows interior_inspec" style="border-right: 2px solid #0e62af !important;border-left: 2px solid #0e62af !important;padding:0px;width:138px; padding:0 3px; float:left;">
                                                                                                    <div cellspacing="0" class="bordernone padding_reset" style="">
                                                                                                        <div style="text-align:center;margin-top:10px;">
                                                                                                            <h2 style="text-align:center;margin: 0 0 0px;"><?php echo e($choice_array[0][3][0]->title); ?></h2>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][0]->title); ?>" />
                                                                                                        </div>
                                                                                                        <div id="redBlock">
                                                                                                            <span style="float:left; width:16px;margin-right:2px;">
                                                                                                                <b class="<?php echo e($smlimgclrr); ?>"></b>
                                                                                                            </span>
                                                                                                            <h2 style="text-align:center;margin-top: 2px;margin: 0 0 0px;"><?php echo e($choice_array[0][3][1]->title); ?></h2>

                                                                                                            <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][1]->title); ?>" />
                                                                                                            <?php if(isset($cols->imgsecondpath)): ?>
                                                                                                                <input type="hidden" class="imgsecondpath" value="<?php echo e($cols->imgsecondpath); ?>" />
                                                                                                            <?php endif; ?>
                                                                                                            <div id="imgBottomMid" class="imgBottomMid" style="width:40px; height:36px;">
                                                                                                                <?php if(isset($cols->imgsecondpath) && ($cols->imgsecondpath!='undefined' && $cols->imgsecondpath!='')): ?>
                                                                                                                    <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($cols->imgsecondpath); ?>"style="max-height: 36px;max-width: 40px;" />
                                                                                                                <?php else: ?>
                                                                                                                    <img src="<?php echo e(URL::asset('mighty/images/symbol.png')); ?>" alt="symbol" style="max-width:40px;max-height: 36px;" id="image">
                                                                                                                <?php endif; ?>

                                                                                                            </div>

                                                                                                        </div>
                                                                                                        <div class="bordernone interior_inspec">
                                                                                                            <div class="beforeAfter">
                                                                                                                <strong  class="comp4boxl"  style="position:relative; left:11px;font-size: 8px;"><?php echo e($choice_array[0][3][2]->title); ?></strong>
                                                                                                                <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][2]->title); ?>" />
                                                                                                                &nbsp;&nbsp;

                                                                                                                <strong  class="comp4boxl"  style="position:relative; left:11px;font-size: 8px;"><?php echo e($choice_array[0][3][3]->title); ?></strong>
                                                                                                                <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][3]->title); ?>" />

                                                                                                            </div>
                                                                                                            <div style="width:100%;" class="clear">
                                                                                                                <div style="float:left;width:20px;">
                                 				<span style="width:20px;display:block; float:left; height:27px;">
                                 			<span class="comp4boxl txt_bold" colspan="2" style=""><?php echo e($choice_array[0][3][4]->title); ?></span>
                                           <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][4]->title); ?>" />

                                 				</span>
								 				<span style="width:20px;display:block; float:left; height:27px;">
								 					<span class="comp4boxl txt_bold" colspan="2" style=""><?php echo e($choice_array[0][3][5]->title); ?></span>
                                           <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][5]->title); ?>" />
								 				</span>
                                                                                                                </div>
                                                                                                                <div style="width:50px; float:left;margin-right:3px;">
                                                                                                                    <span class="white_box">&nbsp;</span><br>
                                                                                                                    <span class="white_box">&nbsp;</span></div>
                                                                                                                <span class="white_box_rectangle">&nbsp;</span>
                                                                                                            </div>
                                                                                                            <div style="width:100%;" class="clear">
                                                                                                                <div style="float:left;width:20px;">
                                 					<span style="width:20px;display:block; float:left; height:27px;">
                                 						<span class="comp4boxl txt_bold" colspan="2" style=""><?php echo e($choice_array[0][3][6]->title); ?></span>
                                           <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][6]->title); ?>" />
                                 					</span>
								 					<span style="width:20px;display:block; float:left; height:27px;">
								 					<span class="comp4boxl txt_bold" colspan="2" style=""><?php echo e($choice_array[0][3][7]->title); ?></span>
                                           <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][3][7]->title); ?>" />
								 					</span>
                                                                                                                </div>
                                                                                                                <div style="width:50px; float:left;margin-right:3px;">
                                                                                                                    <span class="white_box">&nbsp;</span><br>
                                                                                                                    <span class="white_box">&nbsp;</span>
                                                                                                                </div>&nbsp;
                                                                                                                <span class="white_box_rectangle">&nbsp;</span>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div style="float: left">
                                                                                                <div class="comp4rows interior_inspec" style="padding:0px;width:155px;float:left; padding: 0px 3px 10px 10px;">
                                                                                                    <div style="margin-top:15px;">

                                                                                                        <h2 class="comp4boxl titleFont" colspan="2" style="padding:0px;word-wrap: break-word !important;"><?php echo e($choice_array[0][4][0]->title); ?></h2>
                                                                                                        <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($choice_array[0][4][0]->title); ?>" />

                                                                                                    </div>
                                                                                                    <div class="bordernone interior_inspec" style="width:85px;">
                                                                                                        <div class="clear" id="b1" style="height:20px; margin-bottom:5px;">
                                                                                                            <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                                                                                            <span class="comp4boxl txtFont" style="vertical-align:-3px;"><?php echo e($choice_array[0][4][1]->title); ?></span>
                                                                                                            <input  class="comp4boxi" name="editComp_65" value="<?php echo e($choice_array[0][4][1]->title); ?>" style="width:45px;display:none;" maxlength="9" type="text">
                                                                                                        </div>
                                                                                                        <div class="clear" id="b2" style="height:20px; margin-bottom:5px;">
                                                                                                            <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                                                                                            <span class="comp4boxl txtFont"  style="vertical-align:-3px;"><?php echo e($choice_array[0][4][2]->title); ?></span>
                                                                                                            <input class="comp4boxi" name="editComp_66" value="<?php echo e($choice_array[0][4][2]->title); ?>" style="width:45px;display:none;" maxlength="9" type="text">
                                                                                                        </div>
                                                                                                        <div class="clear" id="b3" style="height:20px; margin-bottom:5px;">
                                                                                                            <span><span class="white_box_square" style="float:left;margin-right:5px;"></span> </span>
                                                                                                            <span class="txtFont comp4boxl" id="comp_67" style="vertical-align:-3px;"><?php echo e($choice_array[0][4][3]->title); ?></span>
                                                                                                            <input class="comp4boxi" name="editComp_67" value="<?php echo e($choice_array[0][4][3]->title); ?>" style="width:45px;display:none;" maxlength="9" type="text">
                                                                                                        </div>
                                                                                                        <div class="clear" id="b4" style="height:20px; margin-bottom:5px;">
                                                                                                            <span class="white_box_square" style="float:left;vertical-align:-3px;margin-right:5px;"></span>
                                                                                                            <span class="txtFont comp4boxl"><?php echo e($choice_array[0][4][4]->title); ?></span>
                                                                                                            <input class="comp4boxi"  value="<?php echo e($choice_array[0][4][4]->title); ?>" style="width:45px;display:none;" maxlength="9" type="text">
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>

                                                                                    </div>
                                                                                </div>

                                                                                <div class="options" id="choices" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                        </a> -->
                                                                                        <element>
                                                                                            <p>
                                                                                                <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                       value="Brakes (Pads / Shoes)"/>
                                                                                                <span class="add-option add_field_button"></span>
                                                                                            </p>
                                                                                        </element>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        <?php elseif($cols->type=="component5"): ?>
                                                                            <div class="uk-grid ">
                                                                                <div class="left_setting inspectionTable" style="width: 100%;border-bottom: 1px solid #000;padding-bottom: 15px;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>
                                                                                    <div class="title_component5 select">
                                                                                        <div class="clear " style="border-bottom:0px;">
                                                                                            <div style="padding: 0px 0px 0px 21px; border:0px;width:161px; float:left;">
                                                                                                <div class="bordernone interior_inspec">
                                                                                                    <div class="alignCenter clear paddingBottom" style="width:360px;">
                                                                                                        <span class="comp4boxl spanlable title_label1"  ><?php echo e($cols->subtitle); ?></span>
                                                                                                        <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="<?php echo e($cols->subtitle); ?>" />
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="clear paddingBottom" style="width:261px; height:40px;">

<span class="clear"><b class="<?php echo e($imgclrg); ?>"></b>
<span class="txtFont comp4boxl option1" style="display:block;font-size: 17px !important;"><?php echo e($cols->option1); ?></span>

</span>
                                                                                                    <span class="clear"><b class="<?php echo e($imgclry); ?>"></b>
<span class="txtFont comp4boxl option2" style="display:block;font-size: 17px !important;" ><?php echo e($cols->option2); ?></span>

</span>
                                                                                                    <span class="clear"><b class="<?php echo e($imgclrr); ?>"></b>
<span class="txtFont comp4boxl option3" style="display:block;font-size: 17px !important;"  ><?php echo e($cols->option3); ?></span>

</span>
                                                                                                </div>
                                                                                                <div id="img" style="float: left;width: 70px;height: 70px;position: absolute;top: 18px;margin-left: 246px;; " align="center">

               		 	<span style=" position:relative;">
                             <?php if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!='')): ?>
                                <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($cols->filepath); ?>" style="margin-top: 22px;position:relative;top:20px;max-height: 95px;
max-width: 85px; " alt=""/>
                            <?php else: ?>
                                <img src="<?php echo e(URL::asset('mighty/images/inspect_Brakes.png')); ?>" style="position:relative;top:20px;" alt="">
                            <?php endif; ?>

                            <?php if(isset($cols->filepath)): ?>
                                <input type="hidden" class="filepath" value="<?php echo e($cols->filepath); ?>" />
                            <?php endif; ?>
						</span>
                                                                                                </div>
                                                                                                <?php
                                                                                                $choice_array=$cols->choices;
                                                                                                ?>
                                                                                                <div style="height:162px;top: 25px;position: relative;">
                                                                                                    <div class="clear" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
<span style="width:75px; display:block;float:right;">
<b class="<?php echo e($smlimgclrg); ?>"></b>
<b class="<?php echo e($smlimgclry); ?>"></b>
<b class="<?php echo e($smlimgclrr); ?>"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;"><?php echo e($choice_array[0]->title); ?></span>
<input class="comp4boxi" style="display: none;" value="<?php echo e($choice_array[0]->title); ?>" type="text">
</span>
                                                                                                    </div>
                                                                                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
<span style="width:75px; display:block;float:right;">
<b class="<?php echo e($smlimgclrg); ?>"></b>
<b class="<?php echo e($smlimgclry); ?>"></b>
<b class="<?php echo e($smlimgclrr); ?>"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;"><?php echo e($choice_array[1]->title); ?></span>
<input class="comp4boxi" style="display: none;" value="<?php echo e($choice_array[1]->title); ?>" type="text">
</span>
                                                                                                    </div>
                                                                                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
<span style="width:75px; display:block;float:right;">
<b class="<?php echo e($smlimgclrg); ?>"></b>
<b class="<?php echo e($smlimgclry); ?>"></b>
<b class="<?php echo e($smlimgclrr); ?>"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;"><?php echo e($choice_array[2]->title); ?></span>
<input class="comp4boxi" style="display: none;" value="<?php echo e($choice_array[2]->title); ?>" type="text">
</span>
                                                                                                    </div>
                                                                                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
<span style="width:75px; display:block;float:right;">
<b class="<?php echo e($smlimgclrg); ?>"></b>
<b class="<?php echo e($smlimgclry); ?>"></b>
<b class="<?php echo e($smlimgclrr); ?>"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;"><?php echo e($choice_array[3]->title); ?></span>
<input class="comp4boxi" style="display: none;" value="<?php echo e($choice_array[3]->title); ?>" type="text">
</span>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="clear" style="width:400px;position: relative;top: 15px;">
							<span class="fontF" style="float:left;display:block; margin-left:11px;"> <strong>
                                    <span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;"><?php echo e($choice_array[4]->title); ?></span>
                                    <input class="comp4boxi" style="display: none;" value="<?php echo e($choice_array[4]->title); ?>" type="text">
                                </strong>

					  	</span>
					  	<span style="padding:0px;width:150px;float:left;display:block;margin-right:5px;margin-left:5px;">
							<div id="imgBottomLast" class="imgBottomLast" style="margin-top:-6px;margin-bottom: 5px;width: 150px;" align="center">
                                <?php if(isset($cols->imgsecondpath) && ($cols->imgsecondpath!='undefined' && $cols->imgsecondpath!='')): ?>
                                    <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($cols->imgsecondpath); ?>"alt="brands" style="max-height: 45px;max-width: 150px;" id="image" />
                                <?php else: ?>
                                    <img src="<?php echo e(URL::asset('mighty/images/brands.png')); ?>" alt="brands" style="max-height: 45px;max-width: 150px;" id="image">
                                <?php endif; ?>                           </div>
 						</span>
                                                                                                    <?php if(isset($cols->imgsecondpath)): ?>
                                                                                                        <input type="hidden" class="imgsecondpath" value="<?php echo e($cols->imgsecondpath); ?>" />
                                                                                                    <?php endif; ?>
                                                                                                    <span class="fontF" style="float:left;display:block"> <strong>
                                                                                                            <span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;"><?php echo e($choice_array[5]->title); ?></span>
                                                                                                            <input class="comp4boxi" style="display: none;" value="<?php echo e($choice_array[5]->title); ?>" type="text">
                                                                                                        </strong>
							</span>
                                                                                                    <span class="fontF" style="float:left;"> </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>

                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        <?php elseif($cols->type=="component6"): ?>
                                                                            <div class="uk-grid ">
                                                                                <div class="left_setting inspectionTable" style="width:100%;border-bottom: 1px solid #000;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>
                                                                                    <div class="title_component6 select">
                                                                                        <div class="clear ">
                                                                                            <input type="hidden" name="component6"/>
                                                                                            <div class="clear row1" style="height:27px;">
                                                                                            </div>
                                                                                            <div class="clear row1" style="height:27px;">
                                                                                            </div>
                                                                                            <div class="clear row1" style="height:27px;">
                                                                                            </div>
                                                                                            <div class="clear " style="height:27px;">
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        <?php elseif($cols->type=="component7"): ?>
                                                                            <div class="uk-grid ">
                                                                                <div class="titl-field2 left_setting inspectionTable" style="width:100%;border-bottom: 1px solid #000;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label"><?php echo e($cols->title); ?></label><br/> </div>

                                                                                    <div class="title_component7 selects">
                                                                                        <div class="clear ">
                                                                                            <input type="hidden" name="component7"/>
                                                                                            <?php
                                                                                            $chocies_array=$cols->choices;
                                                                                            ?>
                                                                                            <p style="margin-left: 5px; display: inline-block; ">
                                                                                                <span class="comp4boxl inspectionTxt title_value"data-optionid="0" ><?php echo e($chocies_array[0]->title); ?></span>
                                                                                                <input class="comp4boxi" style="display: none;height:40px;width: 300px !important;" value="<?php echo e($chocies_array[0]->title); ?>" type="text">
                                                                                                <br>
                                                                                                <span style="margin: 10px 40px; display: block;"><b class="<?php echo e($imgclrg); ?>"></b><b class="<?php echo e($imgclry); ?>"></b><b class="<?php echo e($imgclrr); ?>"></b></span>
                                                                                            </p><div style="float: right;    margin: 20px;">
                                                                                                <?php if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!='')): ?>
                                                                                                    <img src="<?php echo e(URL::asset('mighty/images/template/')); ?>/<?php echo e($cols->filepath); ?>"style="max-width: 92px;max-height: 60px;"/>
                                                                                                <?php else: ?>
                                                                                                    <img src="<?php echo e(URL::asset('mighty/images/Might99171.PNG')); ?>" style="max-width: 92px;max-height: 60px;">
                                                                                                <?php endif; ?>


                                                                                                <?php if(isset($cols->filepath)): ?>
                                                                                                    <input type="hidden" class="filepath" value="<?php echo e($cols->filepath); ?>" />
                                                                                                <?php endif; ?>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        <?php elseif($cols->type=="condition"): ?>

                                                                            <?php
                                                                            $choice_array=$cols->choices;
                                                                            ?>

                                                                            <div class="uk-grid">
                                                                                <div class="left_setting" style="width:100%;">
                                                                                    <div class="svgTable">

                                                                                        <ul class="condition-box widthzero">
                                                                                            <li>
                                                                                                <span><b class="green_checkbox"></b></span>
                                                                                                <strong class="floatLeft title_value" data-optionid="0"   style=""><?php echo e($choice_array[0]->title); ?></strong>
                                                                                            </li>
                                                                                            <li>
                                                                                                <span><b class="yellow_checkbox"></b></span>
                                                                                                <strong  class="floatLeft title_value" data-optionid="0"  style="" ><?php echo e($choice_array[1]->title); ?></strong>
                                                                                            </li>
                                                                                            <li>
                                                                                                <span><b class="red_checkbox"></b></span>
                                                                                                <strong class="floatLeft title_value" data-optionid="0"   style="" ><?php echo e($choice_array[2]->title); ?></strong>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        <?php elseif($cols->type=="condition2"): ?>
                                                                            <?php
                                                                            $choice_array=$cols->choices;
                                                                            ?>
                                                                            <div class="uk-grid">
                                                                                <div class="left_setting" style="width:100%;">
                                                                                    <div class="svgTable">

                                                                                        <ul class="condition-box">
                                                                                            <li>
                                                                                                <span><b class="<?php echo e($imgclrg); ?>"></b></span>
                                                                                                <strong class="floatLeft title_value" data-optionid="0"   style=""><?php echo e($choice_array[0]->title); ?></strong>
                                                                                            </li>
                                                                                            <li>
                                                                                                <span><b class="<?php echo e($imgclry); ?>"></b></span>
                                                                                                <strong  class="floatLeft title_value" data-optionid="0"  style="" ><?php echo e($choice_array[1]->title); ?></strong>
                                                                                            </li>
                                                                                            <li>
                                                                                                <span><b class="<?php echo e($imgclrr); ?>"></b></span>
                                                                                                <strong class="floatLeft title_value" data-optionid="0"   style="" ><?php echo e($choice_array[2]->title); ?></strong>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        <?php elseif($cols->type=="tablehead"): ?>
                                                                            <div class="uk-grid">
                                                                                <div class="uk-width-1-2" style="width:100%;">
                                                                                    <?php
                                                                                    $choice_array=$cols->choices;
                                                                                    ?>

                                                                                    <table class="tables_<?php echo e($col); ?> uk-table">
                                                                                        <tr>
                                                                                            <th class="th">ITEMS</th>
                                                                                            <th class="th table_content">CONDITION</th>
                                                                                        </tr>
                                                                                        <?php $__currentLoopData = $choice_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind=>$chres): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                            <tr id="cnt_<?php echo e($ind); ?>rw<?php echo e($col); ?>">
                                                                                                <td class="th">
                                                                                                    <div class="title_tablehead select">
                                                                                                        <span><?php echo e($chres->title); ?></span>
                                                                                                    </div>
                                                                                                </td>
                                                                                                <td class="th">
                                                                                                    <span><b class="green_checkbox"></b><b class="yellow_checkbox"></b><b class="red_checkbox"></b></span>
                                                                                                </td>
                                                                                            </tr>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                                                                    </table>
                                                                                </div>
                                                                            </div>

                                                                            <?php endif; ?>
                                                                                    <!--End -->
                                                                    </div>
                                                                </div>

                                                            </div></li>



                                                        <?php

                                                        $edFlag++;

                                                        }
                                                        ?>
                                                    </ul></li>
                                                <?php
                                                }
                                                }

                                                }

                                                }
                                                ?>

                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="formToken" class="form_token" value ="" />
                            <input type="hidden" name="form_name" class="form_name" value = " "/>
                            <input type="hidden" name="form_desc" class="form_desc" value = " "/>
                            <input type="hidden" id="org_id" name="org_id" value="1" />

                            <div class="buildform" >

                                <input type="hidden" name="imageType" id="imageType" value="<?php echo e($formdetails->imageType); ?>" />
                                <!--   <a href="<?php echo e(url('/cvif/generate-pdf/')); ?>/<?php echo e($formdetails->id); ?>" target="_blank" style="margin-left: 14px;" >Generate Pdf</a>-->

                            </div>
                        </form>

                        <?php echo $__env->make('mighty.layout.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <!-- </form> -->
                    </div>
                </div>
        </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>


    <script src="<?php echo e(URL::asset('mighty/plugins/xepOnline.jqPlugin.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('mighty/plugins/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('mighty/plugins/jspdf.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('mighty/plugins/html2canvas.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('mighty/plugins/app.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>

    <!--
<script src="<?php echo e(URL::asset('mighty/plugins/jquery-ui.min.js')); ?>"></script>
-->

    <script type="text/javascript">jQuery.noConflict();</script>



    <script src="<?php echo e(URL::asset('mighty/plugins/jquery-1.12.4.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('mighty/plugins/jquery-ui.js')); ?>"></script>
    <script type="text/javascript">jQuery.noConflict();</script>

    <!--<script src="<?php echo e(URL::asset('mighty/plugins/form-builder.min.js')); ?>"></script>-->
    <!-- <script src="<?php echo e(URL::asset('mighty/plugins/form.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('mighty/plugins/uikit_custom.min.js')); ?>"></script>-->
    <script src="<?php echo e(URL::asset('mighty/plugins/datatables_uikit.min.js')); ?>"></script>
    <script type='text/javascript'>//<![CDATA[
        $(window).load(function(){
            $(document).ready(function() {
                $('#create_pdfs').click(function() {
                    html2canvas($("#content_right"), {
                        onrendered: function(canvas) {
                            var imgData = canvas.toDataURL('image/png');
                            $("#imgRes").attr("src", imgData);
                            var doc = new jsPDF('p', 'mm');
                            doc.addImage(imgData, 'PNG', -12, -12);
                            doc.save('sample-file.pdf');
                        }
                    });

                });
                $('#create_canvas').click(function() {
                    html2canvas($("#content_right"), {
                        onrendered: function(canvas) {
                            theCanvas = canvas;
                            canvas.style.width  = '8.5in';
                            canvas.style.height = '11in';

                            document.getElementById("img-out").appendChild(canvas);
                            /*  var options = {};
                             var pdf = new jsPDF('p', 'pt', 'a4');
                             pdf.addHTML($("#img-out"), 15, 15, options, function() {
                             pdf.save('pageContent.pdf');
                             });*/
                            generatePDF();
                            /*    var imgData = canvas.toDataURL(
                             'image/png');
                             var doc = new jsPDF('p', 'mm');
                             doc.addImage(imgData, 'PNG', -12, -12);
                             doc.save('sample-file.pdf');*/


                            // Convert and download as image
                            // Canvas2Image.saveAsPNG(canvas);
                            /*  $("#img-out").append(canvas);


                             var imgData = canvas.toDataURL(
                             'image/png');
                             var doc = new jsPDF('p', 'mm');
                             doc.addImage(imgData, 'PNG', 10, 10);
                             doc.save('sample-file.pdf');*/

                            // Clean up
                            //document.body.removeChild(canvas);
                        }
                    });

                });
            });
        });//]]>
    </script>

    <script>
        jQuery(document).ready(function ($) {
            var $fbEditor = $(document.getElementById('build-wrap'));
            var formBuilder = $fbEditor.formBuilder().data('formBuilder');

            $(".form-builder-save").click(function (e) {
                e.preventDefault();
                // alert(formBuilder.formData);
                $("#design-tpl").val(formBuilder.formData);
            });
        });
    </script>
    <script>

        $(document).ready(function () {



            $('body').addClass('sidebar-collapse');
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('mighty.layout.tpl', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>