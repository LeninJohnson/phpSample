#!/bin/sh
ssh -i /home/innoppl/Desktop/Lenin/pem/mobile.pem ubuntu@34.195.209.233 '/scripts/cvif-dev-Git-pull.sh'
