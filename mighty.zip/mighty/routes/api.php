<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::group(['prefix' => 'v1'], function () {

Route::post('/login', 'Mighty\v1\ApiController@loginuser');
Route::post('/test', 'Mighty\v1\ApiController@home');
Route::get('/formname/{id}', 'Mighty\v1\ApiController@getFormdetailsByUser');
Route::get('/templates/{id}', 'Mighty\v1\ApiController@templates');
Route::get('/user/services/{id}', 'Mighty\v1\ApiController@getuserServices');
Route::get('/services', 'Mighty\v1\ApiController@servicesAll');
Route::get('/services/{user_id}', 'Mighty\v1\ApiController@getUserservices');
    //Route::get('/services/{id}', 'Mighty\v1\ApiController@servicesId');
Route::get('/makes/{id}', 'Mighty\v1\ApiController@getmakesByYear');
Route::get('/models/{id}', 'Mighty\v1\ApiController@getmodelsByMake');
Route::get('/engines/{id}', 'Mighty\v1\ApiController@getenginesByModel');
Route::get('/video-library', 'Mighty\v1\ApiController@videoibrary');
Route::post('/inspection', 'Mighty\v1\ApiController@inspection');
Route::post('/form-submission', 'Mighty\v1\ApiController@formSubmission');
Route::post('/car-image/submission', 'Mighty\v1\ApiController@carImgSubmission');
Route::post('/form-signature', 'Mighty\v1\ApiController@formSignature');
Route::get('/active/inspection/{id}', 'Mighty\v1\ApiController@activeInspection');
Route::get('/inspection/list/{id}', 'Mighty\v1\ApiController@activeInspection');
Route::delete('/inspection/{id}', 'Mighty\v1\ApiController@deleteInspection');
Route::get('/inspection/vin/{id}', 'Mighty\v1\ApiController@getInspectionVin');
Route::get('/inspection/mobile/{id}', 'Mighty\v1\ApiController@getInspectionMobile');
Route::get('/carpm/{mak}/{mdl}/{eng}/{year}', 'Mighty\v1\ApiController@getCarPm');
Route::get('/cartsb/{mak}/{mdl}/{eng}/{year}', 'Mighty\v1\ApiController@getCarTsb');
Route::get('/inspection-form/{id}', 'Mighty\v1\ApiController@Inspectionform');

});


Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:api');
