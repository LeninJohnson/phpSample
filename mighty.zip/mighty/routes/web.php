<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/
/*
Route::get('/', function () {
    return view('welcome');
});
*/

//Route::get('/', 'Mighty\LoginController@index');



Route::get('/home', 'Mighty\HomeController@home');
Route::group(['prefix' => 'cvif'], function () {
Route::get('/', 'Mighty\HomeController@cvif');
Route::any('/template', 'Mighty\HomeController@cvifTemplate');
    Route::post('/template-image/upload', 'Mighty\HomeController@uploadImages');
    Route::get('/browse', 'Mighty\HomeController@browseImages');
    Route::post('/template/preview', 'Mighty\HomeController@previewtemplates');
    Route::any('/template/preview/{id}', 'Mighty\HomeController@templatespreview');
    Route::any('/template/edit-preview/{id}', 'Mighty\HomeController@templatesEditpreview');
Route::any('/template/{id}', 'Mighty\HomeController@templates');

Route::get('/template/view/{id}', 'Mighty\HomeController@viewTemplates');
Route::get('/generate-pdf/{id}', 'Mighty\HomeController@generatePdf');
Route::any('/create-template', 'Mighty\HomeController@createTemplate');
Route::any('/create-template101', 'Mighty\HomeController@createTemplate101');
Route::any('/template101', 'Mighty\HomeController@template101');
Route::any('/create-template102', 'Mighty\HomeController@createTemplate102');
Route::any('/create-template103', 'Mighty\HomeController@createTemplate103');
Route::any('/create-template104', 'Mighty\HomeController@createTemplate104');
Route::any('/create-template105', 'Mighty\HomeController@createTemplate105');

});

Route::group(['prefix' => 'mighty-assist'], function () {

    Route::any('/templates/set-active-form', 'Mighty\HomeController@setActiveForm');
    Route::any('/services/set-active-services', 'Mighty\HomeController@setActiveServices');
    Route::get('/services/view-services', 'Mighty\HomeController@viewServices');
    Route::any('/services/edit/{id}', 'Mighty\HomeController@editServices');
    Route::any('/video-library/add', 'Mighty\HomeController@addVideoLibrary');
    Route::get('/video-library', 'Mighty\HomeController@viewVideoLibrary');
    Route::any('/video-library/edit/{id}', 'Mighty\HomeController@editVideoLibrary');
    Route::get('/video-library/delete/{id}', 'Mighty\HomeController@deleteVideoLibrary');
    Route::any('/settings', 'Mighty\HomeController@setSettings');
// make start
    Route::post('/make/add', 'Mighty\HomeController@addMake');
    Route::post('/get-make', 'Mighty\HomeController@getMake');
    Route::any('/show-make', 'Mighty\HomeController@showMake');
    Route::any('/show-model', 'Mighty\HomeController@showModel');
    Route::any('/show-engine', 'Mighty\HomeController@showEngine');
    Route::get('/make', 'Mighty\HomeController@viewMake');
    Route::any('/make/edit/{id}', 'Mighty\HomeController@editMake');
    Route::get('/make/delete/{id}', 'Mighty\HomeController@deleteMake');
    Route::get('/template/delete/{id}', 'Mighty\HomeController@deleteTemplate');
// make end
// model start
    Route::post('/model/add', 'Mighty\HomeController@addModel');
    Route::get('/model', 'Mighty\HomeController@viewModel');
    Route::post('/get-model', 'Mighty\HomeController@getModel');
    Route::any('/model/edit/{id}', 'Mighty\HomeController@editModel');
    Route::get('/model/delete/{id}', 'Mighty\HomeController@deleteModel');
    // model end
    // engine start
    Route::post('/engine/add', 'Mighty\HomeController@addEngine');
    Route::get('/engine', 'Mighty\HomeController@viewEngine');
    Route::any('/engine/edit/{id}', 'Mighty\HomeController@editEngine');
    Route::get('/engine/delete/{id}', 'Mighty\HomeController@deleteEngine');

    Route::get('/reports', 'Mighty\HomeController@inspectionReports');
// engine end
});



Auth::routes();

Route::get('/', 'Mighty\AuthController@index');
Route::get('/login', 'Mighty\AuthController@loginto');
Route::get('/test-api', 'Mighty\HomeController@testthis');
Route::get('/test-enc', 'Mighty\HomeController@testthisX');
Route::get('/test-curl', 'Mighty\HomeController@testcurl');

define('project_name', 'Mighty');