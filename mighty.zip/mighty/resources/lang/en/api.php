<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'forminspection_add'       => 'Form submitted Successfully.',
    'carimage_add'       => 'Car Image Added Successfully.',
    'signature_add'       => 'Signature Added Successfully.',
    'inspection_del'       => 'Profile Deleted Successfully.',
    'inspection_notfound'       => 'Profile details not found',
    'update_succ'       => 'Profile Created Successfully.',
    'userservice_notfound'       => 'User Service Details Not found.',
    'userselectservice'    => 'Login with https://www.mightyautoparts.com/and traverse to Might ASSIST Link and choose any service',
    'inspection_add'       => 'Inspecction Created Successfully.',
    'otp_msg_info'      => 'ParkFind Login OTP : ',
    'newuser_creation'  => 'New User Created Successfully.',
    'login_succ'        => 'Login Successfully.',
    'something_wrong'   => 'Something Went Wrong!.',
    'success'           => 'success',
    'frds_udtsucc'      => 'Friends List Updated Successfully.',
    'pin_dropsucc'      => 'Park Spot Added Successfully.',
    'pin_extendsucc'    => 'Park Spot Updated Successfully.',
    'pin_error'         => 'Pin Already Exist for this user',
    'pin_cant_occupy'   => "Can't occupy this place, Since the user is not yet checkout",
    'pin_outtime_grter' => "Can't occupy this place, right now",
    'pin_create_error'  => 'Error on while creating a pin',
    'pin_expired'       => 'Pin Expired',
    'invalid_pinid'     => 'Invalid Pin Id',
    'pin_extend_error'  => 'Invalid Pin Id or Pin Outtime is greater than current Outtime',
    'pin_checkoutsucc'  => 'Pin Removed Successfully',
    'pin_details'       => 'Pin Details Information',
    'nearByPins'        => 'Near By Pins Listed Successfully',
    'invaild_info'      => 'Invalid Information',
    'otp_verified_succ' => 'OTP Verified Successfully',
    'otp_send_succ'     => 'OTP Send Successfully',
    'invalid_otp'       => 'Please enter Valid OTP (or) Try resend OTP',
    'sendall_req_erro'  => "Please upgrade your membership to use send all feature",
    'req_send_succ'     => "Your request has been send successfully",


    'sendall_req_succ'  => "request has been send successfully",
    'sendall_req_fail'  => "Near by no pin avaliable to send request",

    'req_fail'          => "Your requested pin, has been hold by someone else (Or) Invalid Pin",
    'approve_succ'      => "Approved successfully",
    'not_valid_req_confirm'     => "Not a valid requester to confirm this pin",
    'not_valid_req_cancel'      => "Not a valid requester to cancel this pin",
    'confirm_succ'      => "Confirm successfully",
    'reject_succ'       => "Rejected successfully",
    'not_valid_user'    => "Not valid User Information",
    'req_list'          => "Requested user pin list",
    'req_failed'        => "Requested user already hold a pin",
    'req_confirm_aly'   => "Holder already confirmed some one request",
    'not_valid_approve' => "Not a valid request to approve",
    'not_valid_reject'  => "Not a valid information to reject",
    'cancel_succ'       => "Cancel successfully",
    'req_time_fail'     => "Request time should to greater then the pin outtime",
    'pin_checkout_error'=> "Not a valid information to checkout",

    'req_noty_title'    => "Request Notification from ",
    'req_noty_msg'      => "is requesting for your parking place",

    'approve_noty_title'=> "Approve Notification from ",
    'approve_noty_msg'  => "your request has been approved for parking place",

    'reject_noty_title' => "Reject Notification from ",
    'reject_noty_msg'   => "your request has been rejected for parking place",

    'confirm_noty_title'=> "Confirm Notification from ",
    'confirm_noty_msg'  => "your request has been confirmed for parking place",

    'cancel_noty_title' => "Confirm Notification from ",
    'cancel_noty_msg'   => "your request has been cancelled for parking place",

    'push_notify_disabled'  => "Push notification has been disabled successfully",
    'push_notify_enabled'   => "Push notification has been enabled successfully",
    'invalid_userId'        => "Invalid User information, Please try again",

    'txn_made_suc'          => "Transaction has been made successfully",
    'already_prem_feat'     => "Already you are in premium feature",
    'invalid_txn_info'      => "Invalid Transaction information",

    'newpin_noty_title'     => "Notification Title",
    'newpin_noty_msg'       => "Notification Message",
];
