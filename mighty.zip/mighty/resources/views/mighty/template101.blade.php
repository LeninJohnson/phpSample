<?php
$template=Config::get('custom.template');
?>
@extends('mighty.layout.tpl')
@section('customCss')

    <link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/form-builder.min.css')}}">

    <link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/main.min.css')}}">
    <link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/uikit.almost-flat.min.css')}}">
    <link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/formpro.css')}}">
    <link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/jquery_ui.css')}}">

    <style>
        .content {
        // min-height: 1811px;
        }
    </style>
    <style>
        li.rows{
            min-height:80px;
        }
        li.columns{
            float:left;
            height:75px;
            list-style: none;
        }
        li.highlight{
            min-height: 70px;
        }
        .dropovers{
            /*  border:1px solid #ccc;
              border-right-color:red;*/
        }
        body{
            /*overflow: hidden;
            height: 100%;*/
        }
        .content{
            padding-left: 0px !important;
        }
        body {
            padding-top: 0px !important;
        }
        .uk-grid > * {
            float: none;
        }
    </style>
@endsection

@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Template 101
            <small>Control panel</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Create Template</li>
        </ol>
    </section>
    @if(Session::has('true_msg'))
        <div class="alert alert-success">
            <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
            {{Session::get('true_msg')}}
        </div> <!-- /.alert -->
    @endif
    @if(Session::has('error_msg'))
        <div class="alert alert-danger">
            <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
            {{Session::get('error_msg')}}
        </div> <!-- /.alert -->
    @endif
    <!-- Main content -->
    <section class="content">
        <div id="page_content">
            <div id="page_content_inner">
                <div class="uk-grid" style="display: block;padding-left:0px !important"; data-uk-grid-margin data-uk-grid-match id="wizard_forms">
                    <!--<div id="wizard_advanced">-->
                    <!-- <h2>Design Form</h2>
                    <section> -->
                    <form class="uk-form-stacked" id="wizard_advanced_form" method="post" action ="" enctype="multipart/form-data" >
                        <div class="uk-width-large-2-10"  id="sidebar" style="float: left;width:20%;">
                            <div class="uk-width-1-1">
                                <div class="parsley-row">
                                    <div class="md-card  form-desc ">
                                        <label class="fn">Name your form<span class="req">*</span></label>
                                        <input type="text" class="md-input fn-field" id="form_name" name="form_name" value="" data-parsley-trigger="change" required  />
                                        <label class="fd">Short description about your form </label>
                                        <textarea name="form_desc"  class="md-input" id="form_desc" style=""></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="md-card dragdrop-panel">
                                <div class="md-card-content">
                                    <div class="uk-panel">
                                        <div class="heading">Drag and drop for build new form</div>
                                        <div class="uk-accordion" data-uk-accordion>
                                            <h3 class="uk-accordion-title uk-accordion-title-primary">Basic</h3>
                                            <div class="uk-accordion-content">
                                                <ul id="basic">
                                                    <li><div class="singleline-icon" ></div><span value="heading">Heading</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="text">Single Line Text</span></li>
                                                    <li><div class="email-icon"></div><span value="email">Email</span></li>
                                                    <li><div class="multiline-icon"></div><span value="textarea">Multi Line Text</span></li>
                                                    <li><div class="multiline-icon"></div><span value="number">Number</span></li>
                                                    <li><div class="radio-icon"></div><span value="radio">Radio</span></li>
                                                    <li><div class="select-icon"></div><span value="select">Select</span></li>
                                                    <li><div class="checkbox-icon"></div><span value="checkbox">Checkbox</span></li>
                                                    <li><div class="date-icon"></div><span value="date">Date</span></li>
                                                    <li><div class="time-icon"></div><span value="time">Time</span></li>
                                                    <li><div class="file-icon"></div><span value="file">File</span></li>
                                                    <!--<li><span value="reset">Reset</span></li>
                                                    <li><span value="submit">Submit</span></li>-->
                                                </ul>
                                            </div>

                                            <h3 class="uk-accordion-title uk-accordion-title-primary">Advanced</h3>
                                            <div class="uk-accordion-content">
                                                <ul id="advanced">
                                                    <li><div class="sign-icon"></div><span value="signature">Signature</span></li>
                                                    <!--<li>
                                                        <span value="placepicker">Place Picker</span>
                                                    </li>-->
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="uk-width-large-8-10"  id="content_right" style="float:left;height: 563px;padding-left:12px;width:80%;">
                            <div class="md-card">
                                <div class="md-card-content" style="">
                                    <div id="forms" data-form_id ="1" style="width:100%;height: 550px;">
                                        <ul id="pages" style="height: 520px;overflow-y: scroll;">
                                            <!--<li class="rows" id="rows_1"></li>-->
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{ csrf_field() }}
                        <input type="hidden" name="formToken" class="form_token" value ="" />
                        <input type="hidden" name="form_name" class="form_name" value = " "/>
                        <input type="hidden" name="form_desc" class="form_desc" value = " "/>
                        <input type="hidden" id="org_id" name="org_id" value="1" />

                        <div class="buildform">
                            <a style="margin-left: 14px;"  class="publish">Build this template </a>
                        </div>
                    </form>
                @include('mighty.layout.template')
                <!-- </form> -->
                </div>
            </div>
    </section>

    <!--
    <style>
    .content {
        min-height: 1811px;
    }
    #div1 {
        width: 350px;
        height: 70px;
        padding: 10px;
        border: 1px solid #aaaaaa;
    }
    #div2 {
        width: 650px;
        height: 270px;
        padding: 10px;
        border: 1px solid #aaaaaa;
    }
    #makeMeDraggable { width: 100px; height: 100px; background: red; }
    #draggable { width: 150px; height: 150px; padding: 0.5em; }
    </style>
       <section class="content">
    <div id="draggable" class="ui-widget-content">
      <p>Drag me around</p>
    </div>

        <div id="content" style="height: 400px;">
      </div>

        <p>Drag the W3Schools image into the rectangle:</p>

    <div id="div1" style="float:right;" ondrop="drop(event)" ondragover="allowDrop(event)"></div>
    <div id="div2"   ondrop="drop(event)" ondragover="allowDrop(event)"></div>
    <br>
    <div id="drag1" draggable="true" ondragstart="drag(event)" width="336" height="69">
      <input type="text" name="header" value="Header"/>
    </div>
    <div id="drag2" draggable="true" ondragstart="drag(event)" width="336" height="69">
      <input type="file" name="file1" />
    </div>
    <div id="makeMeDraggable"> </div>



        </section>
        -->


@endsection

@section('customJs')


    <script>

        var rowid = 1;
        var form_rows = 1;
        var colid = 1;
        var comptField = 1;

    </script>

    <script src="{{URL::asset('mighty/plugins/jquery.min.js')}}"></script>
    <script src="{{URL::asset('mighty/plugins/jquery.validate.min.js')}}"></script>
    <!--
<script src="{{URL::asset('mighty/plugins/jquery-ui.min.js')}}"></script>
-->
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
    <script>
        // just for the demos, avoids form submit
        jQuery.validator.setDefaults({
            debug: true,
            success: "valid"
        });
        $(document).ready(function () {
            $( "#wizard_advanced_form" ).validate({
                rules: {
                    'file_name[]': {
                        // required: true,
                        extension: "png|jpg"
                    }
                }
            });
        });
    </script>

    <script src="{{URL::asset('mighty/plugins/jquery-1.12.4.js')}}"></script>
    <script src="{{URL::asset('mighty/plugins/jquery-ui.js')}}"></script>
    <script type="text/javascript">jQuery.noConflict();</script>

    <!--<script src="{{URL::asset('mighty/plugins/form-builder.min.js')}}"></script>-->
    <script src="{{URL::asset('mighty/plugins/form.js')}}"></script>
    <script src="{{URL::asset('mighty/plugins/uikit_custom.min.js')}}"></script>
    <script src="{{URL::asset('mighty/plugins/datatables_uikit.min.js')}}"></script>
    <script>
        function submitform(){

            if ($("#wizard_advanced_form").valid()) {
                document.getElementById("wizard_advanced_form").submit();
            }
        }
        $(document).ready(function () {

            $('body').addClass('sidebar-collapse');

        });
    </script>
    <script>
        $(document).ready(function(){

            $('body').addClass('sidebar-collapse');
        });
    </script>
    <script>
        /*
         jQuery(document).ready(function($) {
         $(document.getElementById('build-wrap')).formBuilder();
         });
         */
        jQuery(document).ready(function($) {
            var $fbEditor = $(document.getElementById('build-wrap'));
            var formBuilder = $fbEditor.formBuilder().data('formBuilder');

            $(".form-builder-save").click(function(e) {
                e.preventDefault();
                alert(formBuilder.formData);
                $("#design-tpl").val(formBuilder.formData);
            });
        });
    </script>


    <!--
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/jquery-ui.min.js"></script>

    <script>
    function allowDrop(ev) {
        ev.preventDefault();
    }

    function drag(ev) {
          ev.dataTransfer.setData("text", ev.target.id);
    }

    function drop(ev) {
        ev.preventDefault();
        var data = ev.dataTransfer.getData("text");
        ev.target.appendChild(document.getElementById(data));
    }
    $( init );

    function init() {
      $('#makeMeDraggable').draggable( {
        containment: '#content',
        cursor: 'move',
        snap: '#content'
      } );


    }
    $( function() {
        $( "#draggable" ).draggable();
      } );
    </script>
    -->
    <script type="text/javascript">

        var $kUI_multiselect_basic = $('#multiselect');
        if($kUI_multiselect_basic.length) {
            $kUI_multiselect_basic.kendoMultiSelect();
        }
        var multiselect_location= $('#multiselect_location');
        if(multiselect_location.length) {
            multiselect_location.kendoMultiSelect();
        }
        var multiselect_size = $('.multiselect_size');
        if(multiselect_size.length) {
            multiselect_size.kendoMultiSelect();
        }
        var location_country = $('.location_country');
        location_country.kendoDropDownList();
        var $kUI_multiselect_domain = $('#multiselect_domain');
        if($kUI_multiselect_domain.length) {
            var required = $kUI_multiselect_domain.kendoMultiSelect().data("kendoMultiSelect");
            $(".domain_select #select").click(function() {
                var values = $.map(required.dataSource.data(), function(dataItem) {
                    //if(dataItem.value){
                    return dataItem.value;
                });
                required.value(values);

                $('.domain_select #select').hide();
                $('.domain_select #deselect').show();
            });

            $(".domain_select #deselect").click(function() {
                required.value([]);
                $('.domain_select #deselect').hide();
                $('.domain_select #select').show();
            });
        }
        var org_location = $("#org_location");
        if(org_location.length){
            org_location.kendoDropDownList();
        }
        var org_forms = $("#org_forms");
        if(org_forms.length){
            org_forms.kendoDropDownList();
        }
        var org_users = $("#org_users");
        if(org_users.length){
            org_users.kendoDropDownList();
        }
        var $kUI_multiselect_department = $('#multiselect_department');
        if($kUI_multiselect_department.length) {
            $kUI_multiselect_department.kendoMultiSelect();
        }
        /*  var $kUI_multiselect_department = $('#multiselect_department');
         if($kUI_multiselect_department.length) {
         $kUI_multiselect_department.kendoMultiSelect();
         }    */
        var $kUI_multiselect_category = $('#multiselect_category');
        if($kUI_multiselect_category.length) {
            $kUI_multiselect_category.kendoMultiSelect();
        }
        var $kUI_multiselect_role = $('#multiselect_role');
        if($kUI_multiselect_role.length) {
            $kUI_multiselect_role.kendoMultiSelect();
        }
        var multiselect_users = $('#multiselect_users');
        if(multiselect_users.length) {
            multiselect_users.kendoMultiSelect();
        }


    </script>
    <script type="text/javascript">
        if($('body').hasClass('sidebar_main_active')){
            $('body').removeClass('sidebar_main_active');
        }
        if($('body').hasClass('sidebar_main_open')){
            $('body').removeClass('sidebar_main_open');
        }
    </script>



    <script>
        $(function() {
            // enable hires images

            altair_helpers.retina_images();
            // fastClick (touch devices)
            if(Modernizr.touch) {
                FastClick.attach(document.body);
            }

        });

    </script>
    <script>
        $(function() {
            var $switcher = $('#style_switcher'),
                    $switcher_toggle = $('#style_switcher_toggle'),
                    $theme_switcher = $('#theme_switcher'),
                    $mini_sidebar_toggle = $('#style_sidebar_mini');

            $switcher_toggle.click(function(e) {
                e.preventDefault();
                $switcher.toggleClass('switcher_active');
            });

            $theme_switcher.children('li').click(function(e) {
                e.preventDefault();
                var $this = $(this),
                        this_theme = $this.attr('data-app-theme');

                $theme_switcher.children('li').removeClass('active_theme');
                $(this).addClass('active_theme');
                $('body')
                        .removeClass('app_theme_a app_theme_b app_theme_c app_theme_d app_theme_e app_theme_f app_theme_g')
                        .addClass(this_theme);

                if(this_theme == '') {
                    localStorage.removeItem('altair_theme');
                } else {
                    localStorage.setItem("altair_theme", this_theme);
                }

            });

            // change input's state to checked if mini sidebar is active
            if((localStorage.getItem("altair_sidebar_mini") !== null && localStorage.getItem("altair_sidebar_mini") == '1') || $('body').hasClass('sidebar_mini')) {
                $mini_sidebar_toggle.iCheck('check');
            }

            // toggle mini sidebar
            $mini_sidebar_toggle
                    .on('ifChecked', function(event){
                        $switcher.removeClass('switcher_active');
                        localStorage.setItem("altair_sidebar_mini", '1');
                        location.reload(true);
                    })
                    .on('ifUnchecked', function(event){
                        $switcher.removeClass('switcher_active');
                        localStorage.removeItem('altair_sidebar_mini');
                        location.reload(true);
                    });

            // hide style switcher
            $document.on('click keyup', function(e) {
                if( $switcher.hasClass('switcher_active') ) {
                    if (
                            ( !$(e.target).closest($switcher).length )
                            || ( e.keyCode == 27 )
                    ) {
                        $switcher.removeClass('switcher_active');
                    }
                }
            });

            if(localStorage.getItem("altair_theme") !== null) {
                $theme_switcher.children('li[data-app-theme='+localStorage.getItem("altair_theme")+']').click();
            }
        });
    </script>


    <script type="text/javascript">
        $(document).ready(function() {
            var wrapper         = $(".location_container"); //Fields wrapper
            var add_button      = $(".add_location_button"); //Add button ID

            var cont = '<div><div class="uk-grid" data-uk-grid-margin><div class="uk-width-medium-1-2"><label>Location Name</label><input type="text" class="md-input" name="location_name[]" value="" /></div><div class="uk-width-medium-1-2"><label>Address</label><input type="text" class="md-input" name="address[]" value="" /></div></div><div class="uk-grid" data-uk-grid-margin><div class="uk-width-medium-1-2"><label>City</label><input type="text" class="md-input" name="city[]" value="" /></div><div class="uk-width-medium-1-2"><label>Country</label><input type="text" class="md-input" name="country[]" value="" /></div></div><div class="uk-grid" data-uk-grid-margin><div class="uk-width-medium-1-2"><label>state</label><input type="text" class="md-input" name="state[]" value="" /></div><div class="uk-width-medium-1-2"><label>Zip Code</label><input type="text" class="md-input" name="zip[]" value="" /></div></div><div class="remove_field" style="text-align: right;width: 92%;">+ Remove Location</div><hr style="border-top:1px #000 solid;"></div>';

            var x = 1; //initlal text box count

            $(add_button).click(function(e){ //on add input button click

                e.preventDefault();

                x++; //text box increment
                $(wrapper).append(cont); //add input box

                datepick();
            });

            $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
                var x = confirm("Are you sure, you want to delete Location?");
                if (x){
                    e.preventDefault(); $(this).parent().remove(); x--;
                }
            });

        });
    </script>
@endsection
