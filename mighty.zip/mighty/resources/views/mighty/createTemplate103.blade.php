<?php
$template=Config::get('custom.template');
?>
@extends('mighty.layout.tpl')
@section('customCss')
<link rel="stylesheet" href="{{URL::asset('mighty/plugins/template3.css')}}"> 
<style>
.content {
    min-height: 1811px;
}
 

#topCmpt{
  font-family: 'MyriadProBold', Arial;
  font-size: 11pt;
}
.imgLogo{
    height: 100px; 
    width: 380px;
    margin-top: 0px;
    padding: 0;
    text-align:center;
    border:none;
}
.noImgLogo{
   height: 100px; 
    width: 380px;
    margin-top: 0px;
    padding: 0;
    text-align:center;
    border:1px solid #000;
}

</style>

@endsection

@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Mighty Customizable Vehicle Inspection Forms
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">CVIF</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li><a href="{{URL::to('/cvif/create-template101')}}" >Template 101</a></li>
              <li><a href="{{URL::to('/cvif/create-template102')}}" >Template 102</a></li>
              <li class="active"><a href="{{URL::to('/cvif/create-template103')}}">Template 103</a></li>
              <li ><a href="{{URL::to('/cvif/create-template104')}}" >Template 104</a></li>
              <li><a href="{{URL::to('/cvif/create-template105')}}" >Template 105</a></li>
              </ul>
            <div class="tab-content">
              <div class="tab-pane" id="tab_1">
           <section class="content">    
        <div class="col-md-12">
        </div>
        </section>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane active" id="tab_2">
   <section class="content">    
        <div class="col-md-12">
<div class="innercontainer">
      
       
				<div id="templateSize">
					<div style="width: 21.5cm;" class="divLogoTab">
						<div class="divLogoRow">
							
							<div class="logo1">
								
							</div>
							
							
							<div id="imgLogo" style="border:none;" align="center">
								
									
										<div class="noImgLogo">
											<p id="msg">(Your logo here)<br>Dimension:[380 x 100]pixels</p>
										</div>
									
									
								
							</div>
							
							<div class="logo2-103">
								
							</div>
							
							
						</div>
					</div>
			
				
				
				
				<div id="pageHeading">
					<p id="heading103">
						<label id="lblText" class="text_label" style="text-transform: uppercase;"><nobr>VEHICLE INSPECTION REPORT</nobr></label>
					</p>
					<div class="clear"></div>
				</div>
				<div class="divTable">
					<div class="divRow" style="margin-left:10px;">
						<div id="customer" class="divCell" style="width:763px;">
							
								
									<div class="custSpanText" style="width: 763px;">
										<span id="cust1" style="font-family: MyriadProRegular;font-size: 11pt;line-height: 1.9;" class="customerSpanText">Name: ___________________________ Mileage: ________________________ Year/Make/Model: ______________________</span>
									</div>
								
									<div class="custSpanText" style="width: 763px;">
										<span id="cust2" style="font-family: MyriadProRegular;font-size: 11pt;line-height: 1.9;" class="customerSpanText">VIN: ______________________ License: __________________________ Email:_______________________________________</span>
									</div>
								
							
						</div>
					</div>
				</div>
				<div class="clear"></div>
				<div class="selTable" style="width:855px;">
					<div class="selRow" style="100%;">
						 
						<div class="selCol33" style="margin-right:10px;">
							<div class="selCell">
								
									<span><b class="greenCircle"></b></span> 
									
									
																 
								<span class="floatLeft">
									<p style="position:relative; left:5px;width:170px;white-space:nowrap;"><span id="topCmpt">CHECKED AND OK</span></p>
								</span>
							</div>
						</div>
						 
						<div class="selCol33" style="margin-right:10px;">
							<div class="selCell">
									
								
									<span><b class="yellowCircle"></b></span> 
									
																 
								<span class="floatLeft">
									<p style="position:relative; left:5px;width:170px;white-space:nowrap;"><span id="topCmpt">MAY REQUIRE ATTENTION</span></p>
								</span>
							</div>
						</div>
						 
						<div class="selCol33" style="margin-right:10px;">
							<div class="selCell">
									
									
								
									<span><b class="redCircle"></b></span> 
																 
								<span class="floatLeft">
									<p style="position:relative; left:5px;width:170px;white-space:nowrap;"><span id="topCmpt">REQUIRES IMMEDIATE ATTENTION</span></p>
								</span>
							</div>
						</div>
												
					</div>
				</div>
				<div class="clear"></div>
				<div class="divTable1 paddingLeft">
					<div class="inspectionleftwrap">
						<div class="inspection_bg">
							<div class="inspectionTable">
							 
								
								
								
									<div class="clear row1 row1Title">
										<span align="center" class="th">INTERIOR/EXTERIOR</span>
									</div>
								
								
							 
								
								
								
								
								<div class="clear row1">
									<span class="smallheading">NOTE ANY EXISTING EXTERIOR BODY DAMAGE OR DEFECTS ON DIAGRAM</span>
								</div>

								
							
								<div class="clear row1">
									 	<span class="alignCenter" style="display:block; height:120px;">
											<img src="{{URL::asset('mighty/images/car-top.png')}}" alt="" style="max-width: 247px;max-height:116px;">
										</span>
								</div>
							
								<div class="clear row1">
											<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
											<span class="inspectionTxt">Exterior Body</span>

								</div>
							
								<div class="clear row1">
										
											<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
											<span class="inspectionTxt">Windshield / Glass</span>

								</div>
							
							
							
							
							 
							
								<div class="clear row1">
									
										
											<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
											<span class="inspectionTxt">Wipers</span>
										
										
									
								</div>
							
							
							
							
							 
							
								<div class="clear row1">
									
										
											<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
											<span class="inspectionTxt">Lights (Head, Brake, Turn)</span>
										
										
									
								</div>
							
							
							
							
							 
							
								<div class="clear row1">
									
										
											<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
											<span class="inspectionTxt">Interior Lights</span>
										
										
									
								</div>
							
							
							
							
							 
							
								<div class="clear row1">
									
										
											<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
											<span class="inspectionTxt">AC Operation</span>
										
										
									
								</div>
							
							
							
							
							 
							
								<div class="clear row1">
									
										
											<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
											<span class="inspectionTxt">Heating</span>
										
										
									
								</div>
							
							
							
							
							 
							
								<div class="clear row1">
									
										
											<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
											<span class="inspectionTxt">Other ___________________</span>
										
										
									
								</div>
							
							
							</div>
							<div class="inspectionTable">
								
									
									
									 
									
									<div class="clear row1 row1Title">
										<span>UNDERHOOD</span>
									</div>
									
									
								
									
									
									 
									
									
									<div class="clear row1">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Engine Oil</span>
											
											
										
									</div>
									
								
									
									
									 
									
									
									<div class="clear row1">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Brake Fluid</span>
											
											
										
									</div>
									
								
									
									
									 
									
									
									<div class="clear row1">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Power Steering Fluid</span>
											
											
										
									</div>
									
								
									
									
									 
									
									
									<div class="clear row1">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Washer Fluid</span>
											
											
										
									</div>
									
								
									
									
									 
									
									
									<div class="clear row1">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Belts &amp; Hoses</span>
											
											
										
									</div>
									
								
									
									
									 
									
									
									<div class="clear row1">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Antifreeze/Coolant</span>
											
											
										
									</div>
									
								
									
									
									 
									
									
									<div class="clear row1">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Air Filter</span>
											
											
										
									</div>
									
								
									
									
									 
									
									
									<div class="clear row1">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Cabin Filter</span>
											
											
										
									</div>
									
								
									
									
									 
									
									
									<div class="clear row1">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Fuel Filter</span>
											
											
										
									</div>
									
								
									
									
									 
									
									
									<div class="clear row1">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Spark Plugs / Wires</span>
											
											
										
									</div>
									
								
									
									
									 
									
									
									<div class="clear row1">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Other ______________________</span>
											
											
										
									</div>
									
								
									
									
									 
									
									
								
									
									
									 
									
									
								
									
									
									 
									
									
								
								<div class="clear row1">
								
									
									
									
									
								
									
									
									
									
								
									
									
									
									
								
									
									
									
									
								
									
									
									
									
								
									
									
									
									
								
									
									
									
									
								
									
									
									
									
								
									
									
									
									
								
									
									
									
									
								
									
									
									
									
								
									
									
									
									
								
									
									
									
									
									<div style="height:30px;">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
												<span class="inspectionTxt">Battery Charge</span>
											
											
										
									</div>
									
								
									
									
									
									
									<div style="height:30px;">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
												<span class="inspectionTxt">Battery Condition</span>
											
											
										
									</div>
									
								
									
									
									
									
									<div style="height:30px;">
										
											
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
												<span class="inspectionTxt">Cables &amp; Connections</span>
											
											
										
									</div>
									
								
								<div>
									<div style="float: right;margin-top: -23%;width: 91px;">
									
										
									
										
											<img src="{{URL::asset('mighty/images/Might99171.PNG')}}" style="max-width: 92px;max-height: 60px;">
										
									
										
									
										
									
									</div>
								</div>
								</div>
							</div>
							<div class="clear"></div>
						</div>
					</div>
					<div class="inspectionrightwrap">
						<div class="inspection_bg">
							<div class="inspectionTable">
										<div class="clear row1 row1Title">
											<span>UNDER VEHICLE</span>
										</div>
										<div class="clear row1">
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
												<span class="inspectionTxt">Brakes (Pads / Shoes)</span>
										</div>
										<div class="clear row1">
											<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
												<span class="inspectionTxt">Brake Lines / Hoses</span>
										</div>
										<div class="clear row1">
											<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span>
												<span class="inspectionTxt">Steering System</span>
										</div>
										<div class="clear row1">
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Shocks &amp; Struts</span>
									 	</div>
										<div class="clear row1">
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Driveline (Axles / CV Shaft)</span>
										</div>
										<div class="clear row1">
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Exhaust System</span>
										</div>
										<div class="clear row1">
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Fuel Lines &amp; Hoses</span>
										</div>
										<div class="clear row1">
												<span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span> 
												<span class="inspectionTxt">Other ________________________</span>
									 	</div>
								
							</div>
							<div class="inspectionTable" style="border-bottom:1px solid #000;">
							
								
        						<div class="clear row1 row1Title">
         	 						<span>TIRES</span>
        						</div>
        						
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								
        					
								<div class="clear row1" style="border-bottom:0px;">
          							<div style="padding:0px; border:0px;height:130px">
          								<div class="bordernone interior_inspec">
          								 	
          									
              							 	
          									
              								<div class="alignCenter clear paddingBottom" style="width:360px;float:none;">
                								<span id="treadDepth">Tread Depth</span>
              								</div>
              								
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							 	
          									
              							
              								<div class="clear paddingBottom" style="width:375px; height:30px;">
              								 	
          										
                							 	
          										
                							 	
          										
          											<span style="width:135px; float:left;">
                									
                										
                											<b class="greenCircle"></b>
                											<span class="fontF">7/32" or greater</span>
                										
                										
                									
                									</span>
                								
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                									<span style="width:120px; float:left;">
                										
                											
                												<b class="yellowCircle"></b>
                												<span class="fontF">3/32" to 6/32"</span>
                											
                											
                										
                									</span>
                								
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                									<span style="width:117px; float:left;">
                										
                											
                												<b class="redCircle"></b>
                												<span class="fontF">2/32"  or less</span>
                											
                											
                										
                									</span>
                								
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							 	
          										
                							
              								</div>
             		 						<div class="clear">
                								<div class="alignCenter" style="width:375px;">
                										<div class="bordernone interior_inspec1 interior_inspecLeft">
                											
				 												
				 													<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
                      													<strong style="display:block;width:20px;">LF</strong>
                      												</span>
                      												<span class="txt_bold_lower_case" style="position:relative; left:-5px;float:right;display:block;width:67px">____/32"</span>
                      												<span style="display:block;float:right;"><b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b></span>
				 												
				 												
				 											
                  										</div>
                										<div class="bordernone interior_inspec1 interior_inspecRight">
                											
				 												
				 													<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
                      													<strong style="display:block;width:20px;">LR</strong>
                      												</span>
                      												<span class="txt_bold_lower_case" style="position:relative; left:-5px;float:right;display:block;width:67px">____/32"</span>
                      												<span style="display:block;float:right;"><b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b></span>
				 												
				 												
				 											
                  										</div>
                										<div class="bordernone interior_inspec1 interior_inspecLeft">
                											
				 												
				 													<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
                      													<strong style="display:block;width:20px;">RF</strong>
                      												</span>
                      												<span class="txt_bold_lower_case" style="position:relative; left:-5px;float:right;display:block;width:67px">____/32"</span>
                      												<span style="display:block;float:right;"><b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b></span>
				 												
				 												
				 											
                  										</div>
                										<div class="bordernone interior_inspec1 interior_inspecRight">
                          									
				 												
				 													<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
                      													<strong style="display:block;width:20px;">RR</strong>
                      												</span>
                      												<span class="txt_bold_lower_case" style="position:relative; left:-5px;float:right;display:block;width:67px">____/32"</span>
                      												<span style="display:block;float:right;"><b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b></span>
				 												
				 												
				 											
                  										</div>
				 								</div>
             							 	</div>
            							</div>
            						</div>
        						</div>
								<div style="background-color:#d4daee; height:215px;">
			  						<div style="float:left; width:200px;">
			  						
										
									
										
									
										
                						<span style="padding:0px;width:100px;float:left;">
				 							<img src="{{URL::asset('mighty/images/rght_tire.png')}}" style="max-height: 200px;max-width: 100px;">
										</span>
										
									
										
									
                						<div class="bordernone interior_inspec padding_reset lessWidth" style="padding:0px;float:right; padding-top:15px;width:100px !important;">
                    					<div style="height:30px;margin-bottom:10px;">
                    					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      						<span colspan="2" style="padding:0px;" id="treadDepth">
                      							<h2 style="text-align:center;">Wear Pattern/ Damage</h2>
                      						</span>
                      						
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					 	
          									
                      					
                    					</div>
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    							<div class="clear" style="display:block; margin-bottom:10px;height:20px;">
                      								<span width="29" class="txt_bold txtLeft"> 
                      									LF
                      								</span>
                      								<span width="284">
                      									<b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b>
                      								</span>
                    							</div>
                    						
                    					 	
          									
                    							<div class="clear" style="display:block; margin-bottom:10px;height:20px;">
                      								<span width="29" class="txt_bold txtLeft"> 
                      									RF
                      								</span>
                      								<span width="284">
                      									<b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b>
                      								</span>
                    							</div>
                    						
                    					 	
          									
                    							<div class="clear" style="display:block; margin-bottom:10px;height:20px;">
                      								<span width="29" class="txt_bold txtLeft"> 
                      									LR
                      								</span>
                      								<span width="284">
                      									<b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b>
                      								</span>
                    							</div>
                    						
                    					 	
          									
                    							<div class="clear" style="display:block; margin-bottom:10px;height:20px;">
                      								<span width="29" class="txt_bold txtLeft"> 
                      									RR
                      								</span>
                      								<span width="284">
                      									<b class="smallGreenCircle"></b><b class="smallYellowCircle"></b><b class="smallRedCircle"></b>
                      								</span>
                    							</div>
                    						
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					 	
          									
                    					
                						</div>
									</div>
				   					<div class="interior_inspec" style="height:215px;border-right: 2px solid #0e62af !important;border-left: 2px solid #0e62af !important;padding:0px;width:96px; padding:0 3px; float:left;">
                        				<div cellspacing="0" class="bordernone padding_reset" style="">
                        				 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            				<div style="text-align:center;margin-top:15px;">
                             				 	<h2 class="titleFont" style="text-align:center;">Air Pressure</h2>
                            				</div>
                            			
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			 	
          									
                            			
                            			<div>
                            				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              						<span style="float:left; width:16px;margin-right:2px;">
                              							<b class="smallRedCircle"></b>
                              						</span>
                              						<span class="fontTxt" style="display:block; float:left;width:75px;">TPMS Warning System</span>
                              					
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				 	
          										
                              				
                            			</div>
                             			<div class="bordernone interior_inspec" style="width:86px !important;">
                                  			<div class="beforeAfter">
                                  				 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    					<span style="float:left; position:relative; left:19px;">BEFORE</span>
                                    				
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			
                                  			</div>
                                  			<div class="beforeAfter">
                                  				 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    					<span style="float:left;position:relative; left:28px;">OEM SPEC</span>
                                    				
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			 	
          											
                                    			
                                  			</div>
                                  			<div style="width:100%;" class="clear">
                                  				<div style="clear:left;width:58%;float:left;">
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			<div style="width:100%;float:left;" class="clear">
								  				<div style="float:left;width:15px;">
                                 				<span style="position:relative;top:7px;">
                                 					<span class="txt_bold">LF</span>
                                 				</span>
								 				</div>
                                 				<div style="width:30px; float:left;margin-right:3px;">
                                 					<span class="white_box"></span>
								  				</div>
                                  			</div>
                                  			
                                  			 	
          									
                                  			<div style="width:100%;float:left;" class="clear">
								  				<div style="float:left;width:15px;">
                                 				<span style="position:relative;top:7px;">
                                 					<span class="txt_bold">RF</span>
                                 				</span>
								 				</div>
                                 				<div style="width:30px; float:left;margin-right:3px;">
                                 					<span class="white_box"></span>
								  				</div>
                                  			</div>
                                  			
                                  			 	
          									
                                  			<div style="width:100%;float:left;" class="clear">
								  				<div style="float:left;width:15px;">
                                 				<span style="position:relative;top:7px;">
                                 					<span class="txt_bold">LR</span>
                                 				</span>
								 				</div>
                                 				<div style="width:30px; float:left;margin-right:3px;">
                                 					<span class="white_box"></span>
								  				</div>
                                  			</div>
                                  			
                                  			 	
          									
                                  			<div style="width:100%;float:left;" class="clear">
								  				<div style="float:left;width:15px;">
                                 				<span style="position:relative;top:7px;">
                                 					<span class="txt_bold">RR</span>
                                 				</span>
								 				</div>
                                 				<div style="width:30px; float:left;margin-right:3px;">
                                 					<span class="white_box"></span>
								  				</div>
                                  			</div>
                                  			
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			 	
          									
                                  			
                                  			</div>
                                  			
                                  			<div style="width:40%;float:left;">
                                  			<div>
                                 				<div>
                                 					<span class="white_box_rectangle">&nbsp;</span>
								  				</div>
								  				<div>
                                 					<span class="white_box_rectangle" style="position:relative; top:2px;">&nbsp;</span>
								  				</div>
                                  			</div>
                                  			</div>
                                  			
                                  			</div>
                                		</div>
                          				</div>
                  					</div>
									<div class="interior_inspec" style="padding:0px;width:74px;float:left; padding:0 3px;">
										 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            					<div style="margin-top:15px;">
                              						<span>
                              							<h2 class="titleFont" style="text-align:center;">Tire Check/ OE Interval Suggests:</h2></span>
                            					</div>
                            				
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			 	
                             		 		
                            			
                             		 	<div class="bordernone interior_inspec" style="width:80px;">
                             		 	 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  		 	
                             		 		
                                  				<div class="clear" style="height:20px; margin-bottom:5px;">
                                    				<span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                    				<span class="txtFont" style="vertical-align:-3px;">Alignment</span>
                                  				</div>
                                  			
                                  		 	
                             		 		
                                  				<div class="clear" style="height:20px; margin-bottom:5px;">
                                    				<span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                    				<span class="txtFont" style="vertical-align:-3px;">Balance</span>
                                  				</div>
                                  			
                                  		 	
                             		 		
                                  				<div class="clear" style="height:20px; margin-bottom:5px;">
                                    				<span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                    				<span class="txtFont" style="vertical-align:-3px;">Rotation</span>
                                  				</div>
                                  			
                                  		 	
                             		 		
                                  				<div class="clear" style="height:20px; margin-bottom:5px;">
                                    				<span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                    				<span class="txtFont" style="vertical-align:-3px;">New Tire</span>
                                  				</div>
                                  			
                                  		
                                		</div>
                          			</div>
              					</div>
      						</div>
      						<div class="bottomtext" style="width: 400px;overflow:hidden;">
								<span style="float: left;" id="comp_72" class="comments">Comments:</span> 
								<span style="display:block;overflow:hidden;"><hr class="cmtLine" id="cmtLine1" style="width: 400px;"></span>
								<br><hr style="width: 400px;"><br><hr style="width: 400px;"><br><hr style="width: 400px;"><br><hr style="width: 400px;"><br><hr style="width: 400px;">
								<div style="width:400px;margin-top:10px;">
									<div style="float:left;width:279px;overflow:hidden;">
										<span style="float: left;" id="comp_73" class="comments">Inspected by:</span> 
										<span style="display:block;overflow:hidden;"><hr class="cmtLine" id="cmtLine2" style="width: 276px;"></span>
									</div>
									<div style="float:right;width: 120px;">
										<span style="float: left;" id="comp_74" class="comments">Date:</span> 
										<span style="display:block;overflow:hidden;"><hr class="cmtLine" id="cmtLine3" style="width: 125px;"></span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="clear"></div>
				<div id="btnClick">
					 
				</div>
				</div>
			 
       <div style="text-align:center;margin-top:10px;padding-bottom:10px;overflow:auto; padding-left:380px;">
          <input name="save" class="savebtn" value="Save" onclick="updateForm();launchWindow('#dialog');" type="button">
           <input value="Cancel" class="cancelbtn1" onclick="launchWindow('#dialog')" type="submit">
        </div>
       
    </div>
        </div>
        </section>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3">
               tab3
              </div>
              <div class="tab-pane" id="tab_4">
              tab4
              </div>
              <div class="tab-pane" id="tab_5">
              tab5
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
      </div>
    </section>
   
 
@endsection


@section('customJs')
@endsection
