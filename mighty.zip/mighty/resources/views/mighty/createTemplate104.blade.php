<?php
$template=Config::get('custom.template');
?>
@extends('mighty.layout.tpl')
@section('customCss')
<link rel="stylesheet" href="{{URL::asset('mighty/plugins/template4.css')}}">
<style>
.content {
    min-height: 1811px;
}
</style>
@endsection

@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Mighty Customizable Vehicle Inspection Forms
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">CVIF</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li><a href="{{URL::to('/cvif/create-template101')}}" >Template 101</a></li>
              <li><a href="{{URL::to('/cvif/create-template102')}}" >Template 102</a></li>
              <li><a href="{{URL::to('/cvif/create-template103')}}" >Template 103</a></li>
              <li class="active"><a href="{{URL::to('/cvif/create-template104')}}" >Template 104</a></li>
              <li><a href="{{URL::to('/cvif/create-template105')}}" >Template 105</a></li>
              </ul>
            <div class="tab-content">
              <div class="tab-pane" id="tab_1">
           <section class="content">    
        <div class="col-md-12">
        </div>
        </section>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane active" id="tab_2">
   <section class="content">    
        <div class="col-md-12">
 <div class="innercontainer">
  <div style="text-align:center; padding-top:10px; padding-bottom:10px;">
   <span class="circlesquare">Form Name</span> : <input name="formName" id="formName" maxlength="20" value="104 Form 2" type="text">
  </div>
	<div id="templateSize">
        <div style="width: 21.5cm;" class="divLogoTab">
			 <div class="divLogoRow">
				<div class="logo1">
					<div class="leftOptImage103" id="logoLeft104">
						 
					</div><br>
					
					<a href="javascript:void(0);" id="uploadImage1" onclick="centerImageSelectionPop('leftLogo104',150,100); return false;" style="display:inline;margin-top:10px; font-family: 'MyriadProRegular';font-size: 11pt;white-space: nowrap;position:relative; left:-14px; top:-15px;">Click to upload optional logo</a> &nbsp;&nbsp;<span class="imgDimension" style="position:relative; top:-13px;left:10px;">[150 x 100]</span>
					
				</div>
				<div id="imgLogo" class="imgLogo" align="center">
				
				
				
					<p id="msg">(Your logo here)<br>Dimension:[384 x 72]pixels</p>
				
				
				</div>
				<div style="width:300px;margin:0 auto;clear:both;text-align:center;">
			   	 <a href="javascript: void(0);" id="centerImageClick" onclick="centerImageSelectionPop('center104',384,72); return false;" style="height: 0; font-family: 'MyriadProRegular';font-size: 11pt;">Click to upload logo</a> &nbsp;&nbsp;<span class="imgDimension">[384 x 72]</span>
			   	</div>
			   
				<div class="logo2-103" style="margin-top:-97px;">
					<div class="rghtOptImage103" id="logoRight104">
						 
					</div>
					<a href="javascript:void(0);" id="uploadImage2" onclick="centerImageSelectionPop('rightLogo104',150,100); return false;" style="display:block; width: 97px;white-space: nowrap;margin-top:0px; font-family: 'MyriadProRegular';font-size: 11pt;position: relative;left:-14px;">Click to upload optional logo</a> &nbsp;&nbsp;<span class="imgDimension" style="position:relative; left:20px;">[150 x 100]</span>
				</div>
			 </div>
		</div>
 
    
    
    <input name="formId" value="689836" type="hidden">
   
    <div id="pageHeading" style="clear:both; margin-top:20px;">
	 <p id="heading">
		<label id="lblText" class="text_label"><nobr>
				<span id="cmt" style="float:left;clear:left;">
					<input readonly="readonly" class="inputBorder" name="headerText" id="headerText" value="MULTI-POINT INSPECTION" onkeypress="return limitOfCharHeader(event,this.id,25)" size="100" maxlength="30" style="width: 620px; height: 30px; font-weight: bold; text-align: center; text-transform: uppercase;" onblur="removeEditHeader('headerText', 25)" type="text">
				</span> 
			   
				<span style="float: right;" class="handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}" onclick="editTextHeader('headerText')" id="editButtonheaderText">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}" onclick="removeEditHeader('headerText', 25)" id="okButtonHeader" style="display: none;">
		
	 </span></nobr></label></p><nobr>
	 <br>
	 <!--<div class="edit"></div>-->																
	 <div class="clear"></div>
	</nobr></div><nobr>
	
	<div class="divTable">
	 <div class="divRow">
		<div id="customer" class="divCell" style="margin-left:25px;">
		 <div id="customerP" class="inspec_formp moreWidth" style="border: 1px solid black; padding: 0px ! important; width: 755px;">
		   
			
				
			
				<span align="center" class="th">
						<input name="componentId0" value="6899044" type="hidden">
						<input name="component0" id="component0" value="" type="hidden">
					  
					  
					  
					  		<div>
					      	 <input readonly="readonly" class="inputBorder" name="component_01" id="component_01" value="Name:__________________________________Mileage:___________________________Year/Make/Model:_______________" onkeypress="return limitnofotextCustomer(this.id,event)" onblur="comp01FocusOut();" onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" size="100" style="width:753px;display:block;padding:5px 0; " type="text">
					   	     </div>
			   	     
			   	     
						
					  
			   	     
					  		<div>
					      	 <input readonly="readonly" class="inputBorder" name="component_02" id="component_02" value="RO#:_____________________________VIN:___________________________License:_______________Email:______________" onkeypress="return limitnofotextCustomer(this.id,event)" onblur="comp02FocusOut();" onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" size="100" style="width:753px;display:block;padding:5px 0; " type="text">
					   	     </div>
			   	     
						
					   </span>
			</div>
		
				<span style="float: rightposition:relative; left:20px; top:-80px;" class="handSymbol">
					<img src="{{URL::asset('mighty/images/ieditover.png')}}" onclick="editTextCustomer('component')" id="editButton0">
					<img src="{{URL::asset('mighty/images/ieditOk.png')}}" onclick="removeEditCustomer('component',250)" id="okButton0" style="display: none;">
		  		</span>												
		</div>						
	 </div>
	</div>
	<div id="commentDiv">
		<span id="temp1"></span>
	</div>
								
	<div class="clear"></div>
	<div class="selTable">
	<div style="padding:15px 25px;">
		
	       <span class="circleSuare">
			<input name="imgType" value="circle" type="radio">Circle
			</span>
			<span class="circleSuare">
				<input name="imgType" value="square" checked="" type="radio">Square
			</span>
	</div>


	 <div class="selRow">
		<div class="selCol selCol3">
		  <div class="selCell">	
		  	<span><b class="green"></b></span>
			
			
			<!--component edit and delete start -->
			
			<span class="floatLeft">			 
			<span id="divTxt_lights">
			
			
			 
			
				
			
					 <span class="inspectionTxt4 leftAlignTxt width4">
					 <input name="componentId1" value="6898381" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component1" id="component1" value="CHECKED AND OK" onkeypress="return limitOfCharForMandatory(event,this.id,20)" size="25" maxlength="20" onblur="removeEditMandatory('component1', 20)" type="text">
					</span>
					 
			</span>
				<span style="float: right;" class="handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}" onclick="editText('component1')" id="editButton1">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}" onclick="removeEditMandatory('component1',20)" id="okButton1" style="display: none;">
					 
				</span>
			</span>
			
		 <br> <input src="{{URL::asset('mighty/images/images.png')}}" style="display: none; margin-left: 11px; margin-top: -5px;" id="inp1" name="clr" class="color" type="image">
		  </div>
		</div>
		<div class="selCol selCol3">
		  <div class="selCell">								
			<span><b class="yellow"></b></span>
			<span id="nobr" class="floatLeft">
			
			<span class="floatLeft">			 
			<span id="divTxt_lights">
			
			
				
			
					 <span class="inspectionTxt4 leftAlignTxt width4">
					 <input name="componentId2" value="6899155" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component2" id="component2" value="FUTURE ATTENTION" onkeypress="return limitOfCharForMandatory(event,this.id,20)" size="25" maxlength="20" onblur="removeEditMandatory('component2', 20)" type="text">
					</span>
					 
			</span>
				<span style="float: right;" class="handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}" onclick="editText('component2')" id="editButton2">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}" onclick="removeEditMandatory('component2', 20)" id="okButton2" style="display: none;">
					 
				</span>
			</span>
			 </span>   
			 <br> <input src="{{URL::asset('mighty/images/images.png')}}" style="display: none; margin-left: 11px; margin-top: -5px;" id="inp2" name="clr" class="color" type="image">
		  </div>
		</div>
		<div class="selCol selCol3">
		  <div class="selCell">
			<span><b class="red"></b></span>
			<span id="nobr" class="floatLeft">
			
			<span class="floatLeft">			 
			<span id="divTxt_lights">
			
				
			
					 <span class="inspectionTxt4 leftAlignTxt width4">
					 <input name="componentId3" value="6898823" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component3" id="component3" value="IMMEDIATE ATTENTION" onkeypress="return limitOfCharForMandatory(event,this.id,20)" size="25" maxlength="20" onblur="removeEditMandatory('component3', 20)" type="text">
					</span>
					 
			</span>
				<span style="float: right;" class="handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}" onclick="editText('component3')" id="editButton3">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}" onclick="removeEditMandatory('component3',20)" id="okButton3" style="display: none;">
					 
				</span>
			</span>
			 																		
			</span>
			<br> <input src="{{URL::asset('mighty/images/images.png')}}" style="display: none; margin-left: 11px; margin-top: -5px;" id="inp3" name="clr" class="color" type="image">
		  </div>
		</div>
						
	 </div>
	</div>
	<div class="clear"></div>
  
    <div class="divTable1 paddingLeft">
     <div class="inspectionleftwrap">
      <div class="inspection_bg">
        <div class="inspectionTable">
        <div class="clear row1 row1Title greyBg">
        
        
			
				
			
					<span align="center" class="th">
					<input name="componentId4" value="6898383" type="hidden">
						<input readonly="readonly" class="inputBorder componentHeader" name="component4" id="component4" value="INTERIOR/EXTERIOR" onkeypress="return limitOfCharForMandatory(event,this.id, 40)" maxlength="30" size="40" onblur="removeEditMandatory('component4', 30)" type="text">
					</span>
			 
				<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}" onclick="editText('component4')" id="editButton4">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}" onclick="removeEditMandatory('component4',40)" id="okButton4" style="display: none;">
            </span>
        </div>                      
        <div class="clear row1" style="text-align:center;padding:3px;">
        
         
			
				
			
					 <span class="smallheading" style="float:left; width:150px;display:block; text-align:center; margin-left:115px;">
					 <input name="componentId5" value="6898719" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component5" id="component5" value="NOTE ANY EXISTING BODY DAMAGE" onkeypress="return limitOfCharForMandatory(event,this.id,40)" size="40" maxlength="40" onblur="removeEditMandatory('component5', 40)" type="text">
					</span>
			 
				<span class="EditBtnNew handSymbol" style="float:right;">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}" onclick="editText('component5')" id="editButton5">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}" onclick="removeEditMandatory('component5',40)" id="okButton5" style="display: none;">
				</span>
      
        </div>
        <!--<div class="clear row1">
          <span  class="alignCenter"><img src="../images/car_3view.png" alt="" width="244" height="196" /></span>
        </div>
        -->
        <div class="clear row1" id="img">
			<div id="imgLeft" class="imgLeft" style="height:210px;margin-top:12px;" align="center">
                <span class="alignCenter" style="display:block; height:210px;margin-top:12px;">
					<img src="{{URL::asset('mighty/images/car_3view.png')}}" alt="" style="max-width:244px; max-height:192px;">
				</span>
			</div>
			<div id="text" style="width:375px; text-align:center; top:0px;left:0px;">
				<a href="javascript:void(0);" id="leftImageClick" onclick="centerImageSelectionPop('left',244,192); return false;">Change Image</a>[244 x 192]
    		</div>
		</div>
        <div class="clear row1">
          
			
				
			
					 <span class="inspectionTxtNew">
					 <input name="componentId6" value="6898828" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component6" id="component6" value="Lights" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component6', 35)" type="text">
					</span>	  
					<span class="EditBtnNew handSymbol">
							<img src="{{URL::asset('mighty/images/ieditover.png')}}" onclick="editText('component6')" id="editButton6">
							<img src="{{URL::asset('mighty/images/ieditOk.png')}}" onclick="removeEdit('component6',35)" id="okButton6" style="display: none;">
						 
					</span>   
					
					 
			 
			
					 
		   <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
        <div class="clear row1">
        
        
        
			
				
			
					 <span class="inspectionTxtNew">
					 <input name="componentId7" value="6898499" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component7" id="component7" value="Windshield / Glass" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="31" onblur="removeEdit('component7', 31)" type="text">
					</span>	  
						  	<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}" onclick="editText('component7')" id="editButton7">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}" onclick="removeEdit('component7',31)" id="okButton7" style="display: none;">
					 
					</span>
					
		   <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
        <div class="clear row1">
        
        
        <span>
       
			
				
			
					 <span class="inspectionTxtNew">
					 <input name="componentId8" value="6898601" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component8" id="component8" value="Wipers" onkeypress="return limitnofotext(event,this.id,31)" size="29" maxlength="31" onblur="removeEdit('component8', 31)" type="text">
					</span>
						  <span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}" onclick="editText('component8')" id="editButton8">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}" onclick="removeEdit('component8',31)" id="okButton8" style="display: none;">
					 
					</span>
					 
			</span>
			 
        
		   <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
        <div class="clear row1">
        
        
			
				
			
					 <span class="inspectionTxtNew">
					 <input name="componentId9" value="6898932" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component9" id="component9" value="Horn / Interior Lights" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component9', 35)" type="text">
					</span>	  
						  <span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}" onclick="editText('component9')" id="editButton9">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}" onclick="removeEdit('component9',35)" id="okButton9" style="display: none;">
					 
					</span>
					     
		   <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
      </div>
	  <div class="inspectionTable">
        <div class="clear row1 row1Title greyBg">
         
			
				
			
					 <span align="center" class="th">
					 <input name="componentId10" value="6898712" type="hidden">
						<input readonly="readonly" class="inputBorder componentHeader" name="component10" id="component10" value="BATTERY" onkeypress="return limitOfCharForMandatory(event,this.id,30)" size="29" maxlength="30" onblur="removeEditMandatory('component10', 30)" type="text">
					</span>
					 
			 
				<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component10')" id="editButton10">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEditMandatory('component10',40)" id="okButton10" style="display: none;">
              </span>
        </div>
		    <div class="clear row1">
          <span style="width:245px; float:left;padding:15px 0;">
          
          
        
			
				
			
					 <span class="textFont" style="display:block; float:left;margin-top:-5px;">
					 <input name="componentId11" value="6898711" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component11" id="component11" value="SEE ATTACHED PRINTOUT" onkeypress="return limitOfCharForMandatory(event,this.id,35)" size="29" maxlength="35" onblur="removeEditMandatory('component11', 35)" style="width:185px;" type="text">
					</span>	
						  	<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}" onclick="editText('component11')" id="editButton11">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}" onclick="removeEditMandatory('component11',35)" id="okButton11" style="display: none;">
				 </span>
					 
			</span>
			
				
             <div style="clear:both;padding:15px 5px 0 40px;;">
             <span>
             	<b class="green"></b><b class="yellow"></b><b class="red"></b>
             </span>
			 </div>
		 
          <!--<div>
             <div style="width:120px; float:left;position:relative;left:100px;top:-30px;"><img src="../images/battery.png" width="125" height="111" /> </div>
		   </div>
        -->
         <div id="img">
			<div id="imgBottomLeft" class="imgBottomLeft" style="float: right;margin-top: -31px;;width: 115px;height:95px;position:relative; top:-23px; left:-20px;" align="center">
				<img src="{{URL::asset('mighty/images/Might85510.JPG')}}" alt="battery" style="max-width:115px;max-height: 90px;" id="image">
			</div>
			<div id="text" style="position:relative; top:40px;left: 137px;width: 210px;">
    			<a href="javascript:void(0);" id="bottomLeftImageClick" onclick="centerImageSelectionPop('bottemLeft',115,90); return false;" style="display:inline;margin-top:10px;">Change Image</a>[115 x 90]
			</div>
		</div>
        </div>
      </div>
      
	  <div class="inspectionTable">
        <div class="clear row1 row1Title greyBg">
        
         
			
				
			
					 <span align="center" class="th">
					 <input name="componentId12" value="6898938" type="hidden">
						<input readonly="readonly" class="inputBorder componentHeader" name="component12" id="component12" value="UNDERHOOD" onkeypress="return limitOfCharForMandatory(event,this.id,40)" size="29" maxlength="30" onblur="removeEditMandatory('component12', 40)" type="text">
					</span>
					 
			 
				<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component12')" id="editButton12">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEditMandatory('component12',40)" id="okButton12" style="display: none;">
				</span>
        </div>
        <div class="clear row1">
          
			
				
			
					 <span class="inspectionTxtNew">
					 <input name="componentId13" value="6898829" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component13" id="component13" value="Oil Condition" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component13', 35)" type="text">
					</span>	  
						  <span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component13')" id="editButton13">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEdit('component13',35)" id="okButton13" style="display: none;">
					 
					</span>
					
 
		  <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
        <div class="clear row1">
        
        
         
			
				
			
					 <span class="inspectionTxtNew">
					 <input name="componentId14" value="6898491" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component14" id="component14" value="Transmission Fluid" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component14', 35)" type="text">
						</span>
						  	<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component14')" id="editButton14">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEdit('component14',35)" id="okButton14" style="display: none;">
					 
					</span>
		  <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
        <div class="clear row1">
         
			
				
			
					 <span class="inspectionTxtNew">
					 <input name="componentId15" value="6898497" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component15" id="component15" value="Power Steering / Brake Fluid" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component15', 35)" type="text">
						</span>
						<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component15')" id="editButton15">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEdit('component15',35)" id="okButton15" style="display: none;">
					</span>
		  <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
		<div class="clear row1">
		<span>
		 
			
				
			
					 <span class="inspectionTxtNew">
					 <input name="componentId16" value="6899041" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component16" id="component16" value="Coolant / Antifreeze" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component16', 35)" type="text">
						  </span>
						  	<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component16')" id="editButton16">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEdit('component16',35)" id="okButton16" style="display: none;">
					 
					</span>
			</span>
			
				 
		  <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
		<div class="clear row1">
		<span>
		 
			
				
			
					 <span class="inspectionTxtNew">
					 <input name="componentId17" value="6898604" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component17" id="component17" value="Air Filter" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component17', 35)" type="text">
						 </span>
						  <span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component17')" id="editButton17">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEdit('component17',35)" id="okButton17" style="display: none;">
					 
					</span>
					 
			</span>
				
		  <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
		<div class="clear row1">
		<span>
		 
			
				
			
					 <span class="inspectionTxtNew">
					 <input name="componentId18" value="6899046" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component18" id="component18" value="Cabin Filter" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component18', 35)" type="text">
						 </span>
						  <span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component18')" id="editButton18">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEdit('component18',35)" id="okButton18" style="display: none;">
					 
					</span>
					 
			</span>
				
		  <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
		<div class="clear row1">
		<span>
		 
			
				
			
					 <span class="inspectionTxtNew">
					 <input name="componentId19" value="6898821" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component19" id="component19" value="Belts" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component19', 35)" type="text">
						  </span>
						  	<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component19')" id="editButton19">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEdit('component19',35)" id="okButton19" style="display: none;">
					 
					</span>
					 
			</span>
		  <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
      </div>
	   <div class="inspectionTable">
        <div class="clear row1 row1Title greyBg">
        
        
        
        
         
         <span>
			
				
			
					 <span align="center" class="th">
					 <input name="componentId20" value="6898490" type="hidden">
						<input readonly="readonly" class="inputBorder componentHeader" name="component20" id="component20" value="UNDER VEHICLE" onkeypress="return limitOfCharForMandatory(event,this.id,40)" size="29" maxlength="30" onblur="removeEditMandatory('component20', 40)" type="text">
					</span>
					 
			</span>
				<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component20')" id="editButton20">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEditMandatory('component20',40)" id="okButton20" style="display: none;">
                </span>
        
         
        </div>
        <div class="clear row1">
        
        
         
			
				
			
					 <span class="inspectionTxtNew">
					  <input name="componentId21" value="6899151" type="hidden">
						<!--<input type="text" class="inputBorder"  name="component21" id="component21"  value="Brake Lines / Brake Hoses /Brake Cables / Fuel Lines"  onkeypress="return limitnofotext(event,this.id,35)" 
						  size="29" disabled="disabled" />
						   -->
						   <textarea readonly="readonly" rows="1" cols="10" class="inputBorder" name="component21" id="component21" onkeypress="return limitnofotext(event,this.id,55)" style="height: 42px;" onblur="removeEdit('component21', 55)" maxlength="55">Brake Lines / Brake Hoses /Brake Cables / Fuel Lines</textarea> 
						  	</span>
						  	<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component21')" id="editButton21">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEdit('component21',55)" id="okButton21" style="display: none;">
					 
					</span>
					 
		  <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
        <div class="clear row1">
        
        
         
			
				
			
			     	 
					 <span class="inspectionTxtNew">
					  <input name="componentId22" value="6898602" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component22" id="component22" value="Suspension &amp; Steering" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component22', 35)" type="text">
						  	</span>
						  	<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component22')" id="editButton22">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEdit('component22',35)" id="okButton22" style="display: none;">
					 
					</span>
		 
		  <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
        <div class="clear row1">
        
         
			
				
			
			     	 
					 <span class="inspectionTxtNew">
					  <input name="componentId23" value="6898603" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component23" id="component23" value="Driveline (Axles / CV Shaft)" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component23', 35)" type="text">
						 </span>
						  <span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component23')" id="editButton23">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEdit('component23',35)" id="okButton23" style="display: none;">
					 
				</span>
		  <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
		<div class="clear row1">
		
         
			
				
			
			     	 
					 <span class="inspectionTxtNew">
					  <input name="componentId24" value="6898710" type="hidden">
						<!--<input type="text" class="inputBorder"  name="component24" id="component24"  value="Rear Differential Fluid Level & Condition"  onkeypress="return limitnofotext(event,this.id,35)" 
						  size="29" disabled="disabled" />
						   --><textarea readonly="readonly" rows="1" cols="10" class="inputBorder" name="component24" id="component24" onkeypress="return limitnofotext(event,this.id,41)" style="height: 42px;" onblur="removeEdit('component24', 41)" maxlength="41">Rear Differential Fluid Level &amp; Condition</textarea> 
						  </span>
						  <span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component24')" id="editButton24">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEdit('component24',35)" id="okButton24" style="display: none;">
					 
				</span>
		  <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
		<div class="clear row1">

         
			
				
			
			     	 
					 <span class="inspectionTxtNew">
					  <input name="componentId25" value="6899150" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component25" id="component25" value="Exhaust System / Shocks &amp; Struts" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component25', 35)" type="text">
						 </span>
						  <span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editText('component25')" id="editButton25">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeEdit('component25',35)" id="okButton25" style="display: none;">
					 
				</span>
					 
			 
		  <span class="floatRightTxt"><b class="green">&nbsp;</b><b class="yellow">&nbsp;</b><b class="red">&nbsp;</b></span>
        </div>
	  </div>
      
      
      
      
      <div class="clear"></div>
	  
    </div>
  </div>
  <div class="inspectionrightwrap">
    <div class="inspection_bg">
     
      <div class="inspectionTable" style="border-bottom:1px solid #000;">
        <div class="clear row1 row1Title greyBg">
         
			
				
			
					 <span align="center" class="th">
					  <input name="componentId26" value="6898930" type="hidden">
						<input readonly="readonly" class="inputBorder componentHeader" name="component26" id="component26" value="TIRES" onkeypress="return limitnofotext(event,this.id,30)" size="29" maxlength="30" type="text">
					</span>
					 
			
				<span class="EditBtnNew handSymbol">
						<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editMultipleText(26,55)" id="editButton26">
						<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeMultipleEdit(26,55)" id="okButton26" style="display: none;">
						</span>
        </div>
       
        <div class="clear row1" style="border-bottom:0px;">
          <div style="padding:0px; border:0px;height:130px">
          <div class="bordernone interior_inspec">
              <div class="alignCenter clear paddingBottom" style="width:360px;">
                
			
				
			
			     	 
					 <span class="inspectionTxtNew">
					  <span><h2 class="noInspec">
					    <input name="componentId27" value="6898498" type="hidden">
						<input readonly="readonly" class="inputBorder" style="text-align: center;" name="component27" id="component27" value="TREAD DEPTH" onkeypress="return limitnofotext(event,this.id,35)" size="50" maxlength="35" type="text">
						  	<span>
						</span>
					  </h2></span>
					</span>
              
              </div>
              <div class="clear paddingBottom" style="width:385px; height:30px; position:relative; top:10px;">
                <span style="width:131px; float:left;">
                <span style="display:block; width:25px;float:left;"><b class="green"></b></span>
                
				
					
				
					 <span class="inspectionTxt4 leftAlignTxt width150" style="width:96px; float:left;">
					  <span class="fontF fontF4">
					   <input name="componentId28" value="6898492" type="hidden"> 
						<input readonly="readonly" class="inputBorder" name="component28" id="component28" value="7/32&quot; or greater" onkeypress="return limitnofotext(event,this.id,35)" size="15" maxlength="16" type="text">
				
					   </span>
					</span>
			</span>
			
				
                
              
              
                <span style="width:127px; float:left;">
                 <span style="display:block; width:25px;float:left;"><b class="yellow"></b></span>
                
                  
			
				
			
			     	 
					 <span class="inspectionTxt4 leftAlignTxt width150" style="width:90px; float:left;">
					  <span class="fontF fontF4">
					   <input name="componentId29" value="6898600" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component29" id="component29" value="3/32&quot; to 6/32&quot;" onkeypress="return limitnofotext(event,this.id,35)" size="15" maxlength="16" type="text">
						  	<span>
						 
				    </span>
					   </span>
					</span>
					 
			</span>
			
			
                
                
                
            
              
                <span style="width:125px; float:left;">
                 <span style="display:block; width:25px;float:left;"><b class="red"></b></span>
                  
			
				
			
			     	 
					 <span class="inspectionTxt4 leftAlignTxt width150" style="width:92px; float:left;">
					  <span class="fontF fontF4">
					   <input name="componentId30" value="6898935" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component30" id="component30" value="2/32&quot; or less" onkeypress="return limitnofotext(event,this.id,35)" size="15" maxlength="14" type="text">
							<span>
						 
				</span>
					  </span>
					</span>
					 
			</span>
			
				
                
            
              </div>
              <div class="clear" style="padding-top:15px;">
                <div class="alignCenter" style="width:350px; overflow:auto; padding-left:30px;">
				 <div class="bordernone interior_inspec interior_inspecLeft" style="margin-left:0px; margin-right:0;margin-bottom:10px;width:170px;">
                  
                      <span class="txt_bold" style="float:left;margin-right:4px;width:25px;">
                      
                      
						
							
						
					     <input name="componentId31" value="6899048" type="hidden">
						 <input readonly="readonly" class="inputBorder" name="component31" id="component31" value="LF" onkeypress="return limitnofotext(event,this.id,3)" onkeyup="removeNextText(this.id, 32);" size="5" maxlength="2" type="text">
						  	<span style="position:relative; left:-15px;">
					  </span>
			       </span>
			         
                  
                      <span id="imgGYR3132"><b class="smallGreen"></b><b class="smallYellow"></b><b class="smallRed"></b></span>
                    
                      <span class="txt_bold">
                      
						
							
						
					      <input name="componentId32" value="6898820" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component32" id="component32" value="____/32&quot;" onkeypress="return limitnofotext(event,this.id, 8)" onkeyup="removeNextText(this.id, 31);" size="5" maxlength="8" type="text">
						  	<span>
						 
				</span>
			</span>
			
                      
                      
                  
                  </div>
                  <div class="bordernone interior_inspec interior_inspecRight" style="margin-left:0px; margin-right:0;margin-bottom:10px;width:170px;">
                      <span class="txt_bold" style="float:left;margin-right:4px;width:25px;">
                       
						
							
						
					   <input name="componentId33" value="6898605" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component33" id="component33" value="RF" onkeypress="return limitnofotext(event,this.id,3)" onkeyup="removeNextText(this.id, 34);" size="5" maxlength="2" type="text">
						  	<span style="position:relative; left:-15px;">
						 </span>
					   </span>
			    
		              <span id="imgGYR3334"><b class="smallGreen"></b><b class="smallYellow"></b><b class="smallRed"></b></span>
		                  <span class="txt_bold">
		                     
								
									
								
							   <input name="componentId34" value="6898607" type="hidden">
								<input readonly="readonly" class="inputBorder" name="component34" id="component34" value="____/32&quot;" onkeypress="return limitnofotext(event,this.id,8)" onkeyup="removeNextText(this.id, 33);" size="5" maxlength="8" type="text">
								  	<span>
						</span>
					   </span>
                  </div>
                  <div class="bordernone interior_inspec interior_inspecLeft" style="margin-left:0px; margin-right:0;margin-bottom:10px;width:170px;">
                      <span class="txt_bold" style="float:left;margin-right:4px;width:25px;">
	                      
							
								
							
						   <input name="componentId35" value="6898385" type="hidden">
							<input readonly="readonly" class="inputBorder" name="component35" id="component35" value="LR" onkeypress="return limitnofotext(event,this.id,3)" onkeyup="removeNextText(this.id, 36);" maxlength="2" size="5" type="text">
						  	<span style="position:relative; left:-15px;"></span>
				  	 </span>
			     
                    <span id="imgGYR3536"><b class="smallGreen"></b><b class="smallYellow"></b><b class="smallRed"></b></span>
                    <span class="txt_bold">
		                    
						
							
						
					   <input name="componentId36" value="6898824" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component36" id="component36" value="____/32&quot;" onkeypress="return limitnofotext(event,this.id,8)" onkeyup="removeNextText(this.id, 35);" maxlength="8" size="5" type="text">
						  	<span></span>
			   		</span>
                  </div>
                  <div class="bordernone interior_inspec interior_inspecRight" style="margin-left:0px; margin-right:0;margin-bottom:10px;width:170px;">
                  <span class="txt_bold" style="float:left;margin-right:4px;width:25px;">
                  
						
							
						
					   <input name="componentId37" value="6898939" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component37" id="component37" value="RR" onkeypress="return limitnofotext(event,this.id,3)" onkeyup="removeNextText(this.id, 38);" maxlength="2" size="5" type="text">
						  	<span style="position:relative; left:-15px;">
						 
				</span>
			   </span>
			     
                     <span id="imgGYR3738"><b class="smallGreen"></b><b class="smallYellow"></b><b class="smallRed"></b></span>
                      
						
							
						
					   <input name="componentId38" value="6898389" type="hidden">
						<input readonly="readonly" class="inputBorder" name="component38" id="component38" value="____/32&quot;" onkeypress="return limitnofotext(event,this.id,8)" onkeyup="removeNextText(this.id, 37);" maxlength="8" size="5" type="text">
						  	<span>
				</span>
                    
                  </div>
				 </div>
              </div>
            </div></div>
        </div>
   
          
        <div style="clear:left;background-color:#dddddf; height:238px;">
			  <div style="float:left; width:200px;">
                <!--<span style="padding:0px;width:100px;float:left;">
				 <img src="../images/rght_tire.png" width="100" height="170" />
				</span>
                -->
                <div style="padding:0px;width:100px;float:left; height:170px;">
					<div id="imgBottomRight" class="imgBottomRight" style="/*margin-top: -27%;*/width:96px;height:200px;" align="center">
						<img src="{{URL::asset('mighty/images/rght_tire.png')}}" alt="rght_tire" style="max-width:100px;max-height:170px;" id="image">
					</div>
					<a href="javascript:void(0);" id="bottomRightImageClick" onclick="centerImageSelectionPop('bottemRight',100,170); return false;" style="display:inline;margin-top:10px;">Change Image</a>[100 x 170]
				</div> 
                <div class="bordernone interior_inspec padding_reset" style="padding:0px;float:right; padding-top:15px; width:100px;">
                    <div>
                    
                     
						
							
						
					  <span style="padding:0px;"><h2 style="text-align:center;">
					   <input name="componentId39" value="6899154" type="hidden">
						<!--<input type="text" class="inputBorder tireComponentHeader"  name="component39" id="component39"  value="Wear Pattern/ Damage"  onkeypress="return limitnofotext(event,this.id,20)" 
						  size="15" disabled="disabled" style="width:150px;" />
						  -->
						 <textarea readonly="readonly" rows="2" cols="10" class="inputBorder tireComponentHeader" name="component39" id="component39" onkeypress="return limitnofotext(event,this.id,39)" style="width:100px;" maxlength="20">Wear Pattern/ Damage</textarea>   
					</h2><span>
					
						 </span></span>
                    </div>
                   <div class="clear" style="width:100px;margin-bottom:10px;">
                     
						
							
						
					  <span style="padding:0px;"><h2>
					   <input name="componentId40" value="6899153" type="hidden">
						<input readonly="readonly" class="inputBorder tireComponentHeader" name="component40" id="component40" value="LF" onkeypress="return limitnofotext(event,this.id,3)" size="2" maxlength="2" type="text">
						  	<span style="position:relative;top:3px;margin-right:10px;">
						 
				</span>
					</h2></span>
                     <span><b class="smallGreen"></b><b class="smallYellow"></b><b class="smallRed"></b></span>
                    
                  </div>
                    <div class="clear" style="width:100px;margin-bottom:10px;">
                    
                     
						
							
						
					  	<span> <h2>
					  	 <input name="componentId41" value="6898717" type="hidden"> 
						<input readonly="readonly" class="inputBorder tireComponentHeader" name="component41" id="component41" value="RF" onkeypress="return limitnofotext(event,this.id,3)" size="2" maxlength="2" type="text">
						  <span style="position:relative;top:3px;margin-right:10px;">
						 
				</span></h2>
					 </span>
			  
                    
                     <span><b class="smallGreen"></b><b class="smallYellow"></b><b class="smallRed"></b></span>
                    </div>
                   
                    <div class="clear" style="width:100px;margin-bottom:10px;">
                    
                    
                    
                    
                     
						
							
						
						<span>
					  	<h2>
					  	 <input name="componentId42" value="6898716" type="hidden">  
						<input readonly="readonly" class="inputBorder tireComponentHeader" name="component42" id="component42" value="LR" onkeypress="return limitnofotext(event,this.id,3)" size="2" maxlength="2" type="text">
					 
					 	<span style="position:relative;top:3px;margin-right:10px;">
						 
				</span></h2>
			   </span>
                     <span><b class="smallGreen"></b><b class="smallYellow"></b><b class="smallRed"></b></span>
                    </div>
              
                    <div class="clear" style="width:100px;">
                      
						
							
						
						<span>
					  	 <h2>
					  	 <input name="componentId43" value="6898718" type="hidden"> 
						<input readonly="readonly" class="inputBorder tireComponentHeader" name="component43" id="component43" value="RR" onkeypress="return limitnofotext(event,this.id,3)" size="2" maxlength="2" type="text">
					
					 	<span style="position:relative;top:3px;margin-right:10px;">
						 
				</span></h2>
			   </span>
                      <span><b class="smallGreen"></b><b class="smallYellow"></b><b class="smallRed"></b></span>
					
                    </div>
                </div>
				</div>
				   <div style="height:238px;border-right: 2px solid #0e62af !important;border-left: 2px solid #0e62af !important;padding:0px;width:96px; padding:0 3px; float:left;">
                        <div cellspacing="0" class="bordernone padding_reset" style="">
                            <div style="margin-top:15px;">
                            
                             
						
							
						
						<span>
					 <h2 class="titleFont" style="text-align:center;padding-bottom:0px;">
					  <input name="componentId44" value="6899045" type="hidden"> 
						<!--<input type="text" class="inputBorder tireComponentHeader"  name="component44" id="component44"  value="Air Pressure"  onkeypress="return limitnofotext(event,this.id,20)" 
						  size="12" disabled="disabled" />
						  -->
						   <textarea readonly="readonly" rows="2" cols="10" class="inputBorder tireComponentHeader" name="component44" id="component44" onkeypress="return limitnofotext(event,this.id,19)" maxlength="12">Air Pressure</textarea>   
						  <span>
						 
				</span>
					</h2> 
			   </span>
                         </div>
                            <div style="padding-left:15px;width:80px;">
                              <span style="float:left; width:22px;margin-right:5px; position:relative; top:10px;display:block;"><b class="smallRed"></b></span>
                              <!--<span class="fontTxt" style="display:block; float:left;width:65px;text-align:center;">
                              	<img src="../images/symbol.png" alt="" width="40" height="36" />
                              </span>
                              
                              -->
                              <div style="display:block; float:left;width:40px;">
								<div id="imgBottomMid" class="imgBottomMid" style="width:40px; height:36px;">
									<img src="{{URL::asset('mighty/images/symbol.png')}}" alt="symbol" style="max-width:40px;max-height: 36px;" id="image">
								</div>  
								<a href="javascript:void(0);" id="bottomMidImageClick" onclick="centerImageSelectionPop('bottomMid',40,36); return false;" style="display:inline;margin-top:4px;position:relative;left:-15px;font-style:normal!important;;">Change Image</a><br><span style="font-size:10px;">[40 x 36]</span>
							</div>
                            </div>
                             <div class="bordernone interior_inspec">
                                  <div class="beforeAfter" style="text-align:leftt;width:85px;">
                              <span style="display:block; width:38px;float:left;">    
                             
						
							
						
					<span>
					 <input name="componentId45" value="6898382" type="hidden"> 
						<input readonly="readonly" class="inputBorder tireComponentHeader" name="component45" id="component45" value="BEFORE" onkeypress="return limitnofotext(event,this.id,10)" size="8" maxlength="10" type="text">
					</span> 
						<span>
								 
						</span>
					   </span>
					   
					 
						
						 
                        <span style="display:block; width:38px;float:left;">    
                             
							
									
							
							<span>
							 <input name="componentId46" value="6898380" type="hidden"> 
								<input readonly="readonly" class="inputBorder tireComponentHeader" name="component46" id="component46" value="SHOULD BE" onkeypress="return limitnofotext(event,this.id,10)" size="12" style="left:12px !important;" maxlength="10" type="text">
							</span>
								 
					   </span>
                      </div>
                      <div style="width:90px;clear:both;" class="clear">
					  <div style="float:left;width:50px;">
                 
                      <span style="width:88px;clear:both; display:block;">    
                             
							
									
							
							<span style="float:left; display:block;width:16px;">
							 <input name="componentId47" value="6898714" type="hidden"> 
								<input readonly="readonly" class="inputBorder tireComponentHeader" name="component47" id="component47" value="LF" onkeypress="return limitnofotext(event,this.id,3)" size="2" maxlength="2" type="text">
							</span> 
								 
						<span class="white_box" style="float:left;display:block;">&nbsp;</span>
						
					   </span>
                                   
                               
								 <span style="position:relative;top:0px;">
								 <!-- <span style="width:88px; margin-top:27px;clear:both; display:block;">    -->
								  <span style="width:88px; clear:both; display:block;">    
                             
							
									
							
							<span style="float:left; display:block;width:16px;">
							 <input name="componentId48" value="6898713" type="hidden"> 
								<input readonly="readonly" class="inputBorder tireComponentHeader" name="component48" id="component48" value="RF" onkeypress="return limitnofotext(event,this.id,3)" size="2" maxlength="2" type="text">
							</span> 
								 
						 <span class="white_box" style="float:left;display:block;">&nbsp;</span>
					   </span>
							</span>
								 </div>
                                 <span class="white_box_rectangle" style="float:left;display:block;width:30px;">&nbsp;</span>
                                  </div>
								  <div style="width:90px;clear:both;" class="clear">
								  <div style="float:left;width:50px;">
                               
                                 <span style="width:88px;clear:both; display:block;">    
                             
							
									
							
							<span style="float:left; display:block;width:16px;">
							 <input name="componentId49" value="6898608" type="hidden"> 
								<input readonly="readonly" class="inputBorder tireComponentHeader" name="component49" id="component49" value="LR" onkeypress="return limitnofotext(event,this.id,3)" size="2" maxlength="2" type="text">
							</span>
								 
						 <span class="white_box" style="float:left;display:block;">&nbsp;</span>
					   </span>
                    
					 
						<span style="width:88px; margin-top:0px;clear:both; display:block;">    
                           
						
									
							
							<span style="float:left; display:block;width:16px;">
							 <input name="componentId50" value="6898936" type="hidden"> 
								<input readonly="readonly" class="inputBorder tireComponentHeader" name="component50" id="component50" value="RR" onkeypress="return limitnofotext(event,this.id,3)" size="2" maxlength="2" type="text">
							</span> 
						 <span class="white_box" style="float:left;display:block;">&nbsp;</span>
					   </span>
					
				 </div>
                                  <span class="white_box_rectangle" style="float:left;display:block;width:30px;">&nbsp;</span>   
                                  </div>
                              
                             
                               
                                </div>
                            
                          </div>
                  </div>
             
             
                
				<div style="padding:0px;width:74px;float:left; padding:0 3px;" class="bordernone padding_reset">
                            <div style="margin-top:15px;">
		                        <span>    
		                             
									
											
									
									<span><h2 class="titleFont" style="text-align:center;">
									 <input name="componentId51" value="6898934" type="hidden"> 
										<!--<input type="text" class="inputBorder componentHeader"  name="component51" id="component51"  value="Based on
 Mileage
 and Wear:"  onkeypress="return limitnofotext(event,this.id,20)" 
										  size="12" disabled="disabled" />
										  	-->
										  	<textarea readonly="readonly" rows="3" cols="10" class="inputBorder tireComponentHeader" name="component51" id="component51" onkeypress="return limitnofotext(event,this.id,29)" maxlength="29">Based on
 Mileage
 and Wear:</textarea>   
										  	<span></span>
										  </h2>
									</span> 
							   </span>
                            </div>
                            <div class="bordernone interior_inspec">
                                  <div class="clear" style="margin-bottom:10px;">
                                    <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                    <span>    
			                             
										
												
										
										<span class="txtFont" style="text-align:left;vertical-align:-2px;">
										 <input name="componentId52" value="6899152" type="hidden"> 
											<input readonly="readonly" class="inputBorder componentHeader" name="component52" id="component52" value="Alignment" onkeypress="return limitnofotext(event,this.id,20)" size="12" maxlength="10" type="text">
										</span>
								   </span>
                                  </div>
                                  <div class="clear" style="margin-bottom:10px;">
                                    <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                     <span>    
			                             
										
												
										
										<span class="txtFont" style="text-align:left;vertical-align:-2px;">
										 <input name="componentId53" value="6898493" type="hidden"> 
											<input readonly="readonly" class="inputBorder componentHeader" name="component53" id="component53" value="Balance" onkeypress="return limitnofotext(event,this.id,20)" size="12" maxlength="10" type="text">
										</span>
											 
								   </span>
			                     </div>
                                  <div class="clear" style="margin-bottom:10px;">
                                    <span><span class="white_box_square" style="float:left;margin-right:5px;"></span> </span>
                                     <span>    
			                             
										
												
										
										<span class="txtFont" style="text-align:left;vertical-align:-2px;">
										 <input name="componentId54" value="6898496" type="hidden"> 
											<input readonly="readonly" class="inputBorder componentHeader" name="component54" id="component54" value="Rotation" onkeypress="return limitnofotext(event,this.id,20)" size="12" maxlength="10" type="text">
										</span> 
											 
								   </span>
                                  </div>
                                   <div class="clear">
                                    <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                     <span>    
			                             
										
												
										
										<span class="txtFont" style="text-align:left;vertical-align:-2px;">
										 <input name="componentId55" value="6898826" type="hidden"> 
											<input readonly="readonly" class="inputBorder componentHeader" name="component55" id="component55" value="New Tire" onkeypress="return limitnofotext(event,this.id,20)" size="12" maxlength="10" type="text">
										</span> 
								   </span>
			                      </div>
                     		</div>
                 	</div>
              </div>
      </div>
	  <div class="inspectionTable inspectionTableBg" style="border-bottom:1px solid #000;clear:both; position:relative;">
        <div class="clear row1 row1Title greyBg">
          
							
									
							
							<span class="txtFont">
							 <input name="componentId56" value="6898606" type="hidden"> 
								<input readonly="readonly" class="inputBorder componentHeader" name="component56" id="component56" value="BRAKES" onkeypress="return limitnofotext(event,this.id,40)" size="29" maxlength="30" type="text">
							</span> 
					  
						<span class="handSymbol">
								<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editMultipleText(56,66)" id="editButton56">
								<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeMultipleEdit(56,66)" id="okButton56" style="display: none;">
						 	</span>		  
        </div>
       
        <div class="clear row1" style="border-bottom:0px;">
          <div style="padding:0px; border:0px;height:155px;width:161px; float:left;">
          <div class="bordernone interior_inspec">
              <div class="alignCenter clear paddingBottom" style="width:360px;">
 				  
							
									
							
							<span class="txtFont">
							 <input name="componentId57" value="6898388" type="hidden"> 
								<input readonly="readonly" class="inputBorder" name="component57" id="component57" value="BRAKE PADS / SHOES" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="30" type="text">
							</span> 
								 
						
              </div>
              <div class="clear paddingBottom" style="width:180px; height:30px;">
                <span class="clear"><b class="green"></b>
                 
							
									
							
							<span class="txtFont">
							 <input name="componentId58" value="6898937" type="hidden"> 
								 <!--<input type="text" class="inputBorder"  name="component58" id="component58"  value="Over 5 mm (Disc)
or 2 mm (Drum)"  onkeypress="return limitnofotext(event,this.id,35)" 
								  size="29" disabled="disabled" /> --> 
								  <textarea readonly="readonly" rows="2" cols="15" class="inputBorder" id="component58" name="component58" onkeypress="return limitnofotext(event,this.id,39)" style="height:42px;width:150px;" maxlength="36">Over 5 mm (Disc)
or 2 mm (Drum)</textarea>
							 </span>
								 
					   </span>
					
						
                <br>
             
                <span class="clear"><b class="yellow"></b>
                  
							
									
							
							<span class="txtFont">
							 <input name="componentId59" value="6899047" type="hidden"> 
								<!-- <input type="text" class="inputBorder"  name="component59" id="component59"  value="3-5 mm (Disc) 
 or 1.01-2 mm(Drum)"  onkeypress="return limitnofotext(event,this.id,35)" 
								  size="29" disabled="disabled" />-->
								    <textarea readonly="readonly" rows="3" cols="15" class="inputBorder" id="component59" name="component59" onkeypress="return limitnofotext(event,this.id,39)" style="height:42px;width:150px;" maxlength="36">3-5 mm (Disc) 
 or 1.01-2 mm(Drum)</textarea>
							</span> 
								 
					   </span>
                <br>
                <span class="clear"><b class="red"></b>
                  
							
									
							
							<span class="txtFont">
							 <input name="componentId60" value="6898825" type="hidden"> 
								<!-- <input type="text" class="inputBorder"  name="component60" id="component60"  value="Less than 3 mm(Disc) or 1 mm (Drum)"  onkeypress="return limitnofotext(event,this.id,35)" 
								  size="29" disabled="disabled" /> -->
								<textarea readonly="readonly" rows="3" cols="15" class="inputBorder" id="component60" name="component60" onkeypress="return limitnofotext(event,this.id,39)" style="height:60px;width:150px;" maxlength="36">Less than 3 mm(Disc) or 1 mm (Drum)</textarea>   
							</span> 
					   </span>
              </div>
            
    
              </div>
            </div></div>
                		<div id="img" style="float:left; width:205px; height:196px; position:absolute; top:75px; margin-left:180px; ">
					<div id="imgBottomCenter" class="imgBottomCenter" style=" position:relative;" align="center">
               		 	<span style=" position:relative;">
							<img src="{{URL::asset('mighty/images/inspect_Brakes.png')}}" style="position:relative;top:20px;max-height: 196px;max-width: 205px; " alt="">
						</span>
					</div>
					<div id="text">
						<a href="javascript:void(0);" id="bottomCenterImageClick" onclick="centerImageSelectionPop('bottomCenter',205,196); return false;" style="display:inline;margin-top:10px;">Change Image</a>[205 x 196]
    				</div>
				</div>
                    <div style="background-color:#dddddf; height:210px; ">
                <div class="bordernone interior_inspec padding_reset" style="padding:15px 30px;">
                    <div class="clear">
                    
							
									
							
							<span class="txt_bold txtLeft" style="width:30px;margin-bottom:10px;"> <strong>
							 <input name="componentId61" value="6898494" type="hidden"> 
								<input readonly="readonly" class="inputBorder tireComponentHeader" name="component61" id="component61" value="LF" onkeypress="return limitnofotext(event,this.id,3)" size="2" maxlength="2" type="text">
							 
							</strong></span> 
						
                      <span style="float:left;"><b class="smallGreen"></b><b class="smallYellow"></b><b class="smallRed"></b></span>
                    </div>
                   
                    <div class="clear">
                    
                    
                    
                     
							
									
							
							<span class="txt_bold txtLeft" style="width:30px;margin-bottom:10px;"> <strong>
							 <input name="componentId62" value="6898931" type="hidden"> 
								<input readonly="readonly" class="inputBorder tireComponentHeader" name="component62" id="component62" value="RF" onkeypress="return limitnofotext(event,this.id,3)" size="2" maxlength="2" type="text">
								 
							</strong></span> 
					   
					
						
                     
                      <span style="float:left;"><b class="smallGreen"></b><b class="smallYellow"></b><b class="smallRed"></b></span>
                    </div>
                  
                    <div class="clear">
                     
							
									
							
							<span class="txt_bold txtLeft" style="clear:left;width:30px; margin-bottom:10px;"> <strong>
							 <input name="componentId63" value="6898822" type="hidden"> 
								<input readonly="readonly" class="inputBorder tireComponentHeader" name="component63" id="component63" value="LR" onkeypress="return limitnofotext(event,this.id,3)" size="2" maxlength="2" type="text">
								  
							</strong></span> 
					   
						
						
                      <span style="float:left;"><b class="smallGreen"></b><b class="smallYellow"></b><b class="smallRed"></b></span>
                    </div>
              
                    <div class="clear">
                     
							
									
							
							<span class="txt_bold txtLeft" style="width:30px; clear:left; margin-bottom:10px;"> <strong>
							 <input name="componentId64" value="6898609" type="hidden"> 
								<input readonly="readonly" class="inputBorder tireComponentHeader" name="component64" id="component64" value="RR" onkeypress="return limitnofotext(event,this.id,3)" size="2" maxlength="2" type="text">
							</strong>
							 
							</span> 
					   
						
						
                      <span style="float: left"><b class="smallGreen"></b><b class="smallYellow"></b><b class="smallRed"></b></span>
					
                    </div>
					
					 <div class="clear" style="width:400px;">
					 
					 
					  
							
									
							
							<span class="fontF" style="float:left;display:block; margin-left:-23px;"> <strong>
							 <input name="componentId65" value="6899040" type="hidden"> 
								<input readonly="readonly" class="inputBorder tireComponentHeader" name="component65" id="component65" value="We feature" onkeypress="return limitnofotext(event,this.id,20)" size="29" style="width:83px;margin-top:15px;" maxlength="10" type="text">
							</strong>
					 	<!--<span>
					  		<img src="../images/brands.png" alt="" width="173" height="45" style="float:left;" />
					  	</span>
					  	-->
					  	</span>
					  	<span style="padding:0px;width:150px;float:left;display:block;margin-right:5px;margin-left:5px;">
							<div id="imgBottomLast" class="imgBottomLast" style="margin-top:10px;width: 150px;" align="center">
								<img src="{{URL::asset('mighty/images/brands.png')}}" alt="brands" style="max-height: 45px;max-width: 150px;" id="image">
							</div>
							<a href="javascript:void(0);" id="bottomLastImageClick" onclick="centerImageSelectionPop('bottomLast',150,45); return false;" style="display:inline;margin-top:10px;position:relative;top:-4px;">Change Image</a>[150 x 45]
						</span>
						
						
							
									
							
							<span class="fontF" style="float:left;display:block"> <strong>
							 <input name="componentId66" value="6899042" type="hidden"> 
								<input readonly="readonly" class="inputBorder tireComponentHeader" name="component66" id="component66" value="Brakes" onkeypress="return limitnofotext(event,this.id,20)" size="29" style="width:115px;margin-top:15px;" maxlength="12" type="text">
							</strong>
							</span>
                       <span class="fontF" style="float:left;"> </span>					   
					 </div>
                </div>
			</div>
        </div>
   				<!--<div>
                	<img src = "/ImageLibrary/inspect_Brakes.png"></img>
                </div>
          		-->
      
      
          </div>
		  <div class="inspectionTable" style="clear:both;padding-top:0;">
		<div class="clear row1Title greyBg" style="margin:0px;">
        
		
			
		
		<span style="display:block;width:345px; float:left;">
			<span id="component67Span" class="comments commentTitle">COMMENTS</span> 
				<input name="componentId67" value="6898384" type="hidden"> 
				<input readonly="readonly" class="inputBorder componentHeader" name="component67" id="component67" value="COMMENTS" onkeypress="return limitOfCharForMandatory(event,this.id,30)" size="40" maxlength="30" style="display: none;margin-left: 40px;" type="text">
				</span>
				<span style="diaplay:block; width:20px;float:left;" class="handSymbol">	
					<img src="{{URL::asset('mighty/images/ieditover.png')}}"" onclick="editMultipleTextLast(67,69)" id="editButton67" style="float: right;;">
			<img src="{{URL::asset('mighty/images/ieditOk.png')}}"" onclick="removeMultipleEditLast(67,69)" id="okButton67" style="display: none;float: right;">
			 </span>
			
        </div>
        <div class="clear row1" style="height:27px;">
        </div>
         <div class="clear row1" style="height:27px;">
        </div>
       <div class="clear row1" style="height:27px;">
        </div>
		 <div class="clear row1" style="height:27px;">
        </div>
	 <div class="clear row1" style="height:27px;">
        </div>
        <div class="clear row1" style="height:27px;">
        </div>
		
      </div>
      <div class="bottomtext" style="width: 393px;overflow:hidden;">
		<div style="width:400px;margin-top:10px;">
			
			
				
			
			<div style="float:left;width:279px;overflow:hidden;">
				<span id="cmt" style="float: left;">
				<span id="component68Span" class="comments">Inspected by:</span> 
					<input name="componentId68" value="6898715" type="hidden"> 
					<input readonly="readonly" class="inputBorder" name="component68" id="component68" value="Inspected by:" size="15" style="width: 90px;display: none;" maxlength="15" type="text">
				</span>
				<span style="display:block;overflow:hidden;margin-top: 19px;"><hr class="cmtLine" id="cmtLine2" style="width: 276px;"></span>  
				<span style="display:block; width:20px; float:left;margin-top:5px;">
	  				
				</span>
			</div> 
			
				
			
			<div style="float:right;width: 120px;">
				<span id="component69Span" class="comments" style="float: left;">Date:</span> 
				<span style="float: left;">
					<input name="componentId69" value="6898827" type="hidden"> 
					<input readonly="readonly" class="inputBorder" name="component69" id="component69" value="Date:" size="15" style="width:40px;display: none;" maxlength="10" type="text">
				</span>
				<span style="display:block;overflow:hidden;margin-top: 19px;"><hr class="cmtLine" id="cmtLine3" style="width: 125px"></span>
				<span style="display:block; width:20px; float:left;margin-top:5px;"></span> 
	    	 </div> 
	     </div>
	</div>
					   <!--Component Id for Image -->
					    <input name="componentId70" value="6898933" type="hidden">
					    <input name="componentId71" value="6899049" type="hidden">
					    <input name="componentId72" value="6898386" type="hidden">
					    <input name="componentId73" value="6898495" type="hidden">
					    <input name="componentId74" value="6899043" type="hidden">
					    <input name="componentId75" value="6898387" type="hidden">
 </div>
  </div>
    <div class="clear"></div>
  <div style="text-align:center;margin-top:10px;padding-bottom:10px;"><a href="javascript:void(0);" name="save" value="Save" id="update102" onclick="updateTemplate104('./updateUserFormByFormId104.do');">Save</a>

  
  
	<a href="./createUserComponentForm104.do" id="cancelBtn" onclick="launchWindow('#dialog');">Cancel</a>
 



 </div>
  <div class="clear"></div>
   <div style="text-align:right;font-family:'MyriadProRegular'; font-size:6pt;padding:0 20px 10px 0;"></div>
   </nobr></div><nobr>
  </nobr></div>
        </div>
        </section>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3">
               tab3
              </div>
              <div class="tab-pane" id="tab_4">
              tab4
              </div>
              <div class="tab-pane" id="tab_5">
              tab5
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
      </div>
    </section>
   
 
@endsection


@section('customJs')
@endsection
