<?php
$template=Config::get('custom.template');
?>
@extends('mighty.layout.tpl')
@section('customCss')

@endsection

@section('content')
 
@endsection


@section('customJs')
@endsection
