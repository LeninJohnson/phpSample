@extends('mighty.layout.tpl')
@section('customCss')
    <style>
        .content {
        //    min-height: 1811px;
        }
    </style>

@endsection
@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            View Active Services
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{URL::to('')}}"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="#">Services</a></li>
            <li class="active">View Services</li>
        </ol>
    </section>

    @if(Session::has('true_msg'))
        <div style="padding: 4px;" class="row">
            <div class="col-md-6">
            <div   class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                {{Session::get('true_msg')}}
            </div>
            </div>
        </div>
    @endif
    @if(Session::has('error_msg'))
        <div style="padding: 4px;" class="row">
            <div class="col-md-6">
                <div class="alert alert-danger">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    {{Session::get('error_msg')}}
                </div> <!-- /.alert -->
            </div>
        </div>
    @endif
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">View Active Services</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Service</th>
                                <th>Description</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($services as $key=>$vals)
                            <tr>
                                <td>{{$key+1}}</td>
                                <td>{{$vals->name}}
                                </td>
                                <td>{{$vals->description}}
                                </td>
                                <td>
                             <a href="{{URL::to('/mighty-assist/services/edit')}}/{{$vals->id}}" class="tabledit-edit-button btn btn-sm btn-primary"  ><i class="fa fa-edit"></i>
                                    </a></td>
                            </tr>
                            @endforeach
                            </tbody>

                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->


                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->


@endsection

@section('customJs')


    <script src="{{URL::asset('mighty/plugins/datatables/jquery.dataTables.min.js')}}"></script>
    <script src="{{URL::asset('mighty/plugins/datatables/dataTables.bootstrap.min.js')}}"></script>


    <script>
        $(function () {
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>
@endsection