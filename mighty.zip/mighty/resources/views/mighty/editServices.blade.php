@extends('mighty.layout.tpl')
@section('customCss')
    <style>
        .content {
          //  min-height: 1811px;
        }
        .add_contents{
            margin-left:3px;
        }
        .boxofblock:hover{
            /*box-shadow: -34px 10px 5px 0px rgba(0,0,0,0.75);*/
        }
        .boxofblock{
             padding:5px;
            border: 1px solid #ddd !important;
            padding: 30px;
            display: block;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        .dontshow{
            display:none;
        }
    </style>

@endsection
@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Edit Services
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{URL::to('')}}"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="#">Services</a></li>
            <li class="active">Edit Services</li>
        </ol>
    </section>
    @if(Session::has('true_msg'))
        <div style="padding: 4px;" class="row">
            <div class="col-md-6">
                <div class="alert alert-success">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    {{Session::get('true_msg')}}
                </div> <!-- /.alert -->
            </div>
        </div>
    @endif
    @if(Session::has('error_msg'))
        <div style="padding: 4px;" class="row">
            <div class="col-md-6">
                <div class="alert alert-danger">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    {{Session::get('error_msg')}}
                </div> <!-- /.alert -->
            </div>
        </div>
    @endif
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Service Descriptions, Images and Pricing
                        </h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form id="service-form" role="form" method="post" enctype="multipart/form-data" >
                        <div class="box-body">
                            <div class="form-group">
                                <label for="name">Service Name</label>
                                <input class="form-control" name="name" value="{{$services->name}}" type="text" readonly>
                            </div>
                            <div class="form-group">
                                <label for="description">Service Description</label>
                                <textarea name="description" class="form-control" >{{$services->description}}</textarea>
                            </div>
                           

                        </div>
                        <!-- /.box-body -->
                        <div class="box-header with-border">
                        <h3 class="box-title">Services Blocks</h3>
                        </div>
                        <!-- Block start-->
                        <div class="box-body">
  <div class="" >
      @if(count($servicedetails)!=0)
          <?php
          $temp=1;
          ?>
          @foreach($servicedetails as $key=>$vals)
              <input   name="blockId{{$key+1}}" value="{{$vals->id}}" type="hidden"  />
              <div class="boxofblock" id="blocktables_{{$key+1}}">
                  <div class="form-group row">
                      <div class="col-md-10">
                          <label for="blockName1">Block Name</label>
                          <input class="form-control" name="blockName{{$key+1}}" value="{{$vals->block_name}}" type="text"  />
                      </div>
                     <!-- <div class="col-md-2">
                          @if($key!=0)
                          <button class="btn btn-danger btn-xs remove_blocks" type="button" data-remove="{{$key+1}}">Remove Blocks</button>
                          @endif
                      </div>-->
                  </div>
                  <div class="form-group row">
                      <div class="col-md-10">
                          <label for="title1">Title</label>
                          <input class="form-control" name="title{{$key+1}}" value="{{$vals->title}}"  type="text"  />
                      </div>
                  </div>
                  <div class="form-group row">
                      <div class="col-md-10">
                          <label for="title1">Sub Title</label>
                          <input class="form-control" name="subtitle{{$key+1}}" value="{{$vals->sub_title}}"  type="text"   />
                      </div>
                  </div>


                  <div class="form-group row {{($vals->type!=1) ? 'dontshow' : ''}}">
                      <div class="col-md-10">
                          <label for="title1">Price</label>
 <input class="form-control" name="price{{$key+1}}" value="{{$vals->price}}" data-rule-number="true" type="text"  />
                      </div>
                  </div>

                  <div class="form-group">
                      <label for="image1">Block Image</label>
                      <input id="image1"   name="image{{$key+1}}" type="file">
                      <p class="text-light-blue">Image Dimension should be  equal to 90px X 90px.</p>
                      @if(!empty($vals->image))
                          <img src="{{URL::asset('mighty/images/services/')}}/{{$vals->image}}" style="width: 20px;
height: 20px;"/>
                          @endif

                  </div>
                  <?php
                  $get_content=App\Helper\AppHelper::GetServiceContent($vals->id);
                  ?>
                  <div class="form-group">
                      <table class="table table-striped table-bordered table-hover table-full-width" id="sample_2">
                          <thead><tr><th style="width:80%">Content</th><th>Action<button class="btn btn-info btn-xs add_contents" data-vals="{{$key+1}}"; type="button">Add Content</button></th></tr></thead>
                          <tbody id="block_content{{$key+1}}" >

                          @foreach($get_content as $index=>$rw)
                          <tr id="cnt_x{{$temp}}" class="odd gradeX">
                              <td>
                                  <input type="text" class="form-control" name="content{{$key+1}}[]" value="{{$rw->content}}"    />
                              </td>
                              <td>
                                  @if($index!=0)
                                  <button class="btn btn-danger btn-xs remove_content" type="button"  data-remove="x{{$temp}}"><i class="fa fa-fw fa-remove"></i></button>
                                  @endif
                              </td>
                          </tr>
<?php
$temp++;
?>
                              @endforeach
                          </tbody>
                      </table>
                  </div>
              </div>
              @endforeach

          <input type="hidden" class="form-control" name="blockcount" id="blockcount" value="{{count($servicedetails)}}"  readonly />
      @else
       <div class="boxofblock" id="blocks1">
           <input   name="blockId1" value="0" type="hidden"  />
           <div class="form-group row">
               <div class="col-md-10">
               <label for="blockName1">Block Name</label>
               <input class="form-control" name="blockName1"  type="text"  />
               </div>
           <div class="col-md-2"></div>
           </div>
           <div class="form-group row">
               <div class="col-md-10">
               <label for="title1">Title</label>
               <input class="form-control" name="title1"  type="text"  />
               </div>
           </div>
           <div class="form-group row">
               <div class="col-md-10">
                   <label for="title1">Sub Title</label>
                   <input class="form-control" name="subtitle1"    type="text"   />
               </div>
           </div>
           <div class="form-group row">
               <div class="col-md-10">
                   <label for="title1">Price</label>
                   <input class="form-control" name="price1"  data-rule-number="true"  type="text"  />
               </div>
           </div>
           <div class="form-group">
               <label for="image1">Block Image</label>
               <input id="image1"  name="image1" type="file"><p class="text-light-blue">Image Dimension should be  equal to 90px X 90px.</p>
           </div>
           <div class="form-group">
               <table class="table table-striped table-bordered table-hover table-full-width" id="sample_2">
                   <thead><tr><th style="width:80%">Content</th><th>Action<button class="btn btn-info btn-xs add_contents" data-vals="1"; type="button">Add Content</button></th></tr></thead>
                   <tbody id="block_content1" >
                   <tr class="odd gradeX">
                       <td>
                           <input type="text" class="form-control" name="content1[]"     />
                       </td>
                       <td></td></tr>
                   </tbody>
               </table>
           </div>
       </div>
          <input type="hidden" class="form-control" name="blockcount" id="blockcount" value="1"   />
        @endif
  </div>
                            <div class="" id="block_details">
                            </div>

                      <!--  <div align="right" class="col-md-12">
                            <button type="button" class="btn bg-navy margin add_blocks">Add Block</button>
                        </div>-->
                        </div>
                        <!-- Block End -->


                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="{{URL::previous()}}" class="btn btn-default">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>


@endsection

@section('customJs')
    <script src="{{URL::asset('mighty/plugins/jquery.validate.min.js')}}"></script>


    <script type="text/javascript">
        $('#service-form').validate();
    </script>
<script>
    $( document ).ready(function() {

//add Block start
        @if(count($servicedetails)!=0)
        var j="{{count($servicedetails)+1}}";
        @else
        var j=2;
        @endif

        $(".add_blocks").on("click",function(e){

//var shrow = $(this).data('ts');
            var data='';

data+='<div class="boxofblock" id="blocktables_'+j+'"><div class="form-group row"><input name="blockId'+j+'" value="0" type="hidden"  /><div class="col-md-10"><label for="blockName'+j+'">Block Name</label> <input class="form-control"  name="blockName'+j+'"    type="text"  /></div><div class="col-md-2"><button class="btn btn-danger btn-xs remove_blocks" type="button" data-remove="'+j+'">Remove Blocks</button></div></div><div class="form-group row"><div class="col-md-10"><label for="title'+j+'">Title</label><input class="form-control" name="title'+j+'"  type="text"  /></div></div><div class="form-group row"><div class="col-md-10"><label for="title1">Sub Title</label><input class="form-control" name="subtitle'+j+'"    type="text"  /></div></div><div class="form-group row"><div class="col-md-10"><label for="title1">Price</label><input class="form-control" name="price'+j+'"  data-rule-number="true" type="text"  /></div></div><div class="form-group"><label for="image'+j+'">Block Image</label><input id="image1"  name="image'+j+'" type="file"></div><div class="form-group"><table class="table table-striped table-bordered table-hover table-full-width" id="sample_2"><thead><tr><th style="width:80%">Content</th><th>Action <button class="btn btn-info btn-xs add_content" data-vals="'+j+'"; type="button">Add Content</button> </th></tr></thead><tbody id="block_content'+j+'" ><tr class="odd gradeX"><td><input type="text" class="form-control" name="content'+j+'[]"     /></td><td></td></tr></tbody></table></div></div>';


            $("#block_details").append(data);


            $("#blockcount").val(j);


            j++;

            $( ".remove_blocks" ).click(function(){
                var id=$(this).attr('data-remove');
                $("#blocktables_"+id).remove();
            });

            $(".add_content").click(function(){

                var vals = $(this).data('vals');
                var data='';
                data+='<tr id="cnt_'+id+'" class="odd gradeX"><td><input type="text" class="form-control" name="content'+vals+'[]"    /></td><td><button class="btn btn-danger btn-xs remove_content" type="button"  data-remove="'+id+'"><i class="fa fa-fw fa-remove"></i></button></td> </tr>';
                $("#block_content"+vals+"").append(data);
                id++;

                $(".remove_content").click(function(){
                    var id=$(this).attr('data-remove');
                    $("#cnt_"+id).remove();
                });

            });

        });


        $( ".remove_blocks" ).click(function(){
            var id=$(this).attr('data-remove');
            $("#blocktables_"+id).remove();
        });

        $(".remove_content").click(function(){
            var id=$(this).attr('data-remove');
            $("#cnt_"+id).remove();
        });
//add Block End


//add content(start)
        var id=1;
        $(".add_contents").click(function(){

                var vals = $(this).data('vals');
                var data='';
                data+='<tr id="cnt_'+id+'" class="odd gradeX"><td><input type="text" class="form-control" name="content'+vals+'[]"    /></td><td><button class="btn btn-danger btn-xs remove_content" type="button"  data-remove="'+id+'"><i class="fa fa-fw fa-remove"></i></button></td> </tr>';
                $("#block_content"+vals+"").append(data);
                id++;

            $(".remove_content").click(function(){
                 var id=$(this).attr('data-remove');
                 $("#cnt_"+id).remove();
            });

            });

        $(".remove_content").click(function(){
            var id=$(this).attr('data-remove');
            $("#cnt_"+id).remove();
        });
            //add content(end)
            //remove content(start)

    });
</script>
@endsection