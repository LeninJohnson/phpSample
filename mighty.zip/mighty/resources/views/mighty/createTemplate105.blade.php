<?php
$template=Config::get('custom.template');
?>
@extends('mighty.layout.tpl')
@section('customCss')
<link rel="stylesheet" href="{{URL::asset('mighty/plugins/template5.css')}}"> 
<style>
.content {
    min-height: 1811px;
}
.customer-details {
    font-family: 'MyriadProRegular';
    font-size: 11pt;
    list-style: none outside none;
     margin-top: -94px;
    width: 362px;
}
.customer-details li {
    border-bottom: 1px solid #333;
    padding: 15px 0 3px;
    display: block;
}
</style>
<link rel="stylesheet" type="text/css" href="../css/pagination.css">
<style>
.grayBox1 {
	top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    opacity: 0.8;
    z-index: 1001;
     display: none;
    position: fixed;
    background-color: black;
    filter:alpha(opacity=80);
}
.box_content1 {
	left: 25%;
    right: 90%;
    z-index: 1002;
    padding: 16px;
    overflow: auto;
    position: fixed;
    margin-top: -65px;
    height: auto !important;
	width: 620px !important;
    border: 8px solid #ACACAC !important;
    background: none repeat scroll 0 0 #FFFFFF;
}
#templateSize.template-105 .divLogoTab .imgLogo {
    float: left;
  //  height: 250px !important;
    width: 350px !important;
    margin-left: 24px !important;
   // margin-top: 25px !important;
}

</style>
<style>.cke{visibility:hidden;}</style>
@endsection

@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Mighty Customizable Vehicle Inspection Forms
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">CVIF</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li><a href="{{URL::to('/cvif/create-template101')}}" >Template 101</a></li>
              <li><a href="{{URL::to('/cvif/create-template102')}}" >Template 102</a></li>
              <li><a href="{{URL::to('/cvif/create-template103')}}" >Template 103</a></li>
              <li ><a href="{{URL::to('/cvif/create-template104')}}" >Template 104</a></li>
              <li class="active"><a href="{{URL::to('/cvif/create-template105')}}" >Template 105</a></li>
              </ul>
            <div class="tab-content">
              <div class="tab-pane" id="tab_1">
           <section class="content">    
        <div class="col-md-12">
        </div>
        </section>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane active" id="tab_2">
   <section class="content">    
        <div class="col-md-12">
 <div class="innercontainer">
                        <div style="text-align:center; padding-top:10px; padding-bottom:10px;">
                            <span class="circlesquare">Form Name</span> : <input name="formName" id="formName" maxlength="20" value="105 Form 4" type="text">
                        </div>
                        <div id="templateSize" class="template-105">
                            <input name="formId" value="689501" type="hidden">
                            
                            <!--Header-->
                            <div id="pageHeading">
                                <p id="heading" class="text_label4">
                                    
                                    <label id="lblText" class="text_label4">
                                        <span id="cmt" style="float:left;clear:left;">
                                            <input readonly="readonly" class="inputBorder" name="headerText" id="headerText" value="MULTI-POINT INSPECTION" onkeypress="return limitOfCharHeader(event, this.id, 25)" size="100" maxlength="30" style="width: 620px; height: 30px; font-weight: bold; text-align: center;text-transform: uppercase;" onblur="removeEditHeader('headerText', 25)" type="text">
                                        </span> 
                                    </label>            
                                    <span style="float: right;" class="handSymbol">
                                        <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editTextHeader('headerText')" id="editButtonheaderText">
                                        <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditHeader('headerText', 25)" id="okButtonHeader" style="display: none;">
                                    </span>
                                </p>
                                <div class="clear"></div>
                            </div>
                           
                                                   
                            <!--Logo-->                            
                            <div class="divLogoTab">
                                <div class="divLogoRow">
                                    <div class="yourlogo">
                                        <input value="" id="logoTextId" name="logoText" type="hidden">
                                        <input id="html2canvasImg" name="html2canvasImg" type="hidden">
                                        
                                            
                                                <div id="imgLogo" class="imgLogo" align="center">
                                                    <img src="{{URL::asset('mighty/images/might89656.JPG')}}" style="margin:0; max-width:350px; max-height:250px;">
                                                </div>
                                                <div id="logoText" style="display: none;"></div>
                                                <textarea id="logoEditorTiny" style="display: none;">                                                    &lt;p&gt;&lt;/p&gt;
                                                </textarea>
                                                <div id="msgText" style="display: none;" align="center">
                                                    <p id="msg">(Your logo here)<br>Dimension:[350 x 250]pixels</p>
                                                </div>
                                            
                                            
                                            
                                        
                                        
                                        <span style="float: right;" class="handSymbol">
                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="showEditor('logoEditorTiny','/Inspection_Form')" id="editButtonLogoText">
                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="hideEditor('logoEditorTiny')" id="okButtonLogo" style="display: none;">
                                        </span> 
                                                
<!--                                        <div style="width:300px;margin:0 auto;clear:both;text-align:center;">
                                            <a href="javascript:void(0);" id="centerImageClick" onclick="centerImageSelectionPop('center105', 350, 250);
                                         return false;" style="height: 0;font-family: 'MyriadProRegular';font-size: 11pt;">Click to upload logo</a>&nbsp;&nbsp;<span class="imgDimension">[350 x 250]</span>
                                        </div>-->
                                    </div>
                                </div>
                            </div>
                            
                            
                            <!--Name-->
                            <div class="divTable" style="width:390px; float: right;clear:none;">
                                <div class="divRow">
                                    <div id="customer" class="divCell">
                                        <div id="customerPDiv" style="border: 0px solid #000;position: relative;">
                                            
                                                
                                                
                                                    
                                                
                                                <input name="componentId0" value="6895039" type="hidden">
                                                <input name="component0" id="component0" value="" type="hidden">
                                                
                                                <p id="customerP" class="inspec_formp moreWidth" style="width: 366px; display: none; border: 1px solid black;">
                                                    <span style="font-family: MyriadProRegular;font-size: 11pt;line-height: 1.9;" class="customerSpanText">
                                                        </span></p><ul class="customer-details">
                                                            
                                                                <li>
                                                                    <input name="component_01" value="Name:" type="hidden">
                                                                    <input readonly="readonly" class="inputBorder" name="component_01" id="component_01" value="Name:" style="width:360px;display:block;padding:5px 0; " onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" size="35" maxlength="35" onfocus="var val=this.value; this.value=''; this.value= val;" type="text">
                                                                </li>
                                                            
                                                                <li>
                                                                    <input name="component_02" value="Mileage:" type="hidden">
                                                                    <input readonly="readonly" class="inputBorder" name="component_02" id="component_02" value="Mileage:" style="width:360px;display:block;padding:5px 0; " onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" size="35" maxlength="35" onfocus="var val=this.value; this.value=''; this.value= val;" type="text">
                                                                </li>
                                                            
                                                                <li>
                                                                    <input name="component_03" value="Year/Make/Model:" type="hidden">
                                                                    <input readonly="readonly" class="inputBorder" name="component_03" id="component_03" value="Year/Make/Model:" style="width:360px;display:block;padding:5px 0; " onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" size="35" maxlength="35" onfocus="var val=this.value; this.value=''; this.value= val;" type="text">
                                                                </li>
                                                            
                                                                <li>
                                                                    <input name="component_04" value="Email:" type="hidden">
                                                                    <input readonly="readonly" class="inputBorder" name="component_04" id="component_04" value="Email:" style="width:360px;display:block;padding:5px 0; " onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" size="35" maxlength="35" onfocus="var val=this.value; this.value=''; this.value= val;" type="text">
                                                                </li>
                                                            
                                                                <li>
                                                                    <input name="component_05" value="License:" type="hidden">
                                                                    <input readonly="readonly" class="inputBorder" name="component_05" id="component_05" value="License:" style="width:360px;display:block;padding:5px 0; " onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" size="35" maxlength="35" onfocus="var val=this.value; this.value=''; this.value= val;" type="text">
                                                                </li>
                                                            
                                                                <li>
                                                                    <input name="component_06" value="VIN:" type="hidden">
                                                                    <input readonly="readonly" class="inputBorder" name="component_06" id="component_06" value="VIN:" style="width:360px;display:block;padding:5px 0; " onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" size="35" maxlength="35" onfocus="var val=this.value; this.value=''; this.value= val;" type="text">
                                                                </li>
                                                            
                                                                <li>
                                                                    <input name="component_07" value="RO#:" type="hidden">
                                                                    <input readonly="readonly" class="inputBorder" name="component_07" id="component_07" value="RO#:" style="width:360px;display:block;padding:5px 0; " onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" size="35" maxlength="35" onfocus="var val=this.value; this.value=''; this.value= val;" type="text">
                                                                </li>
                                                            
                                                        </ul>
                                                    
                                                <p></p> 
                                                <span class="edit-icon-10">
                                                    <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editTextCustomer('component')" id="editButton0">
                                                    <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditCustomer('component', 250)" id="okButton0" style="display: none;">
                                                </span>      
                                            				 
                                        </div>											
                                    </div>						
                                </div>
                            </div>

                            <div class="clear"></div>
                            
                            <!--Checked-Future-Immediate-->
                            <div class="selTable">
                                <div style="padding:15px 25px;">
	
                                    
                                    <span class="circleSuare">
                                    <input name="imgType" value="circle" type="radio"> Circle
                                    </span>
                                    <span class="circleSuare">
                                        <input name="imgType" value="square" checked="" type="radio"> Square
                                    </span>
                                </div>
                                    
                                <div class="selRow">
                                    <div class="selCol selCol3" style="margin-right:25px;">
                                        <div class="selCell">														
                                            <span><b class="green"></b></span>
                                            <span class="floatLeft">
                                                <span id="divTxt_lights">
                                                    <span class="inspectionTxt4 leftAlignTxt width4">
                                                        <input name="componentId1" value="6895145" type="hidden">
                                                        <input readonly="readonly" class="inputBorder" name="component1" id="component1" value="CHECKED AND OK" onkeypress="return limitOfCharForMandatory(event,this.id,20)" size="25" maxlength="20" onblur="removeEditMandatory('component1',20)" type="text">
                                                    </span>
                                                </span>    
                                                <span style="float: right;" class="handSymbol">
                                                    <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component1')" id="editButton1">
                                                    <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component1',20)" id="okButton1" style="display: none;">
                                                </span>        
                                            </span>
                                        </div>
                                    </div>

                                    <div class="selCol selCol3" style="margin-right:40px;">
                                        <div class="selCell">								
                                            <span><b class="yellow"></b></span>
                                            <span class="floatLeft">
                                                <span id="divTxt_lights">
                                                    <span class="inspectionTxt4 leftAlignTxt width4">
                                                        <input name="componentId2" value="6895584" type="hidden">
                                                        <input readonly="readonly" class="inputBorder" name="component2" id="component2" value="FUTURE ATTENTION" onkeypress="return limitOfCharForMandatory(event,this.id,20)" size="25" maxlength="20" onblur="removeEditMandatory('component2',20)" type="text">
                                                    </span>
                                                </span>    
                                                <span style="float: right;" class="handSymbol">
                                                    <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component2')" id="editButton2">
                                                    <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component2',20)" id="okButton2" style="display: none;">
                                                </span>        
                                            </span>
                                        </div>
                                    </div>
                                    <div class="selCol selCol3" style="margin-right:0px;">
                                        <div class="selCell">
                                            <span><b class="red"></b></span>
                                            <span class="floatLeft">
                                                <span id="divTxt_lights">
                                                    <span class="inspectionTxt4 leftAlignTxt width4">
                                                        <input name="componentId3" value="6895478" type="hidden">
                                                        <input readonly="readonly" class="inputBorder" name="component3" id="component3" value="IMMEDIATE ATTENTION" onkeypress="return limitOfCharForMandatory(event,this.id,20)" size="25" maxlength="20" onblur="removeEditMandatory('component3',20)" type="text">
                                                    </span>
                                                </span>    
                                                <span style="float: right;" class="handSymbol">
                                                    <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component3')" id="editButton3">
                                                    <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component3',20)" id="okButton3" style="display: none;">
                                                </span>        
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="clear"></div>

                                        <div class="divTable1 paddingLeft" style="padding-left: 0;">
                                            <div class="inspectionleftwrap">
                                                <div class="inspection_bg">
                                                   <!--Car-->
                                                   <div class="inspectionTable">

                                                       <div class="clear row1 row1Title greyBg">
                                                           <span align="center" class="th">
                                                               <input name="componentId4" value="6895257" type="hidden">
                                                               <input readonly="readonly" class="inputBorder componentHeader" name="component4" id="component4" value="INTERIOR/EXTERIOR" onkeypress="return limitOfCharForMandatory(event,this.id, 40)" maxlength="30" size="40" onblur="removeEditMandatory('component4', 40)" type="text">
                                                           </span>
                                                           <span class="EditBtnNew handSymbol" style="float: right;">
                                                               <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component4')" id="editButton4">
                                                               <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component4',40)" id="okButton4" style="display: none;">
                                                           </span>
                                                       </div>

                                                       <div class="clear row1" style="text-align:center;padding:3px;">
                                                           <span class="smallheading" style="float:left; width:150px;display:block; text-align:center; margin-left:105px;">
                                                               <input name="componentId5" value="6895581" type="hidden">
                                                               <input readonly="readonly" class="inputBorder" name="component5" id="component5" value="NOTE ANY EXISTING BODY DAMAGE" onkeypress="return limitOfCharForMandatory(event,this.id, 40)" size="40" onblur="removeEditMandatory('component5', 40)" style="width: 200px;" type="text">
                                                           </span>
                                                           <span class="EditBtnNew handSymbol" style="float: right; right: 22px; top: 0;">
                                                               <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component5')" id="editButton5">
                                                               <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component5',40)" id="okButton5" style="display: none;">
                                                           </span>
                                                       </div>               
                                                       <input name="componentId70" value="6895695" type="hidden">               
                                                       <div class="clear row1" id="img">
                                                           <div id="imgLeft" class="imgLeft" style="height:210px;margin-top:12px;" align="center">
                                                               <span class="alignCenter" style="display:block; height:210px;margin-top:12px;">
                                                                   <img src="{{URL::asset('mighty/images/car_3view.png')}}" alt=" " style="max-height: 192px;max-width:244px;">
                                                               </span>
                                                           </div>
                                                           <div id="text" style="width:375px; text-align:center; top:0px;left:0px;">
                                                               <a href="javascript:void(0);" id="leftImageClick" onclick="centerImageSelectionPop('left',244,192); return false;">Change Image</a>[244 x 192]
                                                           </div>
                                                       </div>

                                                       
                                                           <div class="clear row1">
                                                               
                                                                   <span class="inspectionTxt4 leftAlignTxt">
                                                                       <input name="componentId6" value="6895586" type="hidden">
                                                                       <input readonly="readonly" class="inputBorder" name="component6" id="component6" value="Lights" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component6', 35)" type="text">
                                                                   </span>
                                                                   <span class="EditBtnNew handSymbol">
                                                                       <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component6')" id="editButton6">
                                                                       <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component6',40)" id="okButton6" style="display: none;">
                                                                   </span>
                                                               
                                                               <span class="floatRightTxt">
                                                                   <b class="green">&nbsp;</b>
                                                                   <b class="yellow">&nbsp;</b>
                                                                   <b class="red">&nbsp;</b>
                                                               </span>
                                                           </div>
                                                       
                                                           <div class="clear row1">
                                                               
                                                                   <span class="inspectionTxt4 leftAlignTxt">
                                                                       <input name="componentId7" value="6895585" type="hidden">
                                                                       <input readonly="readonly" class="inputBorder" name="component7" id="component7" value="Windshield / Glass" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component7', 35)" type="text">
                                                                   </span>
                                                                   <span class="EditBtnNew handSymbol">
                                                                       <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component7')" id="editButton7">
                                                                       <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component7',40)" id="okButton7" style="display: none;">
                                                                   </span>
                                                               
                                                               <span class="floatRightTxt">
                                                                   <b class="green">&nbsp;</b>
                                                                   <b class="yellow">&nbsp;</b>
                                                                   <b class="red">&nbsp;</b>
                                                               </span>
                                                           </div>
                                                       
                                                           <div class="clear row1">
                                                               
                                                                   <span class="inspectionTxt4 leftAlignTxt">
                                                                       <input name="componentId8" value="6895362" type="hidden">
                                                                       <input readonly="readonly" class="inputBorder" name="component8" id="component8" value="Wipers" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component8', 35)" type="text">
                                                                   </span>
                                                                   <span class="EditBtnNew handSymbol">
                                                                       <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component8')" id="editButton8">
                                                                       <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component8',40)" id="okButton8" style="display: none;">
                                                                   </span>
                                                               
                                                               <span class="floatRightTxt">
                                                                   <b class="green">&nbsp;</b>
                                                                   <b class="yellow">&nbsp;</b>
                                                                   <b class="red">&nbsp;</b>
                                                               </span>
                                                           </div>
                                                       
                                                           <div class="clear row1">
                                                               
                                                                   <span class="inspectionTxt4 leftAlignTxt">
                                                                       <input name="componentId9" value="6895583" type="hidden">
                                                                       <input readonly="readonly" class="inputBorder" name="component9" id="component9" value="Horn / Interior Lights" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component9', 35)" type="text">
                                                                   </span>
                                                                   <span class="EditBtnNew handSymbol">
                                                                       <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component9')" id="editButton9">
                                                                       <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component9',40)" id="okButton9" style="display: none;">
                                                                   </span>
                                                               
                                                               <span class="floatRightTxt">
                                                                   <b class="green">&nbsp;</b>
                                                                   <b class="yellow">&nbsp;</b>
                                                                   <b class="red">&nbsp;</b>
                                                               </span>
                                                           </div>
                                                        
                                                   </div> 
                                                   
                                                    <!--Underhood-->        
                                        <div class="inspectionTable">
                                            <div class="clear row1 row1Title greyBg">
                                                
                                                    <span align="center" class="th">
                                                        <input name="componentId10" value="6895143" type="hidden">
                                                        <input readonly="readonly" class="inputBorder" name="component10" id="component10" value="UNDERHOOD" onkeypress="return limitOfCharForMandatory(event,this.id,35)" size="29" maxlength="35" onblur="removeEditMandatory('component10', 35)" type="text">
                                                    </span>
                                                    <span class="EditBtnNew handSymbol" style="float: right;">
                                                        <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component10')" id="editButton10">
                                                        <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component10',40)" id="okButton10" style="display: none;">
                                                    </span>
                                                
                                            </div>

                                            
                                                <div class="clear row1">
                                                    
                                                        <span class="inspectionTxt4 leftAlignTxt">
                                                            <input name="componentId11" value="6895474" type="hidden">
                                                            <input readonly="readonly" class="inputBorder" name="component11" id="component11" value="Oil Condition" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component11', 35)" style="width: 255px !important;" type="text">
                                                        </span>
                                                        <span class="EditBtnNew handSymbol">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component11')" id="editButton11">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component11',40)" id="okButton11" style="display: none;">
                                                        </span>
                                                    
                                                    <span class="floatRightTxt">
                                                        <b class="green">&nbsp;</b>
                                                        <b class="yellow">&nbsp;</b>
                                                        <b class="red">&nbsp;</b>
                                                    </span>
                                                </div>

                                            
                                                <div class="clear row1">
                                                    
                                                        <span class="inspectionTxt4 leftAlignTxt">
                                                            <input name="componentId12" value="6895036" type="hidden">
                                                            <input readonly="readonly" class="inputBorder" name="component12" id="component12" value="Transmission Fluid" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component12', 35)" style="width: 255px !important;" type="text">
                                                        </span>
                                                        <span class="EditBtnNew handSymbol">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component12')" id="editButton12">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component12',40)" id="okButton12" style="display: none;">
                                                        </span>
                                                    
                                                    <span class="floatRightTxt">
                                                        <b class="green">&nbsp;</b>
                                                        <b class="yellow">&nbsp;</b>
                                                        <b class="red">&nbsp;</b>
                                                    </span>
                                                </div>

                                            
                                                <div class="clear row1">
                                                    
                                                        <span class="inspectionTxt4 leftAlignTxt">
                                                            <input name="componentId13" value="6895031" type="hidden">
                                                            <input readonly="readonly" class="inputBorder" name="component13" id="component13" value="Power Steering / Brake Fluid" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component13', 35)" style="width: 255px !important;" type="text">
                                                        </span>
                                                        <span class="EditBtnNew handSymbol">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component13')" id="editButton13">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component13',40)" id="okButton13" style="display: none;">
                                                        </span>
                                                    
                                                    <span class="floatRightTxt">
                                                        <b class="green">&nbsp;</b>
                                                        <b class="yellow">&nbsp;</b>
                                                        <b class="red">&nbsp;</b>
                                                    </span>
                                                </div>

                                            
                                                <div class="clear row1">
                                                    
                                                        <span class="inspectionTxt4 leftAlignTxt">
                                                            <input name="componentId14" value="6895250" type="hidden">
                                                            <input readonly="readonly" class="inputBorder" name="component14" id="component14" value="Coolant / Antifreeze" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component14', 35)" style="width: 255px !important;" type="text">
                                                        </span>
                                                        <span class="EditBtnNew handSymbol">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component14')" id="editButton14">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component14',40)" id="okButton14" style="display: none;">
                                                        </span>
                                                    
                                                    <span class="floatRightTxt">
                                                        <b class="green">&nbsp;</b>
                                                        <b class="yellow">&nbsp;</b>
                                                        <b class="red">&nbsp;</b>
                                                    </span>
                                                </div>

                                            
                                                <div class="clear row1">
                                                    
                                                        <span class="inspectionTxt4 leftAlignTxt">
                                                            <input name="componentId15" value="6895697" type="hidden">
                                                            <input readonly="readonly" class="inputBorder" name="component15" id="component15" value="Air Filter" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component15', 35)" style="width: 255px !important;" type="text">
                                                        </span>
                                                        <span class="EditBtnNew handSymbol">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component15')" id="editButton15">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component15',40)" id="okButton15" style="display: none;">
                                                        </span>
                                                    
                                                    <span class="floatRightTxt">
                                                        <b class="green">&nbsp;</b>
                                                        <b class="yellow">&nbsp;</b>
                                                        <b class="red">&nbsp;</b>
                                                    </span>
                                                </div>

                                            
                                                <div class="clear row1">
                                                    
                                                        <span class="inspectionTxt4 leftAlignTxt">
                                                            <input name="componentId16" value="6895037" type="hidden">
                                                            <input readonly="readonly" class="inputBorder" name="component16" id="component16" value="Cabin Filter" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component16', 35)" style="width: 255px !important;" type="text">
                                                        </span>
                                                        <span class="EditBtnNew handSymbol">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component16')" id="editButton16">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component16',40)" id="okButton16" style="display: none;">
                                                        </span>
                                                    
                                                    <span class="floatRightTxt">
                                                        <b class="green">&nbsp;</b>
                                                        <b class="yellow">&nbsp;</b>
                                                        <b class="red">&nbsp;</b>
                                                    </span>
                                                </div>

                                            
                                                <div class="clear row1">
                                                    
                                                        <span class="inspectionTxt4 leftAlignTxt">
                                                            <input name="componentId17" value="6895804" type="hidden">
                                                            <input readonly="readonly" class="inputBorder" name="component17" id="component17" value="Belts" onkeypress="return limitnofotext(event,this.id,35)" size="29" maxlength="35" onblur="removeEdit('component17', 35)" style="width: 255px !important;" type="text">
                                                        </span>
                                                        <span class="EditBtnNew handSymbol">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component17')" id="editButton17">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component17',40)" id="okButton17" style="display: none;">
                                                        </span>
                                                    
                                                    <span class="floatRightTxt">
                                                        <b class="green">&nbsp;</b>
                                                        <b class="yellow">&nbsp;</b>
                                                        <b class="red">&nbsp;</b>
                                                    </span>
                                                </div>

                                             
                                        </div>           
                                                                       
                                        <!--Under Vehicle-->
                                        <div class="inspectionTable">
                                            <div class="clear row1 row1Title greyBg">
                                                
                                                    <span align="center" class="th">
                                                        <input name="componentId18" value="6895364" type="hidden">
                                                        <input readonly="readonly" class="inputBorder" name="component18" id="component18" value="UNDER VEHICLE" onkeypress="return limitOfCharForMandatory(event,this.id,35)" size="29" maxlength="35" onblur="removeEditMandatory('component18', 35)" type="text">
                                                    </span>
                                                    <span class="EditBtnNew handSymbol" style="float: right;">
                                                        <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component18')" id="editButton18">
                                                        <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component18',40)" id="okButton18" style="display: none;">
                                                    </span>
                                                
                                            </div>

                                            
                                                <div class="clear row1">
                                                    
                                                           <input name="componentId19" value="6895369" type="hidden">
                                                            
                                                                
                                                                    <span class="inspectionTxtNew" style="width: 263px;">
                                                                    <textarea readonly="readonly" rows="2" cols="15" class="inputBorder" id="component19" name="component19" onkeypress="return limitnofotext(event,this.id,60)" style="height:36px; margin-bottom: 6px;width:255px;" maxlength="60">Brake Lines / Brake Hoses /Brake Cables / Fuel Lines</textarea>
                                                                  </span>
                                                                
                                                                
                                                            
                                                        
                                                        <span class="EditBtnNew handSymbol">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component19')" id="editButton19">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component19',40)" id="okButton19" style="display: none;">
                                                        </span>
                                                    
                                                    <span class="floatRightTxt">
                                                        <b class="green">&nbsp;</b>
                                                        <b class="yellow">&nbsp;</b>
                                                        <b class="red">&nbsp;</b>
                                                    </span>
                                                </div>

                                            
                                                <div class="clear row1">
                                                    
                                                           <input name="componentId20" value="6895142" type="hidden">
                                                            
                                                                
                                                                
                                                                    <span class="inspectionTxt4 leftAlignTxt">
                                                                    <input readonly="readonly" class="inputBorder" name="component20" id="component20" value="Suspension &amp; Steering" onkeypress="return limitnofotext(event,this.id,50)" size="50" maxlength="50" onblur="removeEdit('component20', 50)" type="text">
                                                                    </span>
                                                                
                                                            
                                                        
                                                        <span class="EditBtnNew handSymbol">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component20')" id="editButton20">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component20',40)" id="okButton20" style="display: none;">
                                                        </span>
                                                    
                                                    <span class="floatRightTxt">
                                                        <b class="green">&nbsp;</b>
                                                        <b class="yellow">&nbsp;</b>
                                                        <b class="red">&nbsp;</b>
                                                    </span>
                                                </div>

                                            
                                                <div class="clear row1">
                                                    
                                                           <input name="componentId21" value="6895476" type="hidden">
                                                            
                                                                
                                                                
                                                                    <span class="inspectionTxt4 leftAlignTxt">
                                                                    <input readonly="readonly" class="inputBorder" name="component21" id="component21" value="Driveline (Axles / CV Shaft)" onkeypress="return limitnofotext(event,this.id,50)" size="50" maxlength="50" onblur="removeEdit('component21', 50)" type="text">
                                                                    </span>
                                                                
                                                            
                                                        
                                                        <span class="EditBtnNew handSymbol">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component21')" id="editButton21">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component21',40)" id="okButton21" style="display: none;">
                                                        </span>
                                                    
                                                    <span class="floatRightTxt">
                                                        <b class="green">&nbsp;</b>
                                                        <b class="yellow">&nbsp;</b>
                                                        <b class="red">&nbsp;</b>
                                                    </span>
                                                </div>

                                            
                                                <div class="clear row1">
                                                    
                                                           <input name="componentId22" value="6895470" type="hidden">
                                                            
                                                                
                                                                
                                                                    <span class="inspectionTxt4 leftAlignTxt">
                                                                    <input readonly="readonly" class="inputBorder" name="component22" id="component22" value="Rear Differential Fluid Level &amp; Condition" onkeypress="return limitnofotext(event,this.id,50)" size="50" maxlength="50" onblur="removeEdit('component22', 50)" type="text">
                                                                    </span>
                                                                
                                                            
                                                        
                                                        <span class="EditBtnNew handSymbol">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component22')" id="editButton22">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component22',40)" id="okButton22" style="display: none;">
                                                        </span>
                                                    
                                                    <span class="floatRightTxt">
                                                        <b class="green">&nbsp;</b>
                                                        <b class="yellow">&nbsp;</b>
                                                        <b class="red">&nbsp;</b>
                                                    </span>
                                                </div>

                                            
                                                <div class="clear row1">
                                                    
                                                           <input name="componentId23" value="6895035" type="hidden">
                                                            
                                                                
                                                                
                                                                    <span class="inspectionTxt4 leftAlignTxt">
                                                                    <input readonly="readonly" class="inputBorder" name="component23" id="component23" value="Exhaust System / Shocks &amp; Struts" onkeypress="return limitnofotext(event,this.id,50)" size="50" maxlength="50" onblur="removeEdit('component23', 50)" type="text">
                                                                    </span>
                                                                
                                                            
                                                        
                                                        <span class="EditBtnNew handSymbol">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component23')" id="editButton23">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component23',40)" id="okButton23" style="display: none;">
                                                        </span>
                                                    
                                                    <span class="floatRightTxt">
                                                        <b class="green">&nbsp;</b>
                                                        <b class="yellow">&nbsp;</b>
                                                        <b class="red">&nbsp;</b>
                                                    </span>
                                                </div>

                                             
                                        </div>                               
                                        <div class="clear"></div>                               
                                        </div>
                                </div>                               
                                
                                                               
                                                               
                                                               
                                <div class="inspectionrightwrap">
                                    <div class="inspection_bg">

                                    <!--Tires-->
                                        <div class="inspectionTable" id="tiresBlock" style="border-bottom:1px solid #000;">
                                            <div class="clear row1Title greyBg rightHeadings">
                                                
                                                    <span align="center" class="th">
                                                        <input name="componentId24" value="6895691" type="hidden">
                                                        <input readonly="readonly" class="inputBorder componentHeader" name="component24" id="component24" value="TIRES" onkeypress="return limitOfCharForMandatory(event, this.id, 40)" size="40" maxlength="40" type="text">
                                                    </span>
                                                    <span class="EditBtnNew handSymbol">
                                                        <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editMultipleText(24, 53)" id="editButton24">
                                                        <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeMultipleEdit(24, 53)" id="okButton24" style="display: none;">
                                                    </span>
                                                
                                            </div>

                                            <div class="clear row1" style="border-bottom:0px;">
                                                <div style="padding:0px; border:0px;height:100px">
                                                    <div class="bordernone interior_inspec">
                                                        <div class="alignCenter clear paddingBottom" style="width:360px;">
                                                            
                                                                <span class="inspectionTxtNew" style="top:0px; width: 380px;">
                                                                <h2 class="noInspec">
                                                                    <input name="componentId25" value="6895259" type="hidden">
                                                                    <input readonly="readonly" class="inputBorder" style="text-align: center; font-family: 'MyriadProBold';" name="component25" id="component25" value="TREAD DEPTH" onkeypress="return limitnofotext(event, this.id, 50)" size="40" maxlength="50" type="text">
                                                                </h2>
                                                            </span>
                                                            
                                                        </div>


                                                        <div class="clear paddingBottom" style="width:385px; height:28px; padding-bottom: 2px;">
                                                            
                                                                <span style="width:139px; float:left;"><b class="green"></b>

                                                                    <span class="fontF4 ">
                                                                        <input name="componentId26" value="6895368" type="hidden"> 
                                                                        <input readonly="readonly" class="inputBorder" name="component26" id="component26" value="7/32&quot; or greater" onkeypress="return limitnofotext(event, this.id, 17)" size="15" maxlength="17" style="width:107px; font-family: 'MyriadProBold'; font-size: 10pt !important;" type="text">
                                                                    </span>

                                                                </span>
                                                            
                                                            
                                                                <span style="width:124px; float:left;"><b class="yellow"></b>
                                                                    <span class="fontF4 ">
                                                                        <input name="componentId27" value="6895800" type="hidden"> 
                                                                        <input readonly="readonly" class="inputBorder" name="component27" id="component27" value="3/32&quot; to 6/32&quot;" onkeypress="return limitnofotext(event, this.id, 16)" size="15" maxlength="16" style="width:90px; font-size: 10pt !important;" type="text">
                                                                    </span>
                                                                </span>
                                                            
                                                            
                                                                <span style="width:119px; float:left;"><b class="red"></b>
                                                                    <span class="fontF4 ">
                                                                        <input name="componentId28" value="6895149" type="hidden"> 
                                                                        <input readonly="readonly" class="inputBorder" name="component28" id="component28" value="2/32&quot; or less" onkeypress="return limitnofotext(event, this.id, 16)" size="15" maxlength="16" style="width:88px;font-family: 'MyriadProBold';font-size: 11pt;font-weight: normal;font-style: oblique; font-size: 10pt !important;" type="text">
                                                                    </span>
                                                                </span>
                                                            

                                                        </div>



                                                        <div class="clear">
                                                            <div class="alignCenter" style="width:375px;">
                                                                <div class="bordernone interior_inspec interior_inspecLeft" style="width: 155px;">
                                                                    <span class="txt_bold" style="float:left;margin-right:4px;width:18px;">
                                                                        
                                                                            
                                                                                <strong>

                                                                                    <input name="componentId29" value="6895251" type="hidden"> 
                                                                                    <input readonly="readonly" class="inputBorder tireComponentHeader" name="component29" id="component29" value="LF" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" style="width: 19px;" type="text">

                                                                                </strong>
                                                                            
                                                                            
                                                                        
                                                                    </span>
                                                                    
                                                                        <span style="width: 73px; float:left;"><b class="smallGreen" style="width:20px; height:20px;"></b><b class="smallYellow" style="width:20px; height:20px;"></b><b class="smallRed" style="width:20px; height:20px;"></b></span>
                                                                        <span class="txt_bold" style="float:left;">
                                                                            <strong>

                                                                                <input name="componentId30" value="6895366" type="hidden"> 
                                                                                <input readonly="readonly" class="inputBorder tireComponentHeader" name="component30" id="component30" value="____/32" onkeypress="return limitnofotext(event, this.id, 10)" size="10" maxlength="10" style="width:58px;" type="text">

                                                                            </strong>
                                                                        </span>
                                                                    

                                                                </div>
                                                                <div class="bordernone interior_inspec interior_inspecRight" style="width: 155px;">
                                                                    <span class="txt_bold" style="float:left;margin-right:4px;width:18px;">
                                                                        
                                                                            
                                                                                <strong>

                                                                                    <input name="componentId31" value="6895473" type="hidden"> 
                                                                                    <input readonly="readonly" class="inputBorder tireComponentHeader" name="component31" id="component31" value="RF" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" style="width: 20px;" type="text">

                                                                                </strong>   
                                                                            
                                                                            
                                                                        
                                                                    </span>
                                                                    
                                                                        <span style="width: 73px; float:left;"><b class="smallGreen" style="width:20px; height:20px;"></b><b class="smallYellow" style="width:20px; height:20px;"></b><b class="smallRed" style="width:20px; height:20px;"></b></span>
                                                                        <span class="txt_bold" style="float:left;">
                                                                            <strong>

                                                                                <input name="componentId32" value="6895699" type="hidden"> 
                                                                                <input readonly="readonly" class="inputBorder tireComponentHeader" name="component32" id="component32" value="____/32" onkeypress="return limitnofotext(event, this.id,10)" size="10" maxlength="10" style="width:58px;" type="text">

                                                                            </strong>
                                                                        </span>
                                                                    
                                                                </div>

                                                                <div class="bordernone interior_inspec interior_inspecLeft" style="width: 155px;">

                                                                    <span class="txt_bold" style="float:left;margin-right:4px;width:18px;">
                                                                        
                                                                            
                                                                                <strong>

                                                                                    <input name="componentId33" value="6895802" type="hidden"> 
                                                                                    <input readonly="readonly" class="inputBorder tireComponentHeader" name="component33" id="component33" value="LR" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" type="text">

                                                                                </strong>
                                                                            
                                                                            
                                                                        
                                                                    </span>
                                                                    
                                                                        <span style="width: 73px; float:left;"><b class="smallGreen" style="width:20px; height:20px;"></b><b class="smallYellow" style="width:20px; height:20px;"></b><b class="smallRed" style="width:20px; height:20px;"></b></span>
                                                                        <span class="txt_bold" style="float:left;">
                                                                            <strong>

                                                                                <input name="componentId34" value="6895582" type="hidden"> 
                                                                                <input readonly="readonly" class="inputBorder tireComponentHeader" name="component34" id="component34" value="____/32" onkeypress="return limitnofotext(event, this.id, 10)" size="10" maxlength="10" style="width:58px;" type="text">

                                                                            </strong>
                                                                        </span>
                                                                    

                                                                </div>
                                                                <div class="bordernone interior_inspec interior_inspecRight" style="width: 155px;">
                                                                    <span class="txt_bold" style="float:left;margin-right:4px;width:18px;">
                                                                        
                                                                            
                                                                                <strong>

                                                                                    <input name="componentId35" value="6895252" type="hidden"> 
                                                                                    <input readonly="readonly" class="inputBorder tireComponentHeader" name="component35" id="component35" value="RR" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" style="width: 20px;" type="text">

                                                                                </strong>
                                                                            
                                                                            
                                                                        
                                                                    </span>
                                                                    
                                                                        <span style="width: 73px; float:left;"><b class="smallGreen" style="width:20px; height:20px;"></b><b class="smallYellow" style="width:20px; height:20px;"></b><b class="smallRed" style="width:20px; height:20px;"></b></span>
                                                                        <span class="txt_bold" style="float:left;">
                                                                            <strong>

                                                                                <input name="componentId36" value="6895148" type="hidden"> 
                                                                                <input readonly="readonly" class="inputBorder tireComponentHeader" name="component36" id="component36" value="____/32" onkeypress="return limitnofotext(event, this.id, 10)" size="10" maxlength="10" style="width:58px;" type="text">

                                                                            </strong>
                                                                        </span>
                                                                    
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div></div>
                                            </div>

                                            <div style="min-height:235px; border-top: 2px solid #000;">
                                                <input name="componentId71" value="6895801" type="hidden">
                                                <div style="float:left; width:200px;">
                                                    <div style="padding:0px;width:100px;float:left;">
                                                        <div id="imgBottomRight" class="imgBottomRight" style="float: right;/*margin-top: -27%;*/width:99px;height:200px;" align="center">
                                                            <img id="image" src="{{URL::asset('mighty/images/lbi1411133389282.JPG')}}" alt=" " style="max-width: 100px;max-height: 170px;">
                                                        </div>  
                                                        <a href="javascript:void(0);" id="bottomRightImageClick" onclick="centerImageSelectionPop('bottemRight', 100, 170);
                                                                                    return false;" style="display:inline;margin-top:10px; margin-left: 3px;">Change Image</a><br>
                                                                                                            <span style="margin-left: 3px">[100 x 170]</span>
                                                    </div>

                                                    <div class="bordernone interior_inspec padding_reset lessWidth" style="padding:0px;float:right; padding-top:15px;width:100px !important;">
                                                        <div style="height:30px; margin-bottom:10px;">
                                                            
                                                                <h2 class="titleFont" style="text-align:center;">

                                                                    <input name="componentId37" value="6895255" type="hidden">
                                                                    <textarea readonly="readonly" rows="3" cols="12" class="inputBorder tireComponentHeader" name="component37" id="component37" onkeypress="return limitnofotext(event, this.id, 39)" style="width:94px;height: 55px;font-style: italic;" maxlength="25">Wear Pattern/ Damage</textarea>   


                                                                </h2>
                                                            
                                                        </div>
                                                        
                                                            <div class="clear" style="height:20px;margin-bottom:10px;">
                                                                <span class="txt_bold txtLeft" style="width:18px;"> <strong>

                                                                        <input name="componentId38" value="6895147" type="hidden">
                                                                        <input readonly="readonly" class="inputBorder tireComponentHeader" name="component38" id="component38" value="LF" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" style="width: 19px;" type="text">

                                                                    </strong></span>
                                                                <span width="284"><b class="smallGreen" style="width:20px; height:20px;"></b><b class="smallYellow" style="width:20px; height:20px;"></b><b class="smallRed" style="width:20px; height:20px;"></b></span>
                                                            </div>
                                                        


                                                        
                                                            <div class="clear" style="height:20px;margin-bottom:10px;">
                                                                <span class="txt_bold txtLeft" style="width:18px;"><strong>

                                                                        <input name="componentId39" value="6895258" type="hidden">
                                                                        <input readonly="readonly" class="inputBorder tireComponentHeader" name="component39" id="component39" value="RF" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" style="" type="text">

                                                                </strong></span>
                                                                <span><b class="smallGreen" style="width:20px; height:20px;"></b><b class="smallYellow" style="width:20px; height:20px;"></b><b class="smallRed" style="width:20px; height:20px;"></b></span>
                                                            </div>
                                                        

                                                        
                                                            <div class="clear" style="height:20px;margin-bottom:10px;">
                                                                <span class="txt_bold txtLeft" style="width:18px;"><strong>

                                                                        <input name="componentId40" value="6895692" type="hidden">
                                                                        <input readonly="readonly" class="inputBorder tireComponentHeader" name="component40" id="component40" value="LR" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" type="text">

                                                                </strong></span>
                                                                <span><b class="smallGreen" style="width:20px; height:20px;"></b><b class="smallYellow" style="width:20px; height:20px;"></b><b class="smallRed" style="width:20px; height:20px;"></b></span>
                                                            </div>
                                                        
                                                        
                                                            <div class="clear" style="height:20px;margin-bottom:10px;">
                                                                <span class="txt_bold txtLeft" style="width:18px;"><strong>

                                                                        <input name="componentId41" value="6895588" type="hidden">
                                                                        <input readonly="readonly" class="inputBorder tireComponentHeader" name="component41" id="component41" value="RR" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" type="text">

                                                                </strong></span>
                                                                <span><b class="smallGreen" style="width:20px; height:20px;"></b><b class="smallYellow" style="width:20px; height:20px;"></b><b class="smallRed" style="width:20px; height:20px;"></b></span>

                                                            </div>
                                                        
                                                    </div>
                                                </div>
                                                <div class="interior_inspec" style="min-height:230px;border-right: 2px solid #000 !important;border-left: 2px solid #000 !important;padding:0px;width:96px; padding:0 3px; float:left;">
                                                    <div cellspacing="0" class="bordernone padding_reset" style="">
                                                        <div style="text-align:center;margin-top:15px;">
                                                            
                                                                <h2 class="titleFont" style="text-align:center;">

                                                                    <input name="componentId42" value="6895580" type="hidden"> 
                                                                    <textarea readonly="readonly" rows="1" cols="10" class="inputBorder tireComponentHeader" style="width:90px;font-style: italic;" name="component42" id="component42" onkeypress="return limitnofotext(event, this.id, 20)" maxlength="15">Air Pressure</textarea>   
                                                                </h2>
                                                            
                                                        </div>
                                                        <input name="componentId72" value="6895363" type="hidden">
                                                        <div>
                                                            <span style="float:left; width:16px;margin-right:2px; position:relative; top:7px;left:7px;">
                                                                <b class="smallRed"></b>
                                                            </span>
                                                            <input name="componentId72" value="6895363" type="hidden">
                                                            <div style="display:block; float:left;width:40px;margin-left: 27px;">
                                                                <div id="imgBottomMid" class="imgBottomMid" style="width:40px; height:36px;" align="center">
                                                                    <img src="{{URL::asset('mighty/images/iSymbol.png')}}" alt=" " style="max-width: 40px; max-height: 36px;" id="image">
                                                                </div>
                                                                <a href="javascript:void(0);" id="bottomMidImageClick" onclick="centerImageSelectionPop('bottomMid',40,36); return false;" style="display:inline;margin-top:4px;white-space:nowrap;">Change Image</a>
                                                                         <br>
                                                                         <div style="font-size:10px;padding-top: 4px;">[40 x 36]</div>
                                                            </div>     
                                                        </div>

                                                        <div class="bordernone interior_inspec">
                                                            <div class="beforeAfter">
                                                                
                                                                    <span class="beforeTxt">BEFORE</span>
                                                                
                                                                &nbsp;&nbsp;
                                                                
                                                                    <span class="afterTxt">SHOULD BE</span>
                                                                
                                                            </div>
                                                            <div style="width:100%;" class="clear">
                                                                <div style="float:left;width:15px; position: relative; height: 50px;">
                                                                    <span style="position: absolute;top:0px; left: 2px;"><strong>
                                                                            
                                                                                <span class="txt_bold">

                                                                                    <input name="componentId45" value="6895365" type="hidden"> 
                                                                                    <input readonly="readonly" class="inputBorder tireComponentHeader" name="component45" id="component45" value="LF" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" type="text">

                                                                                </span>
                                                                            
                                                                        </strong></span>
                                                                    <span style="position: absolute;top:26px; left: 2px;"><strong>
                                                                            
                                                                                <span class="txt_bold">

                                                                                    <input name="componentId46" value="6895256" type="hidden"> 
                                                                                    <input readonly="readonly" class="inputBorder tireComponentHeader" name="component46" id="component46" value="RF" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" type="text">

                                                                                </span>
                                                                            
                                                                        </strong></span>
                                                                </div>
                                                                <div style="width:30px; float:left;margin-right:3px;">
                                                                    <span class="white_box">&nbsp;</span><br>
                                                                    <span class="white_box">&nbsp;</span></div>&nbsp;
                                                                    
                                                                    <span class="white_box_rectangle">&nbsp;</span>
                                                                
                                                            </div>
                                                            <div style="width:100%;" class="clear">
                                                                <div style="float:left;width:15px; position: relative; height: 50px;">
                                                                    <span style="position: absolute;top:3px; left: 2px;"><strong>
                                                                            
                                                                                <span class="txt_bold">

                                                                                    <input name="componentId47" value="6895690" type="hidden"> 
                                                                                    <input readonly="readonly" class="inputBorder tireComponentHeader" name="component47" id="component47" value="LR" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" type="text">

                                                                                </span>
                                                                            
                                                                        </strong></span> 
                                                                    <span style="position: absolute;top:30px; left: 2px;"><strong>
                                                                            
                                                                                <span class="txt_bold">

                                                                                    <input name="componentId48" value="6895475" type="hidden"> 
                                                                                    <input readonly="readonly" class="inputBorder tireComponentHeader" name="component48" id="component48" value="RR" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" type="text">

                                                                                </span>
                                                                             
                                                                        </strong>
                                                                    </span>
                                                                </div>
                                                                <div style="width:30px; float:left;margin-right:3px;"><span class="white_box">&nbsp;</span><br>
                                                                    <span class="white_box">&nbsp;</span></div>&nbsp;
                                                                    
                                                                    <span class="white_box_rectangle">&nbsp;</span>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="interior_inspec" style="width:74px;float:left; padding:0 3px;">
                                                    <div style="margin-top:15px;">
                                                        
                                                            <span><h2 class="titleFont" style="text-align:center;">

                                                                    <input name="componentId49" value="6895472" type="hidden"> 
                                                                    <textarea readonly="readonly" rows="3" cols="10" class="inputBorder tireComponentHeader" style="margin-left: 3px;width:80px !important;height: 69px;font-style: italic;" name="component49" id="component49" onkeypress="return limitnofotext(event, this.id, 40)" maxlength="40">Based on Mileage and Wear:</textarea>   

                                                            </h2></span>
                                                            
                                                    </div>
                                                    <div class="bordernone interior_inspec">
                                                        
                                                            <div class="clear" style="height:20px;margin-bottom:10px;">
                                                                
                                                                    <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                                                    <span class="txtFont" style="vertical-align:-3px;">

                                                                        <input name="componentId50" value="6895587" type="hidden"> 
                                                                        <input readonly="readonly" class="inputBorder componentHeader" name="component50" id="component50" value="Alignment" onkeypress="return limitnofotext(event, this.id, 20)" size="12" maxlength="10" type="text">
                                                                    </span>
                                                                
                                                            </div>
                                                        
                                                            <div class="clear" style="height:20px;margin-bottom:10px;">
                                                                
                                                                    <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                                                    <span class="txtFont" style="vertical-align:-3px;">

                                                                        <input name="componentId51" value="6895146" type="hidden"> 
                                                                        <input readonly="readonly" class="inputBorder componentHeader" name="component51" id="component51" value="Balance" onkeypress="return limitnofotext(event, this.id, 20)" size="12" maxlength="10" type="text">
                                                                    </span>
                                                                
                                                            </div>
                                                        
                                                            <div class="clear" style="height:20px;margin-bottom:10px;">
                                                                
                                                                    <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                                                    <span class="txtFont" style="vertical-align:-3px;">

                                                                        <input name="componentId52" value="6895140" type="hidden"> 
                                                                        <input readonly="readonly" class="inputBorder componentHeader" name="component52" id="component52" value="Rotation" onkeypress="return limitnofotext(event, this.id, 20)" size="12" maxlength="10" type="text">
                                                                    </span>
                                                                
                                                            </div>
                                                        
                                                            <div class="clear" style="height:20px;margin-bottom:10px;">
                                                                
                                                                    <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                                                    <span class="txtFont" style="vertical-align:-3px;">

                                                                        <input name="componentId53" value="6895360" type="hidden"> 
                                                                        <input readonly="readonly" class="inputBorder componentHeader" name="component53" id="component53" value="New Tire" onkeypress="return limitnofotext(event, this.id, 20)" size="12" maxlength="10" type="text">
                                                                    </span>
                                                                
                                                            </div>
                                                         
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                
                                        <!--   Brakes  -->
                                        <div class="inspectionTable inspectionTableBg" style="border-bottom:1px solid #000; overflow: hidden;">
                                            <div class="clear row1 row1Title greyBg rightHeadings">
                                                
                                                    <span class="txtFont">
                                                        <input name="componentId54" value="6895253" type="hidden"> 
                                                        <input readonly="readonly" class="inputBorder componentHeader" name="component54" id="component54" value="BRAKES" onkeypress="return limitOfCharForMandatory(event, this.id, 40)" size="40" maxlength="30" style="font-family: 'ImpactRegular';font-style: normal; font-size: 11pt !important; width: 120px;" type="text">
                                                    </span> 
                                                    <span class="handSymbol">
                                                        <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editMultipleText(54, 64)" id="editButton54">
                                                        <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeMultipleEdit(54, 64)" id="okButton54" style="display: none;">
                                                    </span>   
                                                           
                                            </div>
                                            <div class="clear alignCenter paddingBottom" style="width: 389px; margin-left: 0px;margin-top:2px; padding-bottom: 2px;">
                                                              
                                                    <span><h2 class="noInspec">
                                                            <input name="componentId55" value="6895803" type="hidden"> 
                                                            <input readonly="readonly" class="inputBorder componentHeader" name="component55" id="component55" value="BRAKE PADS / SHOES" onkeypress="return limitOfCharForMandatory(event, this.id, 40)" size="40" maxlength="30" style="font-family: 'MyriadProBold';font-style: normal; font-size: 11pt !important; width: 380px; text-align: center;font-weight: normal;" type="text">
                                                        </h2></span>
                                                
                                            </div>
                                            
                                            <div class="clear row1" style="border-bottom:0px; width: 190px; float: left;margin-left: 20px;">
                                                <div style="padding:0px; border:0px;height:130px">
                                                    <div class="bordernone interior_inspec">
                                                        <div class="clear paddingBottom" style="width:200px; height:30px;">
                                                            
                                                                <span class="clear" style="display:block;margin-bottom:5px;"><b class="green"></b>
                                                                    <span class="fontF4 fontF49" style="display:block; width:160px; float:left;word-wrap: break-word;">
                                                                        
                                                                        <span class="txtFont">
                                                                            <input name="componentId56" value="6895698" type="hidden"> 
                                                                            <textarea readonly="readonly" rows="2" cols="15" class="inputBorder" id="component56" name="component56" onkeypress="return limitnofotext(event, this.id, 39)" style="height:30px;line-height: 16px; margin-bottom: 10px;width:150px;" maxlength="36">Over 5 mm (Disc) or 2 mm (Drum)</textarea>
                                                                        </span>
                                                    
                                                                    </span>
                                                                </span>
                                                            	
                                                            
                                                                <span class="clear" style="display:block;margin-bottom:5px;"><b class="yellow"></b>
                                                                    <span class="fontF4 fontF49" style="display:block; width:160px; float:left;word-wrap: break-word;"> 
                                                                        
                                                                        <span class="txtFont">
                                                                            <input name="componentId57" value="6895032" type="hidden"> 
                                                                            <textarea readonly="readonly" rows="2" cols="15" class="inputBorder" id="component57" name="component57" onkeypress="return limitnofotext(event, this.id, 39)" style="height:30px;line-height: 16px; margin-bottom: 10px;width:150px;" maxlength="36">3-5 mm (Disc) or 1.01-2 mm(Drum)</textarea>
                                                                        </span>
                                                                        
                                                                        
                                                                    </span>
                                                                </span>
                                                            
                                                            	
                                                                <span class="clear" style="display:block;margin-bottom:5px;"><b class="red"></b>
                                                                    <span class="fontF4 fontF49" style="display:block; width:160px; float:left;word-wrap: break-word;">
                                                                        
                                                                        <span class="txtFont">
                                                                            <input name="componentId58" value="6895361" type="hidden"> 
                                                                            <textarea readonly="readonly" rows="2" cols="15" class="inputBorder" id="component58" name="component58" onkeypress="return limitnofotext(event, this.id, 39)" style="height:38px !important; font-family: 'MyriadProRegular' !important; margin-top: -2px;line-height: 16px; width:150px !important;" maxlength="36">Less than 3 mm(Disc) or 1 mm (Drum)</textarea>
                                                                        </span>
                                                                    </span>
                                                                </span>
                                                            

                                                        </div>
                                                        <div class="clear">

                                                        </div>
                                                    </div></div>
                                            </div>
                                            
                                            <div style="  width: 125px; float: right;">

                                                <div class="bordernone interior_inspec padding_reset" style="padding:5px;">
                                                    <div style="height: 90px;">
                                                        
                                                            
                                                                <div class="clear">
                                                                        
                                                                    <span class="txt_bold txtLeft" style="width:18px;"> <strong>
                                                                        <input name="componentId59" value="6895034" type="hidden"> 
                                                                        <input readonly="readonly" class="inputBorder tireComponentHeader" name="component59" id="component59" value="LF" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" type="text">
                                                                    </strong></span>   
                                                                               
                                                                    <span width="284"><b class="smallGreen" style="width:20px; height:20px;"></b><b class="smallYellow" style="width:20px; height:20px;"></b><b class="smallRed" style="width:20px; height:20px;"></b></span>
                                                                </div>
                                                            
                                                        
                                                            
                                                                <div class="clear">
                                                                        
                                                                    <span class="txt_bold txtLeft" style="width:18px;"> <strong>
                                                                        <input name="componentId60" value="6895693" type="hidden"> 
                                                                        <input readonly="readonly" class="inputBorder tireComponentHeader" name="component60" id="component60" value="RF" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" type="text">
                                                                    </strong></span>   
                                                                               
                                                                    <span width="284"><b class="smallGreen" style="width:20px; height:20px;"></b><b class="smallYellow" style="width:20px; height:20px;"></b><b class="smallRed" style="width:20px; height:20px;"></b></span>
                                                                </div>
                                                            
                                                        
                                                            
                                                                <div class="clear">
                                                                        
                                                                    <span class="txt_bold txtLeft" style="width:18px;"> <strong>
                                                                        <input name="componentId61" value="6895479" type="hidden"> 
                                                                        <input readonly="readonly" class="inputBorder tireComponentHeader" name="component61" id="component61" value="LR" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" type="text">
                                                                    </strong></span>   
                                                                               
                                                                    <span width="284"><b class="smallGreen" style="width:20px; height:20px;"></b><b class="smallYellow" style="width:20px; height:20px;"></b><b class="smallRed" style="width:20px; height:20px;"></b></span>
                                                                </div>
                                                            
                                                        
                                                            
                                                                <div class="clear">
                                                                        
                                                                    <span class="txt_bold txtLeft" style="width:18px;"> <strong>
                                                                        <input name="componentId62" value="6895030" type="hidden"> 
                                                                        <input readonly="readonly" class="inputBorder tireComponentHeader" name="component62" id="component62" value="RR" onkeypress="return limitnofotext(event, this.id, 2)" size="2" maxlength="2" type="text">
                                                                    </strong></span>   
                                                                               
                                                                    <span width="284"><b class="smallGreen" style="width:20px; height:20px;"></b><b class="smallYellow" style="width:20px; height:20px;"></b><b class="smallRed" style="width:20px; height:20px;"></b></span>
                                                                </div>
                                                            
                                                         
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="clear" style="width:300px;margin-top:35px;margin-left: 30px;">
                                                
                                                    <span class="fontF4" style="float:left;display:block; width:76px;margin-top:12px;">
                                                        <strong>
                                                            <input name="componentId63" value="6895471" type="hidden"> 
                                                            <input readonly="readonly" class="inputBorder tireComponentHeader" name="component63" id="component63" value="We feature" onkeypress="return limitnofotext(event, this.id, 20)" size="29" style="width:115px;font-style: oblique;" maxlength="12" type="text">
                                                        </strong>
                                                    </span>
                                                
                                                
                                                <input name="componentId73" value="6895589" type="hidden">
                                                <span style="padding:0px;width:150px;float:left;display:block;margin-right:5px;margin-left:5px; text-align: center;">
                                                    <div id="imgBottomLast" class="imgBottomLast" style="float: right;margin-top:10px;width: 150px; text-align: center;" align="center">
                                                        <img src="{{URL::asset('mighty/images/ibrands.png')}}" alt=" " style="margin-left:3px; margin-right:3px;max-width:150px; max-height:45px;" id="image">
                                                    </div>
                                                    <a href="javascript:void(0);" id="bottomLastImageClick" onclick="centerImageSelectionPop('bottomLast', 150, 45);
                                                                return false;" style="display:inline;margin-top:10px;position:relative; top:-4px;">Change Image</a>[150 x 45]
                                                </span>
                                                
                                                
                                                
                                                    <span class="fontF4" style="float:left;display:block; width:64px;margin-top:12px;">
                                                        <strong>
                                                            <input name="componentId64" value="6895696" type="hidden"> 
                                                            <input readonly="readonly" class="inputBorder tireComponentHeader" name="component64" id="component64" value="Brakes" onkeypress="return limitnofotext(event, this.id, 20)" size="29" style="width:115px;font-style: oblique;" maxlength="12" type="text">
                                                        </strong>
                                                    </span>
                                                				   
                                            </div>

                                        </div>

                                        <!-- Battery -->
                                        <div class="inspectionTable">
                                            <div class="clear row1 row1Title greyBg rightHeadings">
                                                
                                                    <span align="center" class="th">
                                                        <input name="componentId65" value="6895038" type="hidden">
                                                        <input readonly="readonly" class="inputBorder componentHeader" name="component65" id="component65" value="BATTERY" onkeypress="return limitOfCharForMandatory(event, this.id, 40)" size="35" maxlength="40" onblur="removeEditMandatory('component65', 40)" style="font-family: 'ImpactRegular';font-style: normal;font-weight: normal;" type="text">
                                                    </span>
                                                    <span class="EditBtnNew handSymbol">
                                                        <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component65')" id="editButton65">
                                                        <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component65', 40)" id="okButton65" style="display: none;">
                                                    </span>
                                                
                                            </div>
                                            <div class="clear row1" style="height: 120px;">
                                                <div style="width:245px; float:left;padding:5px 0;">
                                                    
                                                        <span class="textFont4">
                                                            <input name="componentId66" value="6895367" type="hidden">
                                                            <input readonly="readonly" class="inputBorder" name="component66" id="component66" value="SEE ATTACHED PRINTOUT" onkeypress="return limitOfCharForMandatory(event, this.id, 35)" size="29" maxlength="35" onblur="removeEditMandatory('component66', 35)" style="font-family: 'helvetica';font-style: normal;font-weight: normal; width: 200px !important;" type="text">
                                                        </span>
                                                        <span class="EditBtnNew handSymbol" style="float: right;">
                                                            <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editText('component66')" id="editButton66">
                                                            <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeEditMandatory('component66', 35)" id="okButton66" style="display: none;">
                                                        </span>       
                                                    
                                                    <div style="padding:10px 15px 0 40px;;">
                                                        <span>
                                                            <b class="green"></b>
                                                            <b class="yellow"></b>
                                                            <b class="red"></b>
                                                        </span>
                                                    </div>
                                                </div>
                                                <input name="componentId74" value="6895254" type="hidden">
                                                <div id="img">
                                                    <div id="imgBottomLeft" class="imgBottomLeft" style="width:120px;height:90px; float:left;" align="center">
                                                        <img src="{{URL::asset('mighty/images/lbi1423151263753.JPG')}}" alt=" " style="max-width: 115px;max-height: 90px;"> 
                                                    </div>
                                                    <div id="text" style="top:100px; width: 120px; left: 250px;">
                                                        <a href="javascript:void(0);" id="bottomLeftImageClick" onclick="centerImageSelectionPop('bottemLeft', 115, 90);return false;" style="display:inline;margin-top:10px;">Change Image</a>[115 x 90]
                                                    </div>
                                                </div>
                                             </div>
                                        </div>

                                        <!-- Comments -->            
                                        <div class="inspectionTable" style="margin-bottom: 0px;">
                                            <div class="clear" style="font-family:'MyriadProRegular';font-size: 11pt;height: 1px;margin-left: 8px;padding-top: 5px;">
                                                
                                                    <span id="component67Span" class="comments" style="float: left;width: 335px;">Comments:</span> 
                                                    <span class="th" style="float: left">
                                                        <input name="componentId67" value="6895141" type="hidden">
                                                        <input readonly="readonly" class="inputBorder" name="component67" id="component67" value="Comments:" onkeypress="return limitOfCharForMandatory(event,this.id,35)" size="35" maxlength="35" style="width:335px;display: none;" onblur="removeEditMandatory('component67', 35)" type="text">
                                                    </span>
                                                              <span class="EditBtnNew handSymbol" style="top:0;">
                                                        <img src="{{URL::asset('mighty/images/ieditover.PNG')}}" onclick="editMultipleTextLast(67,69)" id="editButton67" style="float: right;">
                                                        <img src="{{URL::asset('mighty/images/ieditOk.PNG')}}" onclick="removeMultipleEditLast(67,69)" id="okButton67" style="display: none;float: right;">
                                                    </span>            
                                                
                                            </div>
                                            <div class="clear row1" style="height:1px;"></div>
                                            <div class="clear row1" style="height:26px;"></div>
                                            <div class="clear row1" style="height:26px;"></div>
                                        </div>

                                        <div class="bottomtext" style="width: 393px;overflow:hidden;">
                                            <div style="width:400px;margin-top:0px;">
                                               
                                                <div style="float:left;width:279px;overflow:hidden;">
                                                    <span id="cmt" style="float: left;">
                                                        <span id="component68Span" class="comments">Inspected by:</span> 
                                                        <input name="componentId68" value="6895144" type="hidden"> 
                                                        <input readonly="readonly" class="inputBorder" name="component68" id="component68" value="Inspected by:" size="15" style="width: 90px;display: none;" maxlength="15" type="text">
                                                    </span>
                                                    <span style="display:block;overflow:hidden;margin-top: 19px;"><hr class="cmtLine" id="cmtLine2" style="width: 276px;"></span>    
                                                </div> 
                                               
                                                <div style="float:right;width: 120px;">
                                                    <span id="component69Span" class="comments" style="float: left;">Date:</span> 
                                                    <span style="float: left;">
                                                            <input name="componentId69" value="6895477" type="hidden"> 
                                                            <input readonly="readonly" class="inputBorder" name="component69" id="component69" value="Date:" size="15" style="width:40px;display: none;" maxlength="10" type="text">
                                                    </span>
                                                    <span style="display:block;overflow:hidden;margin-top: 19px;"><hr class="cmtLine" id="cmtLine3" style="width: 125px"></span>
                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                </div>                               
                                                                       
                                                                   

                                                    
                                            
                                        </div>
                                        <div class="clear"></div>
                                        <div style="text-align:center;margin-top:10px;padding-bottom:10px;">
                                            <a href="javascript:void(0);" name="save" value="Save" id="update102" onclick="updateTemplate105('./updateUserFormByFormId105.do');">Save</a>
                                            
                                                
                                                
                                                    <a href="./createUserComponentForm105.do" id="cancelBtn" onclick="launchWindow('#dialog');">Cancel</a>
                                                

                                            

                                        </div>
                                        <div class="clear"></div>
                                        <div style="text-align:right;font-family:'MyriadProRegular'; font-size:6pt;padding:0 20px 10px 0;"></div>
                                        </div>
                                        </div>
        </div>
        </section>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3">
               tab3
              </div>
              <div class="tab-pane" id="tab_4">
              tab4
              </div>
              <div class="tab-pane" id="tab_5">
              tab5
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
      </div>
    </section>
   
 
@endsection


@section('customJs')
@endsection
