<?php
header("Content-Type: text/html; charset=utf-8\n");
header("Cache-Control: no-cache, must-revalidate\n");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");

// e-z params
$dim = 150;         /* image displays proportionally within this square dimension ) */
$cols = 4;          /* thumbnails per row */
$thumIndicator = '_th'; /* e.g., *image123_th.jpg*) -> if not using thumbNails then use empty string */
?>
        <!DOCTYPE html>
<html>
<head>
    <title>browse file</title>
    <meta charset="utf-8">

    <style>
        html,
        body {padding:0; margin:0;/* background:black;*/ }
        table {width:100%; border-spacing:15px; }
        td {text-align:center; padding:5px; background:#181818; }
        img {border:5px solid #303030; padding:0; verticle-align: middle;}
        img:hover { border-color:blue; cursor:pointer; }
        .dirimg{
            float: left;
            padding: 20px;
            border: 1px solid #ddd;
            text-align: center;
            width: 136px;
            height: 136px;
            position: relative;
        }
        .dirimgs{
            float: left;
            padding: 6px;
            /* border: 1px solid #ddd;*/
            text-align: center;
            width: 136px;
            height: 102px;
            position: relative;
        }
    </style>

</head>

@php
$dir=public_path().'/mighty/images/template/';
$files1 = scandir($dir);
$files2 = scandir($dir, 1);
@endphp
<body>
<div class="modal-body" style="height: 500px;
    overflow-y: auto;">
    @foreach ($files1 as $key=>$chres)
        @if($key!=0 && $key!=1 && strpos($chres, 'original') !== false)
            <div class="dirimg"  >

                <img style="height: 70px;width:100%;" src="{{URL::asset('mighty/images/template/')}}/{{$chres}}" alt=""  />
                <input type="button" data-val="{{$chres}}" onclick="getImages('{{URL::asset('mighty/images/template/')}}/{{$chres}}');"  class=" btn selectImage" value="Select" />

            </div>
        @endif
    @endforeach
</div>
<script>
    function getImages(a){
        window.opener.CKEDITOR.tools.callFunction( 1, a );
        window.close();
        if (window.opener != null && !window.opener.closed) {
             var txtName = window.opener.document.getElementById("cke_81_textInput");
            txtName.value = a;
            var txtWidth = window.opener.document.getElementById("cke_91_textInput");
            txtWidth.value = "282";
            var txtheight = window.opener.document.getElementById("cke_94_textInput");
            txtheight.value = "200";  // height and width set

        }
        window.close();
    }
</script>
</body>
</html>