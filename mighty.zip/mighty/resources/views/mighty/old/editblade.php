
<?php   
$CI = & get_instance(); 
$CI->load->library('templates');
$datas = json_decode($details->form_content);
?>
<style>
    li.rows{ 
        min-height:80px;
    }
    li.columns{
        float:left; 
        height:75px;
        list-style: none;
    }
    li.highlight{
        min-height: 70px;   
    }
    .content{
        padding-left: 0px !important;
    }
</style>
<script>
//function auto_update_text(type){
                $(document).on("click",'label.title_label', function () {

                    var current = $(this).parent().parent();
                    var txt = $(this).text();
                    $(".title_label",current).replaceWith('<input class="title_labels" value="'+txt+'"/>');
                    $(".info",current).remove();
                });
                $(document).on('click','span.click-edit-icon',function(){
                    var type = $(this).data('type');
                    if(type === 'select' || type === 'radio' || type === 'checkbox'){
                        var current = $(this).parent().parent().parent();
                    }else{
                        var current = $(this).parent().parent();
                    }
                    if($('ul#pages').find('.title_labels')){
                        var input_label = $('ul#pages').find('.title_labels').val();
                        $('ul#pages').find('.title_labels').replaceWith("<label class='title_label'>"+input_label+"</label>");
                    }
                    var txt = $(current).find('.title_label').text();
                    $(".title_label",current).replaceWith('<input class="title_labels" value="'+txt+'"/>');
                });
         //   }
         //   
         
         $(document).on('click','.options-icon',function(){ 
            popupid = $(this).data('popup');
            console.log(popupid);
            $('#'+popupid).dialog("open"); 
        });
function popup_initialize(popupid,current,type,row_id,column_id){
    
            var dialog = $('#'+popupid).dialog({
              title: " OPTIONS",
              height: "auto",
              width: "auto",
              //modal: true,
              autoOpen: false,
              //height: 300,
              buttons: {
                "ok" :function(){
                    var html = '';
                    switch(type){
                            
                        case 'select':
                            var select = '<select id="'+popupid+'_'+row_id+'">';
                            var hidden = '';
                            $('#'+popupid).find('.select_label').each(function(){
                                if($(this).val() != ''){
                                    html += '<option>'+$(this).val()+'</option>';
                                    hidden += '<input type="hidden" class="title_value" data-optionid="0" value="'+$(this).val()+'" />';
                                }
                            })
                            select += html;
                            select +='</select>';
                            select += hidden;
                            break;
                        case 'radio':
                            var select = '';
                            $('#'+popupid).find('.select_label').each(function(){
                                if($(this).val() != ''){
                                    select += '<input type="radio" name="'+popupid+'"/> <span class="title_value" data-optionid="0">'+$(this).val()+'</span>';
                                }
                            })
                            break;
                        case 'checkbox':
                            var select = '';
                            $('#'+popupid).find('.select_label').each(function(){
                                if($(this).val() != ''){
                                    select += '<input type="checkbox"/><span class="title_value" data-optionid="0">'+$(this).val()+'</span>';
                                }
                            })
                            break;
                        case 'date':
                            var select = '';
                                console.log($('#date_formats').val());
                                $('#date_format',current).val($('#date_formats').val());
                            break;  
                        case 'time':
                            var select = '';
                                console.log($('#time_formats').val());
                                $('#time_format',current).val($('#time_formats').val());
                            break;

                    }
                    $('ul#'+row_id+'> #'+column_id).find('.select').empty().append(select);
                    $(this).dialog( "close" );
                },
                Cancel: function() {
                  $(this).dialog( "close" );
                }
              },
            });
            return dialog;
        }


        
        var popup = {
            open_dialog:function(optionid,dialog){
                $('.'+optionid).click(function(){
                    dialog.dialog( "open" );
                });
            },
            options_open:function(dialog){
                    
                    current = dialog.attr('id');
                    var max_fields      = 5; //maximum input boxes allowed
                    var wrapper         = $("#"+current+" element"); //Fields wrapper
                    var add_button      = $(".add_field_button"); //Add button ID
                    var x = 0;
                    //console.log(wrapper);
                    $(wrapper).on("click",'.add_field_button',function(e){ //on add input button click
                         //initlal text box count
                        e.preventDefault();
                        if(x < max_fields){ //max input box allowed
                            x++; //text box increment
                            //$(wrapper).find('.add-option').remove();
                            $(wrapper).append('<p><input type="text" name="mytext[]" class="select_label"/><span class="delete-option remove_field"></span></p>'); //add input box
                        }else{
                            if($(wrapper).find('p.req').size() == 0){
                                $(wrapper).prepend('<p class="req">Limited only for trial version</p>');
                            }
                        }
                        return false;
                    });
                    $(add_button).on("click",function(e){ //on add input button click
                         //initlal text box count
                        e.preventDefault();
                        if(x < max_fields){ //max input box allowed
                            x++; //text box increment
                           // $(wrapper).find('.add-option').remove();
                            $(wrapper).append('<p><input type="text" name="mytext[]" class="select_label"/><span class="delete-option remove_field"></span></p>'); //add input box
                        }else{
                            if($(wrapper).find('p.req').size() == 0){
                                $(wrapper).prepend('<p class="req">Limited only for trial version</p>');
                            }
                        }
                        return false;
                    });
                    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
                        e.preventDefault();
                        if($(wrapper).find('p.req').size() == 1){
                            $(wrapper).find('p.req').remove();
                        }
                        
                        $(this).parent('p').remove(); 

                        x--;
                    });
                    return false;
               // });
            },
            options_close:function(type){
                $(d).on('click','.options_cancel',function(){
                    console.log('here');
                });
            },
        };
</script>
<div id="page_content">
    <div id="page_content_inner">
        <div class="uk-grid" style="display: block;padding-left:0px !important"; data-uk-grid-margin data-uk-grid-match id="wizard_forms">
        <div class="uk-width-large-2-10"  id="sidebar" style="float: left;">
            <div class="uk-width-1-1">
                <div class="parsley-row">
                    <div class="md-card  form-desc ">
                        <label class="fn">Name your form<span class="req">*</span></label>
                        <input type="text" class="md-input fn-field" id="form_name" name="form_name" value="" data-parsley-trigger="change" required value="<?php echo $details->form_name; ?>" />
                        <label class="fd">Short description about your form </label>
                        <textarea name="form_desc"  class="md-input" id="form_desc" style=""><?php echo $details->form_desc; ?></textarea>
                    </div>
                </div>
            </div>
            <div class="md-card dragdrop-panel">
                <div class="md-card-content">
                   <div class="uk-panel">
                        <div class="heading">Drag and drop for build new form</div>
                        <div class="uk-accordion" data-uk-accordion>
                            <h3 class="uk-accordion-title uk-accordion-title-primary">Basic</h3>
                            <div class="uk-accordion-content">
                                <ul id="basic">
                                    <li><div class="singleline-icon" ></div><span value="heading">Heading</span></li>
                                    <li><div class="singleline-icon" ></div><span value="text">Single Line Text</span></li>
                                    <li><div class="email-icon"></div><span value="email">Email</span></li>
                                    <li><div class="multiline-icon"></div><span value="textarea">Multi Line Text</span></li>
                                    <li><div class="multiline-icon"></div><span value="number">Number</span></li>
                                    <li><div class="radio-icon"></div><span value="radio">Radio</span></li>
                                    <li><div class="select-icon"></div><span value="select">Select</span></li>
                                    <li><div class="checkbox-icon"></div><span value="checkbox">Checkbox</span></li>
                                    <li><div class="date-icon"></div><span value="date">Date</span></li>
                                    <li><div class="time-icon"></div><span value="time">Time</span></li>
                                    <li><div class="file-icon"></div><span value="file">File</span></li>
                                    <!--<li><span value="reset">Reset</span></li>
                                    <li><span value="submit">Submit</span></li>-->
                                </ul>
                            </div>
                            <!--<h3 class="uk-accordion-title uk-accordion-title-primary">Group</h3>
                            <div class="uk-accordion-content">
                                <ul id="group">
                                    <li><span value="name">Name</span></li>
                                    <li><span value="address">Address</span></li>
                                </ul>
                            </div>-->
                            <h3 class="uk-accordion-title uk-accordion-title-primary">Advanced</h3>
                            <div class="uk-accordion-content">
                                <ul id="advanced">
                                    <li><div class="sign-icon"></div><span value="signature">Signature</span></li>
                                    <!--<li>
                                        <span value="placepicker">Place Picker</span>
                                    </li>-->
                                </ul>
                            </div>
                        </div>
                     </div>
                </div>
            </div>
        </div>
        <div class="uk-width-large-8-10"  id="content_right" style="float:left;height: 520px;padding-left:12px;">
            <div class="md-card">
                <div class="md-card-content" style="">
                    <div id="forms" data-form_id ="1" style="width:100%;height: 550px;">
                            <ul id="pages" style="height: 520px;overflow-y: scroll;">
                               <?php 
                               //echo '<pre>';
                                //print_r($datas);
                                foreach($datas->fields as $p=>$pages){ 
                                    $row_count = count($pages);
                                    $total_rows = 0;
                                    $comptField = 0;
                                        foreach($pages as $r=>$rows){ 
                                        $r++;
                                        $column_count = count($rows);
                                        if($r < $row_count){
                                            $total_rows++;
                                    ?>

                                    <li class="rows uk-width-1-1" id="rows_<?php echo $r; 
                                     ?>">
                                        <ul id="rows_<?php echo $r; ?>" class="connected"> 
                                            <?php foreach($rows as $c=>$columns) {
                                                    $c++;  
                                                    $comptField++;
                                                                                                                               
                                            ?> 
                                            <li class="uk-width-1-<?php echo $column_count;?> columns" id="columns_<?php echo $c; ?>">
                                                <div class="cols uk-width-1-1"> 
                                                    <?php echo $CI->templates->generate($columns);?>
                                                </div>
                                                <?php
                                                   $type =  $columns->type;
                                                   $edit_row_id = 'row_'.$r;
                                                   $edit_column_id = 'columns_'.$c;
                                                    $edit_choices_id = 'choices_'.$columns->formfieldid;
                                                if($type === 'radio' || $type === 'checkbox' || $type === 'select' || $type === 'time' || $type === 'date'){

                                                    
                                                   
echo '<script>
dialog =  popup_initialize("'.$edit_choices_id.'"," ","'.$type.'","'.$edit_row_id.'","'.$edit_column_id.'");
popup.options_open(dialog); 
popup.open_dialog("'.$edit_choices_id.'",dialog);
</script>
<input type="hidden" name="popup_'.$columns->formfieldid.'" id="popup_'.$columns->formfieldid.'" value="">
';                 


                       

                                                } ?>
                                            </li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } 
                                    }
                                } ?>
                            </ul>
                            <?php 
                                if($c <= 3){
                                    $start_rows = $total_rows;
                                    $start_cols = $c;
                                }  else{
                                    $start_rows = $total_rows++;
                                    $start_cols = 1;
                                }  
                            ?>

                    </div>
                </div>
                
                <div class="buildform">
                     <a class="publish">Build this form </a>
                </div>
            </div>                     
        </div>
        <form class="uk-form-stacked" id="wizard_advanced_form" method="post" action ="">
            <input type="hidden" name="formToken" class="form_token" value ="" />
            <input type="hidden" name="form_name" class="form_name" value = " "/>
            <input type="hidden" name="form_desc" class="form_desc" value = " "/>
            <input type="hidden" name="delete_fields" class="delete_fields" value = " "/>
            <input type="hidden" name="option_id" class="option_id" value = " "/>
            <input type="hidden" id="org_id" name="org_id" value="<?php echo $org_id; ?>" />
        </form>
        <?php $this->load->view('form/template'); ?>
    </div>
</div>


<script type="text/javascript">
         if($('body').hasClass('sidebar_main_active')){
            $('body').removeClass('sidebar_main_active');
        }
        if($('body').hasClass('sidebar_main_open')){
            $('body').removeClass('sidebar_main_open');
        }
    </script> 

<script type="text/javascript">
    $(window).load(function(draggable){           
    (function(w,d,$){
    $(document).ready(function($){
        var rowid = <?php echo $start_rows; ?>;
        var form_rows = 1;
        var colid = <?php echo $start_cols; ?>;
        var comptField = 1;
        var dialog;
        var todrag = $("#basic li span,#group li span,#advanced li span");
        var pages = $("#pages");
        var cols = $(".connected"); 
        todrag.draggable({
          containment : "#container",
          helper: "clone",
          start:function(){
            if($("#rows_"+rowid).length){
                var dragstart='<ul id="rows_'+rowid+'" class="connected"></ul>';
                 $(dragstart).droppable( droppable ).last($("ul#rows_"+rowid));
            }else{
            var dragstart = '<li class="rows uk-width-1-1" id="rows_'+rowid+'"><ul id="rows_'+rowid+'" class="connected"></ul></li>';
             $(dragstart).droppable( droppable ).appendTo(pages);
            }
           
            rowid++;
                    //console.log(rowid);
           },
           drag:function(event,ui){
                $(ui.helper).width(125),$(ui.helper).addClass("addField"),$(ui.helper).find("p").show()
            },zIndex:999,
           stop:function(){
            $(this).removeClass('addField');

           }

        });
        



        var droppable ={
            //activeClass: 'dragHover',
            //hoverClass: 'split',
            drop: function( event, ui) {
                console.log(ui)
                var type = ui.draggable.attr("value");
                var row_id = $(event.target).attr('id');               
                var collength = common.countcollength(row_id);
                console.log("hai");
        
        //  var col = $(this).attr('id');
            
    //      var ro = $('ul#'+col+' '+'li.columns');
            //console.log(this);
            
            //var colid = $(this).find('li.columns');
            //console.log(colid);
/*
                var maxHeight =$('#'+colid).height('');
                
                ro.each(function(){ 
                //  console.log("maxheight"+maxHeight);
                    //  console.log("colheight"+$(this).height());

                        $(this).css('height','');
                        maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height(); 
                    
                    
                    //console.log($(this));     

                });
                //console.log(ro);
                ro.each(function(){

                        $(this).css('height',maxHeight);
                        //$('ul#'+col).css('height',maxHeight);
                    
                });*/


                if(type !== undefined){
                    if(collength <= 3){
                        html = $('#config_'+type).html();
                        /* Set individual required field as unique id */
                        reg = new RegExp("(text_check)", "g");
                        html = html.replace(reg, 'text_check_'+comptField);
                        /* Set individual edits field as unique id */
                        reg = new RegExp("(edits)", "g");
                        html = html.replace(reg, 'edits_'+comptField);
                        /* Set individual options as field as unique id */
                        reg = new RegExp("(choices)", "g");
                        html = html.replace(reg, 'choices_'+comptField);
                        reg = new RegExp("(open_options)" , "g");
                        html = html.replace(reg, 'open_options_'+comptField);
                        var append_div = '<li class="columns uk-width-1-'+collength+'" id="columns_'+collength+'"><div class="cols uk-width-1-'+form_rows+' '+type+'_'+colid+'"><div class="uk-panel config_'+type+' portlet">'+html+'</div></div></li>'; 
                        $('ul#'+row_id).append(append_div);
                        common.auto_update_text(type);

            var col = $(this).attr('id');
            console.log(col);
            var colid = $(append_div).attr('id');

            var ro = $('ul#'+col+' '+'li.columns');

            var maxHeight =$('#'+colid).height('');

                ro.each(function(){ 
                //  console.log("maxheight"+maxHeight);
                    //  console.log("colheight"+$(this).height());

                        $(this).css('height','');
                        maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height();                    
                        console.log(maxHeight);
                    //console.log($(this)); 

                });
                //console.log(ro);
                ro.each(function(){

                        $(this).css('height',maxHeight);
                        //$('ul#'+col).css('height',maxHeight);
                    
                });




                        //common.required();
                        if(type === 'radio' || type === 'checkbox' || type === 'select' || type === 'time' || type === 'date'){
                            dialog = popup_initialize('choices_'+comptField,this,type,row_id,"columns_"+collength);
                            common.options_open(type,type+'_'+colid,'choices_'+comptField,dialog);
                            common.open_dialog(type,type+'_'+colid,'choices_'+comptField,'open_options_'+comptField,dialog);
                            rowid++;
                        } 
                        colid++;
                        var rows = $('.rows');
                        var empty_li = 0;
                        /* Remove li has zero columns */
                        rows.each(function(){
                            var length = $('ul.connected',this).find('li.columns').size();
                            if(length === 0){
                                ++empty_li;
                                if(empty_li > 2){
                                    $(this).remove();   
                                }
                            }else{
                                $id = $('ul.connected',this).attr('id');
                                if($id !== undefined){
                                    //console.log($id);
                                }
                                if($(this).find('.highlight')){
                                    $(this).find('.highlight').remove();
                                }
                            }
                        });
                        /* Resize the column width based upon its size */
                        $('.resize').each(function(){
                            var length = $('ul.connected',this).find('li.columns').size();
                            alert(length);
                            if(length <= 3){
                                var width ='uk-width-1-'+length;
                                var left_div = 'titl-field'+length+' left_setting';
                                var right_div ='hover-icons'+length+' right_setting hover-icons action';
                                var columns = $('.columns');
                                $('.columns',this).each(function(){
                                    $(this).removeClass().addClass(width).addClass('columns').css('width','');
                                    $(this).find('.left_setting').removeClass().addClass(left_div);
                                    $(this).find('.right_setting').removeClass().addClass(right_div);
                                });
                            }
                            $(this).removeClass('resize');
                        });
                        if($("#"+row_id).hasClass("dropover")){
                            $("#"+row_id).removeClass('dropover');
                        }
                        if($("#"+row_id).find('.columns').hasClass("dropovers")){
                            $("#"+row_id).removeClass('dropovers');
                        }
                    }   
                    else{
                        return false;
                    }
                }
                comptField++;
            },
            out:function(event,ui){
                if($("ul#pages").find('.highlight')){
                    $(this).find('.highlight').remove();
                }
            },
            over :function(event,ui){
                var rowid = $(event.target).attr('id');
                /* Remove highlighted area */
                $('#pages').find('.highlight').remove(); 
                var colcount = $('ul#'+rowid).find('.columns').length;
                //console.log(colcount);
                if(colcount === 1){
                    width = 100/2+'%';
                    $('#'+rowid).find('.columns').css('width',width);
                    var over_id = $('li.columns','ul#'+rowid).last().attr('id');
                    if(over_id != undefined){
                            if($("#"+rowid).find('.highlight').size() == 0){
                            $('#'+rowid+' li#'+over_id).after('<li class="highlight" style="width:'+width+'"></li>');
                        }
                    }
                }else if(colcount === 2){
                    width = 100/3+'%';
                    $('#'+rowid).find('.columns').css('width',width);
                    var over_id = $('li.columns','ul#'+rowid).last().attr('id');
                    if(over_id != undefined){
                            if($("#"+rowid).find('.highlight').size() == 0){
                            $('#'+rowid+' li#'+over_id).after('<li class="highlight" style="width:'+width+'"></li>');
                        }
                    }
                }   
                else if(colcount === 0){
                    width = 100+'%';
                    $('li#'+rowid).find('.columns').css('width',width);
                    if($("ul#"+rowid).find('li').size() == 0){
                        $('ul#'+rowid).after('<li class="highlight" style="width:'+width+'"></li>');
                    }
                }
                $('#'+rowid).find('.columns');
                //console.log("Over "+rowid+" Count "+colcount);
                var rows = $('.rows');
                rows.each(function(){
                    if($(this).hasClass('dropover')){
                        $(this).removeClass('dropover');
                    }
                }); 
                $('#'+rowid).addClass('dropover resize');
                $('#'+rowid).find('.columns').addClass('dropovers');
            },
        }

///max height
    pages.children().droppable(droppable).on('scroll',function(){
            $(this).scrollTop();
        });



        $(d).on("blur",".title_labels" ,function () {

            var txt = $(this).val();

            current = $(this).parent().parent();
             
            var type = $(current).find('.required').data('type');
            currents = $(this).parent().parent().parent().parent().parent().parent().parent();

            $(this).replaceWith("<label class='title_label'>"+txt+"</label>");
            console.log(currents);
          
            var col = $(currents).attr('id'); //column id
            //console.log(currents);
                //var rowid_height = $('#'+col).closest("ul").parent().attr('id'); // rowid
             

            var ro = $('ul#'+col+' '+'li.columns');
            
            var colid = $(current).closest("li").attr('id');
            
            //console.log(colid);

                var maxHeight =$('#'+colid).height('');
                
                ro.each(function(){ 
                //  console.log("maxheight"+maxHeight);
                    //  console.log("colheight"+$(this).height());

                        $(this).css('height','');
                        alert("height");
                        maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height(); 
                    
                    
                    //console.log($(this)); 

                });
                //console.log(ro);
                ro.each(function(){

                        $(this).css('height',maxHeight);
                        //$('ul#'+col).css('height',maxHeight);
                    
                });



        });



        $(d).on("click",'.edit_field',function(){
            //UIkit.modal.prompt('Name:','', function(val){ Console.log(val) });
        });
        $(d).on("mouseover",".columns",function(){
            var id = $(this).find('.action').attr('id');
            $('#'+id).show();

            $(this).addClass('hover');
        });
        $(d).on("mouseout",".columns",function(){
            var id = $(this).find('.action').attr('id');
            $('#'+id).hide();
            $(this).removeClass('hover');
        });
        $(d).on('click','.required',function(){
            var type = $(this).data('type');
            if(type === 'select' || type === 'radio' || type === 'checkbox'){
                grandparent = $(this).parent().parent().parent();   
            }else{
                grandparent = $(this).parent().parent();
            }
            if($(this).is(':checked')){
                $(grandparent).find('.title_label').append('<span class="req">*</span>');
            }else{
                $(grandparent).find('span.req').remove();
            }
        });
        $(d).on('input[readonly]','focus',function(){
                this.blur();
        });
        $('#form_name').on('focus',function(){
            $(this).parent().find('b.req').remove();
        });



        $(d).on('click','.delete_field',function(){

             del_id = $(this).parent().find("input").val();
            


            grand_parent = $(this).parent().parent().parent().parent().parent().parent().parent().attr('id');
            parent = $(this).parent().parent().parent().parent().parent().parent().attr('id');
            UIkit.modal.confirm('Are you sure, you want to delete this row?', 
                function(){
                    
                
                 
                type = $(parent).find('div.portlet-header').attr('data-type');

              $('.delete_fields').val($('.delete_fields').val()+','+del_id);
 
                console.log($('.delete_fields').val());



                        $("ul#"+grand_parent+" #"+parent).remove();
                    //});
                    var length = $('ul#'+grand_parent).find('.columns').size();
                    if(length <= 3 && length != 0){
                        var width ='uk-width-1-'+length;
                        var left_div = 'titl-field'+length+' left_setting';
                        var right_div ='hover-icons'+length+' right_setting hover-icons action';
                        var columns = $('.columns');
                        $('ul#'+grand_parent+' .columns').each(function(){
                            //$(this).
                            $(this).removeClass().addClass(width).addClass('columns',400,'easeInBack');
                            $(this).find('.left_setting').removeClass().addClass(left_div);
                            $(this).find('.right_setting').removeClass().addClass(right_div);
                        });
                    }else if(length == 0){
                        $("li#"+grand_parent).remove();
                    }
            });
            
        });
        $(d).on('click','.check',function(){    
            if($(this).hasClass('uncheck-grey'))    {
                $(this).removeClass("uncheck-grey").addClass("check-red");
            }else{
                $(this).removeClass("check-red").addClass("uncheck-grey");
            }
        }); 
        $(d).on('click','.publish',function(){
            console.log('publish');
            common.build();
        });
        function popup_initialize(popupid,current,type,row_id,column_id){
            var dialog = $(current).find('#'+popupid).dialog({
              title: " OPTIONS",
              height: "auto",
              width: "auto",
              modal: true,
              //height: 300,
              buttons: {
                "ok" :function(){
                    var html = '';
                    switch(type){
                            
                        case 'select':
                            var select = '<select id="'+popupid+'_'+row_id+'">';
                            var hidden = '';
                            $('#'+popupid).find('.select_label').each(function(){
                                if($(this).val() != ''){
                                    html += '<option>'+$(this).val()+'</option>';
                                    hidden += '<input type="hidden" class="title_value" data-optionid="0" value="'+$(this).val()+'" />';
                                }
                            })
                            select += html;
                            select +='</select>';
                            select += hidden;
                            break;
                        case 'radio':
                            var select = '';
                            $('#'+popupid).find('.select_label').each(function(){
                                if($(this).val() != ''){
                                    select += '<input type="radio" name="'+popupid+'"/> <span class="title_value" data-optionid="0">'+$(this).val()+'</span>';
                                }
                            })
                            break;
                        case 'checkbox':
                            var select = '';
                            $('#'+popupid).find('.select_label').each(function(){
                                if($(this).val() != ''){
                                    select += '<input type="checkbox"/><span class="title_value" data-optionid="0">'+$(this).val()+'</span>';
                                }
                            })
                            break;
                        case 'date':
                            var select = '';
                                console.log($('#date_formats').val());
                                $('#date_format',current).val($('#date_formats').val());
                            break;  
                        case 'time':
                            var select = '';
                                console.log($('#time_formats').val());
                                $('#time_format',current).val($('#time_formats').val());
                            break;

                    }
                    $('ul#'+row_id+'> #'+column_id).find('.select').empty().append(select);
                    $(this).dialog( "close" );
                },
                Cancel: function() {
                  $(this).dialog( "close" );
                }
              },
            });
            return dialog;
        }
        
        var common = {
            countcollength :function(rowid){    
                var colcount = $('#'+rowid).find('div.cols').size();
                //console.log(colcount+" Column "+" in "+rowid);
                return ++colcount;
            },
            auto_update_text:function(type){
                $(d).on("click",'label.title_label', function () {

                    var current = $(this).parent().parent();
                    var txt = $(this).text();
                    $(".title_label",current).replaceWith('<input class="title_labels" value="'+txt+'"/>');
                    $(".info",current).remove();
                });
                $(d).on('click','span.click-edit-icon',function(){
                    if(type === 'select' || type === 'radio' || type === 'checkbox'){
                        var current = $(this).parent().parent().parent();
                    }else{
                        var current = $(this).parent().parent();
                    }
                    if($('ul#pages').find('.title_labels')){
                        var input_label = $('ul#pages').find('.title_labels').val();
                        $('ul#pages').find('.title_labels').replaceWith("<label class='title_label'>"+input_label+"</label>");
                    }
                    var txt = $(current).find('.title_label').text();
                    $(".title_label",current).replaceWith('<input class="title_labels" value="'+txt+'"/>');
                });
            },
            open_dialog:function(type,selectedid,popupid,optionid,dialog){
                $('.'+optionid).click(function(){
                    alert("open_dialog")
                    dialog.dialog( "open" );
                });
            },
            options_open:function(type,selectedid,popupid,dialog){
                    current = dialog.attr('id');
                    var max_fields      = 5; //maximum input boxes allowed
                    var wrapper         = $("#"+current+" element"); //Fields wrapper
                    var add_button      = $(".add_field_button"); //Add button ID
                    var x = 0;
                    //console.log(wrapper);
                    $(wrapper).on("click",'.add_field_button',function(e){ //on add input button click
                         //initlal text box count
                        e.preventDefault();
                        if(x < max_fields){ //max input box allowed
                            x++; //text box increment
                            //$(wrapper).find('.add-option').remove();
                            $(wrapper).append('<p><input type="text" name="mytext[]" class="select_label"/><span class="delete-option remove_field"></span></p>'); //add input box
                        }else{
                            if($(wrapper).find('p.req').size() == 0){
                                $(wrapper).prepend('<p class="req">Limited only for trial version</p>');
                            }
                        }
                        return false;
                    });
                    $(add_button).on("click",function(e){ //on add input button click
                         //initlal text box count
                        e.preventDefault();
                        if(x < max_fields){ //max input box allowed
                            x++; //text box increment
                           // $(wrapper).find('.add-option').remove();
                            $(wrapper).append('<p><input type="text" name="mytext[]" class="select_label"/><span class="delete-option remove_field"></span></p>'); //add input box
                        }else{
                            if($(wrapper).find('p.req').size() == 0){
                                $(wrapper).prepend('<p class="req">Limited only for trial version</p>');
                            }
                        }
                        return false;
                    });
                    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
                        e.preventDefault();
                        if($(wrapper).find('p.req').size() == 1){
                            $(wrapper).find('p.req').remove();
                        }
                        //$(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span><span class="delete-option remove_field"></span>');     
                       /* if(type === 'radio'){
                            if($(wrapper).find('p').size() > 3){
                                $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span><span class="delete-option remove_field"></span>');       
                            } else{
                                $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span>');       
                            }
                        }
                        if(type === 'checkbox' || type === 'select'){
                            if($(wrapper).find('p').size() > 2){
                                $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span><span class="delete-option remove_field"></span>');       
                            } else{
                                $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span>');       
                            }   
                        }*/
                        $(this).parent('p').remove(); 

                        x--;
                    });
                    return false;
               // });
            },
            options_close:function(type,selectedid,popupid,dialog){
                $(d).on('click','.options_cancel',function(){
                    console.log('here');
                });
            },
            required:function(){
                $(d).on('click','.check',function(){    
                    if($(this).hasClass('uncheck-grey') === true)   {
                        console.log($(this).hasClass('uncheck-grey'));
                        $(this).removeClass("uncheck-grey").addClass("check-red");
                    }else{
                        console.log('else');
                        $(this).removeClass("check-red").addClass("uncheck-grey");
                    }
                }); 
            },
            build:function(){
                var formname = $("#form_name").val();
                if(formname === '' || formname === undefined){
                    if (($('#form_name').parent().find('b').length) == 0){
                            $('#form_name').after('<b class="req">Please enter form name </b>');
                            return false;
                            
                            }else{
                                return false;
                            
                           }
                }
                var button_col = new Array();
                reset = {};
                reset.type = "reset";
                reset.formfieldid = "0";
                reset.title = "Reset";
                reset.api_type = "element-reset";
                buttons = {};
                buttons.type = "submit";
                buttons.formfieldid = "1";
                buttons.title = "Submit";
                buttons.api_type = "element-button-submit";
                fields ={};
                button_col[0]  = reset;
                button_col[1] = buttons;
                var pages = [];
                var rows = $('ul#pages li');
                var row_ = new Array();
                var row_incr = 0;
                $(rows).each(function(r,rows){
                    var row = $('ul.connected li',rows);
                    length = row.length;
                    if(length != 0){
                          var col = new Array();
                          var col_incr = 0;
                        $(row).each(function(c,columns){
                            fielddata = {};
                            rclass =  $('.cols', columns).attr('class').split("_");
                            id = rclass[1].split("-");
                            type = $('.portlet-header',columns).data('type').toString();
                            title = $('.title_label',columns).text();
                            // implement fieldid on libraries/Template.php
                            // every field need a fieldid
                            // first time need a formfieldid as zero while creating the form once the form saved
                            // formfieldid value should be form_fields table primary id
                            // field params are 

                            /*  fieldid
                                formfieldid
                                type
                                title
                                required
                                choices
                            */

                            fielddata.fieldid =$('.portlet-header', columns).data('fieldid').toString();
                            fielddata.formfieldid =String($('.formfieldid',columns).val());
                            fielddata.type = type;
                            fielddata.title = title;
                            if($(columns).find('.title_value').length > 0){
                                choices = [];
                                $(columns).find('.title_value').each(function(i,value){
                                    options = {};
                                    if($(this).text() === ''){
                                        options['title'] = $(this).val();
                                    }else{
                                        options['title'] = $(this).text();
                                    }
                                    options['id'] = String($(this).data('optionid'));
                                    options['checked'] =String(0);
                                    choices.push(options);
                                    fielddata.choices = choices;
                                });
                            }
                            if($(columns).find('#time_format').length > 0){
                                fielddata.format = $('#time_format').val();
                            }
                            if($(columns).find('#date_format').length > 0){
                                fielddata.format = $('#date_format').val();
                            }
                            if($(columns).find('.check-red').length > 0){
                                fielddata.required = String(1);
                            }
                            else{
                                fielddata.required = String(0);   
                            }
                            col[col_incr]=fielddata;
                            col_incr++;
                        });
                        row_[row_incr] = col; 
                        row_incr++; 
                    }
                });
                row_[row_incr++] = button_col;
               // row_[row_incr++] = buttons;
                pages[0] = row_;
                fields.fields = pages;
                console.log(JSON.stringify(fields));
                $('.form_token').val(CryptoJS.AES.encrypt(JSON.stringify(fields),'',{format: CryptoJSAesJson}).toString());
                var form_name = $("#form_name");
                var form_desc = $("#form_desc");
                $('.form_name').val(form_name.val());
                $(".form_desc").val(form_desc.val());
                $('#wizard_advanced_form').submit();
            }
        }
    });
  }(window,document,window.jQuery));
}(window,document,window.jQuery));
        
   
                </script>