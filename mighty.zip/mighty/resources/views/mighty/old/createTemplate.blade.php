<?php
$template=Config::get('custom.template');
?>
@extends('mighty.layout.tpl')
@section('customCss')
<link rel="stylesheet" href="{{URL::asset('mighty/plugins/template.css')}}"> 
<style>
.boxdiv{
    height: 100%;
    padding: 10px;
    border: 1px solid #aaaaaa;  
}
.content {
    min-height: 1811px;
}
#div2 {
    width: 650px;
    height: 270px;
    padding: 10px;
    border: 1px solid #aaaaaa;
}
#makeMeDraggable { width: 100px; height: 100px; background: red; }
#draggable { width: 150px; height: 150px; padding: 0.5em; }
</style>
@endsection

@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Mighty Customizable Vehicle Inspection Forms
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Create Template</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    <p>Drag and Drop to make your template:</p>
    <div class="row" style="height:100%">
        <div class="col-md-3">
          <p>Drag</p>
        </div>
        <div class="col-md-9">
        <p>Drop</p>
        </div>
    
  <div class="col-md-3 boxdiv" ondrop="drop(event)" ondragover="allowDrop(event)">
      <div id="dragx" draggable="true" ondragstart="drag(event)" width="336" height="69">
        <input type="text" name="header" value="Header"/>
      </div>
      <div id="drag2" draggable="true" ondragstart="drag(event)" width="336" height="69">
        <input type="file" name="file1" />
      </div>
  </div>
  <div class="col-md-9 boxdiv"  id="div1"  ondrop="drop(event)" ondragover="allowDrop(event)">
  </div>
</div>
</section>

<!--
<style>
.content {
    min-height: 1811px;
}
#div1 {
    width: 350px;
    height: 70px;
    padding: 10px;
    border: 1px solid #aaaaaa;
}
#div2 {
    width: 650px;
    height: 270px;
    padding: 10px;
    border: 1px solid #aaaaaa;
}
#makeMeDraggable { width: 100px; height: 100px; background: red; }
#draggable { width: 150px; height: 150px; padding: 0.5em; }
</style>
   <section class="content">
<div id="draggable" class="ui-widget-content">
  <p>Drag me around</p>
</div>

    <div id="content" style="height: 400px;">
  </div>
    
    <p>Drag the W3Schools image into the rectangle:</p>

<div id="div1" style="float:right;" ondrop="drop(event)" ondragover="allowDrop(event)"></div>
<div id="div2"   ondrop="drop(event)" ondragover="allowDrop(event)"></div>
<br>
<div id="drag1" draggable="true" ondragstart="drag(event)" width="336" height="69">
  <input type="text" name="header" value="Header"/>
</div>
<div id="drag2" draggable="true" ondragstart="drag(event)" width="336" height="69">
  <input type="file" name="file1" />
</div>
<div id="makeMeDraggable"> </div>



    </section>
    -->
   
 
@endsection

@section('customJs')
<!--
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
$(document).ready(function(){
   
  $('body').addClass('sidebar-collapse');
});
</script>
-->

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/jquery-ui.min.js"></script>
<script>
function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
      ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
}
$( init );
 
function init() {
  $('#makeMeDraggable').draggable( {
    containment: '#content',
    cursor: 'move',
    snap: '#content'
  } );


}
$( function() {
    $( "#draggable" ).draggable();
  } );
</script>

@endsection
