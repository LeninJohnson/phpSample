@extends('mighty.layout.tpl')
@section('customCss')
    <link rel="stylesheet" href="{{URL::asset('mighty/plugins/select2/select2.min.css')}}">

    <link rel="stylesheet" href="{{URL::asset('mighty/plugins/datatables/dataTables.bootstrap.css')}}">

    <style>
        .content {
        //   min-height: 1811px;
        }
    </style>

    @endsection
    @section('content')

            <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Make
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{URL::to('')}}"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="#">Mighty Assist</a></li>
            <li class="active">Make</li>
        </ol>
    </section>

    @if(Session::has('true_msg'))
        <div style="padding: 4px;" class="row">
            <div class="col-md-6">
                <div   class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                    {{Session::get('true_msg')}}
                </div>
            </div>
        </div>
    @endif
    @if(Session::has('error_msg'))
        <div style="padding: 4px;" class="row">
            <div class="col-md-6">
                <div class="alert alert-danger">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    {{Session::get('error_msg')}}
                </div> <!-- /.alert -->
            </div>
        </div>
        @endif
                <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">
                            <!--<h3 class="box-title">View Video Library</h3> -->
                            <a   class="btn bg-navy margin addvideo">Add Make</a>
                        </div>
                        <div id="addrow" style="display: none" class="box box-primary">
                            <div class="box-header with-border">
                                <h3 class="box-title">Add Make</h3>
                            </div>
                            <!-- /.box-header -->
                            <!-- form start -->
                            <form role="form" method="post" action="{{URL::to('/mighty-assist/make/add')}}" enctype="multipart/form-data" >
                                <div class="box-body">
                                    <div class="form-group">
                                        <label>Year</label>
                                        <select class="form-control select2"  name="year" style="width: 100%;">
                                            <option value="">Select</option>
                                            @for($a=0;$a<=95;$a++)
                                            <option value="{{date("Y")-$a}}">{{date("Y")-$a}}</option>
                                            @endfor
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="model">Make</label>
                                        <input class="form-control" name="make" maxlength="20" type="text" required />
                                    </div>
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control" name="description"  ></textarea>
                                    </div>
                                </div>
                                <!-- /.box-body -->

                                <div class="box-footer">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    <a id="cancelvideo" class="btn btn-default">Cancel</a>
                                </div>
                            </form>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            {{--<table id="example2" class="table table-bordered table-hover">--}}
                                <table id="Mkexample1" class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Year</th>
                                    <th>Make</th>
                                    <th>Description</th>
                                    <th width="15%">Action</th>
                                </tr>
                                </thead>
                              {{--  <tbody>
                                @foreach($carmake as $key=>$vals)
                                    <tr>
                                        <td>{{$key+1}}</td>
                                        <td>{{$vals->make_year}}
                                        </td>
                                        <td>{{$vals->make}}
                                        </td>
                                        <td>{{$vals->description}}
                                        </td>
                                        <td>

                                            <a href="{{URL::to('/mighty-assist/make/edit')}}/{{$vals->id}}"  class="tabledit-edit-button btn btn-sm btn-primary" style="float: left;" ><i class="fa fa-edit"></i>
                                            </a>
                                            <button type="button" class="tabledit-delete-button btn btn-sm btn-default confirm-delete" style="float: none;" onclick="confirmDelete('{{$vals->id}}');"  data-rid="{{$vals->id}}" ><span class="glyphicon glyphicon-trash"></span></button>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>--}}

                            </table>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->


                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->


@endsection

@section('customJs')


    <script src="{{URL::asset('mighty/plugins/datatables/jquery.dataTables.min.js')}}"></script>

    <script src="{{URL::asset('mighty/plugins/datatables/dataTables.bootstrap.min.js')}}"></script>
    <script src="{{URL::asset('mighty/plugins/select2/select2.full.min.js')}}"></script>

    <script>
        function confirmDelete(id){
            var confirmMsg = confirm("Are you sure want to delete this Make? You cannot undo this action");
            if(confirmMsg) {
                window.location.href = "{{URL::to('mighty-assist/make/delete')}}/"+id;
            }
        }
        jQuery( document ).ready(function() {

        });

        $(function () {
            var table = jQuery('#Mkexample1').DataTable({
                "bProcessing": true,
                "sAjaxSource": "{{URL::to('mighty-assist/show-make')}}",
                "bPaginate":true,
                "searching": true,
                "sPaginationType":"full_numbers",
                "iDisplayLength": 10,
                "bLengthChange":true,
                "bFilter": true,
                "aoColumns": [
                    { mData: 'id' } ,
                    { mData: 'make_year' } ,
                    { mData: 'make' },
                    { mData: 'description' },
                    { mData: 'actions' }
                ]
            });

            $(".select2").select2();
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
           /* $('.confirm-delete').click(function(){
                var id = $(this).data('rid');
                var confirmMsg = confirm("Are you sure want to delete this Make? You cannot undo this action");
                if(confirmMsg) {
                    window.location.href = "{{URL::to('mighty-assist/make/delete')}}/"+id;
                }
            });*/
            $('.addvideo').click(function(){
                $("#addrow").css('display','block');
            });
            $('#cancelvideo').click(function(){
                $("#addrow").css('display','none');
            });
        });
    </script>
@endsection