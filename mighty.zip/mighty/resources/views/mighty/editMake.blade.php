@extends('mighty.layout.tpl')
@section('customCss')
    <style>
        .content {
        // min-height: 1811px;
        }
    </style>
    <link rel="stylesheet" href="{{URL::asset('mighty/plugins/select2/select2.min.css')}}">
    @endsection
    @section('content')

            <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Make
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{URL::to('')}}"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="#">Mighty Assist</a></li>
            <li class="active">Edit Make</li>
        </ol>
    </section>
    @if(Session::has('true_msg'))
        <div style="padding: 4px;"  class="row">
            <div class="col-md-6">
                <div class="alert alert-success">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    {{Session::get('true_msg')}}
                </div> <!-- /.alert -->
            </div>
        </div>
    @endif
    @if(Session::has('error_msg'))
        <div class="row">
            <div class="col-md-6">
                <div class="alert alert-danger">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    {{Session::get('error_msg')}}
                </div> <!-- /.alert -->
            </div>
        </div>
    @endif
    <section class="content">
        <div   class="row">
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Make</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" method="post"  enctype="multipart/form-data" >
                        <div class="box-body">
                            <div class="form-group">
                                <label>Year</label>
                                <select class="form-control select2"  name="year" style="width: 100%;">
                                    <option value="">Select</option>
                                    @for($a=0;$a<=95;$a++)
                                        <option value="{{date("Y")-$a}}" @if($carmake->make_year==date("Y")-$a) selected @endif>{{date("Y")-$a}}</option>
                                    @endfor
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="model">Make</label>
                                <input class="form-control" name="make" maxlength="20" type="text" value="{{$carmake->make}}" required />
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea class="form-control" name="description"  >{{$carmake->description}}</textarea>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="{{URL::previous()}}" class="btn btn-default">Cancel</a>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </section>


@endsection

@section('customJs')


    <script src="{{URL::asset('mighty/plugins/select2/select2.full.min.js')}}"></script>


    <script>
        $(function () {
            $(".select2").select2();
        });
    </script>
@endsection