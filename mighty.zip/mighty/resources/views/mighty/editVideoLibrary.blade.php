@extends('mighty.layout.tpl')
@section('customCss')
    <style>
        .content {
           // min-height: 1811px;
        }
    </style>

@endsection
@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Video Library
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="#">Mighty Assist</a></li>
            <li class="active">Edit Video Library</li>
        </ol>
    </section>
    @if(Session::has('true_msg'))
        <div style="padding: 4px;"  class="row">
            <div class="col-md-6">
                <div class="alert alert-success">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    {{Session::get('true_msg')}}
                </div> <!-- /.alert -->
            </div>
        </div>
    @endif
    @if(Session::has('error_msg'))
        <div class="row">
            <div class="col-md-6">
                <div class="alert alert-danger">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    {{Session::get('error_msg')}}
                </div> <!-- /.alert -->
            </div>
        </div>
    @endif
    <section class="content">
        <div   class="row">
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Video Library</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" method="post" enctype="multipart/form-data" >
                        <div class="box-body">
                            <div class="form-group">
                                <label for="title">Title</label>
                                <input class="form-control" name="title" value="{{$videolibrary->title}}"  type="text" required />
                            </div>
                            <div class="form-group">
                                <label for="video_url">Video URL</label>
                                <input class="form-control" name="video_url" value="{{$videolibrary->video_url}}"  type="text" required />
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea name="description" class="form-control" >{{$videolibrary->description}}</textarea>
                            </div>

                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="{{URL::previous()}}" class="btn btn-default">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>


@endsection

@section('customJs')

@endsection