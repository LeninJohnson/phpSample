@extends('mighty.layout.tpl')
@section('customCss')
    <link rel="stylesheet" href="{{URL::asset('mighty/plugins/select2/select2.min.css')}}">

    <style>
        .content {
        //   min-height: 1811px;
        }
    </style>

    @endsection
    @section('content')

            <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Report
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{URL::to('')}}"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="#">Mighty Assist</a></li>
            <li class="active">Report</li>
        </ol>
    </section>

    @if(Session::has('true_msg'))
        <div style="padding: 4px;" class="row">
            <div class="col-md-6">
                <div   class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                    {{Session::get('true_msg')}}
                </div>
            </div>
        </div>
    @endif
    @if(Session::has('error_msg'))
        <div style="padding: 4px;" class="row">
            <div class="col-md-6">
                <div class="alert alert-danger">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    {{Session::get('error_msg')}}
                </div> <!-- /.alert -->
            </div>
        </div>
        @endif
                <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">

                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Report Id</th>
                                    <th>Date</th>
                                    <th>Customer Name</th>
                                    <th>Technician Name</th>
                                    <th>Time</th>
                                    <th>VIN</th>
                                    <th>Make</th>
                                    <th>Model</th>

                                </tr>
                                </thead>
                                <tbody>
                                @foreach($userprofile as $key=>$vals)
                                    <tr>
                                        <td>{{$key+1}}</td>
                                        <td><a style="letter-spacing: 1px;text-decoration: underline;" href="{{URL::to('api/v1/inspection-form/'.$vals->id.'')}}" target="_blank">{{$vals->id}}</a></td>
                                        <td>{{date('d-m-Y',strtotime($vals->inspection_date))}}</td>
                                        <td>{{$vals->first_name}}</td>
                                        <td>{{$vals->technician}}</td>
                                        <td>{{$vals->duration}}</td>
                                        <td>{{$vals->vin}}</td>
                                        <td>{{$vals->make}}</td>
                                        <td>{{$vals->model}}</td>
                                    </tr>
                                @endforeach
                                </tbody>

                            </table>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->


                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->


@endsection

@section('customJs')


    <script src="{{URL::asset('mighty/plugins/datatables/jquery.dataTables.min.js')}}"></script>
    <script src="{{URL::asset('mighty/plugins/select2/select2.full.min.js')}}"></script>
    <script src="{{URL::asset('mighty/plugins/datatables/dataTables.bootstrap.min.js')}}"></script>


    <script>
        $(function () {
            $(".select2").select2();
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
            $('.confirm-delete').click(function(){
                var id = $(this).data('rid');
                var confirmMsg = confirm("Are you sure want to delete this Engine? You cannot undo this action");
                if(confirmMsg) {
                    window.location.href = "{{URL::to('mighty-assist/engine/delete')}}/"+id;
                }
            });
            $('.addvideo').click(function(){
                $("#addrow").css('display','block');
            });
            $('#cancelvideo').click(function(){
                $("#addrow").css('display','none');
            });

            $("#year").on("change",function(e){
                var year = $("#year").val();
                if(year!='')
                {
                    $.ajax({
                        type: "POST",
                        url: "{{URL::to('/mighty-assist/get-make')}}",
                        data: {
                            "year": year,

                        },
                        success: function(html)
                        {
                            var options='<option value="">Select</option>';
                            $.each(html,function(e,val){
                                options+='<option value="'+val.id+'">'+val.make+'</option>';
                            });
                            $("#make").html(options);
                        }
                    });
                }else{
                    var options='<option value="">Select</option>';
                    $("#make").html(options);
                }

            });

            $("#make").on("change",function(e){
                var make = $("#make").val();
                if(make!='')
                {
                    $.ajax({
                        type: "POST",
                        url: "{{URL::to('/mighty-assist/get-model')}}",
                        data: {
                            "make": make,

                        },
                        success: function(html)
                        {
                            var options='<option value="">Select</option>';
                            $.each(html,function(e,val){
                                options+='<option value="'+val.id+'">'+val.model+'</option>';
                            });
                            $("#model").html(options);
                        }
                    });
                }else{
                    var options='<option value="">Select</option>';
                    $("#model").html(options);
                }

            });
        });
    </script>
@endsection