<?php
$template = Config::get('custom.template');
?>
@extends('mighty.layout.tpl')
@section('customCss')
    <link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/form-builder.min.css')}}">
    <link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/main.min.css')}}">
    <link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/uikit.almost-flat.min.css')}}">
    <link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/formpro.css')}}">
    <link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/jquery_ui.css')}}">
    <link rel="stylesheet" href="{{URL::asset('mighty/plugins/template3.css')}}">
    <style>
        .content {
        // min-height: 1811px;
        }
    </style>
    <style>
        li.rows{
            min-height:80px;
        }
        li.columns{
            float:left;
            height:75px;
            list-style: none;
        }
        li.highlight{
            min-height: 70px;
        }
        .dropovers{
            /*  border:1px solid #ccc;
              border-right-color:red;*/
        }
        body{
            /*overflow: hidden;
            height: 100%;*/
        }
        .content{
            padding-left: 0px !important;
        }
        body {
            padding-top: 0px !important;
        }
        .uk-grid > * {
            float: none;
        }
        .cmdline{
            width:90%;margin-top: 6%;color: rgb(12, 12, 12);border: 0.1px solid;
        }
        .th{
        // padding: 6px 22px 13px 1px;
            border: 1px solid;
        }
        .row1Title {
            background: none repeat scroll 0 0 #005AAB;
            border-bottom: 1px solid #000000;
            color: #FFFFFF;
        //  color: #000000 !important;
            font-family: 'MyriadProBold';
            font-size: 12pt;
            height: 30px;

            text-align: center;
        }
        .svgTable{
            margin-left: 30px;
            margin-top: 7px;
        }
        .uk-h2, h2 {
            font-size: 24px;
            line-height: normal;
        }
        .click-edit-icons {

            background-image: url("{{URL::asset('mighty/images/clicktoedit.png')}}");
            background-size: 15px;
            width: 15px;
            height: 15px;
            float: right;
        }
        .spanlable{

            max-width: 100%;
            font-weight: 700;
            display: block;
            text-align: center;
            margin: 4px 0px 8px;
        }
        .comp4boxi{
            width: 145px !important;
        }
        .optionbox{
            float:left;
        }
        .lrchange
        {
            background: url('{{URL::asset('mighty/images/leftright.png')}}');
            width: 18px;
            height: 18px;
            background-size: 19px;
            display: block;
            margin-top: -2px;
            margin-right: 10px;
        }
        .add_morerow{
            background: url('{{URL::asset('mighty/images/add2.png')}}');
            background-size: 15px;
            display: block;
            width: 15px;
            height: 15px;
            float: right;
            cursor: pointer;
            padding-left: 0px;
        }
        .uncheck-grey,.check-red{
            display: none;
        }
        .comp4text{
            font-size: 10pt !important;
            font-style: italic;
            font-family: 'MyriadProBold';
            text-align: left;
            word-wrap: break-word !important;
        }
        <!-- -->
        .inspectionTxt {
            font-size: 14px !important;
        }
        .white_box, .white_box_rectangle {
            width: 30px !important;
        }
        .yellow, .green, .red {
            width: 22px !important;
            height: 22px !important;
        }
        .tire-condition{
            display: block;
            width: 100%;
            float: left;
        }
        .tire-lflr{
            display: block;
            width: 100%;
            float: left;
            margin-top: 10px;
        }
        .beforeAfter {
            width: 77px;
        }

    </style>

    <script src="{{URL::asset('mighty/plugins/jquery.min.js')}}"></script>
    <script src="{{URL::asset('mighty/plugins/jquery-ui.js')}}"></script>

    <script>

        var popup = {
            open_dialog:function(optionid,dialog){

                $('.'+optionid).click(function(){
                    dialog.dialog( "open" );
                });
            },
            options_open:function(type,dialog){

                current = dialog.selector;
                var max_fields      = 5; //maximum input boxes allowed
                var wrapper         = $(""+current+" element"); //Fields wrapper
                var add_button      = $(".add_field_button"); //Add button ID
                var x = 0;


                $(wrapper).on("click",'.add_image_button',function(e){ //on add input button click
                    //initlal text box count
                    e.preventDefault();
                    if(x < max_fields){ //max input box allowed
                        x++; //text box increment
                        //$(wrapper).find('.add-option').remove();
                        $(wrapper).append('<p><input type="file" name="myfile[]" class="select_label"/><span class="delete-option remove_field"></span></p>'); //add input box
                    }else{
                        if($(wrapper).find('p.req').size() == 0){
                            $(wrapper).prepend('<p class="req">Limited only for trial version</p>');
                        }
                    }
                    return false;
                });
                $(add_button).on("click",function(e){ //on add input button click
                    //initlal text box count
                    e.preventDefault();
                    if(x < max_fields){ //max input box allowed
                        x++; //text box increment
                        // $(wrapper).find('.add-option').remove();
                        $(wrapper).append('<p><input type="text" name="mytext[]" class="select_label"/><span class="delete-option remove_field"></span></p>'); //add input box
                    }else{
                        if($(wrapper).find('p.req').size() == 0){
                            $(wrapper).prepend('<p class="req">Limited </p>');
                        }
                    }
                    return false;
                });
                $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
                    e.preventDefault();
                    if($(wrapper).find('p.req').size() == 1){
                        $(wrapper).find('p.req').remove();
                    }
                    //
                    // $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span><span class="delete-option remove_field"></span>');
                    /* if(type === 'radio'){
                     if($(wrapper).find('p').size() > 3){
                     $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span><span class="delete-option remove_field"></span>');
                     } else{
                     $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span>');
                     }
                     }
                     if(type === 'checkbox' || type === 'select'){
                     if($(wrapper).find('p').size() > 2){
                     $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span><span class="delete-option remove_field"></span>');
                     } else{
                     $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span>');
                     }
                     }*/
                    $(this).parent('p').remove();

                    x--;
                });
                return false;
            },
            options_close:function(classs,dialog){
                $(document).on('click','.'+classs,function(){
                    console.log($(this).text());
                    dialog.dialog('close');
                });
            },
        };
        function popup_initialize(popupid,current,type,row_id,column_id){

            var dialog = $('#'+popupid).dialog({
                title: " OPTIONS",
                height: "auto",
                width: "auto",
                modal: true,
                //height: 300,
                autoOpen: false,
                buttons: {
                    "ok" :function(){
                        var html = '';
                        var imgt = $('#imageType').val();

                        switch(type){
                            case 'select':
                                var select = '<select id="'+popupid+'_'+row_id+'">';
                                var hidden = '';
                                $('#'+popupid).find('.select_label').each(function(){
                                    if($(this).val() != ''){
                                        html += '<option>'+$(this).val()+'</option>';
                                        hidden += '<input type="hidden" class="title_value" data-optionid="0" value="'+$(this).val()+'" />';
                                    }
                                })
                                select += html;
                                select +='</select>';
                                select += hidden;
                                break;
                            case 'radio':
                                var select = '';
                                $('#'+popupid).find('.select_label').each(function(){
                                    if($(this).val() != ''){
                                        select += '<input type="radio" name="'+popupid+'"/> <span class="title_value" data-optionid="0">'+$(this).val()+'</span>';
                                    }
                                })
                                break;
                            case 'component1':
                                var select = '';
                                $('#'+popupid).find('.select_label').each(function(){
                                    // var inputType = $(this).attr('type');

                                    if($(this).val() != ''){
                                        if(imgt==0){
                                            select += '<div class="clear row1"><input type="hidden" name="'+popupid+'"/> <span class="optionbox"><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span><span class="inspectionTxt title_value" data-optionid="0">'+$(this).val()+'</span></div>';
                                        }else{
                                            select += '<div class="clear row1"><input type="hidden" name="'+popupid+'"/> <span class="optionbox"><b class="green"></b><b class="yellow"></b><b class="red"></b></span><span class="inspectionTxt title_value" data-optionid="0">'+$(this).val()+'</span></div>';
                                        }


                                    }
                                    //
                                })
                                break;
                            case 'component2':
                                var select = '';
                                $('#'+popupid).find('.select_label').each(function(){
                                    // var inputType = $(this).attr('type');

                                    if($(this).val() != ''){
                                        if(imgt==0){
                                            select += '<div class="clear row1"><input type="hidden" name="'+popupid+'"/> <span class="optionbox"><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span><span class="inspectionTxt title_value" data-optionid="0">'+$(this).val()+'</span></div>';
                                        }else{
                                            select += '<div class="clear row1"><input type="hidden" name="'+popupid+'"/> <span class="optionbox"><b class="green"></b><b class="yellow"></b><b class="red"></b></span><span class="inspectionTxt title_value" data-optionid="0">'+$(this).val()+'</span></div>';
                                        }
                                    }
                                    //
                                })
                                break;
                            case 'component3':
                                var select = '';
                                $('#'+popupid).find('.select_label').each(function(){
                                    // var inputType = $(this).attr('type');

                                    if($(this).val() != ''){

                                        if(imgt==0){
                                            select += '<div class="clear row1"><input type="hidden" name="'+popupid+'"/> <span><b class="greenCircle"></b><b class="yellowCircle"></b><b class="redCircle"></b></span><span class="inspectionTxt title_value" data-optionid="0">'+$(this).val()+'</span></div>';
                                        }else{
                                            select += '<div class="clear row1"><input type="hidden" name="'+popupid+'"/> <span><b class="green"></b><b class="yellow"></b><b class="red"></b></span><span class="inspectionTxt title_value" data-optionid="0">'+$(this).val()+'</span></div>';
                                        }

                                    }
                                    //
                                })
                                break;
                            case 'checkbox':
                                var select = '';

                                $('#'+popupid).find('.select_label').each(function(){
                                    if($(this).val() != ''){
                                        select += '<input type="checkbox"/><span class="title_value" data-optionid="0">'+$(this).val()+'</span>';
                                    }
                                })
                                break;
                            case 'date':
                                var select = '';
                                console.log($('#date_formats').val());
                                $('#date_format',current).val($('#date_formats').val());
                                break;
                            case 'time':
                                var select = '';
                                //  console.log($('#time_formats').val());
                                $('#time_format',current).val($('#time_formats').val());
                                break;

                        }
                        $('ul#'+row_id+'> #'+column_id).find('.select').empty().append(select);
                        $(this).dialog( "close" );
                    },
                    Cancel: function() {
                        $(this).dialog( "close" );
                    }
                },
            });
            // console.log(dialog);
            return dialog;
        }

        //function auto_update_text(type){
        $(document).on("click",'label.title_label', function () {

            var current = $(this).parent().parent();
            var txt = $(this).text();
            $(".title_label",current).replaceWith('<input class="title_labels" value="'+txt+'"/>');
            $(".info",current).remove();
        });
        $(document).on('click','span.click-edit-icon',function(){
            var type = $(this).data('type');
            if(type === 'select' || type === 'radio' || type === 'checkbox'){
                var current = $(this).parent().parent().parent();
            }else{
                var current = $(this).parent().parent();
            }
            if($('ul#pages').find('.title_labels')){
                var input_label = $('ul#pages').find('.title_labels').val();
                $('ul#pages').find('.title_labels').replaceWith("<label class='title_label'>"+input_label+"</label>");
            }
            var txt = $(current).find('.title_label').text();
            $(".title_label",current).replaceWith('<input class="title_labels" value="'+txt+'"/>');
        });
        //   }
        //
        /*
         $(document).on('click','.options-icon',function(){
         popupid =$(this).data('opt');
         console.log(popupid);
         $('#'+popupid).dialog("open");
         });
         */
    </script>
    <style>

        .trmodal {
            display: block;
            position: fixed;
            z-index: 1;
            padding-top: 100px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.4);
        }

        .trmodal-content {
            margin-left: 70px;
            position: relative;
            background-color: #fefefe;
            margin: auto;
            padding: 0;
            border: 1px solid #888;
            width: 80%;
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
            -webkit-animation-name: animatetop;
            -webkit-animation-duration: 0.4s;
            animation-name: animatetop;
            animation-duration: 0.4s
        }
        .close {
            color: white;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }
        .content_right{
            float:left;height: 100%;padding-left:12px;width:958px;

        }

        @media (min-width:1500px) {
            .content_right {
                width: 1196px;

            }
        }
    </style>

    @endsection
    @section('content')

            <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Mighty Customizable Vehicle Inspection Forms
            <small>Control panel</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Update Template</li>
        </ol>
    </section>
    @if(Session::has('true_msg'))
        <div class="alert alert-success">
            <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
            {{Session::get('true_msg')}}
        </div> <!-- /.alert -->
    @endif
    @if(Session::has('error_msg'))
        <div class="alert alert-danger">
            <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
            {{Session::get('error_msg')}}
        </div> <!-- /.alert -->
        @endif
                <!-- Main content -->
        <section class="content">
            <div class="col-md-12">
                <!-- Custom Tabs -->
                {{--<div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        @foreach($fd_alls as $vals)
                            <li @if($formdetails->id==$vals->id) class="active" @endif><a href="{{URL::to('cvif/template')}}/{{$vals->uuid}}" >{{$vals->form_name}}</a></li>
                        @endforeach
                    </ul>
                </div>--}}
            </div>

            <div id="page_content">
                <div id="page_content_inner">
                    <div class="uk-grid" style="display: block;padding-left:0px !important"; data-uk-grid-margin data-uk-grid-match id="wizard_forms">
                        <!--<div id="wizard_advanced">-->
                        <!-- <h2>Design Form</h2>
                        <section> -->
                        <div class="uk-width-large-2-10"  id="sidebar" style="float: left;width:20%;">
                            <div class="uk-width-1-1">
                                <div class="parsley-row">
                                    <div class="md-card  form-desc ">
                                        <label class="fn">Name your form<span class="req">*</span></label>
                                        <input type="text" class="md-input fn-field" id="form_name" name="form_name" value="{{$formdetails->form_name}}" data-parsley-trigger="change" required  />
                                        <label class="fd">Short description about your form </label>
                                        <textarea name="form_desc"  class="md-input" id="form_desc" style="">{{$formdetails->form_desc}}</textarea>
                                    </div>
                                </div>
                                <div class="parsley-row">
                                    <div class="md-card  form-desc ">
                                        <label class="fn">Box Type</label>
                                        <div style="margin-left: 20px;">
                                            <div class="radio">
                                                <label>
                                                    <input name="imageTypes" id="imageType1" class="imageType" value="0" @if($formdetails->imageType==0) checked @endif    type="radio">Circle
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input name="imageTypes" id="imageType2" class="imageType" value="1"  @if($formdetails->imageType==1) checked @endif   type="radio">Square
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                if($formdetails->imageType==0){
                                    $imgclrg="greenCircle";
                                    $imgclry="yellowCircle";
                                    $imgclrr="redCircle";

                                    $smlimgclrg="smallGreenCircle";
                                    $smlimgclry="smallYellowCircle";
                                    $smlimgclrr="smallRedCircle";
                                }else{
                                    $imgclrg="green";
                                    $imgclry="yellow";
                                    $imgclrr="red";

                                    $smlimgclrg="smallGreen";
                                    $smlimgclry="smallYellow";
                                    $smlimgclrr="smallRed";
                                }
                                ?>
                            </div>
                            <div class="md-card dragdrop-panel">
                                <div class="md-card-content">
                                    <div class="uk-panel">
                                        <div class="heading">Drag and drop for build new form</div>
                                        <div class="uk-accordion" data-uk-accordion>
                                            <h3 class="uk-accordion-title uk-accordion-title-primary">Basic</h3>
                                            <div class="uk-accordion-content">
                                                <ul id="basic">
                                                    <li><div class="singleline-icon" ></div><span value="heading">Heading</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="text">Single Line Text</span></li>
                                                    <!--<li><div class="email-icon"></div><span value="email">Email</span></li>
                                                    <li><div class="multiline-icon"></div><span value="textarea">Multi Line Text</span></li>
                                                    <li><div class="multiline-icon"></div><span value="number">Number</span></li>
                                                    <li><div class="radio-icon"></div><span value="radio">Radio</span></li>
                                                    <li><div class="select-icon"></div><span value="select">Select</span></li>
                                                    <li><div class="date-icon"></div><span value="date">Date</span></li>
                                                    <li><div class="time-icon"></div><span value="time">Time</span></li>-->


                                                    <li><div class="checkbox-icon"></div><span value="checkbox">Checkbox</span></li>
                                                    <li><div class="file-icon"></div><span value="file">File</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="emptyspace">Empty space</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="line">Line</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="textwithline">Text with Line</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="condition">Condition Square</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="condition2">Condition Circle</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="tablehead">Item and Content (Table)</span></li>
                                                    <!-- <li><div class="singleline-icon" ></div><span value="tablerow">Table Row</span></li>-->
                                                    <li><div class="singleline-icon" ></div><span value="component2">INTERIOR/EXTERIOR</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="component1">UNDER VEHICLE </span></li>
                                                    <li><div class="singleline-icon" ></div><span value="component3">UNDERHOOD</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="component4">TIRES</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="component5">BRAKES</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="component6">COMMENTS</span></li>
                                                    <li><div class="singleline-icon" ></div><span value="component7">BATTERY</span></li>
                                                    <!--<li><span value="reset">Reset</span></li>
                                                    <li><span value="submit">Submit</span></li>-->
                                                </ul>
                                            </div>
                                            <!-- <h3 class="uk-accordion-title uk-accordion-title-primary">Advanced</h3>
                                            <div class="uk-accordion-content">
                                                <ul id="advanced">
                                                    <li><div class="sign-icon"></div><span value="signature">Signature</span></li>

                                                </ul>
                                            </div>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <form class="uk-form-stacked" id="wizard_advanced_form" method="post" enctype="multipart/form-data" >
                            <div class="uk-width-large-8-10 content_right"  id="content_right" style="">
                                <div class="md-card">
                                    <div class="md-card-content" style="">
                                        <div id="forms" data-form_id ="1" style="width:100%;height: 100%;">
                                            <ul id="pages" style="height: 100%;">
                                                <!--<li class="rows" id="rows_1"></li>-->
                                                <?php
                                                $edFlag=1;
                                                $options=0;
                                                $formToken=$formdetails->form_content;
                                                $ftk_array=json_decode($formToken);


                                                foreach ($ftk_array as $pages) {
                                                $res_array=$pages;
                                                foreach ($res_array as $res) {

                                                $res_result=$res;
                                                $remove=count($res_result)-1;
                                                unset($res_result[$remove]);

                                                foreach ($res_result as $key=> $rows) {
                                                $row=$key;


                                                ?>
                                                <li class="rows uk-width-1-1 ui-droppable" id="rows_{{$row+1}}">
                                                    <ul id="rows_{{$row+1}}" style="height: {{$rows[0]->rowheight}}px;" class="connected" >
                                                        <?php

                                                        foreach ($rows as $index=>$cols) {
                                                        $col=$index;
                                                        if(isset($cols->choices)){
                                                            $options++;
                                                        }


                                                        ?>

                                                        <li style="height: {{$cols->rowheight}}px;" class="uk-width-1-{{count($rows)}} columns" id="columns_{{$col+1}}">

                                                            <div class="cols uk-width-1-1 {{$cols->type}}_undefined">
                                                                <div class="uk-panel config_{{$cols->type}} portlet">
                                                                    <div class="portlet-header" data-type="{{$cols->type}}" data-fieldid="{{$cols->fieldid}}">
                                                                        <!--Start -->
                                                                        @if($cols->type=="text")
                                                                                <!--<input type="text" />-->
                                                                        <div class="uk-grid">
                                                                            <div class="titl-field1 left_setting">
                                                                                <label class="title_label" style="width:100%;display:table">{{$cols->title}}</label>
                                                                                <input type="text" readonly style="display:table"/>
                                                                            </div>

                                                                            <div class="hover-icons1 right_setting hover-icons action" style="display:none;" id="edits_{{$edFlag}}">
                                                                                <span class="delete_field"></span>
                                                                                <span class="click-edit-icon" ></span>
                                                                                <span class="uncheck-grey check "></span>
                                                                                <input type="hidden" class="formfieldid" value="0" />
                                                                            </div>
                                                                        </div>
                                                                        @elseif($cols->type=="heading")
                                                                                <!-- Heading Templates-->

                                                                        <!--<input type="text" />-->
                                                                        <div class="uk-grid">
                                                                            <div class="titl-field1 left_setting">
                                                                                <label class="title_label">{{$cols->title}}</label>
                                                                            </div>
                                                                            <div class="hover-icons1 right_setting hover-icons action" style="display:none;" id="edits_{{$edFlag}}" >
                                                                                <span class="delete_field"></span>
                                                                                <span class="click-edit-icon" ></span>
                                                                                <input type="hidden" class="formfieldid" value="0" />
                                                                            </div>
                                                                        </div>

                                                                        @elseif($cols->type=="email")
                                                                                <!-- Email Controls -->

                                                                        <div class="uk-grid">
                                                                            <div class="titl-field1 left_setting">
                                                                                <label class="title_label" style="width:100%;display:table">{{$cols->title}}</label>
                                                                                <input type="email" readonly style="display:table" />
                                                                            </div>
                                                                            <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}" >
                                                                                <span class="delete_field"></span>
                                                                                <span class="click-edit-icon" ></span>
                                                                                <span class="uncheck-grey check "></span>
                                                                                <input type="hidden" class="formfieldid" value="0" />
                                                                            </div>
                                                                        </div>

                                                                        @elseif($cols->type=="number")
                                                                                <!-- Number Controls -->

                                                                        <div class="uk-grid">
                                                                            <div class="titl-field1 left_setting">
                                                                                <label class="title_label" style="width:100%;display:table">{{$cols->title}}</label>
                                                                                <input type="number" readonly style="display:table" />
                                                                            </div>
                                                                            <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}" >
                                                                                <span class="delete_field"></span>
                                                                                <span class="click-edit-icon" ></span>
                                                                                <span class="uncheck-grey check "></span>
                                                                                <input type="hidden" class="formfieldid" value="0" />
                                                                            </div>
                                                                        </div>

                                                                        <!-- Date controls -->
                                                                        @elseif($cols->type=="date")

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting">
                                                                                    <label class="title_label" style="width:100%;display:table">{{$cols->title}}</label>
                                                                                    <input type="text"  readonly style="display:table" />
                                                                                    <input type = "hidden" id="date_format"  value ="" />
                                                                                </div>
                                                                                <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}" >
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon" ></span>
                                                                                    <span class="open_options options-icon" ></span>
                                                                                    <span class="uncheck-grey check "></span>
                                                                                    <input type="hidden" class="formfieldid" value="0" />
                                                                                </div>
                                                                                <div class="options" id="choices" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <select style="padding:4px 6px;"  class="uk-form-select" name="date_format" id="date_formats">
                                                                                            <option value="MM/dd/yyyy">MM/DD/YYYY</option>
                                                                                            <option value="dd/MM/yyyy">DD/MM/YYYY</option>
                                                                                            <option value="yyyy/MM/dd">YYYY/MM/DD</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <!-- Time controls -->
                                                                        @elseif($cols->type=="time")

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting">
                                                                                    <label class="title_label" style="width:100%;display:table">{{$cols->title}}</label>
                                                                                    <input type="text" readonly style="display:table">
                                                                                    <input type = "hidden" id="time_format"  value ="" />
                                                                                </div>
                                                                                <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon" ></span>
                                                                                    <span class="open_options options-icon"></span>
                                                                                    <span class="uncheck-grey check "></span>
                                                                                    <input type="hidden" class="formfieldid" value="0" />
                                                                                </div>
                                                                                <div class="options" id="choices" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <select style="padding:4px 6px;"  class="uk-form-select" name="time_format" id="time_formats">
                                                                                            <option value="hh:mm:ss">12 Hrs</option>
                                                                                            <option value="HH:mm:ss">24 Hrs</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <!-- Signature -->
                                                                        @elseif($cols->type=="signature")

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting">
                                                                                    <label class="title_label">{{$cols->title}}</label>
                                                                                    <br/>
                                                                                    <input type="text" readonly style="display:table">
                                                                                </div>
                                                                                <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon" ></span>
                                                                                    <span class="uncheck-grey check "></span>
                                                                                    <input type="hidden" class="formfieldid" value="0" />
                                                                                </div>
                                                                            </div>

                                                                            @elseif($cols->type=="radio")
                                                                                    <!-- Radio Button Templates -->

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting">
                                                                                    <label class="title_label">{{$cols->title}}</label><br/>
                                                                                    <div class="title_radio select">
                                                                                        @if(isset($cols->choices))
                                                                                            <?php
                                                                                            $choice_array=$cols->choices;
                                                                                            ?>
                                                                                            @foreach ($choice_array as $chres)
                                                                                                <input type="radio" name="radio" value="{{$chres->title}}" /> <span class="title_value" data-optionid="0">{{$chres->title}}</span>
                                                                                            @endforeach
                                                                                        @endif

                                                                                    </div>
                                                                                </div>
                                                                                <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon" ></span>
                                                                             <span class="open_options_{{$cols->formfieldid}} options-icon" data-opt="{{$options}}"
                                                                                   data-row="{{$row+1}}"  data-column="{{$col+1}}"></span>
                                                                                    <span class="uncheck-grey check "></span>
                                                                                    <input type="hidden" class="formfieldid" value="0" />
                                                                                </div>
                                                                                <div class="options" id="choices_{{$cols->formfieldid}}" style="display:none">

                                                                                    <div class="input_fields_wrap">
                                                                                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                        </a> -->
                                                                                        <element>
                                                                                            <?php
                                                                                            $choice_array=$cols->choices;
                                                                                            ?>
                                                                                            @foreach ($choice_array as $chindex=>$chres)
                                                                                                <p>
                                                                                                    <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                           value="{{$chres->title}}"/>
                                                                                                    @if ($chindex==0)
                                                                                                        <span class="add-option add_field_button"></span>
                                                                                                    @else
                                                                                                        <span class="delete-option remove_field"></span>
                                                                                                    @endif
                                                                                                </p>
                                                                                            @endforeach
                                                                                        </element>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="{{$cols->type}}";
                                                                                //// comptField="{{$options}}";
                                                                                row_id="rows_{{$row+1}}";
                                                                                collength="{{$col+1}}";
                                                                                dialog = popup_initialize('choices_{{$cols->formfieldid}}','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_{{$cols->formfieldid}}',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                            <!--Check Box Templates -->
                                                                        @elseif($cols->type=="checkbox")
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting">
                                                                                    <label class="title_label">{{$cols->title}}</label><br/>
                                                                                    <label class="title_label1">{{$cols->subtitle}}</label>
                                                                                    <div class="title_checkbox select">
                                                                                        @if(isset($cols->choices))
                                                                                            <?php
                                                                                            $choice_array=$cols->choices;
                                                                                            ?>
                                                                                            @foreach ($choice_array as $chres)
                                                                                                <input type="checkbox" />
                                                                                                <span class="title_value" data-optionid="0">{{$chres->title}}</span>
                                                                                            @endforeach
                                                                                        @endif
                                                                                    </div>
                                                                                    <div class="options" id="choices_{{$cols->formfieldid}}" style="display:none">
                                                                                        <div class="input_fields_wrap">
                                                                                            <!--  <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                             <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                             </a> -->
                                                                                            <element>

                                                                                                @foreach ($choice_array as $chindex=>$chres)
                                                                                                    <p>
                                                                                                        <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                               value="{{$chres->title}}"/>
                                                                                                        @if ($chindex==0)
                                                                                                            <span class="add-option add_field_button"></span>
                                                                                                        @else
                                                                                                            <span class="delete-option remove_field"></span>
                                                                                                        @endif
                                                                                                    </p>
                                                                                                @endforeach

                                                                                            </element>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon" ></span>
                                                                                <span class="open_options_{{$cols->formfieldid}} options-icon" data-opt="{{$options}}"
                                                                                      data-row="{{$row+1}}"  data-column="{{$col+1}}"></span>
                                                                                    <span class="uncheck-grey check "></span>
                                                                                    <input type="hidden" class="formfieldid" value="0" />
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="{{$cols->type}}";
                                                                                //// comptField="{{$options}}";
                                                                                row_id="rows_{{$row+1}}";
                                                                                collength="{{$col+1}}";
                                                                                dialog = popup_initialize('choices_{{$cols->formfieldid}}','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_{{$cols->formfieldid}}',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                            <!-- start checkbox -->

                                                                            <!-- end checkbox -->

                                                                            @elseif($cols->type=="select")
                                                                                    <!-- Select dropdown Templates -->

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting">
                                                                                    <label class="title_label">{{$cols->title}}</label><br/>
                                                                                    <div class="title_checkbox select">
                                                                                        <select>
                                                                                            @if(isset($cols->choices))
                                                                                                <?php
                                                                                                $choice_array=$cols->choices;
                                                                                                ?>
                                                                                                @foreach ($choice_array as $chres)
                                                                                                    <option>
                                <span class="title_value" data-optionid="0">
                                {{$chres->title}}
                                </span>
                                                                                                    </option>
                                                                                                @endforeach
                                                                                            @endif
                                                                                        </select>
                                                                                    </div>
                                                                                    <div class="options" id="choices_{{$cols->formfieldid}}" style="display:none">
                                                                                        <div class="input_fields_wrap">
                                                                                            <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                            </a> -->
                                                                                            <element>
                                                                                                @foreach ($choice_array as $chindex=>$chres)
                                                                                                    <p>
                                                                                                        <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                               value="{{$chres->title}}"/>
                                                                                                        @if ($chindex==0)
                                                                                                            <span class="add-option add_field_button"></span>
                                                                                                        @else
                                                                                                            <span class="delete-option remove_field"></span>
                                                                                                        @endif
                                                                                                    </p>
                                                                                                @endforeach

                                                                                            </element>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}" >
                                                                                    <input type="hidden" class="formfieldid" value="0" />
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon" ></span>
                                                                               <span class="open_options_{{$cols->formfieldid}} options-icon" data-opt="{{$options}}"
                                                                                     data-row="{{$row+1}}"  data-column="{{$col+1}}"></span>
                                                                                    <span class="uncheck-grey check "></span>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="{{$cols->type}}";
                                                                                //// comptField="{{$options}}";
                                                                                row_id="rows_{{$row+1}}";
                                                                                collength="{{$col+1}}";
                                                                                dialog = popup_initialize('choices_{{$cols->formfieldid}}','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_{{$cols->formfieldid}}',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                            @elseif($cols->type=="textarea")
                                                                                    <!-- TextArea Templates -->

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting">
                                                                                    <label class="title_label">{{$cols->title}}</label><br/>
                                                                                    <textarea style="resize: none;height: 40px; width: 200px;" readonly></textarea>
                                                                                </div>
                                                                                <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}" >
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon" ></span>
                                                                                    <span class="uncheck-grey check "></span>
                                                                                    <input type="hidden" class="formfieldid" value="0" />
                                                                                </div>
                                                                            </div>

                                                                            @elseif($cols->type=="file")
                                                                                    <!-- File Select Templates -->

                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting">
                                                                                    <label class="title_label">{{$cols->title}}</label>

                                                                                    <input type="file" class="{{$cols->filename}} files" name="{{$cols->filename}}"   />@if(isset($cols->filepath) && ($cols->filepath!='undefined'))
                                                                                        @if($cols->filepath!='')
                                                                                            <img src="{{URL::asset('mighty/images/template/')}}/{{$cols->filepath}}" style="width: 20px;
height: 20px;"/>
                                                                                        @endif
                                                                                    @endif
                                                                                    <p>
                                                                                        <input type="text" class="height" name="height"  style="height: 22px;width: 78px;"
                                                                                               maxlength="3" minlength="1" value="{{$cols->height}}" required/><span style="color:red;font-size:10px;">Height</span>
                                                                                        <input type="text" class="width" name="width"  style="height: 22px;width: 78px;"
                                                                                               maxlength="3" minlength="1" value="{{$cols->width}}" required/><span style="color:red;font-size:10px;">Width</span>
                                                                                    </p>

                                                                                </div>
                                                                                <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}" >
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon" ></span>
                                                                                    <span class="uncheck-grey check "></span>
                                                                                    <input type="hidden" class="formfieldid" value="0" />
                                                                                    @if(isset($cols->filepath))
                                                                                        <input type="hidden" class="filepath" value="{{$cols->filepath}}" />
                                                                                    @endif
                                                                                </div>
                                                                            </div>

                                                                            @elseif($cols->type=="placepicker")
                                                                                    <!-- Place picker -->

                                                                            <div class="uk-grid">
                                                                                <div class="uk-width-1-2">
                                                                                    <label class="title_label">{{$cols->title}}</label><br/>
                                                                                </div>
                                                                                <div class="uk-width-1-2 action" style="display: none;" id="edits_{{$edFlag}}" >
                                                                                    <span class="delete_field"></span>
                                                                                    <!--<i class="uk-icon-edit edit_field"></i>--> <input type="hidden" class="formfieldid" value="0" />
                                                                                    <input  type="checkbox" id="placepicker_check" class="required" data-type= class="required" data-type=/>Required
                                                                                </div>
                                                                            </div>

                                                                        @elseif($cols->type=="line")
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting">
                                                                                    <label class="title_label" style="display: none;">Comment Line</label>
                                                                                    <hr class="cmdline">
                                                                                </div>
                                                                                <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <input class="formfieldid" value="0" type="hidden">
                                                                                </div>
                                                                            </div>
                                                                        @elseif($cols->type=="textwithline")
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field1 left_setting">
                                                                                    <label class="title_label">{{$cols->title}}</label>
                                                                                    <hr class="cmdline">
                                                                                </div>
                                                                                <div class="hover-icons1 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon"></span>
                                                                                    <input class="formfieldid" value="0" type="hidden">
                                                                                </div>
                                                                            </div>
                                                                        @elseif($cols->type=="emptyspace")
                                                                            <div class="uk-grid">
                                                                                <div class="left_setting">
                                                                                    <label class="title_label" style="display: none;">Empty space</label><br/>
                                                                                </div>
                                                                                <div class="hover-icons action right_setting" style="display: none;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <input type="hidden" class="formfieldid" value="0"/>
                                                                                </div>
                                                                            </div>
                                                                        @elseif($cols->type=="component1")
                                                                            <div class="uk-grid">
                                                                                <div class="titl-field2 left_setting inspectionTable">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label">{{$cols->title}}</label><br/> </div>
                                                                                    <div class="title_component1 select">

                                                                                        <?php
                                                                                        $choice_array=$cols->choices;
                                                                                        ?>
                                                                                        @foreach ($choice_array as $chres)
                                                                                            <div class="clear row1">
                                                                                                <input type="hidden" name="component1"/>
                                                                                                <span class="optionbox" @if($cols->lrtype==1) style="float:right" @else style="float:left" @endif ><b class="{{$imgclrg}}"></b><b class="{{$imgclry}}"></b><b class="{{$imgclrr}}"></b></span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" >{{$chres->title}}</span>
                                                                                            </div>
                                                                                        @endforeach

                                                                                    </div>
                                                                                    <div class="options" id="choices_{{$cols->formfieldid}}" style="display:none">
                                                                                        <div class="input_fields_wrap">
                                                                                            <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                            </a> -->
                                                                                            <element>
                                                                                                @foreach ($choice_array as $chindex=>$chres)
                                                                                                    <p>
                                                                                                        <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                               value="{{$chres->title}}"/>
                                                                                                        @if ($chindex==0)
                                                                                                            <span class="add-option add_field_button"></span>
                                                                                                        @else
                                                                                                            <span class="delete-option remove_field"></span>
                                                                                                        @endif
                                                                                                    </p>
                                                                                                @endforeach
                                                                                            </element>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <input type="hidden" style="display:none" name="component1_style" id="component1_style" value="{{$cols->lrtype}}" />
                                                                                <div class="hover-icons2 right_setting hover-icons action" style="display: none;" id="edits_{{$edFlag}}" >
                                                                                    <input type="hidden" class="formfieldid" value="0" />
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon" ></span>
                                                                               <span class="open_options_{{$cols->formfieldid}} options-icon" data-opt="{{$options}}"
                                                                                     data-row="{{$row+1}}"  data-column="{{$col+1}}"></span>
                                                                                    <span class="uncheck-grey check "></span>
                                                                                    <span class="lrchange" data-vals="component1_style" style="cursor: pointer"></span>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="{{$cols->type}}";
                                                                                //// comptField="{{$options}}";
                                                                                row_id="rows_{{$row+1}}";
                                                                                collength="{{$col+1}}";
                                                                                dialog = popup_initialize('choices_{{$cols->formfieldid}}','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_{{$cols->formfieldid}}',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                        @elseif($cols->type=="component2")
                                                                            <div class="uk-grid ">
                                                                                <div class="titl-field2 left_setting inspectionTable">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label">{{$cols->title}}</label><br/> </div>
                                                                                    <div class="title_component2 selects">
                                                                                        <div class="clear row1">
                                                                                            <input type="hidden" name="component2"/>
                                                                                            <label class="title_label1">{{$cols->subtitle}}</label>
                                                                                        </div>
                                                                                    </div>
                                                                                    <input type="hidden" style="display:none" name="component2_style" id="component2_style" value="{{$cols->lrtype}}" />
                                                                                    <div class="title_component2 selects">
                                                                                        <div class="clear row1">
                                                                                            <input type="hidden" name="component2"/>
                            <span class="alignCenter" style="display:block; height:120px;">
                                @if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!=''))
                                    <img src="{{URL::asset('mighty/images/template/')}}/{{$cols->filepath}}"  alt="" style="max-width: 247px;max-height:116px;" />
                                @else
                                    <img src="{{URL::asset('mighty/images/car-top.png')}}" alt="" style="max-width: 247px;max-height:116px;">
                                @endif

										</span>
                                                                                            <input class="{{$cols->filename}} files" name="{{$cols->filename}}" type="file">[247 x 116]
                                                                                        </div>
                                                                                    </div>
                                                                                    @if(isset($cols->filepath))
                                                                                        <input type="hidden" class="filepath" value="{{$cols->filepath}}" />
                                                                                    @endif
                                                                                    <div class="title_component2 select">

                                                                                        <?php
                                                                                        $choice_array=$cols->choices;
                                                                                        ?>
                                                                                        @foreach ($choice_array as $chres)
                                                                                            <div class="clear row1">
                                                                                                <input type="hidden" name="component2"/>
                                                                                                <span class="optionbox" @if($cols->lrtype==1) style="float:right" @else style="float:left" @endif ><b class="{{$imgclrg}}"></b><b class="{{$imgclry}}"></b><b class="{{$imgclrr}}"></b></span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" >{{$chres->title}}</span>
                                                                                            </div>
                                                                                        @endforeach

                                                                                    </div>

                                                                                </div>

                                                                                <div class="hover-icons2 hover-icons action right_setting" style="display: none;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon"></span>
                                                                             <span class="open_options_{{$cols->formfieldid}} options-icon" data-opt="{{$options}}"
                                                                                   data-row="{{$row+1}}"  data-column="{{$col+1}}"></span>

                                                                                    <span class="uncheck-grey check "></span>
                                                                                    <span class="lrchange" data-vals="component2_style" style="cursor: pointer"></span>
                                                                                    <input type="hidden" class="formfieldid" value="0"/>
                                                                                </div>
                                                                                <div class="options" id="choices_{{$cols->formfieldid}}" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                        </a> -->
                                                                                        <element>

                                                                                            @foreach ($choice_array as $chindex=>$chres)
                                                                                                <p>
                                                                                                    <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                           value="{{$chres->title}}"/>
                                                                                                    @if ($chindex==0)
                                                                                                        <span class="add-option add_field_button"></span>
                                                                                                    @else
                                                                                                        <span class="delete-option remove_field"></span>
                                                                                                    @endif
                                                                                                </p>
                                                                                            @endforeach

                                                                                        </element>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="{{$cols->type}}";
                                                                                //// comptField="{{$options}}";
                                                                                row_id="rows_{{$row+1}}";
                                                                                collength="{{$col+1}}";
                                                                                dialog = popup_initialize('choices_{{$cols->formfieldid}}','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_{{$cols->formfieldid}}',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                        @elseif($cols->type=="component3")
                                                                            <div class="uk-grid ">
                                                                                <div class="titl-field2 left_setting inspectionTable">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label">{{$cols->title}}</label><br/> </div>
                                                                                    <div class="title_component3 select">
                                                                                        <?php
                                                                                        $choice_array=$cols->choices;
                                                                                        $choicecount=count($choice_array)-3;

                                                                                        ?>
                                                                                        @foreach ($choice_array as $index=>$chres)
                                                                                            @if($choicecount>$index)
                                                                                                <div class="clear row1">
                                                                                                    <input type="hidden" name="component3"/>
                                                                                                    <span class="optionbox"  ><b class="{{$imgclrg}}"></b><b class="{{$imgclry}}"></b><b class="{{$imgclrr}}"></b></span>
                                                                                                    <span class="inspectionTxt title_value" data-optionid="0" >{{$chres->title}}</span>
                                                                                                </div>
                                                                                            @endif
                                                                                        @endforeach


                                                                                    </div>
                                                                                    <div class="title_component3 selects">
                                                                                        <div class="clear row1">
                                                                                            <input type="hidden" name="component3"/>
                                                                                            <p>
                                                                                                <span ><b class="{{$imgclrg}}"></b><b class="{{$imgclry}}"></b><b class="{{$imgclrr}}"></b></span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" >{{$choice_array[count($choice_array)-3]->title}}</span>
                                                                                            </p><p>
                                                                                                <span><b class="{{$imgclrg}}"></b><b class="{{$imgclry}}"></b><b class="{{$imgclrr}}"></b></span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" >{{$choice_array[count($choice_array)-2]->title}}</span>
                                                                                            <div style="float: right;margin-top: -23%;width: 91px;">

                                                                                                @if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!=''))
                                                                                                    <img src="{{URL::asset('mighty/images/template/')}}/{{$cols->filepath}}" style="max-width: 92px;max-height: 60px;" />
                                                                                                @else
                                                                                                    <img src="{{URL::asset('mighty/images/Might99171.PNG')}}" style="max-width: 92px;max-height: 60px;">
                                                                                                @endif
                                                                                                <input type="file" class="{{$cols->filename}} files" name="{{$cols->filename}}" />[92 x 62]
                                                                                                @if(isset($cols->filepath))
                                                                                                    <input type="hidden" class="filepath" value="{{$cols->filepath}}" />
                                                                                                @endif

                                                                                            </div>
                                                                                            </p><p>
                                                                                                <span><b class="{{$imgclrg}}"></b><b class="{{$imgclry}}"></b><b class="{{$imgclrr}}"></b></span>
                                                                                                <span class="inspectionTxt title_value" data-optionid="0" >{{$choice_array[count($choice_array)-1]->title}}</span>
                                                                                            </p>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="hover-icons2 hover-icons action right_setting" style="display: none;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon"></span>
                                                                                <span class="open_options_{{$cols->formfieldid}} options-icon" data-opt="{{$options}}"
                                                                                      data-row="{{$row+1}}"  data-column="{{$col+1}}"></span>
                                                                                    <span class="uncheck-grey check "></span>

                                                                                    <input type="hidden" class="formfieldid" value="0"/>
                                                                                </div>
                                                                                <div class="options" id="choices_{{$cols->formfieldid}}" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                        </a> -->
                                                                                        <element>

                                                                                            @foreach ($choice_array as $index=>$chres)
                                                                                                @if($choicecount>$index)
                                                                                                    <p>
                                                                                                        <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                               value="{{$chres->title}}"/>
                                                                                                        @if ($index==0)
                                                                                                            <span class="add-option add_field_button"></span>
                                                                                                        @else
                                                                                                            <span class="delete-option remove_field"></span>
                                                                                                        @endif
                                                                                                    </p>
                                                                                                @endif
                                                                                            @endforeach

                                                                                        </element>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <script>
                                                                                type ="{{$cols->type}}";
                                                                                //// comptField="{{$options}}";
                                                                                row_id="rows_{{$row+1}}";
                                                                                collength="{{$col+1}}";
                                                                                dialog = popup_initialize('choices_{{$cols->formfieldid}}','',type,row_id,"columns_"+collength);
                                                                                popup.open_dialog('open_options_{{$cols->formfieldid}}',dialog);
                                                                                popup.options_open(type,dialog);
                                                                            </script>
                                                                        @elseif($cols->type=="component4")
                                                                            <div class="uk-grid ">
                                                                                <div class="left_setting inspectionTable " style="width: 97%;border-bottom: 1px solid #000;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label">{{$cols->title}}</label><br/> </div>
                                                                                    <div class="title_component4 select">
                                                                                        <div class="clear row1x">
                                                                                            <input type="hidden" name="component4"/>
                                                                                            <span class="comp4boxl spanlable title_label1"  >{{$cols->subtitle}}</span>
                                                                                            <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$cols->subtitle}}" />
                                                                                            <div class="clear paddingBottom" style="width:375px; height:30px;">
                                                                                                <!-- start -->
                                                                                                <div class="tire-condition">
	<span style="width:135px; float:left;">
	<b style="margin-left: 24px;" class="{{$imgclrg}}"></b>
<span class="comp4boxl fontF option1"  >{{$cols->option1}}</span>
<input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$cols->option1}}" />
	</span>
	<span style="width:120px; float:left;">
	<b class="{{$imgclry}}"></b>
	 <span class="comp4boxl fontF option2"  >{{$cols->option2}}</span>
<input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$cols->option2}}" />
	</span>
	<span style="width:117px; float:left;">
	<b class="{{$imgclrr}}"></b>

        <span class="comp4boxl fontF option3"  >{{$cols->option3}}</span>
<input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$cols->option3}}" />
	</span></div>
                                                                                                <?php
                                                                                                $choice_array=$cols->cm4rows;
                                                                                                ?>
                                                                                                <div class="tire-lflr">
                                                                                                    <div class="comp4rows"><div class="bordernone interior_inspec1 interior_inspecLeft">
<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">

<span style="display:block;width:20px;font-weight: bold;" class="comp4boxl fontF title_value4"  >{{$choice_array[0][0][0]->title}}</span>
<input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][0][0]->title}}" />
</span>

                                                                                                            <span class="txt_bold_lower_case comp4boxl fontF title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px" >{{$choice_array[0][0][1]->title}}</span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][0][1]->title}}" />
                                                                                                            <span style="display:block;float:right;"><b class="{{$smlimgclrg}}"></b><b class="{{$smlimgclry}}"></b><b class="{{$smlimgclrr}}"></b></span>
                                                                                                        </div>
                                                                                                        <div class="bordernone interior_inspec1 interior_inspecRight">
<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
<span style="display:block;width:20px;font-weight: bold;" class="comp4boxl fontF title_value4"  >{{$choice_array[0][0][2]->title}}</span>
<input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][0][2]->title}}" />
</span>
                                                                                                            <span class="comp4boxl txt_bold_lower_case title_res4" style="position:relative; left:-5px;float:right;display:block;width:67px">{{$choice_array[0][0][3]->title}}</span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][0][3]->title}}" />
                                                                                                            <span style="display:block;float:right;"><b class="{{$smlimgclrg}}"></b><b class="{{$smlimgclry}}"></b><b class="{{$smlimgclrr}}"></b></span>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="comp4rows">
                                                                                                        <div class="bordernone interior_inspec1 interior_inspecLeft">
<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
<span style="display:block;width:20px;font-weight: bold;" class="comp4boxl fontF title_value4"  >{{$choice_array[0][1][0]->title}}</span>
<input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][1][0]->title}}" />
</span>

                                                                                                            <span class="comp4boxl txt_bold_lower_case title_res4 " style="position:relative; left:-5px;float:right;display:block;width:67px">{{$choice_array[0][1][1]->title}}</span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][1][1]->title}}" />
                                                                                                            <span style="display:block;float:right;"><b class="{{$smlimgclrg}}"></b><b class="{{$smlimgclry}}"></b><b class="{{$smlimgclrr}}"></b></span>
                                                                                                        </div>
                                                                                                        <div class="bordernone interior_inspec1 interior_inspecRight">
<span class="txt_bold_lower_case" style="float:left;margin-right:4px; display:block; width:20px;text-align:right;">
<strong style="display:block;width:20px;"> <span class="comp4boxl fontF title_value4" style="position:relative; left:-5px;float:right;display:block;width:67px">{{$choice_array[0][1][2]->title}}</span><input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][1][2]->title}}" /></strong>


</span>
                                                                                                            <span class="comp4boxl txt_bold_lower_case title_res4 " style="position:relative; left:-5px;float:right;display:block;width:67px">{{$choice_array[0][1][3]->title}}</span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][1][3]->title}}" />
                                                                                                            <span style="display:block;float:right;"><b class="{{$smlimgclrg}}"></b><b class="{{$smlimgclry}}"></b><b class="{{$smlimgclrr}}"></b></span>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <!-- end -->
                                                                                            </div></div>
                                                                                        <div class="clear row1x">
                                                                                            <div class="comp4rows" style="float: left">
                               <span style="padding:0px;width:100px;float:left;margin-top: 28px;">
                                    @if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!=''))
                                       <img src="{{URL::asset('mighty/images/template/')}}/{{$cols->filepath}}"   style="max-height: 181px;max-width: 72px;" />
                                   @else
                                       <img src="{{URL::asset('mighty/images/rght_tire.png')}}" style="max-height: 200px;max-width: 100px;">
                                   @endif
                                   <input type="file" class="{{$cols->filename}} files" name="{{$cols->filename}}" />
								</span>
                                                                                                @if(isset($cols->filepath))
                                                                                                    <input type="hidden" class="filepath" value="{{$cols->filepath}}" />
                                                                                                @endif
                                                                                                <div class="bordernone interior_inspec padding_reset lessWidth" style="padding:0px;float:right; padding-top:15px;width:100px !important;">
                                                                                                    <div style="height:30px;margin-bottom:10px;width: 99px;">
                                                                                                        <span class="comp4boxl comp4text" colspan="2"  >{{$choice_array[0][2][0]->title}}</span>
                                                                                                        <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][2][0]->title}}" />
                                                                                                    </div>
                                                                                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
                                                                                                        <span style="width:75px; display:block;float:right;"><b class="{{$smlimgclrg}}"></b><b class="{{$smlimgclry}}"></b><b class="{{$smlimgclrr}}"></b></span>
                      						<span width="29" class="txt_bold txtLeft">

                                                <span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;">{{$choice_array[0][2][1]->title}}</span>
                                       <input type="text"  class="comp4boxi" style="display: none;font-size: 10px; " value="{{$choice_array[0][2][1]->title}}" />

                      						</span>

                                                                                                    </div>

                                                                                                    <div class="clear" id="c2" style="text-align:right;width:100px; margin-bottom:10px;height:20px;">
                                                                                                        <span style="width:75px; display:block;float:right;"><b class="{{$smlimgclrg}}"></b><b class="{{$smlimgclry}}"></b><b class="{{$smlimgclrr}}"></b></span>
                      						<span class="txt_bold txtLeft">
                      							                   <span class="comp4boxl " colspan="2"  >{{$choice_array[0][2][2]->title}}</span>
                                       <input type="text"  class="comp4boxi" style="display: none;font-size: 10px; " value="{{$choice_array[0][2][2]->title}}" />
                      						</span>

                                                                                                    </div>

                                                                                                    <div class="clear" id="c3" style="text-align:right;width:100px; margin-bottom:10px;height:20px;">
                                                                                                        <span style="width:75px; display:block;float:right;"><b class="{{$smlimgclrg}}"></b><b class="{{$smlimgclry}}"></b><b class="{{$smlimgclrr}}"></b></span>
                      						<span class="txt_bold txtLeft">
                      							<span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;">{{$choice_array[0][2][3]->title}}</span>
                                       <input type="text"  class="comp4boxi" style="display: none; font-size: 10px;" value="{{$choice_array[0][2][3]->title}}" />
                      						</span>

                                                                                                    </div>
                                                                                                    <div class="clear" id="c4" style="text-align:right;width:100px; margin-bottom:10px;height:20px;">
                                                                                                        <span style="width:75px; display:block;float:right;"><b class="{{$smlimgclrg}}"></b><b class="{{$smlimgclry}}"></b><b class="{{$smlimgclrr}}"></b></span>
                      						<span class="txt_bold txtLeft">
                      							<span class="comp4boxl" colspan="2" style="font-weight: bold;padding:0px;">{{$choice_array[0][2][4]->title}}</span>
                                       <input type="text"  class="comp4boxi" style="display: none;font-size: 10px; " value="{{$choice_array[0][2][4]->title}}" />
                      						</span>

                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div style="float: left">
                                                                                                <div class="comp4rows interior_inspec" style="/* height:215px; */border-right: 2px solid #0e62af !important;border-left: 2px solid #0e62af !important;padding:0px;width: 124px;padding:0 3px;float:left;">
                                                                                                    <div cellspacing="0" class="bordernone padding_reset" style="">
                                                                                                        <div style="text-align:center;margin-top:15px;">
                                                                                                            <span class="comp4boxl comp4text" colspan="2" >{{$choice_array[0][3][0]->title}}</span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][3][0]->title}}" />
                                                                                                        </div>
                                                                                                        <div id="redBlock">
                              				<span style="float:left; width:16px;margin-right:2px;">
                              					<b class="{{$smlimgclrr}}"></b>
                              				</span>

                                                                                                            <span class="comp4boxl comp4text" colspan="2"  >{{$choice_array[0][3][1]->title}}</span>
                                                                                                            <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][3][1]->title}}" />
                                                                                                            <input type="file" class="imagesecond" name="{{$cols->imagesecond}}" />
                                                                                                            @if(isset($cols->imgsecondpath))
                                                                                                                <input type="hidden" class="imgsecondpath" value="{{$cols->imgsecondpath}}" />
                                                                                                            @endif
                                                                                                            <div id="imgBottomMid" class="imgBottomMid" style="width:40px; height:36px;">
                                                                                                                @if(isset($cols->imgsecondpath) && ($cols->imgsecondpath!='undefined' && $cols->imgsecondpath!=''))
                                                                                                                    <img src="{{URL::asset('mighty/images/template/')}}/{{$cols->imgsecondpath}}" style="max-height: 36px;max-width: 40px;" />
                                                                                                                @else
                                                                                                                    <img src="{{URL::asset('mighty/images/symbol.png')}}" alt="symbol" style="max-width:40px;max-height: 36px;" id="image">
                                                                                                                @endif

                                                                                                            </div>

                                                                                                        </div>
                                                                                                        <div class="bordernone interior_inspec" style="width: 90px;">
                                                                                                            <div class="beforeAfter">
                                                                                                                <span  class="comp4boxl"  style="position:relative; left:11px;">{{$choice_array[0][3][2]->title}}</span>
                                                                                                                <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][3][2]->title}}" />
                                                                                                                &nbsp;&nbsp;

                                                                                                                <span  class="comp4boxl"  style="position:relative; left:11px;">{{$choice_array[0][3][3]->title}}</span>
                                                                                                                <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][3][3]->title}}" />

                                                                                                            </div>
                                                                                                            <div style="width:100%;" class="clear">
                                                                                                                <div style="float:left;width:20px;">
                                 				<span style="width:20px;display:block; float:left; height:27px;">
                                 			<span class="comp4boxl txt_bold" colspan="2" style="">{{$choice_array[0][3][4]->title}}</span>
                                           <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][3][4]->title}}" />

                                 				</span>
								 				<span style="width:20px;display:block; float:left; height:27px;">
								 					<span class="comp4boxl txt_bold" colspan="2" style="">{{$choice_array[0][3][5]->title}}</span>
                                           <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][3][5]->title}}" />
								 				</span>
                                                                                                                </div>
                                                                                                                <div style="width:30px; float:left;margin-right:3px;">
                                                                                                                    <span class="white_box">&nbsp;</span><br>
                                                                                                                    <span class="white_box">&nbsp;</span></div>
                                                                                                                <span class="white_box_rectangle">&nbsp;</span>
                                                                                                            </div>
                                                                                                            <div style="width:100%;" class="clear">
                                                                                                                <div style="float:left;width:20px;">
                                 					<span style="width:20px;display:block; float:left; height:27px;">
                                 						<span class="comp4boxl txt_bold" colspan="2" style="">{{$choice_array[0][3][6]->title}}</span>
                                           <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][3][6]->title}}" />
                                 					</span>
								 					<span style="width:20px;display:block; float:left; height:27px;">
								 					<span class="comp4boxl txt_bold" colspan="2" style="">{{$choice_array[0][3][7]->title}}</span>
                                           <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][3][7]->title}}" />
								 					</span>
                                                                                                                </div>
                                                                                                                <div style="width:30px; float:left;margin-right:3px;">
                                                                                                                    <span class="white_box">&nbsp;</span><br>
                                                                                                                    <span class="white_box">&nbsp;</span>
                                                                                                                </div>&nbsp;
                                                                                                                <span class="white_box_rectangle">&nbsp;</span>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div style="float: left">
                                                                                                <div class="comp4rows interior_inspec" style="padding:0px;width:74px;float:left; padding:0 3px;">
                                                                                                    <div style="margin-top:15px;">

                                                                                                        <span class="comp4boxl titleFont" colspan="2" style="padding:0px;word-wrap: break-word !important;">{{$choice_array[0][4][0]->title}}</span>
                                                                                                        <input type="text"  class="comp4boxi" style="display:none;font-size: 10px;" value="{{$choice_array[0][4][0]->title}}" />

                                                                                                    </div>
                                                                                                    <div class="bordernone interior_inspec" style="width:80px;">
                                                                                                        <div class="clear" id="b1" style="height:20px; margin-bottom:5px;">
                                                                                                            <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                                                                                            <span class="comp4boxl txtFont" style="vertical-align:-3px;">{{$choice_array[0][4][1]->title}}</span>
                                                                                                            <input  class="comp4boxi" name="editComp_65" value="{{$choice_array[0][4][1]->title}}" style="width:45px;display:none;font-size: 10px;" maxlength="9" type="text">
                                                                                                        </div>
                                                                                                        <div class="clear" id="b2" style="height:20px; margin-bottom:5px;">
                                                                                                            <span class="white_box_square" style="float:left;margin-right:5px;"></span>
                                                                                                            <span class="comp4boxl txtFont"  style="vertical-align:-3px;">{{$choice_array[0][4][2]->title}}</span>
                                                                                                            <input class="comp4boxi" name="editComp_66" value="{{$choice_array[0][4][2]->title}}" style="width:45px;display:none;font-size: 10px;" maxlength="9" type="text">
                                                                                                        </div>
                                                                                                        <div class="clear" id="b3" style="height:20px; margin-bottom:5px;">
                                                                                                            <span><span class="white_box_square" style="float:left;margin-right:5px;"></span> </span>
                                                                                                            <span class="txtFont comp4boxl" id="comp_67" style="vertical-align:-3px;">{{$choice_array[0][4][3]->title}}</span>
                                                                                                            <input class="comp4boxi" name="editComp_67" value="{{$choice_array[0][4][3]->title}}" style="width:45px;display:none;font-size: 10px;" maxlength="9" type="text">
                                                                                                        </div>
                                                                                                        <div class="clear" id="b4" style="height:20px; margin-bottom:5px;">
                                                                                                            <span class="white_box_square" style="float:left;vertical-align:-3px;margin-right:5px;"></span>
                                                                                                            <span class="txtFont comp4boxl">{{$choice_array[0][4][4]->title}}</span>
                                                                                                            <input class="comp4boxi"  value="{{$choice_array[0][4][4]->title}}" style="width:45px;display:none;font-size: 10px;" maxlength="9" type="text">
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>

                                                                                    </div>
                                                                                </div>
                                                                                <div class="hover-icons action right_setting" style="display: none;width: 3%;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icons"></span>
                                                                                    <a class="click-upd-icons" style="float:right;display:none">
                                                                                        <img id="iok" src="{{URL::asset('mighty/images/iok.jpg')}}" height="17px" width="16px">
                                                                                    </a>
                                                                                    <span style="display:none;" class="open_options options-icon"></span>
                                                                                    <!--  <span class="uncheck-grey check "></span>-->
                                                                                    <input type="hidden" class="formfieldid" value="0"/>
                                                                                </div>
                                                                                <div class="options" id="choices" style="display:none">
                                                                                    <div class="input_fields_wrap">
                                                                                        <!-- <a class="add_field_button md-btn md-btn-primary" style="min-width:0px;min-height:0px;border-radius:51px;padding:0px;">
                                                                                            <img src="/assets/assets/img/add_circle_white_48dp.png" style="width:30px;" class="">
                                                                                        </a> -->
                                                                                        <element>
                                                                                            <p>
                                                                                                <input type="text" name="select[]" class="select_label" data-optionid="0"
                                                                                                       value="Brakes (Pads / Shoes)"/>
                                                                                                <span class="add-option add_field_button"></span>
                                                                                            </p>
                                                                                        </element>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        @elseif($cols->type=="component5")
                                                                            <div class="uk-grid ">
                                                                                <div class="left_setting inspectionTable" style="width: 88%;border-bottom: 1px solid #000;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label">{{$cols->title}}</label><br/> </div>
                                                                                    <div class="title_component5 select">
                                                                                        <div class="clear " style="border-bottom:0px;">
                                                                                            <div style="padding: 0px 0px 0px 21px; border:0px;width:161px; float:left;">
                                                                                                <div class="bordernone interior_inspec">
                                                                                                    <div class="alignCenter clear paddingBottom" style="width:360px;">
                                                                                                        <span class="comp4boxl spanlable title_label1"  >{{$cols->subtitle}}</span>
                                                                                                        <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="{{$cols->subtitle}}" />
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="clear paddingBottom" style="width:375px; height:30px;">

<span class="clear"><b class="{{$imgclrg}}"></b>
<span class="txtFont comp4boxl option1" style="display:block;">{{$cols->option1}}</span>
      <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="{{$cols->option1}}" />
</span>
                                                                                                    <br><span class="clear"><b class="{{$imgclry}}"></b>
<span class="txtFont comp4boxl option2" style="display:block;" >{{$cols->option2}}</span>
      <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="{{$cols->option2}}" />
</span>
                                                                                                    <br><span class="clear"><b class="{{$imgclrr}}"></b>
<span class="txtFont comp4boxl option3" style="display:block;"  >{{$cols->option3}}</span>
      <input type="text"  class="comp4boxi" style="display:none; height:30px;" value="{{$cols->option3}}" />
</span>
                                                                                                </div>
                                                                                                <div id="img" style="float: left;width: 70px;height: 70px;position: absolute;top: 18px;margin-left: 246px;; " align="center">

               		 	<span style=" position:relative;">
                             @if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!=''))
                                <img src="{{URL::asset('mighty/images/template/')}}/{{$cols->filepath}}" style="margin-top: 21px;position:relative;top:20px;max-height: 95px;
max-width: 85px; " alt=""/>
                            @else
                                <img src="{{URL::asset('mighty/images/inspect_Brakes.png')}}" style="position:relative;top:20px;max-height: 95px;
max-width: 85px; " alt="">
                            @endif

                            <input style="margin-top: 32px;" type="file" class="{{$cols->filename}} files" name="{{$cols->filename}}" />
                                        Change Image[205 x 196]
                            @if(isset($cols->filepath))
                                <input type="hidden" class="filepath" value="{{$cols->filepath}}" />
                            @endif
						</span>
                                                                                                </div>
                                                                                                <?php
                                                                                                $choice_array=$cols->choices;
                                                                                                ?>
                                                                                                <div style="height:162px;">
                                                                                                    <div class="clear" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
<span style="width:75px; display:block;float:right;">
<b class="{{$smlimgclrg}}"></b>
<b class="{{$smlimgclry}}"></b>
<b class="{{$smlimgclrr}}"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;">{{$choice_array[0]->title}}</span>
<input class="comp4boxi" style="display: none;" value="{{$choice_array[0]->title}}" type="text">
</span>
                                                                                                    </div>
                                                                                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
<span style="width:75px; display:block;float:right;">
<b class="{{$smlimgclrg}}"></b>
<b class="{{$smlimgclry}}"></b>
<b class="{{$smlimgclrr}}"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;">{{$choice_array[1]->title}}</span>
<input class="comp4boxi" style="display: none;" value="{{$choice_array[1]->title}}" type="text">
</span>
                                                                                                    </div>
                                                                                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
<span style="width:75px; display:block;float:right;">
<b class="{{$smlimgclrg}}"></b>
<b class="{{$smlimgclry}}"></b>
<b class="{{$smlimgclrr}}"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;">{{$choice_array[2]->title}}</span>
<input class="comp4boxi" style="display: none;" value="{{$choice_array[2]->title}}" type="text">
</span>
                                                                                                    </div>
                                                                                                    <div class="clear" id="c1" style="margin-top: 20px;text-align:right;width:100px; margin-bottom:10px;height:20px;">
<span style="width:75px; display:block;float:right;">
<b class="{{$smlimgclrg}}"></b>
<b class="{{$smlimgclry}}"></b>
<b class="{{$smlimgclrr}}"></b></span>
<span width="29" class="txt_bold txtLeft">
<span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;">{{$choice_array[3]->title}}</span>
<input class="comp4boxi" style="display: none;" value="{{$choice_array[3]->title}}" type="text">
</span>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="clear" style="width:400px;">
							<span class="fontF" style="float:left;display:block; margin-left:11px;"> <strong>
                                    <span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;">{{$choice_array[4]->title}}</span>
                                    <input class="comp4boxi" style="display: none;" value="{{$choice_array[4]->title}}" type="text">
                                </strong>

					  	</span>
					  	<span style="padding:0px;width:150px;float:left;display:block;margin-right:5px;margin-left:5px;">
							<div id="imgBottomLast" class="imgBottomLast" style="margin-top:10px;width: 150px;" align="center">
                                @if(isset($cols->imgsecondpath) && ($cols->imgsecondpath!='undefined' && $cols->imgsecondpath!=''))
                                    <img src="{{URL::asset('mighty/images/template/')}}/{{$cols->imgsecondpath}}"alt="brands" style="max-height: 45px;max-width: 150px;" id="image" />
                                @else
                                    <img src="{{URL::asset('mighty/images/brands.png')}}" alt="brands" style="max-height: 45px;max-width: 150px;" id="image">
                                @endif


                            </div><input type="file" class="imagesecond" name="{{$cols->imagesecond}}" />Change Image</a>[150 x 45]
 						</span>
                                                                                                    @if(isset($cols->imgsecondpath))
                                                                                                        <input type="hidden" class="imgsecondpath" value="{{$cols->imgsecondpath}}" />
                                                                                                    @endif
                                                                                                    <span class="fontF" style="float:left;display:block"> <strong>
                                                                                                            <span class="comp4boxl title_value" colspan="2" style="font-weight: bold; padding: 0px; display: block;">{{$choice_array[5]->title}}</span>
                                                                                                            <input class="comp4boxi" style="display: none;" value="{{$choice_array[5]->title}}" type="text">
                                                                                                        </strong>
							</span>
                                                                                                    <span class="fontF" style="float:left;"> </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>

                                                                                    </div>
                                                                                </div>
                                                                                <div class="hover-icons action right_setting" style="display: none;width: 12%;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icons"></span>
                                                                                    <a class="click-upd-icons" style="float:right;display:none">
                                                                                        <img id="iok" src="{{URL::asset('mighty/images/iok.jpg')}}" height="17px" width="16px">
                                                                                    </a>
                                                                                    <span style="display:none;" class="open_options options-icon"></span>
                                                                                    <!-- <span class="uncheck-grey check "></span>-->
                                                                                    <input type="hidden" class="formfieldid" value="0"/>
                                                                                </div>
                                                                            </div>
                                                                        @elseif($cols->type=="component6")
                                                                            <div class="uk-grid ">
                                                                                <div class="left_setting inspectionTable" style="width:80%">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label">{{$cols->title}}</label><br/> </div>
                                                                                    <div class="title_component6 select">
                                                                                        <div class="clear ">
                                                                                            <input type="hidden" name="component6"/>
                                                                                            <div class="clear row1" style="height:27px;">
                                                                                            </div>
                                                                                            <div class="clear row1" style="height:27px;">
                                                                                            </div>
                                                                                            <div class="clear row1" style="height:27px;">
                                                                                            </div>
                                                                                            <div class="clear row1" style="height:27px;">
                                                                                            </div></div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="hover-icons action right_setting" style="display: none;width:20%" id="edits">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icon"></span>
                                                                                </div>

                                                                            </div>
                                                                        @elseif($cols->type=="component7")
                                                                            <div class="uk-grid ">
                                                                                <div class="titl-field2 left_setting inspectionTable" style="border-bottom: 1px solid #000000;">
                                                                                    <div class="clear row1 row1Title"> <label class="title_label">{{$cols->title}}</label><br/> </div>

                                                                                    <div class="title_component7 selects">

                                                                                        <input type="hidden" name="component7"/>
                                                                                        <?php
                                                                                        $chocies_array=$cols->choices;
                                                                                        ?>
                                                                                        <p style="margin-left: 5px; display: inline-block; ">
                                                                                            <span class="comp4boxl inspectionTxt title_value"data-optionid="0" >{{$chocies_array[0]->title}}</span>
                                                                                            <input class="comp4boxi" style="display: none;height:40px;width: 300px !important;" value="{{$chocies_array[0]->title}}" type="text">
                                                                                            <br>
                                                                                            <span style="margin: 10px 40px; display: block;"><b class="{{$imgclrg}}"></b><b class="{{$imgclry}}"></b><b class="{{$imgclrr}}"></b></span>
                                                                                        </p><div style="float: right;">
                                                                                            @if(isset($cols->filepath) && ($cols->filepath!='undefined' && $cols->filepath!=''))
                                                                                                <img src="{{URL::asset('mighty/images/template/')}}/{{$cols->filepath}}"style="max-width: 92px;max-height: 60px;"/>
                                                                                            @else
                                                                                                <img src="{{URL::asset('mighty/images/Might99171.PNG')}}" style="max-width: 92px;max-height: 60px;">
                                                                                            @endif

                                                                                            <input class="{{$cols->filename}} files" name="{{$cols->filename}}"  type="file">[115 x 90]
                                                                                            @if(isset($cols->filepath))
                                                                                                <input type="hidden" class="filepath" value="{{$cols->filepath}}" />
                                                                                            @endif
                                                                                        </div>

                                                                                    </div>
                                                                                </div>

                                                                                <div class="hover-icons2 action right_setting" style="display: none;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <span style="display: block;" class="click-edit-icons"></span>
                                                                                    <a class="click-upd-icons" style="float:right;display:none">
                                                                                        <img id="iok" src="{{URL::asset('mighty/images/iok.jpg')}}" height="17px" width="16px">
                                                                                    </a>
                                                                                    <!--<span class="uncheck-grey check "></span>-->
                                                                                    <input type="hidden" class="formfieldid" value="0"/>
                                                                                </div>

                                                                            </div>
                                                                        @elseif($cols->type=="condition")

                                                                            <?php
                                                                            $choice_array=$cols->choices;
                                                                            ?>

                                                                            <div class="uk-grid">
                                                                                <div class="left_setting">
                                                                                    <div class="svgTable" style="margin-left: 0px;">
                                                                                        <span style="display: inline-block;"><b class="green_checkbox"></b></span>
<span style="display: inline-block;" width="29" class="txt_bold ">
<span class="floatLeft comp4boxl title_value" colspan="2" style="font-size: 14px;font-weight: bold; padding: 0px; display: block;">{{$choice_array[0]->title}}</span>
<input type="text" name="cnd1" class="floatLeft  comp4boxi" data-optionid="0" value="{{$choice_array[0]->title}}" style="min-width: 200px;display: none;width: 174px;height: 30px;"/>
</span>
                                                                                        <span style="display: inline-block;"><b class="yellow_checkbox"></b></span>
<span style="display: inline-block;" width="29" class="txt_bold ">
<span class="floatLeft comp4boxl title_value" colspan="2" style="font-size: 14px;font-weight: bold; padding: 0px; display: block;">{{$choice_array[1]->title}}</span>
<input type="text" name="cnd2" class="floatLeft  comp4boxi" data-optionid="0" value="{{$choice_array[1]->title}}" style="min-width: 200px;display: none;width: 174px;height: 30px;"/>
</span>  <span style="display: inline-block;"><b class="red_checkbox"></b></span>
                        <span style="display: inline-block;" width="29" class="txt_bold ">
<span class="comp4boxl title_value" colspan="2" style="display: inline-block;font-weight: bold; padding: 0px; display: block;">{{$choice_array[2]->title}}</span>
<input type="text" name="cnd3" class="floatLeft  comp4boxi" data-optionid="0" value="{{$choice_array[2]->title}}" style="display: none;width: 174px;height: 30px;"/>
</span>   </div>
                                                                                </div>
                                                                                <div class="action hover-icons right_setting" style="display:none;" id="edits">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icons"></span>
                                                                                    <a class="click-upd-icons" style="float:right;display:none">
                                                                                        <img id="iok" src="{{URL::asset('mighty/images/iok.jpg')}}" height="17px" width="16px">
                                                                                    </a>
                                                                                    <input type="hidden" class="formfieldid" value="0"/>
                                                                                </div>
                                                                            </div>
                                                                        @elseif($cols->type=="condition2")
                                                                            <?php
                                                                            $choice_array=$cols->choices;
                                                                            ?>
                                                                            <div class="uk-grid">
                                                                                <div class="left_setting">
                                                                                    <div class="svgTable" style="margin-left: 0px;">
                                                                                        <span style="display: inline-block;"><b class="{{$imgclrg}}"></b></span>
<span style="display: inline-block;" width="29" class="txt_bold ">
<span class="floatLeft comp4boxl title_value" colspan="2" style="font-size: 14px;font-weight: bold; padding: 0px; display: block;">{{$choice_array[0]->title}}</span>
<input type="text" name="cnd1" class="floatLeft  comp4boxi" data-optionid="0" value="{{$choice_array[0]->title}}" style="min-width: 200px;display: none;width: 174px;height: 30px;"/>
</span>
                                                                                        <span style="display: inline-block;"><b class="{{$imgclry}}"></b></span>
<span style="display: inline-block;" width="29" class="txt_bold ">
<span class="floatLeft comp4boxl title_value" colspan="2" style="font-size: 14px;font-weight: bold; padding: 0px; display: block;">{{$choice_array[1]->title}}</span>
<input type="text" name="cnd2" class="floatLeft  comp4boxi" data-optionid="0" value="{{$choice_array[1]->title}}" style="min-width: 200px;display: none;width: 174px;height: 30px;"/>
</span>  <span style="display: inline-block;"><b class="{{$imgclrr}}"></b></span>
                        <span style="display: inline-block;" width="29" class="txt_bold ">
<span class="comp4boxl title_value" colspan="2" style="display: inline-block;font-weight: bold; padding: 0px; display: block;">{{$choice_array[2]->title}}</span>
<input type="text" name="cnd3" class="floatLeft  comp4boxi" data-optionid="0" value="{{$choice_array[2]->title}}" style="display: none;width: 174px;height: 30px;"/>
</span>   </div>
                                                                                </div>
                                                                                <div class="action hover-icons right_setting" style="display:none;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="click-edit-icons"></span>
                                                                                    <a class="click-upd-icons" style="float:right;display:none">
                                                                                        <img id="iok" src="{{URL::asset('mighty/images/iok.jpg')}}" height="17px" width="16px">
                                                                                    </a>
                                                                                    <input type="hidden" class="formfieldid" value="0"/>
                                                                                </div>
                                                                            </div>
                                                                        @elseif($cols->type=="tablehead")
                                                                            <div class="uk-grid">
                                                                                <div class="uk-width-1-2" style="width:88%;">
                                                                                    <?php
                                                                                    $choice_array=$cols->choices;
                                                                                    ?>

                                                                                    <table class="tables_{{$col}} uk-table">
                                                                                        <tr>
                                                                                            <th class="th">ITEMS</th>
                                                                                            <th class="th">CONDITION</th>
                                                                                        </tr>
                                                                                        @foreach ($choice_array as $ind=>$chres)
                                                                                            <tr id="cnt_{{$ind}}rw{{$col}}">
                                                                                                <td class="th">
                                                                                                    <div class="title_tablehead select">
                                                                                                        <input type="text" name="tables[]" class="title_value" value="{{$chres->title}}" data-optionid="0" style="height: 34px;width:100%"/>
                                                                                                    </div>
                                                                                                </td>
                                                                                                <td class="th">
                                                                                                    <span><b class="green"></b><b class="yellow"></b><b class="red"></b></span>
                                                                                                    <button class="btn btn-danger btn-xs remove_content" type="button"  data-remove="{{$ind}}rw{{$col}}"><i class="fa fa-fw fa-remove"></i></button></td>
                                                                                            </tr>
                                                                                        @endforeach

                                                                                    </table>
                                                                                </div>
                                                                                <div class="uk-width-1-2 action" style="display: none;width:12%;" id="edits_{{$edFlag}}">
                                                                                    <span class="delete_field"></span>
                                                                                    <span class="add_morerow" onclick="addMorerow(this)"  data-vals="tables_{{$col}}"></span>
                                                                                    <!--<button type="button" class="btn bg-navy margin add_morerow" onclick="addMorerow(this)"  data-vals="tables">Add row</button>-->
                                                                                    <!--<i class="uk-icon-edit edit_field"></i>--> <input type="hidden" class="formfieldid" value="0"/>
                                                                                </div>
                                                                            </div>

                                                                            @endif
                                                                                    <!--End -->
                                                                    </div>
                                                                </div>

                                                            </div></li>



                                                        <?php

                                                        $edFlag++;

                                                        }
                                                        ?>
                                                    </ul></li>
                                                <?php
                                                }

                                                }

                                                }
                                                ?>

                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="margin-top:3px;">
                                <div class="col-md-3">
                                </div>
                                <div class="col-md-4">
                                    <a style="margin-top: 18px;"  href="{{ url('/cvif/template/view/') }}/{{$formdetails->uuid}}" class="btn btn-default">Cancel</a>
                                </div>

                                <div class="col-md-4">
                                    <a style="margin-top: 18px;" class="btn btn-primary publish" data-vals="0" >Build this template</a>
                                    <a   style="margin-top: 18px;" class="btn btn-primary publish" id="preview" data-vals="1" data-url="{{URL::to('/cvif/template/preview')}}">Preview this template</a>
                                </div>

                            </div>

                            {{ csrf_field() }}
                            <input type="hidden" name="formToken" class="form_token" value ="" />
                            <input type="hidden" name="form_name" class="form_name" value = " "/>
                            <input type="hidden" name="form_desc" class="form_desc" value = " "/>
                            <input type="hidden" id="org_id" name="org_id" value="1" />

                            <div class="buildform">

                                <input type="hidden" name="imageType" id="imageType" value="{{$formdetails->imageType}}" />
                                <input type="hidden" name="uuid" id="uuid" value="{{$formdetails->uuid}}" />
                                <!-- <a href="{{ url('/cvif/generate-pdf/') }}/{{$formdetails->id}}" target="_blank" style="margin-left: 14px;" >Generate Pdf</a>-->
                            </div>
                        </form>
                        @include('mighty.layout.template')
                                <!-- </form> -->
                    </div>

                </div>
        </section>
@endsection

@section('customJs')

    <script>
                @if(isset($row) && !empty($row))
        var rowid ="{{$row+2}}";
                @else
        var rowid =1;
                @endif
        var form_rows = 1;
        var colid = 1;
        var comptField ="{{$edFlag+1}}";
    </script>
    <script src="{{URL::asset('mighty/plugins/jquery.validate.min.js')}}"></script>

    <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
    <script>

        // just for the demos, avoids form submit
        /*
         jQuery.validator.setDefaults({
         debug: true,
         success: "valid"
         });
         */
        $(document).ready(function () {
            $( "#wizard_advanced_form" ).validate({
                rules: {
                    'file_name[]': {
                        // required: true,
                        extension: "png|jpg"
                    }
                }
            });

        });

        function submitform(){
            //if ($("#wizard_advanced_form").valid()) {
            document.getElementById("wizard_advanced_form").submit();
            // }
        }
        var id=1;
        function addMorerow(a){
            var vals = $(a).data('vals');
            var data='';
            data+='<tr id="cnt_'+id+'s" class="odd gradeX"><td class="th" ><div class="title_tablehead select"><input type="text" class="form-control title_value"  data-optionid="0" name="tables[]" style="height: 34px;width:100%"  /></div></td><td class="th"><span><b class="green"></b><b class="yellow"></b><b class="red"></b></span><button class="btn btn-danger btn-xs remove_content"  type="button"  data-remove="'+id+'s"><i class="fa fa-fw fa-remove"></i></button></td></tr>';
            $("."+vals+"").append(data);
            var ulheight = $("."+vals+"").height();
            var liheight = $(a).closest("li").height();

            if(liheight<ulheight){
                $(a).closest("li").css('height',ulheight);
                $(a).closest("ul").css('height',ulheight);
            }


            id++;
            $(".remove_content").on('click',function(){

                var id=$(this).attr('data-remove');
                $("#cnt_"+id).remove();
            });
        }
    </script>
    <!--
<script src="{{URL::asset('mighty/plugins/jquery-ui.min.js')}}"></script>
-->
    <script type="text/javascript">jQuery.noConflict();</script>



    <script src="{{URL::asset('mighty/plugins/jquery-1.12.4.js')}}"></script>
    <script src="{{URL::asset('mighty/plugins/jquery-ui.js')}}"></script>
    <script type="text/javascript">jQuery.noConflict();</script>

    <!--<script src="{{URL::asset('mighty/plugins/form-builder.min.js')}}"></script>-->
    <script src="{{URL::asset('mighty/plugins/form.js')}}"></script>
    <script src="{{URL::asset('mighty/plugins/uikit_custom.min.js')}}"></script>
    <script src="{{URL::asset('mighty/plugins/datatables_uikit.min.js')}}"></script>
    <script>
        /*     var ulheight = 0;
         $('.rows').each(function(){
         var ulheight = $(this).height();

         var liheight = $(this).closest("li").height();


         if(liheight<ulheight){
         $(a).closest("li").css('height',ulheight);
         }


         console.log('row');
         var length = $('ul.connected',this).find('li.columns').size();

         if(length <= 4) {
         $('li.columns').each(function () {
         ulheight = ulheight > $(this).height() ? ulheight : $(this).height();
         console.log($(this).height());
         });
         console.log("start");  console.log(ulheight); console.log("end");

         $('ul.connected',this).css('height',ulheight);
         }
         });
         */



        $(document).ready(function () {

            $('body').addClass('sidebar-collapse');

        });
    </script>
    <script>
        /*
         jQuery(document).ready(function($) {
         $(document.getElementById('build-wrap')).formBuilder();
         });
         */
        jQuery(document).ready(function ($) {
            var $fbEditor = $(document.getElementById('build-wrap'));
            var formBuilder = $fbEditor.formBuilder().data('formBuilder');

            $(".form-builder-save").click(function (e) {
                e.preventDefault();
                // alert(formBuilder.formData);
                $("#design-tpl").val(formBuilder.formData);
            });
        });
    </script>


    <!--
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/jquery-ui.min.js"></script>

    <script>
    function allowDrop(ev) {
        ev.preventDefault();
    }

    function drag(ev) {
          ev.dataTransfer.setData("text", ev.target.id);
    }

    function drop(ev) {
        ev.preventDefault();
        var data = ev.dataTransfer.getData("text");
        ev.target.appendChild(document.getElementById(data));
    }
    $( init );

    function init() {
      $('#makeMeDraggable').draggable( {
        containment: '#content',
        cursor: 'move',
        snap: '#content'
      } );


    }
    $( function() {
        $( "#draggable" ).draggable();
      } );
    </script>
    -->
    <script type="text/javascript">

        var $kUI_multiselect_basic = $('#multiselect');
        if ($kUI_multiselect_basic.length) {
            $kUI_multiselect_basic.kendoMultiSelect();
        }
        var multiselect_location = $('#multiselect_location');
        if (multiselect_location.length) {
            multiselect_location.kendoMultiSelect();
        }
        var multiselect_size = $('.multiselect_size');
        if (multiselect_size.length) {
            multiselect_size.kendoMultiSelect();
        }
        var location_country = $('.location_country');
        if (location_country.length) {
            location_country.kendoMultiSelect();
        }

        var $kUI_multiselect_domain = $('#multiselect_domain');
        if ($kUI_multiselect_domain.length) {
            var required = $kUI_multiselect_domain.kendoMultiSelect().data("kendoMultiSelect");
            $(".domain_select #select").click(function () {
                var values = $.map(required.dataSource.data(), function (dataItem) {
                    //if(dataItem.value){
                    return dataItem.value;
                });
                required.value(values);

                $('.domain_select #select').hide();
                $('.domain_select #deselect').show();
            });

            $(".domain_select #deselect").click(function () {
                required.value([]);
                $('.domain_select #deselect').hide();
                $('.domain_select #select').show();
            });
        }
        var org_location = $("#org_location");
        if (org_location.length) {
            org_location.kendoDropDownList();
        }
        var org_forms = $("#org_forms");
        if (org_forms.length) {
            org_forms.kendoDropDownList();
        }
        var org_users = $("#org_users");
        if (org_users.length) {
            org_users.kendoDropDownList();
        }
        var $kUI_multiselect_department = $('#multiselect_department');
        if ($kUI_multiselect_department.length) {
            $kUI_multiselect_department.kendoMultiSelect();
        }
        /*  var $kUI_multiselect_department = $('#multiselect_department');
         if($kUI_multiselect_department.length) {
         $kUI_multiselect_department.kendoMultiSelect();
         }    */
        var $kUI_multiselect_category = $('#multiselect_category');
        if ($kUI_multiselect_category.length) {
            $kUI_multiselect_category.kendoMultiSelect();
        }
        var $kUI_multiselect_role = $('#multiselect_role');
        if ($kUI_multiselect_role.length) {
            $kUI_multiselect_role.kendoMultiSelect();
        }
        var multiselect_users = $('#multiselect_users');
        if (multiselect_users.length) {
            multiselect_users.kendoMultiSelect();
        }


    </script>
    <script type="text/javascript">
        if ($('body').hasClass('sidebar_main_active')) {
            $('body').removeClass('sidebar_main_active');
        }
        if ($('body').hasClass('sidebar_main_open')) {
            $('body').removeClass('sidebar_main_open');
        }
    </script>
    <script>
        /*
         $(function () {
         // enable hires images

         altair_helpers.retina_images();
         // fastClick (touch devices)
         if (Modernizr.touch) {
         FastClick.attach(document.body);
         }

         });
         */
    </script>
    <script>
        $(function () {
            var $switcher = $('#style_switcher'),
                    $switcher_toggle = $('#style_switcher_toggle'),
                    $theme_switcher = $('#theme_switcher'),
                    $mini_sidebar_toggle = $('#style_sidebar_mini');

            $switcher_toggle.click(function (e) {
                e.preventDefault();
                $switcher.toggleClass('switcher_active');
            });

            $theme_switcher.children('li').click(function (e) {
                e.preventDefault();
                var $this = $(this),
                        this_theme = $this.attr('data-app-theme');

                $theme_switcher.children('li').removeClass('active_theme');
                $(this).addClass('active_theme');
                $('body')
                        .removeClass('app_theme_a app_theme_b app_theme_c app_theme_d app_theme_e app_theme_f app_theme_g')
                        .addClass(this_theme);

                if (this_theme == '') {
                    localStorage.removeItem('altair_theme');
                } else {
                    localStorage.setItem("altair_theme", this_theme);
                }

            });

            // change input's state to checked if mini sidebar is active
            if ((localStorage.getItem("altair_sidebar_mini") !== null && localStorage.getItem("altair_sidebar_mini") == '1') || $('body').hasClass('sidebar_mini')) {
                $mini_sidebar_toggle.iCheck('check');
            }

            // toggle mini sidebar
            $mini_sidebar_toggle
                    .on('ifChecked', function (event) {
                        $switcher.removeClass('switcher_active');
                        localStorage.setItem("altair_sidebar_mini", '1');
                        location.reload(true);
                    })
                    .on('ifUnchecked', function (event) {
                        $switcher.removeClass('switcher_active');
                        localStorage.removeItem('altair_sidebar_mini');
                        location.reload(true);
                    });

            // hide style switcher

            $( document ).on('click keyup', function (e) {
                if ($switcher.hasClass('switcher_active')) {
                    if (
                            (!$(e.target).closest($switcher).length)
                            || (e.keyCode == 27)
                    ) {
                        $switcher.removeClass('switcher_active');
                    }
                }
            });

            if (localStorage.getItem("altair_theme") !== null) {
                $theme_switcher.children('li[data-app-theme=' + localStorage.getItem("altair_theme") + ']').click();
            }
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function () {
            var wrapper = $(".location_container"); //Fields wrapper
            var add_button = $(".add_location_button"); //Add button ID

            var cont = '<div><div class="uk-grid" data-uk-grid-margin><div class="uk-width-medium-1-2"><label>Location Name</label><input type="text" class="md-input" name="location_name[]" value="" /></div><div class="uk-width-medium-1-2"><label>Address</label><input type="text" class="md-input" name="address[]" value="" /></div></div><div class="uk-grid" data-uk-grid-margin><div class="uk-width-medium-1-2"><label>City</label><input type="text" class="md-input" name="city[]" value="" /></div><div class="uk-width-medium-1-2"><label>Country</label><input type="text" class="md-input" name="country[]" value="" /></div></div><div class="uk-grid" data-uk-grid-margin><div class="uk-width-medium-1-2"><label>state</label><input type="text" class="md-input" name="state[]" value="" /></div><div class="uk-width-medium-1-2"><label>Zip Code</label><input type="text" class="md-input" name="zip[]" value="" /></div></div><div class="remove_field" style="text-align: right;width: 92%;">+ Remove Location</div><hr style="border-top:1px #000 solid;"></div>';

            var x = 1; //initlal text box count

            $(add_button).click(function (e) { //on add input button click

                e.preventDefault();

                x++; //text box increment
                $(wrapper).append(cont); //add input box

                datepick();
            });

            $(wrapper).on("click", ".remove_field", function (e) { //user click on remove text
                var x = confirm("Are you sure, you want to delete Location?");
                if (x) {
                    e.preventDefault();
                    $(this).parent().remove();
                    x--;
                }
            });

        });

        $( document ).ready(function() {

            $(".remove_content").on('click',function(){
                var id=$(this).attr('data-remove');
                $("#cnt_"+id).remove();

            });


            $( ".title_label" ).on( "click", function() {
                var current = $(this).parent().parent();
                var txt = $(this).text();
                $(".title_label",current).replaceWith('<input class="title_labels" value="'+txt+'"/>');
                $(".info",current).remove();
            });
            $( "span.click-edit-icon" ).on( "click", function() {
                type = $(this).parent().parent().parent().data('type');


                if(type === 'select' || type === 'radio' || type === 'checkbox'){
                    var current = $(this).parent().parent().parent();
                }else{
                    var current = $(this).parent().parent();
                }
                if($('ul#pages').find('.title_labels')){
                    var input_label = $('ul#pages').find('.title_labels').val();
                    $('ul#pages').find('.title_labels').replaceWith("<label class='title_label'>"+input_label+"</label>");
                }
                var txt = $(current).find('.title_label').text();
                $(".title_label",current).replaceWith('<input class="title_labels" value="'+txt+'"/>');

            });


            $( ".title_label1" ).on( "click", function() {
                var current = $(this).parent().parent();
                var txt = $(this).text();
                $(".title_label1",current).replaceWith('<input class="title_label1s" value="'+txt+'"/>');
                $(".info",current).remove();
            });
            $( "span.click-edit-icon" ).on( "click", function() {
                type = $(this).parent().parent().parent().data('type');


                if(type === 'select' || type === 'radio' || type === 'checkbox'){
                    var current = $(this).parent().parent().parent();
                }else{
                    var current = $(this).parent().parent();
                }
                if($('ul#pages').find('.title_label1s')){
                    var input_label = $('ul#pages').find('.title_label1s').val();
                    $('ul#pages').find('.title_label1s').replaceWith("<label class='title_label1'>"+input_label+"</label>");
                }
                var txt = $(current).find('.title_label1').text();
                $(".title_label1",current).replaceWith('<input class="title_label1s" value="'+txt+'"/>');

            });



            $("span.click-edit-icons").on('click',function(){

                $(this).css( "display", "none" );
                $(this).next( "a" ).css( "display", "block" );

                $(this).parent().parent().find(".comp4boxi").css( "display", "block" );
                $(this).parent().parent().find(".comp4boxl").css( "display", "none" );
            });
            $( 'a.click-upd-icons' ).on( "click", function() {
                $(this).css( "display", "none" );
                $(this).prev( "span" ).css( "display", "block" );
                $(this).parent().parent().find(".comp4boxi").css( "display", "none" );
                $(this).parent().parent().find(".comp4boxl").css( "display", "block" );
            });
            $( '.comp4boxi' ).on( "keyup", function() {
                var intvals=$(this).val();
                $(this).prev( "span" ).html(intvals);

            });

            $( "span.options-icon" ).on( "click", function() {

                type = $(this).parent().parent().parent().data('type');
                comptField=$(this).data('opt');
                popupid=$(this).data('opt');
                row_id=$(this).data('row');
                collength=$(this).data('column');


                if(type === 'radio' || type === 'checkbox' || type === 'select' || type === 'time' || type === 'date'){

                    dialog = popup_initialize('choices_'+comptField,this,type,row_id,"columns_"+collength);

                    popup.options_open(type,dialog);
                    common.options_open(type,type+'_'+colid,'choices_'+comptField,dialog);
                    common.open_dialog(type,type+'_'+colid,'choices_'+comptField,'open_options_'+comptField,dialog);
                    popup.open_dialog('open_options_'+comptField,dialog);
                    $('#'+popupid).dialog("open");

                }


            });




            /*
             function popup_initialize(popupid,current,type,row_id,column_id){
             var dialog = $(current).find('#'+popupid).dialog({
             title: " OPTIONS",
             height: "auto",
             width: "auto",
             modal: true,
             //height: 300,
             buttons: {
             "ok" :function(){
             var html = '';

             switch(type){

             case 'select':
             var select = '<select id="'+popupid+'_'+row_id+'">';
             var hidden = '';
             $('#'+popupid).find('.select_label').each(function(){
             if($(this).val() != ''){
             html += '<option>'+$(this).val()+'</option>';
             hidden += '<input type="hidden" class="title_value" data-optionid="0" value="'+$(this).val()+'" />';
             }
             })
             select += html;
             select +='</select>';
             select += hidden;
             break;
             case 'radio':
             var select = '';
             $('#'+popupid).find('.select_label').each(function(){
             if($(this).val() != ''){
             select += '<input type="radio" name="'+popupid+'"/> <span class="title_value" data-optionid="0">'+$(this).val()+'</span>';
             }
             })
             break;
             case 'checkbox':
             var select = '';

             $('#'+popupid).find('.select_label').each(function(){
             if($(this).val() != ''){
             select += '<input type="checkbox"/><span class="title_value" data-optionid="0">'+$(this).val()+'</span>';
             }
             })
             break;
             case 'date':
             var select = '';
             console.log($('#date_formats').val());
             $('#date_format',current).val($('#date_formats').val());
             break;
             case 'time':
             var select = '';
             console.log($('#time_formats').val());
             $('#time_format',current).val($('#time_formats').val());
             break;

             }
             $('ul#'+row_id+'> #'+column_id).find('.select').empty().append(select);
             $(this).dialog( "close" );
             },
             Cancel: function() {
             $(this).dialog( "close" );
             }
             },
             });
             console.log(dialog);
             return dialog;
             }*/
            var common = {
                countcollength :function(rowid){
                    var colcount = $('#'+rowid).find('div.cols').size();
                    //console.log(colcount+" Column "+" in "+rowid);
                    return ++colcount;
                },
                auto_update_text:function(type){
                    $(d).on("click",'label.title_label', function () {
                        var current = $(this).parent().parent();
                        var txt = $(this).text();
                        $(".title_label",current).replaceWith('<input class="title_labels" value="'+txt+'"/>');
                        $(".info",current).remove();
                    });
                    $(d).on('click','span.click-edit-icon',function(){
                        if(type === 'select' || type === 'radio' || type === 'checkbox'){
                            var current = $(this).parent().parent().parent();
                        }else{
                            var current = $(this).parent().parent();
                        }
                        if($('ul#pages').find('.title_labels')){
                            var input_label = $('ul#pages').find('.title_labels').val();
                            $('ul#pages').find('.title_labels').replaceWith("<label class='title_label'>"+input_label+"</label>");
                        }
                        var txt = $(current).find('.title_label').text();
                        $(".title_label",current).replaceWith('<input class="title_labels" value="'+txt+'"/>');
                    });
                },
                open_dialog:function(type,selectedid,popupid,optionid,dialog){
                    dialog.dialog( "open" );
                    $('.'+optionid).click(function(){
                        dialog.dialog( "open" );
                    });
                },
                options_open:function(type,selectedid,popupid,dialog){

                    //current = dialog.attr('id');

                    current = popupid;

                    var max_fields      = 5; //maximum input boxes allowed
                    var wrapper         = $("#"+current+" element"); //Fields wrapper
                    var add_button      = $(".add_field_button"); //Add button ID
                    var x = 0;
                    //console.log(wrapper);
                    $(wrapper).on("click",'.add_field_button',function(e){ //on add input button click
                        //initlal text box count
                        e.preventDefault();
                        if(x < max_fields){ //max input box allowed
                            x++; //text box increment
                            //$(wrapper).find('.add-option').remove();
                            $(wrapper).append('<p><input type="text" name="mytext[]" class="select_label"/><span class="delete-option remove_field"></span></p>'); //add input box
                        }else{
                            if($(wrapper).find('p.req').size() == 0){
                                $(wrapper).prepend('<p class="req">Limited only for trial version</p>');
                            }
                        }
                        return false;
                    });
                    $(add_button).on("click",function(e){ //on add input button click
                        //initlal text box count
                        e.preventDefault();
                        if(x < max_fields){ //max input box allowed
                            x++; //text box increment
                            // $(wrapper).find('.add-option').remove();
                            $(wrapper).append('<p><input type="text" name="mytext[]" class="select_label"/><span class="delete-option remove_field"></span></p>'); //add input box
                        }else{
                            if($(wrapper).find('p.req').size() == 0){
                                $(wrapper).prepend('<p class="req">Limited only for trial version</p>');
                            }
                        }
                        return false;
                    });
                    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
                        e.preventDefault();
                        if($(wrapper).find('p.req').size() == 1){
                            $(wrapper).find('p.req').remove();
                        }
                        //$(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span><span class="delete-option remove_field"></span>');
                        /* if(type === 'radio'){
                         if($(wrapper).find('p').size() > 3){
                         $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span><span class="delete-option remove_field"></span>');
                         } else{
                         $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span>');
                         }
                         }
                         if(type === 'checkbox' || type === 'select'){
                         if($(wrapper).find('p').size() > 2){
                         $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span><span class="delete-option remove_field"></span>');
                         } else{
                         $(this).parent('p').prev().remove('.add-option').remove('.remove_field').append('<span class="add-option add_field_button"></span>');
                         }
                         }*/
                        $(this).parent('p').remove();

                        x--;
                    });
                    return false;
                    // });
                },
                options_close:function(type,selectedid,popupid,dialog){
                    $(d).on('click','.options_cancel',function(){
                        console.log('here');
                    });
                },
                required:function(){
                    $(d).on('click','.check',function(){
                        if($(this).hasClass('uncheck-grey') === true)	{
                            console.log($(this).hasClass('uncheck-grey'));
                            $(this).removeClass("uncheck-grey").addClass("check-red");
                        }else{
                            console.log('else');
                            $(this).removeClass("check-red").addClass("uncheck-grey");
                        }
                    });
                }
            }

        });


    </script>

@endsection