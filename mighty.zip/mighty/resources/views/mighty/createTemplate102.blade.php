<?php
$template=Config::get('custom.template');
?>
@extends('mighty.layout.tpl')
@section('customCss')
<link rel="stylesheet" href="{{URL::asset('mighty/plugins/template2.css')}}"> 
<style>
.content {
    min-height: 1811px;
}


</style>
@endsection

@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Mighty Customizable Vehicle Inspection Forms
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">CVIF</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li><a href="{{URL::to('/cvif/create-template101')}}" >Template 101</a></li>
              <li  class="active"><a href="{{URL::to('/cvif/create-template102')}}" >Template 102</a></li>
              <li><a href="{{URL::to('/cvif/create-template103')}}" >Template 103</a></li>
              <li><a href="{{URL::to('/cvif/create-template104')}}" >Template 104</a></li>
              <li><a href="{{URL::to('/cvif/create-template105')}}" >Template 105</a></li>
              </ul>
            <div class="tab-content">
              <div class="tab-pane" id="tab_1">
           <section class="content">    
        <div class="col-md-12">
        </div>
        </section>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane active" id="tab_2">
   <section class="content">    
        <div class="col-md-12">
<div class="innercontainer">
      
      
                
      <!-- Complete Width and Height -->
      <form name="updateUserForm" action="./updateUserFormIfs.do" method="post" id="updateUserForm">
      <input name="saveImage" id="saveImage" value="" type="hidden">
      <input name="saveLeftImage" id="saveLeftImage" value="" type="hidden">
      <input name="saveRightImage" id="saveRightImage" value="" type="hidden">
      <div style="margin-left:36%;padding:8px;">
         <span class="circlesquare">Form Name :</span> <input name="formName" id="formName" value="102 Form 2" maxlength="25" type="text"> 
      </div>
      <input name="userFormId" value="689921" type="hidden">
      <div id="templateSize">
        <div class="divLogoTab" style="width: 20.8cm;">         
          <div class="divLogoRow">
            <div class="logo1Parent">
              <div class="logo1">
                    <div class="leftOptImage" id="logoLeft"></div>
              </div>
              <a href="javascript:void(0);" id="uploadImage1" onclick="centerImageSelectionPop('leftLogo',100,100); return false;" style="display: block !important;margin-top: 115px;margin-left: -40px; font-size: 14px;font-family: 'MyriadProRegular';">Click to upload optional logo</a> <span class="imgDimension" style="position:relative; left:10px;">[100 x 100]</span>
            </div>
                <div id="imgLogo" class="imgLogo" align="center">
                  <p id="msg">(Your logo here)<br>Dimension:[380 x 100]pixels</p>
                </div>
            
            <a href="#" id="centerImageClick" onclick="centerImageSelectionPop('center',380,100); return false;" style="margin-left: 0px;height: 0; font-family: 'MyriadProRegular'; font-size: 11pt;position:relative; left:38%;top:10px;">Click to upload logo</a> &nbsp;&nbsp;<span class="imgDimension" style="position:relative; left:38%;top:10px;">[380 x 100]</span>
            <div class="logo2">
                  <div class="rghtOptImage" id="logoRight"></div>
              
              <a href="javascript:void(0);" id="uploadImage2" onclick="centerImageSelectionPop('rightLogo',100,100); return false;" style="display:inline;margin-top:0px; font-family: 'MyriadProRegular';font-size: 14px;white-space:nowrap;position:relative;left:-32px;top:10px;">Click to upload optional logo</a><br> <span class="imgDimension" style="position:relative; top:8px;left:20px;">[100 x 100]</span>
            </div>
          </div>
        </div>
      </div>
      <div id="pageHeading">

        <input name="headingText102" id="headingText102" value="WE PERFORMED THE FOLLOWING FREE INSPECTION:" type="text">
        <input value="WE PERFORMED THE FOLLOWING FREE INSPECTION:" id="editText102" style="display: none; font-size: 20pt;font-weight: bold;margin-left: 87px;width: 80%;" maxlength="44" type="text">
        <a href="javascript:void(0);" id="editHeading102" style="float:right;margin-right: 51px;margin-top: -30px;">
          <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="16px">
        </a>
        <a href="javascript:void(0);" id="okHeading102" style="display:none;">
          <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="16px">
        </a>
        <div class="clear"></div>
      </div>
      <!-- Form 1 -->
      <div class="divTable" style="width:850px;">
        <div class="divRow">
          <div class="divCell" id="customer" style="border: 1px solid #ACACAC;margin-left: 40px;width: 763px;">
            <div class="divCell" id="inner_Customer">
            
              <input id="editComp_6_0" name="editComp_6_0" style="text-align:left;width:763px;height:30px;font-family: MyriadProRegular;font-size: 11pt;border:1px solid black;" onkeypress="return checkStringLength(this.id, event);" onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" value="Customer: _______________________________ Phone: _________________ Mileage: __________________________" onblur=" mouseOut0()" type="text">
            
              <input id="editComp_6_1" name="editComp_6_1" style="text-align:left;width:763px;height:30px;font-family: MyriadProRegular;font-size: 11pt;border:1px solid black;" onkeypress="return checkStringLength(this.id, event);" onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" value="Year/Make/Model: ________________________________ VIN: ______________________________________________" onblur=" mouseOut1()" type="text">
            
            </div>
            <span id="divTxt_attention" >
              <input id="editComp_6" name="editComp_6" style="text-align:left;display:none;width:763px;height:30px;" value="Customer: _______________________________ Phone: _________________ Mileage: __________________________~Year/Make/Model: ________________________________ VIN: ______________________________________________" type="text">
              <input id="componentId6" name="componentId6" value="6899371" type="hidden">
            </span>
            
            

            
          </div>
         
        </div>
      </div>
      <div id="commentDiv" style="font-family: 'MyriadProRegular', Sans-Serif; font-size: 11pt; letter-spacing: .5px; width: 960px;">
        <span id="temp1"></span>
      </div>
      
        <div style="padding:15px 55px;">
          <span class="circlesquare">
            <input name="imgType" value="circle" type="radio"> Circle
          </span>
          <span class="circlesquare">
            <input name="imgType" value="square" checked="checked" type="radio"> Square
          </span>
        </div>
          
      
      <!-- ATTENTION -->
      <div class="selTable selTableEdit">
        <div class="selRow">
          <div class="selCol">
            <div class="selCell">             
              
                
                
                  <input class="greenSquare" type="button">
                
              
              <nobr>
               
                <input id="editComp_7" name="editComp_7" value="NO IMMEDIATE ATTENTION" style="float: none;width: 200px;" class="focusOutSave" maxlength="23" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId7" value="6899156" type="hidden">
                </span>
                <a href="javascript:void(0);" id="okButton7" onclick="removeEdit('editComp_7',23)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="16px">
                </a>
              </nobr>
            </div>
          </div>
          <div class="selCol">
            <div class="selCell">
              
                
                
                  <input class="yellowSquare" type="button">
                
              
              <nobr id="nobr">

                <input id="editComp_8" name="editComp_8" value="MAY REQUIRE FUTURE ATTENTION" style="float: none;width: 200px;" class="focusOutSave" maxlength="30" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId8" value="6899157" type="hidden">
                </span>
                
              </nobr>
            </div>
          </div>
          <div class="selCol">
            <div class="selCell"> 
                  <input class="redSquare" type="button">
                 
              <nobr id="nobr">
                <input id="editComp_9" name="editComp_9" value="IMMEDIATE ATTENTION" style="float: none;width: 200px;" class="focusOutSave" maxlength="23" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId9" value="6899158" type="hidden">
                </span>
                
              </nobr>               
            </div>
          </div>
        </div>
      </div>
      <!-- Items And Conditions -->
        <div class="divTable1">
          <div id="div1" style="margin-left:40px;">
            <div class="divRow">
              <div class="divCell1 rowheading" id="content">
                <p id="comp_10">ITEMS</p>
                <input id="editComp_10" name="editComp_10" value="ITEMS" style="display:none;float: none;width: 170px;" maxlength="10" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId10" value="6899375" type="hidden">
                </span>
                <a href="javascript:void(0);" id="editButton10" onclick="editText('component10')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="16px">
                </a> 
                <a href="javascript:void(0);" id="okButton10" onclick="removeEdit('editComp_10',25)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="16px">
                </a>  
              </div>
              
              <div class="divCell1 rowheading" id="content">
                <p id="comp_11">CONDITION</p>
                <input id="editComp_11" name="editComp_11" value="CONDITION" style="display:none;float: none;width: 170px;" maxlength="10" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId11" value="6899481" type="hidden">
                </span>
                <a href="javascript:void(0);" id="editButton11" onclick="editText('component11')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="16px">
                </a> 
                <a href="javascript:void(0);" id="okButton11" onclick="removeEdit('editComp_11',25)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="16px">
                </a>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_12">Lights</p>
                <input id="editComp_12" name="editComp_12" value="Lights" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId12" value="6899376" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component12" style="float: right;" onclick="deleteText('component12')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="16px">
                </a>
                
                <a href="javascript:void(0);" id="editButton12" onclick="editText('component12')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="16px">
                </a> 
                <a href="javascript:void(0);" id="okButton12" onclick="removeEdit('editComp_12',26)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="16px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_13">Wiper Blades</p>
                <input id="editComp_13" name="editComp_13" value="Wiper Blades" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId13" value="6899262" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component13" style="float: right;" onclick="deleteText('component13')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton13" onclick="editText('component13')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton13" onclick="removeEdit('editComp_13',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_14">Windshield/Glass Damage</p>
                <input id="editComp_14" name="editComp_14" value="Windshield/Glass Damage" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId14" value="6899370" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component14" style="float: right;" onclick="deleteText('component14')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton14" onclick="editText('component14')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton14" onclick="removeEdit('editComp_14',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_15">Check Engine Light On</p>
                <input id="editComp_15" name="editComp_15" value="Check Engine Light On" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId15" value="6899260" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component15" style="float: right;" onclick="deleteText('component15')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton15" onclick="editText('component15')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton15" onclick="removeEdit('editComp_15',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_16">Oil Level</p>
                <input id="editComp_16" name="editComp_16" value="Oil Level" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId16" value="6899263" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component16" style="float: right;" onclick="deleteText('component16')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton16" onclick="editText('component16')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton16" onclick="removeEdit('editComp_16',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_17">Oil Condition</p>
                <input id="editComp_17" name="editComp_17" value="Oil Condition" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId17" value="6899591" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component17" style="float: right;" onclick="deleteText('component17')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton17" onclick="editText('component17')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton17" onclick="removeEdit('editComp_17',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_18">Brake Fluid</p>
                <input id="editComp_18" name="editComp_18" value="Brake Fluid" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId18" value="6899484" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component18" style="float: right;" onclick="deleteText('component18')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton18" onclick="editText('component18')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton18" onclick="removeEdit('editComp_18',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>            
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_19">Power Steering Fluid</p>
                <input id="editComp_19" name="editComp_19" value="Power Steering Fluid" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId19" value="6899269" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component19" style="float: right;" onclick="deleteText('component19')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton19" onclick="editText('component19')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton19" onclick="removeEdit('editComp_19',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_20">Washer Fluid</p>
                <input id="editComp_20" name="editComp_20" value="Washer Fluid" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId20" value="6899373" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component20" style="float: right;" onclick="deleteText('component20')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton20" onclick="editText('component20')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton20" onclick="removeEdit('editComp_20',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_21">Transmission Fluid</p>
                <input id="editComp_21" name="editComp_21" value="Transmission Fluid" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId21" value="6899159" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component21" style="float: right;" onclick="deleteText('component21')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton21" onclick="editText('component21')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton21" onclick="removeEdit('editComp_21',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_22">Belt(s) &amp; Tensioner</p>
                <input id="editComp_22" name="editComp_22" value="Belt(s) &amp; Tensioner" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId22" value="6899266" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component22" style="float: right;" onclick="deleteText('component22')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton22" onclick="editText('component22')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton22" onclick="removeEdit('editComp_22',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_23">Hoses</p>
                <input id="editComp_23" name="editComp_23" value="Hoses" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId23" value="6899482" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component23" style="float: right;" onclick="deleteText('component23')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton23" onclick="editText('component23')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton23" onclick="removeEdit('editComp_23',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_24">Antifreeze / Coolant</p>
                <input id="editComp_24" name="editComp_24" value="Antifreeze / Coolant" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId24" value="6899379" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component24" style="float: right;" onclick="deleteText('component24')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton24" onclick="editText('component24')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton24" onclick="removeEdit('editComp_24',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_25">Air Filter</p>
                <input id="editComp_25" name="editComp_25" value="Air Filter" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId25" value="6899590" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component25" style="float: right;" onclick="deleteText('component25')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton25" onclick="editText('component25')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton25" onclick="removeEdit('editComp_25',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
          </div>
          
          <div id="div2" style="margin-right:35px;">
            <div class="divRow">
              <div class="divCell1 rowheading" id="content">
                <p id="comp_26">ITEMS</p>
                <input id="editComp_26" name="editComp_26" value="ITEMS" style="display:none;float: none;width: 170px;" maxlength="10" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId26" value="6899486" type="hidden">
                </span>
                <a href="javascript:void(0);" id="editButton26" onclick="editText('component26')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton26" onclick="removeEdit('editComp_26',10)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>            
              </div>
              
              <div class="divCell1 rowheading" id="content">
                <p id="comp_27">CONDITION</p>
                <input id="editComp_27" name="editComp_27" value="CONDITION" style="display:none;float: none;width: 170px;" maxlength="10" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId27" value="6899489" type="hidden">
                </span>
                <a href="javascript:void(0);" id="editButton27" onclick="editText('component27')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton27" onclick="removeEdit('editComp_27',10)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>  
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_28">Cabin Filter</p>
                <input id="editComp_28" name="editComp_28" value="Cabin Filter" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId28" value="6899265" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component28" style="float: right;" onclick="deleteText('component28')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton28" onclick="editText('component28')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton28" onclick="removeEdit('editComp_28',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_29">Fuel Filter</p>
                <input id="editComp_29" name="editComp_29" value="Fuel Filter" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId29" value="6899264" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component29" style="float: right;" onclick="deleteText('component29')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton29" onclick="editText('component29')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton29" onclick="removeEdit('editComp_29',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_30">Battery Condition</p>
                <input id="editComp_30" name="editComp_30" value="Battery Condition" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId30" value="6899374" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component30" style="float: right;" onclick="deleteText('component30')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton30" onclick="editText('component30')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton30" onclick="removeEdit('editComp_30',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_31">Spark Plugs / Wires</p>
                <input id="editComp_31" name="editComp_31" value="Spark Plugs / Wires" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId31" value="6899488" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component31" style="float: right;" onclick="deleteText('component31')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton31" onclick="editText('component31')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton31" onclick="removeEdit('editComp_31',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_32">Fuel System Service</p>
                <input id="editComp_32" name="editComp_32" value="Fuel System Service" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId32" value="6899377" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component32" style="float: right;" onclick="deleteText('component32')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton32" onclick="editText('component32')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton32" onclick="removeEdit('editComp_32',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_33">Differential Fluid</p>
                <input id="editComp_33" name="editComp_33" value="Differential Fluid" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId33" value="6899378" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component33" style="float: right;" onclick="deleteText('component33')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton33" onclick="editText('component33')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton33" onclick="removeEdit('editComp_33',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_34">Tire Pressure</p>
                <input id="editComp_34" name="editComp_34" value="Tire Pressure" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId34" value="6899268" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component34" style="float: right;" onclick="deleteText('component34')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton34" onclick="editText('component34')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton34" onclick="removeEdit('editComp_34',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_35">Tire Rotation</p>
                <input id="editComp_35" name="editComp_35" value="Tire Rotation" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId35" value="6899485" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component35" style="float: right;" onclick="deleteText('component35')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton35" onclick="editText('component35')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton35" onclick="removeEdit('editComp_35',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_36">Tire Condition</p>
                <input id="editComp_36" name="editComp_36" value="Tire Condition" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId36" value="6899483" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component36" style="float: right;" onclick="deleteText('component36')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton36" onclick="editText('component36')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton36" onclick="removeEdit('editComp_36',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_37">Alignment</p>
                <input id="editComp_37" name="editComp_37" value="Alignment" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId37" value="6899372" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component37" style="float: right;" onclick="deleteText('component37')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton37" onclick="editText('component37')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton37" onclick="removeEdit('editComp_37',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_38">Shocks / Struts</p>
                <input id="editComp_38" name="editComp_38" value="Shocks / Struts" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId38" value="6899267" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component38" style="float: right;" onclick="deleteText('component38')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton38" onclick="editText('component38')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton38" onclick="removeEdit('editComp_38',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_39">CV Boots / Axles</p>
                <input id="editComp_39" name="editComp_39" value="CV Boots / Axles" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId39" value="6899261" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component39" style="float: right;" onclick="deleteText('component39')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton39" onclick="editText('component39')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton39" onclick="removeEdit('editComp_39',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_40">Exhaust System</p>
                <input id="editComp_40" name="editComp_40" value="Exhaust System" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId40" value="6899487" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component40" style="float: right;" onclick="deleteText('component40')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton40" onclick="editText('component40')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton40" onclick="removeEdit('editComp_40',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_41">Other</p>
                <input id="editComp_41" name="editComp_41" value="Other" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId41" value="6899480" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component41" style="float: right;" onclick="deleteText('component41')">
                  <img id="iok" src="{{URL::asset('mighty/images/iDelete.png')}}" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton41" onclick="editText('component41')" style="float: right;">
                  <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton41" onclick="removeEdit('editComp_41',27)" style="display:none;float: right;">
                  <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
          </div>
        </div>
        <!-- Form 2 -->
        <div class=" bottomtext" style="width:88%;">
           <div style="width:838px; height:25px;">
          <span id="cmt" style="float:left;">Comments:</span> 
          <hr style="width:90%;position:relative; top:18px;">
           </div> 
          <br><hr><br><hr><br>
           <div style="width:838px; height:25px;">  
          <span id="cmt" style="float:left;clear:left;margin-top: -25px;">Inspected by: </span> 
          <hr style="width:60%;float:left;position:relative; top:-5px;">
          <span style="float: left; margin-top: -25px; margin-left: 60.5%;">Date:</span>
          <hr style="width:25%;float:left;position:relative; top:-5px;">
           </div> 
        </div>
        <div style="text-align:center;margin-top:10px;padding-bottom:10px;overflow:auto; padding-left:380px;">
          <input name="save" class="savebtn" value="Save" onclick="updateForm();launchWindow('#dialog');" type="button">
            <!-- <a id="cancelButtonId" href="./getUserComponentIfs.do"  class="btn-txt"><input type="button" class="cancelbtn" value="Cancel"></a> -->
        </div>
      </form>
      <form id="cancelAdminForm" method="get" action="./getUserViewComponentIfs.do">
      <input name="formid" id="formid" value="689921" type="hidden">
        <input value="Cancel" class="cancelbtn1" onclick="launchWindow('#dialog')" type="submit">
      </form>
    </div>
        </div>
        </section>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3">
               tab3
              </div>
              <div class="tab-pane" id="tab_4">
              tab4
              </div>
              <div class="tab-pane" id="tab_5">
              tab5
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
      </div>
    </section>
   
 
@endsection


@section('customJs')
@endsection
