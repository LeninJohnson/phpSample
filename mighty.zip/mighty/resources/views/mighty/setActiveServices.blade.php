@extends('mighty.layout.tpl')
@section('customCss')
    <style>
        .content {
          //  min-height: 1811px;
        }
    </style>

@endsection
@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Set Active Services
            <small></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{URL::to('')}}"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="{{URL::to('mighty-assist/services/set-active-services')}}">Services</a></li>
            <li class="active">set active Services</li>
        </ol>
    </section>
    @if(Session::has('true_msg'))
        <div class="row">
            <div class="col-md-6">
                <div class="alert alert-success">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    {{Session::get('true_msg')}}
                </div> <!-- /.alert -->
            </div>
        </div>
    @endif
    @if(Session::has('error_msg'))
        <div class="row">
            <div class="col-md-6">
                <div class="alert alert-danger">
                    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
                    {{Session::get('error_msg')}}
                </div> <!-- /.alert -->
            </div>
        </div>
    @endif
    <section class="content">
        <div class="row">
            <div class="col-md-6">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Please select active services. Click submit to complete.</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" method="post" enctype="multipart/form-data" >
                        <div class="box-body">
                            <div class="form-group">
                            <?php
                            $active_services=explode(",",$active_services);
                            ?>
                                @foreach($services as $vals)
                                    <div class="radio">
                                        <label>
    <input name="service_name[]" id="optionsRadios{{$vals->id}}" value="{{$vals->id}}" @if (in_array($vals->id, $active_services))
    checked @endif  type="checkbox">
                                            {{$vals->name}}
                                        </label>
                                    </div>
                                @endforeach


                            </div>

                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>


@endsection

@section('customJs')

@endsection