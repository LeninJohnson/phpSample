<?php
$template=Config::get('custom.template');
?>
@extends('mighty.layout.tpl')
@section('customCss')
<link rel="stylesheet" href="{{URL::asset('mighty/plugins/template.css')}}"> 
<style>
.content {
    min-height: 1811px;
}
</style>
@endsection
@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Mighty Customizable Vehicle Inspection Forms
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">CVIF</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
                <li class="active"><a href="#tab_1" >Template 101</a></li>
                <li><a href="{{URL::to('/cvif/create-template102')}}" >Template 102</a></li>
                <li><a href="{{URL::to('/cvif/create-template103')}}" >Template 103</a></li>
                <li><a href="{{URL::to('/cvif/create-template104')}}" >Template 104</a></li>
                <li><a href="{{URL::to('/cvif/create-template105')}}" >Template 105</a></li>
              </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
           <section class="content">    
        <div class="col-md-12">
        <!-- Horizontal Form -->
<div class="insideinnercontainer">
            <div style="width:576px;margin:16px 5px; float:left;">
              <div style="width:579px; border:1px #000 solid; float:left;">
              <input name="currentDiv" id="currentDiv" value="compDiv_1" type="hidden">
            <input name="prevDiv" id="prevDiv" value="compDiv_1" type="hidden">
            <input name="edited" id="edited" value="false" type="hidden">
            <form id="updateForm" name="updateForm" action="./updateForm.do" method="post">
              <!-- Template will be shown up here -->
            <!-- Header Starts -->
            
              <div id="header">
               <input value="Your Header" id="editText" maxlength="24" type="text">
              </div>            <!-- Header Ends -->
              <div id="imgLogo" align="center">
                <p id="msg">(Your logo here)<br>Dimension:[336 x 72]pixels</p>
               </div> 
            <div class="text_field">Mileage_________________</div>
                <!--Vc Inner container starts-->
                <div id="VCcontinner" class="VCcontinner">
                <input name="userFormId" id="userFormId" value="689357" type="hidden">
                <input name="templateId" id="templateId" value="1" type="hidden">
                <input name="headingText" id="headingText" value="VEHICLE CONDITION repoRT" type="hidden"> 
          <input name="saveImage" id="saveImage" value="" type="hidden"> 
                <input name="headerColor" id="headerColor" value="#045fb4" type="hidden">
                <input name="currHeaderColor" id="currHeaderColor" value="#045fb4" type="hidden">
                <div class="row">
                @foreach($templatecomponents as $res)
                  <div class="col-md-6">
                  <div id="visibleDiv1" class="ListDivVisible">
  <div id="compDiv_1" class="ListDiv">
    <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan1">{{$res->name}}</span>
    <img class="iImageEdit handSymbol" data-sts="{{$res->id}}" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_1"> 
    <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_1">
  
    <span class="subText" id="labelSpan9">{{$res->sub_heading}}</span>

<?php
$get_chkbox=App\Helper\AppHelper::GetoptionResults($res->id);
?>    
    <div id="optDivParent1">
      <div class="checkboxcnt" id="optDiv1">
        <div class="checkbox">
          <span>
@foreach($get_chkbox as $opres)
              <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_11">
              <label id="opt11" class="optionText">{{$opres->details}}</label>
@endforeach
          </span>
        </div>
      </div>
    </div>
  </div>
</div>
                  </div>
                  @endforeach
                  </div>
                  <div class="listcontatleftEdit">
                  <!-- List out first eight elements -->
                   <ul class="VClist">
                        <li>
                   <div id="visibleDiv1" class="ListDivVisible">
                        <div id="compDiv_1" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan1">Lights</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_1"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_1">
               <div id="optDivParent1">
                           <div class="checkboxcnt" id="optDiv1">
                              <div class="checkbox">
                                <span>
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_11">
                <label id="opt11" class="optionText">Pass</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_12">
                <label id="opt12" class="optionText">Fail</label>
                        </span>
                           </div>
                           </div>
                           </div>
                           <div class="clear"></div>
                          </div>
                         </div></li>                        
                </ul>
              </div>
                <!--List left Ends-->
                
                <!--List right starts-->
                <div class="listcontatrightEdit">
                 <!-- List out rest seven elements -->
                  <ul class="VClist">
                  
                    <input name="viewComponent9" id="viewComponent9" value="689412" type="hidden">
                        <input name="viewPosition9" id="viewPosition9" value="9" type="hidden">
                        <input name="templateComponent9" id="templateComponent9" value="689412" type="hidden">
            <input name="templatePosition9" id="templatePosition9" value="9" type="hidden">
            <input name="componentName9" id="componentName9" value="Antifreeze/Coolant" type="hidden">
            <input name="label9" id="label9" value="30,000 Miles" type="hidden">
                      <li>
                      
                      <input name="visibility9" id="visibility9" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv9" class="ListDivVisible">
                      
                      
                       
                      <div id="compDiv_9" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan9">Antifreeze/Coolant</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_9"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_9">
                          
                   <span class="subText" id="labelSpan9">30,000 Miles</span>
                
              <div id="optDivParent9">
                           <input name="scoptionId9" id="scoptionId9" value="689409" type="hidden">
                           <input name="optionId9" id="optionId9" value="689408" type="hidden">
                           <input name="optionValue9" id="optionValue9" value="Good^Next Visit^Overdue" type="hidden">
                           <input name="optionString9" id="optionString9" value="Good^Next Visit^Overdue" type="hidden">
                           <input id="optType9" name="optType9" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv9">
                            
                              
                               <div class="checkboxcnt">
                              
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_91">
                    <label id="opt91" class="optionText">Good</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_92">
                    <label id="opt92" class="optionText">Next Visit</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_93">
                    <label id="opt93" class="optionText">Overdue</label>
                  </span>
                             </div>
                           </div>
                          </div>
                       </div>
                         <div class="clear"></div>
                         </div>
                         </div>
                     </li>
                                        
                   </ul>
                 </div>
                 <!--List right Ends-->
                 <div class="clear"></div>
                
            </div>
            <div class="clear"></div>
              <!--Vc Inner container Ends-->
                <div class="bottomtext">
        <span style="float:left;">Comments:</span>
        <hr style="width: 87%; margin-top:4%;"><br>
        <hr style="width: 99%;"><br>
        <hr style="width: 99%;"><br>    
        <span style="float: left; clear: left; margin-top: -4%;">Inspected by: </span> 
        <hr style="width: 45%;float:left;position:relative; top:-3px;">
        <span style="float: left; margin-top: -4%; width: 20.5%;">Date:</span>
        <hr style="width: 33.5%;float:left;margin-left:-14%;position:relative; top:-3px;">
        </div>
               <div class="clear"></div>
                </form></div>
            <!--Container Bottom Starts-->
            <div class="containerbtm" style="padding-left:200px;">
            <a id="updateId" class="btn-txt" onclick="launchWindow('#dialog');">Save</a>
          <a id="cancelButtonId" href="./userFormView.do?formid=689357" class="btn-txt" onclick="launchWindow('#dialog');">Cancel</a>
            </div>
            <!--Container Bottom Ends-->
            <div class="clear"></div>
             </div>
                  <!--Innercontainer left starts-->
          <div style="float: left; width: 333px; margin: 16px 5px;">
          <div class="rightcontainer">
            <div class="sideheading">
              <label>Form name : </label>
              <div>
                <input id="formName" name="formName" value="101 Form 2" maxlength="20" type="text">
              </div>
            </div>
           
          <form name="uploadLocalImage" action="./userFormEdit.do" method="post" id="uploadLocalImage" enctype="multipart/form-data">
            <div class="sideheading"><label>Upload your own image:</label>
            <div>
               <input id="center" name="center" value="template1" type="hidden">
                   <input id="centerimageHeight" name="centerimageHeight" value="72" type="hidden">
                   <input id="centerimageWidth" name="centerimageWidth" value="336" type="hidden">
              <input name="fileImage" id="localImage" value="" type="file">
                <span id="delBtn"></span>
            </div>
            </div>
          </form>
          <form name="uploadRImage" action="./browseImage.do?type=template1" method="post" id="uploadRImage" enctype="multipart/form-data">
          <div class="sideheading">
            <label><nobr>Choose from existing images :</nobr>
            </label>
          </div>
          <div style="width:340px;">
            <input readonly="readonly" style="height: 22px;width: 143px;float:left;" type="text">
            <input value="Browse..." id="browse" onclick="displayHideBox('1'); return false;" style="left: -80px;margin-top: 0px;position: relative;float:left;" type="submit">
              
                <span id="delBtn1"></span>
              
            
            <div id="grayBG" class="grayBox">
            </div>
            <div id="LightBox1" class="box_content" style="display: none;">
              <span style="float: right;"><img src="{{URL::asset('mighty/images/icon-delete.gif')}}" onclick="displayHideBox('1')"></span>
              <div style="background: #fff; width: 100%;">
                <div onclick="displayHideBox('1'); return false;" style="cursor: pointer;" align="right">
                  
                </div>
                <p>
                </p><div id="lbox"></div>
                <p></p>
              </div>
            </div>
          </div>
        </form>
          <!-- <div class="sideheading">
              <label>Choose From Existing Images </label> <input type="file" />
          </div> -->
              <div class="sideheading" style="clear:left;">
                  <label>Heading color</label>
                </div>
                <div id="iColor">
                      <input autocomplete="off" maxlength="7" name="color3" class="colors miniColors" value="#123456" id="inp1" src="{{URL::asset('mighty/images/images.png')}}" type="image"><a class="miniColors-trigger" style="background-color: #123456" href="#"></a>
                     
                  </div>
               <div class="sideheading">
               <label>Default Heading color:</label> <input id="inpDefault" style="cursor: pointer;" type="button">
             </div>
                      </div>               
                     </div>
            <div id="editComponent" style="float: left; width: 333px; margin: 0px 5px;display:none;">
                      <div class="rightcontainer">
                      <div class="sideheading">
                      <input name="lastEditOptionDiv" id="lastEditOptionDiv" value="" type="hidden"> 
                      <label>Position on the template :</label><label id="showPosition"></label>
                      </div>
                      @foreach($templatecomponents as $rels)
                        <div class="templcomps" id="tempcms_{{$rels->id}}">
                      <div class="sideheading">
                       <label>Heading</label><br>
                         <input name="TextboxExample" value="{{$rels->name}}" maxlength="25" id="changedHeading" tabindex="2" onchange="DropDownIndexClear('DropDownExTextboxExample');" onkeyup="editHeadingLabel(this.id)" style="width: 215px; height: 17px; position: absolute; border-right: none; border-bottom:none;" type="text">
              <select name="CompDrp" id="CompDrp" tabindex="1000" size="1" style="text-transform: capitalize; font-size: 12pt; font-family: 'MyriadProRegular', Arial; ">
                <option value="0">--Select--</option>
                 @foreach($templatecomponents as $ex)
                  <option @if($ex->id==$rels->id) selected @endif value="689381" selected id="headingValue">{{$ex->name}}</option>
                @endforeach
              </select>
              </div>
            
            <div id="compDetails">
            <!-- Added for drefault values -->
            <div>
            <div class="sideheading">
              <label>Subheading</label>
              <br>
                <input value="{{$rels->sub_heading}}" id="editLabel" onkeyup="editLabel(this.id)" maxlength="24" type="text">
            </div>
<?php
$get_options=App\Helper\AppHelper::GetoptionsFirstSecond($rels->id);
?> 
            <div class="sideheading">
              <label>Option</label>
              <br>
              <div id="editOpdtionDiv">
                  <select class="editOption" >
                      @foreach($get_options as $ex)
                       <option value="{{$ex->id}}">{{$ex->options}}</option>
                      @endforeach
                  </select>
                </div>
            </div>
  
            <div class="sideheading" id="tickType">
                <select id="editOptionType" name="editOptionType">
                  <option id="1" value="Square">Square</option>
                  <option id="2" value="Circle">Circle</option>
                  <option id="3" value="None">None</option>
                </select>
            </div>
  
<?php
$get_allchkbox=App\Helper\AppHelper::GetoptionResultsAll($rels->id);
?> 
   @foreach($get_allchkbox as $ckbx)
            <div class="sideheading editDesc optdesc_{{$ckbx->option_id}}" id="editDesc" @if($ckbx->options=="Second") style="display:none" @endif >
               <div id="optionList">
<div class="checkbox" id="checkboxcnt_1">
  <span class="checkbox" style="display:block;">
  <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="editImage_1">&nbsp;&nbsp;
  <input size="9" class="optiontext" id="optiontext_1" value="{{$ckbx->details}}" style="width: 100px;" type="text">
  <input name="remove_1" value="" id="remove_1" class="deleteEditOption" type="button">
  <input name="add_1" value="" id="add_1" class="addEditOption" style="display: none;" type="button">
  </span>
</div>
               </div>
            </div>
      @endforeach      
</div>
        <!-- /.box -->
        </div>
            </div>
        @endforeach
        </section>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
tab2
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3">
               tab3
              </div>
              <div class="tab-pane" id="tab_4">
              tab4
              </div>
              <div class="tab-pane" id="tab_5">
              tab5
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
      </div>
    </section>
   
 
@endsection


@section('customJs')

<script type="text/javascript">
$( document ).ready(function() {


$( ".iImageEdit" ).on( "click", function() {
    
   var sts=$(this).data('sts');
    $( "#editComponent" ).css("display","block");
    $( ".templcomps" ).css("display","none");
    
       $( "#tempcms_"+sts+"" ).css("display","block");
    
});
$( ".editOption" ).on( "click", function() {
    var optfirst=$(this).val();
 
    console.log(optfirst); 
    $( ".editDesc" ).css("display","none");
    $( ".optdesc_"+optfirst+"" ).css("display","block");
});


});

</script>

@endsection
