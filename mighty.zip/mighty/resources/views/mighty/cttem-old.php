<?php
$template=Config::get('custom.template');
?>
@extends('mighty.layout.tpl')
@section('customCss')
<link rel="stylesheet" href="{{URL::asset('mighty/plugins/template.css')}}"> 
<style>
.content {
    min-height: 1811px;
}
</style>
@endsection

@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Mighty Customizable Vehicle Inspection Forms
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">CVIF</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab">Template 101</a></li>
              <li><a href="#tab_2" data-toggle="tab">Template 102</a></li>
              <li><a href="#tab_3" data-toggle="tab">Template 103</a></li>
              <li><a href="#tab_4" data-toggle="tab">Template 104</a></li>
              <li><a href="#tab_5" data-toggle="tab">Template 105</a></li>
              </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
           <section class="content">    
        <div class="col-md-12">
        <!-- Horizontal Form -->
<div class="insideinnercontainer">
            <div style="width:576px;margin:16px 5px; float:left;">
              <div style="width:579px; border:1px #000 solid; float:left;">
              <input name="currentDiv" id="currentDiv" value="compDiv_1" type="hidden">
            <input name="prevDiv" id="prevDiv" value="compDiv_1" type="hidden">
            <input name="edited" id="edited" value="false" type="hidden">
            <form id="updateForm" name="updateForm" action="./updateForm.do" method="post">
              <!-- Template will be shown up here -->
            <!-- Header Starts -->
            
              <div id="header">
                <p id="headerText" style="display: block; margin-left: 100px;">VEHICLE CONDITION repoRT</p>
                <input value="VEHICLE CONDITION repoRT" id="editText" style="display: none;" maxlength="24" type="text">
              </div>
              <a href="#" id="editHeading" style="position: relative; top: -30px; display: inline;">
                <img src="{{URL::asset('mighty/images/ieditover.png')}}" height="17px" width="16px">
              </a> 
              <a href="#" id="okHeading" style="position: relative; top: -30px; display: none;">
                <img id="iok" src="{{URL::asset('mighty/images/iok.png')}}" height="17px" width="16px">
              </a>
              <!-- Header Ends -->
              <div id="imgLogo" align="center">
              
              
                <p id="msg">(Your logo here)<br>Dimension:[336 x 72]pixels</p>
              
              </div>
            
            
            <div class="text_field">Mileage_________________</div>
           
                <!--Vc Inner container starts-->
                <div id="VCcontinner" class="VCcontinner">
                
                <!--List left starts-->
                
                <input name="userFormId" id="userFormId" value="689357" type="hidden">
                <input name="templateId" id="templateId" value="1" type="hidden">
                <input name="headingText" id="headingText" value="VEHICLE CONDITION repoRT" type="hidden"> 
          <input name="saveImage" id="saveImage" value="" type="hidden"> 
                <input name="headerColor" id="headerColor" value="#045fb4" type="hidden">
                <input name="currHeaderColor" id="currHeaderColor" value="#045fb4" type="hidden">
                  <div class="listcontatleftEdit">
                  <!-- List out first eight elements -->
                    <ul class="VClist">
                    
                    <input name="viewComponent1" id="viewComponent1" value="689469" type="hidden">
                    <input name="templateComponent1" id="templateComponent1" value="689469" type="hidden">
                    <input name="viewPosition1" id="viewPosition1" value="1" type="hidden">
            <input name="templatePosition1" id="templatePosition1" value="1" type="hidden">
            <input name="componentName1" id="componentName1" value="Lights" type="hidden">
            <input name="label1" id="label1" value="" type="hidden">
                        <li>
                        
                        <input name="visibility1" id="visibility1" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv1" class="ListDivVisible">
                      
                      
                      
                        <div id="compDiv_1" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan1">Lights</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_1"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_1">
                            
               <div id="optDivParent1">
                           
                           
                              
                 
                           <input name="scoptionId1" id="scoptionId1" value="689466" type="hidden">
                           <input name="optionId1" id="optionId1" value="689465" type="hidden">
                           <input name="optionValue1" id="optionValue1" value="Pass^Fail" type="hidden">
                           <input name="optionString1" id="optionString1" value="Pass^Fail" type="hidden">
                           <input id="optType1" name="optType1" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv1">
                              <div class="checkbox">
                                <span>
                
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_11">
                <label id="opt11" class="optionText">Pass</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_12">
                <label id="opt12" class="optionText">Fail</label>
                
                        
                        </span>
                           </div>
                           </div>
                           
                           
                           
                           
                           </div>
                           <div class="clear"></div>
                          </div>
                         </div></li>
                     
                    <input name="viewComponent2" id="viewComponent2" value="689400" type="hidden">
                    <input name="templateComponent2" id="templateComponent2" value="689400" type="hidden">
                    <input name="viewPosition2" id="viewPosition2" value="2" type="hidden">
            <input name="templatePosition2" id="templatePosition2" value="2" type="hidden">
            <input name="componentName2" id="componentName2" value="Wiper Blades" type="hidden">
            <input name="label2" id="label2" value="6,000 Miles" type="hidden">
                        <li>
                        
                        <input name="visibility2" id="visibility2" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv2" class="ListDivVisible">
                      
                      
                      
                        <div id="compDiv_2" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan2">Wiper Blades</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_2"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_2">
                            
                  <span class="subText" id="labelSpan2">6,000 Miles</span>
                 
               <div id="optDivParent2">
                           
                           
                              
                 
                           <input name="scoptionId2" id="scoptionId2" value="689397" type="hidden">
                           <input name="optionId2" id="optionId2" value="689396" type="hidden">
                           <input name="optionValue2" id="optionValue2" value="Good^Next Visit^Overdue" type="hidden">
                           <input name="optionString2" id="optionString2" value="Good^Next Visit^Overdue" type="hidden">
                           <input id="optType2" name="optType2" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv2">
                              <div class="checkbox">
                                <span>
                
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_21">
                <label id="opt21" class="optionText">Good</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_22">
                <label id="opt22" class="optionText">Next Visit</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_23">
                <label id="opt23" class="optionText">Overdue</label>
                
                        
                        </span>
                           </div>
                           </div>
                           
                           
                           
                           
                           </div>
                           <div class="clear"></div>
                          </div>
                         </div></li>
                     
                    <input name="viewComponent3" id="viewComponent3" value="689424" type="hidden">
                    <input name="templateComponent3" id="templateComponent3" value="689424" type="hidden">
                    <input name="viewPosition3" id="viewPosition3" value="3" type="hidden">
            <input name="templatePosition3" id="templatePosition3" value="3" type="hidden">
            <input name="componentName3" id="componentName3" value="Oil Level " type="hidden">
            <input name="label3" id="label3" value="" type="hidden">
                        <li>
                        
                        <input name="visibility3" id="visibility3" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv3" class="ListDivVisible">
                      
                      
                      
                        <div id="compDiv_3" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan3">Oil Level </span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_3"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_3">
                            
               <div id="optDivParent3">
                           
                           
                              
                 
                           <input name="scoptionId3" id="scoptionId3" value="689421" type="hidden">
                           <input name="optionId3" id="optionId3" value="689420" type="hidden">
                           <input name="optionValue3" id="optionValue3" value="OK^1/2-1 qt. low^>1 qt. low" type="hidden">
                           <input name="optionString3" id="optionString3" value="OK^1/2-1 qt. low^>1 qt. low" type="hidden">
                           <input id="optType3" name="optType3" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv3">
                              <div class="checkbox">
                                <span>
                
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_31">
                <label id="opt31" class="optionText">OK</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_32">
                <label id="opt32" class="optionText">1/2-1 qt. low</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_33">
                <label id="opt33" class="optionText">&gt;1 qt. low</label>
                
                        
                        </span>
                           </div>
                           </div>
                           
                           
                           
                           
                           </div>
                           <div class="clear"></div>
                          </div>
                         </div></li>
                     
                    <input name="viewComponent4" id="viewComponent4" value="689499" type="hidden">
                    <input name="templateComponent4" id="templateComponent4" value="689499" type="hidden">
                    <input name="viewPosition4" id="viewPosition4" value="4" type="hidden">
            <input name="templatePosition4" id="templatePosition4" value="4" type="hidden">
            <input name="componentName4" id="componentName4" value="Brake Fluid " type="hidden">
            <input name="label4" id="label4" value="30,000 Miles" type="hidden">
                        <li>
                        
                        <input name="visibility4" id="visibility4" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv4" class="ListDivVisible">
                      
                      
                      
                        <div id="compDiv_4" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan4">Brake Fluid </span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_4"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_4">
                            
                  <span class="subText" id="labelSpan4">30,000 Miles</span>
                 
               <div id="optDivParent4">
                           
                           
                              
                 
                           <input name="scoptionId4" id="scoptionId4" value="689496" type="hidden">
                           <input name="optionId4" id="optionId4" value="689495" type="hidden">
                           <input name="optionValue4" id="optionValue4" value="Good^Next Visit^Overdue" type="hidden">
                           <input name="optionString4" id="optionString4" value="Good^Next Visit^Overdue" type="hidden">
                           <input id="optType4" name="optType4" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv4">
                              <div class="checkbox">
                                <span>
                
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_41">
                <label id="opt41" class="optionText">Good</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_42">
                <label id="opt42" class="optionText">Next Visit</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_43">
                <label id="opt43" class="optionText">Overdue</label>
                
                        
                        </span>
                           </div>
                           </div>
                           
                           
                           
                           
                           </div>
                           <div class="clear"></div>
                          </div>
                         </div></li>
                     
                    <input name="viewComponent5" id="viewComponent5" value="689436" type="hidden">
                    <input name="templateComponent5" id="templateComponent5" value="689436" type="hidden">
                    <input name="viewPosition5" id="viewPosition5" value="5" type="hidden">
            <input name="templatePosition5" id="templatePosition5" value="5" type="hidden">
            <input name="componentName5" id="componentName5" value="Power Steering Fluid" type="hidden">
            <input name="label5" id="label5" value="60,000 Miles" type="hidden">
                        <li>
                        
                        <input name="visibility5" id="visibility5" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv5" class="ListDivVisible">
                      
                      
                      
                        <div id="compDiv_5" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan5">Power Steering Fluid</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_5"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_5">
                            
                  <span class="subText" id="labelSpan5">60,000 Miles</span>
                 
               <div id="optDivParent5">
                           
                           
                              
                 
                           <input name="scoptionId5" id="scoptionId5" value="689433" type="hidden">
                           <input name="optionId5" id="optionId5" value="689432" type="hidden">
                           <input name="optionValue5" id="optionValue5" value="Good^Next Visit^Overdue" type="hidden">
                           <input name="optionString5" id="optionString5" value="Good^Next Visit^Overdue" type="hidden">
                           <input id="optType5" name="optType5" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv5">
                              <div class="checkbox">
                                <span>
                
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_51">
                <label id="opt51" class="optionText">Good</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_52">
                <label id="opt52" class="optionText">Next Visit</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_53">
                <label id="opt53" class="optionText">Overdue</label>
                
                        
                        </span>
                           </div>
                           </div>
                           
                           
                           
                           
                           </div>
                           <div class="clear"></div>
                          </div>
                         </div></li>
                     
                    <input name="viewComponent6" id="viewComponent6" value="689493" type="hidden">
                    <input name="templateComponent6" id="templateComponent6" value="689493" type="hidden">
                    <input name="viewPosition6" id="viewPosition6" value="6" type="hidden">
            <input name="templatePosition6" id="templatePosition6" value="6" type="hidden">
            <input name="componentName6" id="componentName6" value="Washer Fluid" type="hidden">
            <input name="label6" id="label6" value="" type="hidden">
                        <li>
                        
                        <input name="visibility6" id="visibility6" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv6" class="ListDivVisible">
                      
                      
                      
                        <div id="compDiv_6" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan6">Washer Fluid</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_6"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_6">
                            
               <div id="optDivParent6">
                           
                           
                              
                 
                           <input name="scoptionId6" id="scoptionId6" value="689490" type="hidden">
                           <input name="optionId6" id="optionId6" value="689489" type="hidden">
                           <input name="optionValue6" id="optionValue6" value="Ok^Leaking^Topped off" type="hidden">
                           <input name="optionString6" id="optionString6" value="Ok^Leaking^Topped off" type="hidden">
                           <input id="optType6" name="optType6" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv6">
                              <div class="checkbox">
                                <span>
                
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_61">
                <label id="opt61" class="optionText">Ok</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_62">
                <label id="opt62" class="optionText">Leaking</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_63">
                <label id="opt63" class="optionText">Topped off</label>
                
                        
                        </span>
                           </div>
                           </div>
                           
                           
                           
                           
                           </div>
                           <div class="clear"></div>
                          </div>
                         </div></li>
                     
                    <input name="viewComponent7" id="viewComponent7" value="689387" type="hidden">
                    <input name="templateComponent7" id="templateComponent7" value="689387" type="hidden">
                    <input name="viewPosition7" id="viewPosition7" value="7" type="hidden">
            <input name="templatePosition7" id="templatePosition7" value="7" type="hidden">
            <input name="componentName7" id="componentName7" value="Transmission Fluid" type="hidden">
            <input name="label7" id="label7" value="30,000 Miles" type="hidden">
                        <li>
                        
                        <input name="visibility7" id="visibility7" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv7" class="ListDivVisible">
                      
                      
                      
                        <div id="compDiv_7" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan7">Transmission Fluid</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_7"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_7">
                            
                  <span class="subText" id="labelSpan7">30,000 Miles</span>
                 
               <div id="optDivParent7">
                           
                           
                              
                 
                           <input name="scoptionId7" id="scoptionId7" value="689384" type="hidden">
                           <input name="optionId7" id="optionId7" value="689383" type="hidden">
                           <input name="optionValue7" id="optionValue7" value="Good^Next Visit^Overdue" type="hidden">
                           <input name="optionString7" id="optionString7" value="Good^Next Visit^Overdue" type="hidden">
                           <input id="optType7" name="optType7" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv7">
                              <div class="checkbox">
                                <span>
                
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_71">
                <label id="opt71" class="optionText">Good</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_72">
                <label id="opt72" class="optionText">Next Visit</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_73">
                <label id="opt73" class="optionText">Overdue</label>
                
                        
                        </span>
                           </div>
                           </div>
                           
                           
                           
                           
                           </div>
                           <div class="clear"></div>
                          </div>
                         </div></li>
                     
                    <input name="viewComponent8" id="viewComponent8" value="689369" type="hidden">
                    <input name="templateComponent8" id="templateComponent8" value="689369" type="hidden">
                    <input name="viewPosition8" id="viewPosition8" value="8" type="hidden">
            <input name="templatePosition8" id="templatePosition8" value="8" type="hidden">
            <input name="componentName8" id="componentName8" value="Belt(s) &amp; Tensioner" type="hidden">
            <input name="label8" id="label8" value="48,000 Miles" type="hidden">
                        <li>
                        
                        <input name="visibility8" id="visibility8" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv8" class="ListDivVisible">
                      
                      
                      
                        <div id="compDiv_8" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan8">Belt(s) &amp; Tensioner</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_8"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_8">
                            
                  <span class="subText" id="labelSpan8">48,000 Miles</span>
                 
               <div id="optDivParent8">
                           
                           
                              
                 
                           <input name="scoptionId8" id="scoptionId8" value="689366" type="hidden">
                           <input name="optionId8" id="optionId8" value="689365" type="hidden">
                           <input name="optionValue8" id="optionValue8" value="Good^Next Visit^Overdue" type="hidden">
                           <input name="optionString8" id="optionString8" value="Good^Next Visit^Overdue" type="hidden">
                           <input id="optType8" name="optType8" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv8">
                              <div class="checkbox">
                                <span>
                
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_81">
                <label id="opt81" class="optionText">Good</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_82">
                <label id="opt82" class="optionText">Next Visit</label>
                
                        
                
                <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_83">
                <label id="opt83" class="optionText">Overdue</label>
                
                        
                        </span>
                           </div>
                           </div>
                           
                           
                           
                           
                           </div>
                           <div class="clear"></div>
                          </div>
                         </div></li>
                        
                </ul>
              </div>
                <!--List left Ends-->
                
                <!--List right starts-->
                <div class="listcontatrightEdit">
                 <!-- List out rest seven elements -->
                  <ul class="VClist">
                  
                    <input name="viewComponent9" id="viewComponent9" value="689412" type="hidden">
                        <input name="viewPosition9" id="viewPosition9" value="9" type="hidden">
                        <input name="templateComponent9" id="templateComponent9" value="689412" type="hidden">
            <input name="templatePosition9" id="templatePosition9" value="9" type="hidden">
            <input name="componentName9" id="componentName9" value="Antifreeze/Coolant" type="hidden">
            <input name="label9" id="label9" value="30,000 Miles" type="hidden">
                      <li>
                      
                      <input name="visibility9" id="visibility9" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv9" class="ListDivVisible">
                      
                      
                       
                      <div id="compDiv_9" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan9">Antifreeze/Coolant</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_9"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_9">
                          
                   <span class="subText" id="labelSpan9">30,000 Miles</span>
                
              <div id="optDivParent9">
                         
                         
                             
                
                           <input name="scoptionId9" id="scoptionId9" value="689409" type="hidden">
                           <input name="optionId9" id="optionId9" value="689408" type="hidden">
                           <input name="optionValue9" id="optionValue9" value="Good^Next Visit^Overdue" type="hidden">
                           <input name="optionString9" id="optionString9" value="Good^Next Visit^Overdue" type="hidden">
                           <input id="optType9" name="optType9" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv9">
                            
                              
                               <div class="checkboxcnt">
                              
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_91">
                    <label id="opt91" class="optionText">Good</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_92">
                    <label id="opt92" class="optionText">Next Visit</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_93">
                    <label id="opt93" class="optionText">Overdue</label>
                  
                  </span>
                             </div>
                          
                           </div>
                              
                              
                            
                          </div>
                       
                       
                         
                       
                       </div>
                         <div class="clear"></div>
                         </div>
                         </div>
                     </li>
                   
                    <input name="viewComponent10" id="viewComponent10" value="689487" type="hidden">
                        <input name="viewPosition10" id="viewPosition10" value="10" type="hidden">
                        <input name="templateComponent10" id="templateComponent10" value="689487" type="hidden">
            <input name="templatePosition10" id="templatePosition10" value="10" type="hidden">
            <input name="componentName10" id="componentName10" value="Air Filter" type="hidden">
            <input name="label10" id="label10" value="12,000 Miles" type="hidden">
                      <li>
                      
                      <input name="visibility10" id="visibility10" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv10" class="ListDivVisible">
                      
                      
                       
                      <div id="compDiv_10" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan10">Air Filter</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_10"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_10">
                          
                   <span class="subText" id="labelSpan10">12,000 Miles</span>
                
              <div id="optDivParent10">
                         
                         
                             
                
                           <input name="scoptionId10" id="scoptionId10" value="689484" type="hidden">
                           <input name="optionId10" id="optionId10" value="689483" type="hidden">
                           <input name="optionValue10" id="optionValue10" value="Good^Next Visit^Overdue" type="hidden">
                           <input name="optionString10" id="optionString10" value="Good^Next Visit^Overdue" type="hidden">
                           <input id="optType10" name="optType10" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv10">
                            
                              
                               <div class="checkboxcnt">
                              
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_101">
                    <label id="opt101" class="optionText">Good</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_102">
                    <label id="opt102" class="optionText">Next Visit</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_103">
                    <label id="opt103" class="optionText">Overdue</label>
                  
                  </span>
                             </div>
                          
                           </div>
                              
                              
                            
                          </div>
                       
                       
                         
                       
                       </div>
                         <div class="clear"></div>
                         </div>
                         </div>
                     </li>
                   
                    <input name="viewComponent11" id="viewComponent11" value="689406" type="hidden">
                        <input name="viewPosition11" id="viewPosition11" value="11" type="hidden">
                        <input name="templateComponent11" id="templateComponent11" value="689406" type="hidden">
            <input name="templatePosition11" id="templatePosition11" value="11" type="hidden">
            <input name="componentName11" id="componentName11" value="Cabin Filter" type="hidden">
            <input name="label11" id="label11" value="15,000 Miles" type="hidden">
                      <li>
                      
                      <input name="visibility11" id="visibility11" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv11" class="ListDivVisible">
                      
                      
                       
                      <div id="compDiv_11" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan11">Cabin Filter</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_11"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_11">
                          
                   <span class="subText" id="labelSpan11">15,000 Miles</span>
                
              <div id="optDivParent11">
                         
                         
                             
                
                           <input name="scoptionId11" id="scoptionId11" value="689403" type="hidden">
                           <input name="optionId11" id="optionId11" value="689402" type="hidden">
                           <input name="optionValue11" id="optionValue11" value="Good^Next Visit^Overdue" type="hidden">
                           <input name="optionString11" id="optionString11" value="Good^Next Visit^Overdue" type="hidden">
                           <input id="optType11" name="optType11" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv11">
                            
                              
                               <div class="checkboxcnt">
                              
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_111">
                    <label id="opt111" class="optionText">Good</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_112">
                    <label id="opt112" class="optionText">Next Visit</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_113">
                    <label id="opt113" class="optionText">Overdue</label>
                  
                  </span>
                             </div>
                          
                           </div>
                              
                              
                            
                          </div>
                       
                       
                         
                       
                       </div>
                         <div class="clear"></div>
                         </div>
                         </div>
                     </li>
                   
                    <input name="viewComponent12" id="viewComponent12" value="689450" type="hidden">
                        <input name="viewPosition12" id="viewPosition12" value="12" type="hidden">
                        <input name="templateComponent12" id="templateComponent12" value="689450" type="hidden">
            <input name="templatePosition12" id="templatePosition12" value="12" type="hidden">
            <input name="componentName12" id="componentName12" value="Fuel Filter" type="hidden">
            <input name="label12" id="label12" value="15,000 Miles" type="hidden">
                      <li>
                      
                      <input name="visibility12" id="visibility12" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv12" class="ListDivVisible">
                      
                      
                       
                      <div id="compDiv_12" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan12">Fuel Filter</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_12"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_12">
                          
                   <span class="subText" id="labelSpan12">15,000 Miles</span>
                
              <div id="optDivParent12">
                         
                         
                             
                
                           <input name="scoptionId12" id="scoptionId12" value="689447" type="hidden">
                           <input name="optionId12" id="optionId12" value="689446" type="hidden">
                           <input name="optionValue12" id="optionValue12" value="Good^Next Visit^Overdue" type="hidden">
                           <input name="optionString12" id="optionString12" value="Good^Next Visit^Overdue" type="hidden">
                           <input id="optType12" name="optType12" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv12">
                            
                              
                               <div class="checkboxcnt">
                              
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_121">
                    <label id="opt121" class="optionText">Good</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_122">
                    <label id="opt122" class="optionText">Next Visit</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_123">
                    <label id="opt123" class="optionText">Overdue</label>
                  
                  </span>
                             </div>
                          
                           </div>
                              
                              
                            
                          </div>
                       
                       
                         
                       
                       </div>
                         <div class="clear"></div>
                         </div>
                         </div>
                     </li>
                   
                    <input name="viewComponent13" id="viewComponent13" value="689375" type="hidden">
                        <input name="viewPosition13" id="viewPosition13" value="13" type="hidden">
                        <input name="templateComponent13" id="templateComponent13" value="689375" type="hidden">
            <input name="templatePosition13" id="templatePosition13" value="13" type="hidden">
            <input name="componentName13" id="componentName13" value="Battery Condition" type="hidden">
            <input name="label13" id="label13" value="" type="hidden">
                      <li>
                      
                      <input name="visibility13" id="visibility13" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv13" class="ListDivVisible">
                      
                      
                       
                      <div id="compDiv_13" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan13">Battery Condition</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_13"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_13">
                          
              <div id="optDivParent13">
                         
                         
                             
                
                           <input name="scoptionId13" id="scoptionId13" value="689372" type="hidden">
                           <input name="optionId13" id="optionId13" value="689371" type="hidden">
                           <input name="optionValue13" id="optionValue13" value="Pass^Fail" type="hidden">
                           <input name="optionString13" id="optionString13" value="Pass^Fail" type="hidden">
                           <input id="optType13" name="optType13" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv13">
                            
                              
                               <div class="checkboxcnt">
                              
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_131">
                    <label id="opt131" class="optionText">Pass</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_132">
                    <label id="opt132" class="optionText">Fail</label>
                  
                  </span>
                             </div>
                          
                           </div>
                              
                              
                            
                          </div>
                       
                       
                         
                       
                       </div>
                         <div class="clear"></div>
                         </div>
                         </div>
                     </li>
                   
                    <input name="viewComponent14" id="viewComponent14" value="689393" type="hidden">
                        <input name="viewPosition14" id="viewPosition14" value="14" type="hidden">
                        <input name="templateComponent14" id="templateComponent14" value="689393" type="hidden">
            <input name="templatePosition14" id="templatePosition14" value="14" type="hidden">
            <input name="componentName14" id="componentName14" value="Differential  Fluid" type="hidden">
            <input name="label14" id="label14" value="30,000 Miles" type="hidden">
                      <li>
                      
                      <input name="visibility14" id="visibility14" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv14" class="ListDivVisible">
                      
                      
                       
                      <div id="compDiv_14" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan14">Differential  Fluid</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_14"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_14">
                          
                   <span class="subText" id="labelSpan14">30,000 Miles</span>
                
              <div id="optDivParent14">
                         
                         
                             
                
                           <input name="scoptionId14" id="scoptionId14" value="689390" type="hidden">
                           <input name="optionId14" id="optionId14" value="689389" type="hidden">
                           <input name="optionValue14" id="optionValue14" value="Good^Next Visit^Overdue" type="hidden">
                           <input name="optionString14" id="optionString14" value="Good^Next Visit^Overdue" type="hidden">
                           <input id="optType14" name="optType14" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv14">
                            
                              
                               <div class="checkboxcnt">
                              
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_141">
                    <label id="opt141" class="optionText">Good</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_142">
                    <label id="opt142" class="optionText">Next Visit</label>
                  
                  </span>
                             </div>
                          
                              <div class="checkbox">
                                 <span>
                                 
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_143">
                    <label id="opt143" class="optionText">Overdue</label>
                  
                  </span>
                             </div>
                          
                           </div>
                              
                              
                            
                          </div>
                       
                       
                         
                       
                       </div>
                         <div class="clear"></div>
                         </div>
                         </div>
                     </li>
                   
                    <input name="viewComponent15" id="viewComponent15" value="689418" type="hidden">
                        <input name="viewPosition15" id="viewPosition15" value="15" type="hidden">
                        <input name="templateComponent15" id="templateComponent15" value="689418" type="hidden">
            <input name="templatePosition15" id="templatePosition15" value="15" type="hidden">
            <input name="componentName15" id="componentName15" value="Tire Condition" type="hidden">
            <input name="label15" id="label15" value="Tread Depth Remaining" type="hidden">
                      <li>
                      
                      <input name="visibility15" id="visibility15" value="" class="displayDiv" type="hidden">
                      <div id="visibleDiv15" class="ListDivVisible">
                      
                      
                       
                      <div id="compDiv_15" class="ListDiv">
                          <span style="color: rgb(4, 95, 180);" class="text" id="headingSpan15">Tire Condition</span>
                           <img class="iImageEdit handSymbol" src="{{URL::asset('mighty/images/ieditover.png')}}" id="editComp_15"> 
            <img class="iDeleteEdit handSymbol" src="{{URL::asset('mighty/images/iDelete.png')}}" id="delComp_15">
                          
                   <span class="subText" id="labelSpan15">Tread Depth Remaining</span>
                
              <div id="optDivParent15">
                
                           <input name="scoptionId15" id="scoptionId15" value="689415" type="hidden">
                           <input name="optionId15" id="optionId15" value="689414" type="hidden">
                           <input name="optionValue15" id="optionValue15" value="Good (6/32&quot;+)^Next Visit(2/32&quot; or 3/23&quot;)^Overdue(5/32&quot; or 5/23&quot;)" type="hidden">
                           <input name="optionString15" id="optionString15" value="Good (6/32&quot;+)^Next Visit(2/32&quot; or 3/23&quot;)^Overdue(5/32&quot; or 5/23&quot;)" type="hidden">
                           <input id="optType15" name="optType15" value="Square" type="hidden">
                           <div class="checkboxcnt" id="optDiv15">
                            
                              
                              
                               <div class="checkboxcnt">
                               <span>
                    
                    <div class="checkbox15">
                    
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_151"> 
                    <label id="opt151" class="optionText">Good (6/32"+)</label>
                    
                    </div>
                            
                    <div class="checkbox15">
                    
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_152"> 
                    <label id="opt152" class="optionText">Next Visit(2/32" or 3/23")</label>
                    
                    </div>
                            
                    <div class="checkbox15">
                    
                    <img src="{{URL::asset('mighty/images/square.png')}}" class="imageOptionType" id="image_153"> 
                    <label id="opt153" class="optionText">Overdue(5/32" or 5/23")</label>
                    
                    </div>
                            
                            </span>
                              </div>
                            
                            
                          </div>
                       
                       
                         
                       
                       </div>
                         <div class="clear"></div>
                         </div>
                         </div>
                     </li>
                   
                   </ul>
                 </div>
                 <!--List right Ends-->
                 <div class="clear"></div>
                
            </div>
            <div class="clear"></div>
              <!--Vc Inner container Ends-->
                <div class="bottomtext">
        <span style="float:left;">Comments:</span>
        <hr style="width: 87%; margin-top:4%;"><br>
        <hr style="width: 99%;"><br>
        <hr style="width: 99%;"><br>    
        <span style="float: left; clear: left; margin-top: -4%;">Inspected by: </span> 
        <hr style="width: 45%;float:left;position:relative; top:-3px;">
        <span style="float: left; margin-top: -4%; width: 20.5%;">Date:</span>
        <hr style="width: 33.5%;float:left;margin-left:-14%;position:relative; top:-3px;">
        </div>
               <div class="clear"></div>
                </form></div>
            <!--Container Bottom Starts-->
            <div class="containerbtm" style="padding-left:200px;">
            <a id="updateId" class="btn-txt" onclick="launchWindow('#dialog');">Save</a>
          <a id="cancelButtonId" href="./userFormView.do?formid=689357" class="btn-txt" onclick="launchWindow('#dialog');">Cancel</a>
            </div>
            <!--Container Bottom Ends-->
            <div class="clear"></div>
             </div>
                  <!--Innercontainer left starts-->
          <div style="float: left; width: 333px; margin: 16px 5px;">
          <div class="rightcontainer">
            <div class="sideheading">
              <label>Form name : </label>
              <div>
                <input id="formName" name="formName" value="101 Form 2" maxlength="20" type="text">
              </div>
            </div>
           
          <form name="uploadLocalImage" action="./userFormEdit.do" method="post" id="uploadLocalImage" enctype="multipart/form-data">
            <div class="sideheading"><label>Upload your own image:</label>
            <div>
            
               <input id="center" name="center" value="template1" type="hidden">
                   <input id="centerimageHeight" name="centerimageHeight" value="72" type="hidden">
                   <input id="centerimageWidth" name="centerimageWidth" value="336" type="hidden">
              <input name="fileImage" id="localImage" value="" type="file">
              
              
              
                <span id="delBtn"></span>
              
                
            </div>
            </div>
          </form>
          <form name="uploadRImage" action="./browseImage.do?type=template1" method="post" id="uploadRImage" enctype="multipart/form-data">
          <div class="sideheading">
            <label><nobr>Choose from existing images :</nobr>
            </label>
          </div>
          <div style="width:340px;">
            <input readonly="readonly" style="height: 22px;width: 143px;float:left;" type="text">
            <input value="Browse..." id="browse" onclick="displayHideBox('1'); return false;" style="left: -80px;margin-top: 0px;position: relative;float:left;" type="submit">
            
              
              
                <span id="delBtn1"></span>
              
            
            <div id="grayBG" class="grayBox">
            </div>
            <div id="LightBox1" class="box_content" style="display: none;">
              <span style="float: right;"><img src="{{URL::asset('mighty/images/icon-delete.gif')}}" onclick="displayHideBox('1')"></span>
              <div style="background: #fff; width: 100%;">
                <div onclick="displayHideBox('1'); return false;" style="cursor: pointer;" align="right">
                  
                </div>
                <p>
                </p><div id="lbox"></div>
                <p></p>
              </div>
            </div>
          </div>
        </form>
          <!-- <div class="sideheading">
              <label>Choose From Existing Images </label> <input type="file" />
          </div> -->
              <div class="sideheading" style="clear:left;">
                  <label>Heading color</label>
                </div>
                <div id="iColor">
                      <input autocomplete="off" maxlength="7" name="color3" class="colors miniColors" value="#123456" id="inp1" src="{{URL::asset('mighty/images/images.png')}}" type="image"><a class="miniColors-trigger" style="background-color: #123456" href="#"></a>
                     
                  </div>
               <div class="sideheading">
               <label>Default Heading color:</label> <input id="inpDefault" style="cursor: pointer;" type="button">
             </div>
                      </div>               
                     </div>
            <div id="editComponent" style="float: left; width: 333px; display: none; margin: 0px 5px;">
                      <div class="rightcontainer">
                      <div class="sideheading">
                      <input name="lastEditOptionDiv" id="lastEditOptionDiv" value="" type="hidden"> 
                      <label>Position on the template :</label><label id="showPosition"></label>
                      </div>
                      <div class="sideheading">
                       <label>Heading</label><br>
                         <input name="TextboxExample" maxlength="25" id="changedHeading" tabindex="2" onchange="DropDownIndexClear('DropDownExTextboxExample');" onkeyup="editHeadingLabel(this.id)" style="width: 215px; height: 17px; position: absolute; border-right: none; border-bottom:none;" type="text">
              <select name="CompDrp" id="CompDrp" tabindex="1000" size="1" style="text-transform: capitalize; font-size: 12pt; font-family: 'MyriadProRegular', Arial; ">
                <option value="0">--Select--</option>
                
                  <option value="689381" id="headingValue">Hoses</option>
                
                  <option value="689436" id="headingValue">Power Steering Fluid</option>
                
                  <option value="689438" id="headingValue">Test Heading</option>
                
                  <option value="689469" id="headingValue">Lights</option>
                
                  <option value="689499" id="headingValue">Brake Fluid </option>
                
                  <option value="689424" id="headingValue">Oil Level </option>
                
                  <option value="689493" id="headingValue">Washer Fluid</option>
                
                  <option value="689457" id="headingValue">Check Engine Light </option>
                
                  <option value="689463" id="headingValue">Unusual Sounds/conditions</option>
                
                  <option value="689430" id="headingValue">Tire Pressure</option>
                
                  <option value="689387" id="headingValue">Transmission Fluid</option>
                
                  <option value="689450" id="headingValue">Fuel Filter</option>
                
                  <option value="689487" id="headingValue">Air Filter</option>
                
                  <option value="689418" id="headingValue">Tire Condition</option>
                
                  <option value="689481" id="headingValue">Windshield/Glass</option>
                
                  <option value="689363" id="headingValue">Tire Rotation</option>
                
                  <option value="689393" id="headingValue">Differential  Fluid</option>
                
                  <option value="689375" id="headingValue">Battery Condition</option>
                
                  <option value="689406" id="headingValue">Cabin Filter</option>
                
                  <option value="689400" id="headingValue">Wiper Blades</option>
                
                  <option value="689412" id="headingValue">Antifreeze/Coolant</option>
                
                  <option value="689475" id="headingValue">CV Boots/Axle</option>
                
                  <option value="689369" id="headingValue">Belt(s) &amp; Tensioner</option>
                
                  <option value="689444" id="headingValue">Oil Condition</option>
                
              </select>
            </div>
            
            <div id="compDetails">
            <!-- Added for drefault values -->
            <div>
            <div class="sideheading">
              <label>Subheading</label>
              <br>
                <input value="" id="editLabel" onkeyup="editLabel(this.id)" maxlength="24" type="text">
            </div>
            <div class="sideheading">
              <label>Option</label>
              <br>
              <div id="editOpdtionDiv">
                  <select id="editOption" onchange="changeOPtion(this.id)">
                      <option value="" selected="selected"></option>
                      <option value=""></option>
                  </select>
                </div>
            </div>
  
            <div class="sideheading" id="tickType">
                <select id="editOptionType" name="editOptionType">
                  <option id="1" value="Square">Square</option>
                  <option id="2" value="Circle">Circle</option>
                  <option id="3" value="None">None</option>
                </select>
            </div>
  
  
            <div class="sideheading" id="editDesc">
               <div id="optionList">
                 
               </div>
            </div>
</div>
        <!-- /.box -->
        </div>
        </section>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
<div class="innercontainer">
      
      
                
      <!-- Complete Width and Height -->
      <form name="updateUserForm" action="./updateUserFormIfs.do" method="post" id="updateUserForm">
      <input name="saveImage" id="saveImage" value="" type="hidden">
      <input name="saveLeftImage" id="saveLeftImage" value="" type="hidden">
      <input name="saveRightImage" id="saveRightImage" value="" type="hidden">
      <div style="margin-left:36%;padding:8px;">
         <span class="circlesquare">Form Name :</span> <input name="formName" id="formName" value="102 Form 2" maxlength="25" type="text"> 
      </div>
      <input name="userFormId" value="689921" type="hidden">
      <div id="templateSize">
        <div class="divLogoTab" style="width: 20.8cm;">         
          <div class="divLogoRow">
            <div class="logo1Parent">
              <div class="logo1">
                
                  
                    <div class="leftOptImage" id="logoLeft"></div>
                  
                  
                
              </div>
              <a href="javascript:void(0);" id="uploadImage1" onclick="centerImageSelectionPop('leftLogo',100,100); return false;" style="display: block !important;margin-top: 115px;margin-left: -40px; font-size: 14px;font-family: 'MyriadProRegular';">Click to upload optional logo</a> <span class="imgDimension" style="position:relative; left:10px;">[100 x 100]</span>
            </div>
            
              
                <div id="imgLogo" class="imgLogo" align="center">
                  <p id="msg">(Your logo here)<br>Dimension:[380 x 100]pixels</p>
                </div>
              
              
            
            <a href="#" id="centerImageClick" onclick="centerImageSelectionPop('center',380,100); return false;" style="margin-left: 0px;height: 0; font-family: 'MyriadProRegular'; font-size: 11pt;position:relative; left:38%;top:10px;">Click to upload logo</a> &nbsp;&nbsp;<span class="imgDimension" style="position:relative; left:38%;top:10px;">[380 x 100]</span>
            <div class="logo2">
              
                
                  <div class="rghtOptImage" id="logoRight"></div> 
                
                
              
              <a href="javascript:void(0);" id="uploadImage2" onclick="centerImageSelectionPop('rightLogo',100,100); return false;" style="display:inline;margin-top:0px; font-family: 'MyriadProRegular';font-size: 14px;white-space:nowrap;position:relative;left:-32px;top:10px;">Click to upload optional logo</a><br> <span class="imgDimension" style="position:relative; top:8px;left:20px;">[100 x 100]</span>
            </div>
          </div>
        </div>
      </div>
      <div id="pageHeading">
        <p id="headerText102" style="display: block; margin-left: 20px;font-size:20pt;">WE PERFORMED THE FOLLOWING FREE INSPECTION:</p>
        <input name="headingText102" id="headingText102" value="WE PERFORMED THE FOLLOWING FREE INSPECTION:" type="hidden">
        <input value="WE PERFORMED THE FOLLOWING FREE INSPECTION:" id="editText102" style="display: none; font-size: 20pt;font-weight: bold;margin-left: 87px;width: 80%;" maxlength="44" type="text">
        <a href="javascript:void(0);" id="editHeading102" style="float:right;margin-right: 51px;margin-top: -30px;">
          <img src="../images/ieditover.PNG" height="17px" width="16px">
        </a>
        <a href="javascript:void(0);" id="okHeading102" style="display:none;">
          <img id="iok" src="../images/iok.png" height="17px" width="16px">
        </a>
        <div class="clear"></div>
      </div>
      <!-- Form 1 -->
      <div class="divTable" style="width:850px;">
        <div class="divRow">
          <div class="divCell" id="customer" style="border: 1px solid #ACACAC;margin-left: 40px;width: 763px;">
            <div class="divCell" id="inner_Customer">
            
              <input id="editComp_6_0" name="editComp_6_0" style="text-align:left;display:none;width:763px;height:30px;font-family: MyriadProRegular;font-size: 11pt;border:1px solid black;" onkeypress="return checkStringLength(this.id, event);" onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" value="Customer: _______________________________ Phone: _________________ Mileage: __________________________" onblur=" mouseOut0()" type="text">
            
              <input id="editComp_6_1" name="editComp_6_1" style="text-align:left;display:none;width:763px;height:30px;font-family: MyriadProRegular;font-size: 11pt;border:1px solid black;" onkeypress="return checkStringLength(this.id, event);" onpaste="return false" ondrop="return false" ondrag="return false" oncopy="return false" value="Year/Make/Model: ________________________________ VIN: ______________________________________________" onblur=" mouseOut1()" type="text">
            
            </div>
            <span id="divTxt_attention" style="display:none;">
              <input id="editComp_6" name="editComp_6" style="text-align:left;display:none;width:763px;height:30px;" value="Customer: _______________________________ Phone: _________________ Mileage: __________________________~Year/Make/Model: ________________________________ VIN: ______________________________________________" type="text">
              <input id="componentId6" name="componentId6" value="6899371" type="hidden">
            </span>
            
            
              <div class="custSpanText" style="width: 800px;">
                <span id="cust1" style="font-family: MyriadProRegular;font-size: 11pt;line-height: 1.9" class="customerSpanText">Customer: _______________________________ Phone: _________________ Mileage: __________________________</span>
              </div>
            
              <div class="custSpanText" style="width: 800px;">
                <span id="cust2" style="font-family: MyriadProRegular;font-size: 11pt;line-height: 1.9" class="customerSpanText">Year/Make/Model: ________________________________ VIN: ______________________________________________</span>
              </div>
            
          </div>
          <a href="javascript:void(0);" id="editButton6" onclick="editTextFirstCompnent('component6')" style="float:left; position:relative; left:5px;">
            <img src="../images/ieditover.PNG" height="17px" width="16px">
          </a> 
          <a href="javascript:void(0);" id="okButton6" onclick="removeFirstComponentEdit('editComp_6',186)" style="display:none;float:left; position:relative; left:5px;">
            <img id="iok" src="../images/iok.png" height="17px" width="16px">
          </a>
        </div>
      </div>
      <div id="commentDiv" style="font-family: 'MyriadProRegular', Sans-Serif; font-size: 11pt; letter-spacing: .5px; width: 960px;">
        <span id="temp1"></span>
      </div>
      
        <div style="padding:15px 55px;">
          <span class="circlesquare">
            <input name="imgType" value="circle" type="radio"> Circle
          </span>
          <span class="circlesquare">
            <input name="imgType" value="square" checked="checked" type="radio"> Square
          </span>
        </div>
          
      
      <!-- ATTENTION -->
      <div class="selTable selTableEdit">
        <div class="selRow">
          <div class="selCol">
            <div class="selCell">             
              
                
                
                  <input class="greenSquare" type="button">
                
              
              <nobr>
                <p id="comp_7">NO IMMEDIATE ATTENTION</p>
                <input id="editComp_7" name="editComp_7" value="NO IMMEDIATE ATTENTION" style="display:none;float: none;width: 200px;" class="focusOutSave" maxlength="23" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId7" value="6899156" type="hidden">
                </span>
                <a href="javascript:void(0);" id="editButton7" onclick="editText('component7')">
                  <img src="../images/ieditover.PNG" height="17px" width="16px">
                </a> 
                <a href="javascript:void(0);" id="okButton7" onclick="removeEdit('editComp_7',23)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="16px">
                </a>
              </nobr>
            </div>
          </div>
          <div class="selCol">
            <div class="selCell">
              
                
                
                  <input class="yellowSquare" type="button">
                
              
              <nobr id="nobr">
                <p id="comp_8">MAY REQUIRE FUTURE ATTENTION</p>
                <input id="editComp_8" name="editComp_8" value="MAY REQUIRE FUTURE ATTENTION" style="display:none;float: none;width: 200px;" class="focusOutSave" maxlength="30" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId8" value="6899157" type="hidden">
                </span>
                <a href="javascript:void(0);" id="editButton8" onclick="editText('component8')">
                  <img src="../images/ieditover.PNG" height="17px" width="16px">
                </a> 
                <a href="javascript:void(0);" id="okButton8" onclick="removeEdit('editComp_8',25)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="16px">
                </a>
              </nobr>
            </div>
          </div>
          <div class="selCol">
            <div class="selCell">
              
                
                
                  <input class="redSquare" type="button">
                
              
              <nobr id="nobr">
                <p id="comp_9">IMMEDIATE ATTENTION</p>
                <input id="editComp_9" name="editComp_9" value="IMMEDIATE ATTENTION" style="display:none;float: none;width: 200px;" class="focusOutSave" maxlength="23" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId9" value="6899158" type="hidden">
                </span>
                <a href="javascript:void(0);" id="editButton9" onclick="editText('component9')">
                  <img src="../images/ieditover.PNG" height="17px" width="16px">
                </a> 
                <a href="javascript:void(0);" id="okButton9" onclick="removeEdit('editComp_9',25)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="16px">
                </a>
              </nobr>               
            </div>
          </div>
        </div>
      </div>
      <!-- Items And Conditions -->
        <div class="divTable1">
          <div id="div1" style="margin-left:40px;">
            <div class="divRow">
              <div class="divCell1 rowheading" id="content">
                <p id="comp_10">ITEMS</p>
                <input id="editComp_10" name="editComp_10" value="ITEMS" style="display:none;float: none;width: 170px;" maxlength="10" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId10" value="6899375" type="hidden">
                </span>
                <a href="javascript:void(0);" id="editButton10" onclick="editText('component10')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="16px">
                </a> 
                <a href="javascript:void(0);" id="okButton10" onclick="removeEdit('editComp_10',25)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="16px">
                </a>  
              </div>
              
              <div class="divCell1 rowheading" id="content">
                <p id="comp_11">CONDITION</p>
                <input id="editComp_11" name="editComp_11" value="CONDITION" style="display:none;float: none;width: 170px;" maxlength="10" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId11" value="6899481" type="hidden">
                </span>
                <a href="javascript:void(0);" id="editButton11" onclick="editText('component11')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="16px">
                </a> 
                <a href="javascript:void(0);" id="okButton11" onclick="removeEdit('editComp_11',25)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="16px">
                </a>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_12">Lights</p>
                <input id="editComp_12" name="editComp_12" value="Lights" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId12" value="6899376" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component12" style="float: right;" onclick="deleteText('component12')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="16px">
                </a>
                
                <a href="javascript:void(0);" id="editButton12" onclick="editText('component12')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="16px">
                </a> 
                <a href="javascript:void(0);" id="okButton12" onclick="removeEdit('editComp_12',26)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="16px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_13">Wiper Blades</p>
                <input id="editComp_13" name="editComp_13" value="Wiper Blades" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId13" value="6899262" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component13" style="float: right;" onclick="deleteText('component13')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton13" onclick="editText('component13')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton13" onclick="removeEdit('editComp_13',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_14">Windshield/Glass Damage</p>
                <input id="editComp_14" name="editComp_14" value="Windshield/Glass Damage" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId14" value="6899370" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component14" style="float: right;" onclick="deleteText('component14')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton14" onclick="editText('component14')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton14" onclick="removeEdit('editComp_14',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_15">Check Engine Light On</p>
                <input id="editComp_15" name="editComp_15" value="Check Engine Light On" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId15" value="6899260" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component15" style="float: right;" onclick="deleteText('component15')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton15" onclick="editText('component15')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton15" onclick="removeEdit('editComp_15',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_16">Oil Level</p>
                <input id="editComp_16" name="editComp_16" value="Oil Level" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId16" value="6899263" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component16" style="float: right;" onclick="deleteText('component16')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton16" onclick="editText('component16')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton16" onclick="removeEdit('editComp_16',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_17">Oil Condition</p>
                <input id="editComp_17" name="editComp_17" value="Oil Condition" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId17" value="6899591" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component17" style="float: right;" onclick="deleteText('component17')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton17" onclick="editText('component17')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton17" onclick="removeEdit('editComp_17',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_18">Brake Fluid</p>
                <input id="editComp_18" name="editComp_18" value="Brake Fluid" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId18" value="6899484" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component18" style="float: right;" onclick="deleteText('component18')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton18" onclick="editText('component18')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton18" onclick="removeEdit('editComp_18',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>            
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_19">Power Steering Fluid</p>
                <input id="editComp_19" name="editComp_19" value="Power Steering Fluid" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId19" value="6899269" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component19" style="float: right;" onclick="deleteText('component19')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton19" onclick="editText('component19')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton19" onclick="removeEdit('editComp_19',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_20">Washer Fluid</p>
                <input id="editComp_20" name="editComp_20" value="Washer Fluid" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId20" value="6899373" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component20" style="float: right;" onclick="deleteText('component20')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton20" onclick="editText('component20')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton20" onclick="removeEdit('editComp_20',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_21">Transmission Fluid</p>
                <input id="editComp_21" name="editComp_21" value="Transmission Fluid" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId21" value="6899159" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component21" style="float: right;" onclick="deleteText('component21')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton21" onclick="editText('component21')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton21" onclick="removeEdit('editComp_21',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_22">Belt(s) &amp; Tensioner</p>
                <input id="editComp_22" name="editComp_22" value="Belt(s) &amp; Tensioner" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId22" value="6899266" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component22" style="float: right;" onclick="deleteText('component22')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton22" onclick="editText('component22')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton22" onclick="removeEdit('editComp_22',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_23">Hoses</p>
                <input id="editComp_23" name="editComp_23" value="Hoses" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId23" value="6899482" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component23" style="float: right;" onclick="deleteText('component23')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton23" onclick="editText('component23')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton23" onclick="removeEdit('editComp_23',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_24">Antifreeze / Coolant</p>
                <input id="editComp_24" name="editComp_24" value="Antifreeze / Coolant" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId24" value="6899379" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component24" style="float: right;" onclick="deleteText('component24')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton24" onclick="editText('component24')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton24" onclick="removeEdit('editComp_24',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_25">Air Filter</p>
                <input id="editComp_25" name="editComp_25" value="Air Filter" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId25" value="6899590" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component25" style="float: right;" onclick="deleteText('component25')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton25" onclick="editText('component25')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton25" onclick="removeEdit('editComp_25',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
          </div>
          
          <div id="div2" style="margin-right:35px;">
            <div class="divRow">
              <div class="divCell1 rowheading" id="content">
                <p id="comp_26">ITEMS</p>
                <input id="editComp_26" name="editComp_26" value="ITEMS" style="display:none;float: none;width: 170px;" maxlength="10" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId26" value="6899486" type="hidden">
                </span>
                <a href="javascript:void(0);" id="editButton26" onclick="editText('component26')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton26" onclick="removeEdit('editComp_26',10)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>            
              </div>
              
              <div class="divCell1 rowheading" id="content">
                <p id="comp_27">CONDITION</p>
                <input id="editComp_27" name="editComp_27" value="CONDITION" style="display:none;float: none;width: 170px;" maxlength="10" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId27" value="6899489" type="hidden">
                </span>
                <a href="javascript:void(0);" id="editButton27" onclick="editText('component27')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton27" onclick="removeEdit('editComp_27',10)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>  
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_28">Cabin Filter</p>
                <input id="editComp_28" name="editComp_28" value="Cabin Filter" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId28" value="6899265" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component28" style="float: right;" onclick="deleteText('component28')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton28" onclick="editText('component28')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton28" onclick="removeEdit('editComp_28',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_29">Fuel Filter</p>
                <input id="editComp_29" name="editComp_29" value="Fuel Filter" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId29" value="6899264" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component29" style="float: right;" onclick="deleteText('component29')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton29" onclick="editText('component29')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton29" onclick="removeEdit('editComp_29',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1">
                <div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div>
              </div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_30">Battery Condition</p>
                <input id="editComp_30" name="editComp_30" value="Battery Condition" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId30" value="6899374" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component30" style="float: right;" onclick="deleteText('component30')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton30" onclick="editText('component30')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton30" onclick="removeEdit('editComp_30',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_31">Spark Plugs / Wires</p>
                <input id="editComp_31" name="editComp_31" value="Spark Plugs / Wires" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId31" value="6899488" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component31" style="float: right;" onclick="deleteText('component31')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton31" onclick="editText('component31')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton31" onclick="removeEdit('editComp_31',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_32">Fuel System Service</p>
                <input id="editComp_32" name="editComp_32" value="Fuel System Service" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId32" value="6899377" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component32" style="float: right;" onclick="deleteText('component32')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton32" onclick="editText('component32')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton32" onclick="removeEdit('editComp_32',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_33">Differential Fluid</p>
                <input id="editComp_33" name="editComp_33" value="Differential Fluid" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId33" value="6899378" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component33" style="float: right;" onclick="deleteText('component33')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton33" onclick="editText('component33')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton33" onclick="removeEdit('editComp_33',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_34">Tire Pressure</p>
                <input id="editComp_34" name="editComp_34" value="Tire Pressure" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId34" value="6899268" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component34" style="float: right;" onclick="deleteText('component34')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton34" onclick="editText('component34')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton34" onclick="removeEdit('editComp_34',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_35">Tire Rotation</p>
                <input id="editComp_35" name="editComp_35" value="Tire Rotation" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId35" value="6899485" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component35" style="float: right;" onclick="deleteText('component35')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton35" onclick="editText('component35')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton35" onclick="removeEdit('editComp_35',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_36">Tire Condition</p>
                <input id="editComp_36" name="editComp_36" value="Tire Condition" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId36" value="6899483" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component36" style="float: right;" onclick="deleteText('component36')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton36" onclick="editText('component36')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton36" onclick="removeEdit('editComp_36',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_37">Alignment</p>
                <input id="editComp_37" name="editComp_37" value="Alignment" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId37" value="6899372" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component37" style="float: right;" onclick="deleteText('component37')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton37" onclick="editText('component37')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton37" onclick="removeEdit('editComp_37',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_38">Shocks / Struts</p>
                <input id="editComp_38" name="editComp_38" value="Shocks / Struts" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId38" value="6899267" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component38" style="float: right;" onclick="deleteText('component38')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton38" onclick="editText('component38')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton38" onclick="removeEdit('editComp_38',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_39">CV Boots / Axles</p>
                <input id="editComp_39" name="editComp_39" value="CV Boots / Axles" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId39" value="6899261" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component39" style="float: right;" onclick="deleteText('component39')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton39" onclick="editText('component39')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton39" onclick="removeEdit('editComp_39',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_40">Exhaust System</p>
                <input id="editComp_40" name="editComp_40" value="Exhaust System" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId40" value="6899487" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component40" style="float: right;" onclick="deleteText('component40')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton40" onclick="editText('component40')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton40" onclick="removeEdit('editComp_40',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
            <div class="divRow">
              <div class="divCell1" id="content">
                <p id="comp_41">Other</p>
                <input id="editComp_41" name="editComp_41" value="Other" style="display:none;float: none;width: 170px;" maxlength="25" class="focusOutSave" type="text">
                <span id="divTxt_attention" style="display:none;">
                  <input name="componentId41" value="6899480" type="hidden">
                </span>
                
                <a href="javascript:void(0);" id="component41" style="float: right;" onclick="deleteText('component41')">
                  <img id="iok" src="../images/iDelete.png" height="17px" width="17px">
                </a>
                
                <a href="javascript:void(0);" id="editButton41" onclick="editText('component41')" style="float: right;">
                  <img src="../images/ieditover.PNG" height="17px" width="17px">
                </a> 
                <a href="javascript:void(0);" id="okButton41" onclick="removeEdit('editComp_41',27)" style="display:none;float: right;">
                  <img id="iok" src="../images/iok.png" height="17px" width="17px">
                </a>
              </div>
              <div class="divCell1"><div class="svgTable"><span><input class="hiddenImage" type="button"><input class="greenSquare" type="button"><input class="yellowSquare" type="button"><input class="redSquare" type="button"></span></div></div>
            </div>
          </div>
        </div>
        <!-- Form 2 -->
        <div class=" bottomtext" style="width:88%;">
           <div style="width:838px; height:25px;">
          <span id="cmt" style="float:left;">Comments:</span> 
          <hr style="width:90%;position:relative; top:18px;">
           </div> 
          <br><hr><br><hr><br>
           <div style="width:838px; height:25px;">  
          <span id="cmt" style="float:left;clear:left;margin-top: -25px;">Inspected by: </span> 
          <hr style="width:60%;float:left;position:relative; top:-5px;">
          <span style="float: left; margin-top: -25px; margin-left: 60.5%;">Date:</span>
          <hr style="width:25%;float:left;position:relative; top:-5px;">
           </div> 
        </div>
        <div style="text-align:center;margin-top:10px;padding-bottom:10px;overflow:auto; padding-left:380px;">
          <input name="save" class="savebtn" value="Save" onclick="updateForm();launchWindow('#dialog');" type="button">
            <!-- <a id="cancelButtonId" href="./getUserComponentIfs.do"  class="btn-txt"><input type="button" class="cancelbtn" value="Cancel"></a> -->
        </div>
      </form>
      <form id="cancelAdminForm" method="get" action="./getUserViewComponentIfs.do">
      <input name="formid" id="formid" value="689921" type="hidden">
        <input value="Cancel" class="cancelbtn1" onclick="launchWindow('#dialog')" type="submit">
      </form>
    </div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                It has survived not only five centuries, but also the leap into electronic typesetting,
                remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset
                sheets containing Lorem Ipsum passages, and more recently with desktop publishing software
                like Aldus PageMaker including versions of Lorem Ipsum.
              </div>
              <div class="tab-pane" id="tab_4">
              tab4
              </div>
              <div class="tab-pane" id="tab_5">
              tab5
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
      </div>
    </section>
   
 
@endsection


@section('customJs')
@endsection
