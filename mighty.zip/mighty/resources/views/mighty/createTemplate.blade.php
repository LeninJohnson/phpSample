<?php
$template=Config::get('custom.template');
?>
@extends('mighty.layout.tpl')
@section('customCss')

<link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/form-builder.min.css')}}">
<link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/main.min.css')}}">
<link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/uikit.almost-flat.min.css')}}">
<link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/formpro.css')}}">
<link rel="stylesheet" type="text/css" media="screen" href="{{URL::asset('mighty/plugins/jquery_ui.css')}}">
<link rel="stylesheet" href="{{URL::asset('mighty/plugins/template3.css')}}">

<style>
.content {
   // min-height: 1811px;
}
</style>
<style>
        li.rows{
            min-height:80px;
        }
        li.columns{
            float:left;
            height:75px;
            list-style: none;
        }
        li.highlight{
            min-height: 70px;
        }
        .dropovers{
          /*  border:1px solid #ccc;
            border-right-color:red;*/
        }
        body{
            /*overflow: hidden;
            height: 100%;*/
        }
        .content{
            padding-left: 0px !important;
        }
body {
    padding-top: 0px !important;
}
 .uk-grid > * {
    float: none;
}
    .cmdline{
        width:90%;margin-top: 6%;color: rgb(12, 12, 12);border: 0.1px solid;
    }
    .th{
       // padding: 6px 22px 13px 1px;
        border: 1px solid;
    }
        .row1Title {
            background: none repeat scroll 0 0 #005AAB;
            border-bottom: 1px solid #000000;
            color: #FFFFFF;
          //  color: #000000 !important;
            font-family: 'MyriadProBold';
            font-size: 12pt;
            height: 23px;

            text-align: center;
        }
        .svgTable{
            margin-left: 30px;
            margin-top: 7px;
        }
        .uk-h2, h2 {
            font-size: 24px;
            line-height: normal;
        }
        .click-edit-icons {
            background-image: url('../mighty/images/clicktoedit.png');
            background-size: 15px;
            width: 15px;
            height: 15px;
            float: right;
        }
        .spanlable{
            max-width: 100%;
            font-weight: 700;
            display: block;
            text-align: center;
            margin: 4px 0px 8px;
        }
    .comp4boxi{
        width: 145px !important;
    }
    .optionbox{
        float:left;
    }
    .lrchange
        {
        background: url('../mighty/images/leftright.png');
        width: 18px;
        height: 18px;
        background-size: 19px;
        display: block;
        margin-top: -2px;
        margin-right: 10px;
    }
       .add_morerow{
           background: url('../mighty/images/add2.png');
           background-size: 15px;
           display: block;
           width: 15px;
           height: 15px;
           float: right;
           cursor: pointer;
           padding-left: 0px;
       }
        .uncheck-grey,.check-red{
            display: none;
        }
    .submitPage{
          margin: 20px 0px;
        border-top: 1px solid #ddd;
        padding: 0px 20px;
    }
    .dirimg{
        float: left;
        padding: 20px;
        border: 1px solid #ddd;
        text-align: center;
        width: 136px;
        height: 136px;
        position: relative;
    }
    .dirimgs{
        float: left;
        padding: 6px;
       /* border: 1px solid #ddd;*/
        text-align: center;
        width: 136px;
        height: 102px;
        position: relative;
    }
    .selectImage{
        bottom: 5px;
        position: absolute;
        left: 35px;
    }
       .profiletext { font-size: 11pt !important;font-style: normal !important;display: inline-block;
        }

        #sidebar textarea.md-input {
            line-height: 20px;
            margin-top: 12px;
            min-height: 30px;
        }
        select.md-input, textarea.md-input, input.md-input:not([type]), input.md-input[type="text"], input.md-input[type="password"], input.md-input[type="datetime"], input.md-input[type="datetime-local"], input.md-input[type="date"], input.md-input[type="month"], input.md-input[type="time"], input.md-input[type="week"], input.md-input[type="number"], input.md-input[type="email"], input.md-input[type="url"], input.md-input[type="search"], input.md-input[type="tel"], input.md-input[type="color"] {
            padding: 4px;
            width: 100%;
        }
        .click-editer {
            background-image: url(../mighty/images/clicktoedit.png);
            background-size: 15px;
            width: 15px;
            height: 15px;
            float: right;
        }
        .cke_dialog_ui_input_file {
            width: 100%;
            height: 71px !important;
        }

        a.cke_dialog_ui_button {
            margin-top: 30px !important;
        }
       /* .cke_editable {
            line-height: 0.2 !important;
        }*/

        .cke_editable
        {
            font-size: 13px;
            /*line-height: 1.6;*/
        }
        .cke_editable p
        {
            margin: 3px 0px;

        }
        .cke_editable h1,.cke_editable h2,.cke_editable h3,.cke_editable h4,.cke_editable h5,.cke_editable h6
        {
            font-weight: normal !important;;
            height: 1.25em  !important;
            line-height: 1.25  !important;
            margin: 3px 0px !important;
        }
        .cke_editable h1{
            display: block;
            font-size: 2em;
            -webkit-margin-before: 0.67em;
            -webkit-margin-after: 0.67em;
            -webkit-margin-start: 0px;
            -webkit-margin-end: 0px;
            font-weight: bold;
        }
        .cke_editable h2{
            display: block;
            font-size: 1.5em;
            -webkit-margin-before: 0.83em;
            -webkit-margin-after: 0.83em;
            -webkit-margin-start: 0px;
            -webkit-margin-end: 0px;
            font-weight: bold;
        }
       .cke_editable p {
            margin: 1px !important;
        }
    .ImagePreviewBox,{
    display:none;  /*.cke_dialog_ui_html*/
    }

</style>
@endsection

@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Customizable Vehicle Inspection Forms
        <small>Control panel</small>
      </h1>
      <!-- test dir s-->
        @php
        $dir=public_path().'/mighty/images/template/';
        $files1 = scandir($dir);
        $files2 = scandir($dir, 1);
        @endphp

   {{-- @foreach ($files1 as $chres)
    <img src="{{URL::asset('mighty/images/template/')}}/{{$chres}}" alt="" style="max-width: 247px;max-height:116px;">
    @endforeach--}}

       <!-- test dir e-->

      <ol class="breadcrumb">
        <li><a href="{{URL::to('')}}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Create Template</li>
      </ol>
    </section>
    @if(Session::has('true_msg'))
    <div class="alert alert-success">
    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
    {{Session::get('true_msg')}}
    </div> <!-- /.alert -->
    @endif
    @if(Session::has('error_msg'))
    <div class="alert alert-danger">
    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">&times;</a>
    {{Session::get('error_msg')}}
    </div> <!-- /.alert -->
    @endif
    <!-- Main content -->
    <section class="content">

        <!-- Button trigger modal -->


         <!-- Modal -->
       {{-- <button type="button" class="btn btn-default" data-toggle="modal" data-target="#myFile">
            Change Image
        </button>

        <div class="modal fade" id="myFile" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Choose image</h4>
                    </div>
                    <div class="modal-body" style="height: 200px;
    overflow-y: auto;">
                       <div>
                           <label>Upload your own image</label>
                           <input type="file" class="imagefiles files" name="imagefiles"  />
                       </div>
                        <br>
                        <div>
                            <div style="float: left;margin-right: 23px;
">
                            <button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal">
                                Choose from existing images:
                            </button>
                            </div>
                            <div id="showimg" style="float: left">

                            </div>

                        </div>

                    </div>

                </div>
            </div>
        </div>--}}

     {{--<textarea style="width: 400px;height: 168px;" class="textarea  s1" name="editor1" ></textarea>
        <button type="button" onclick="getCkval();">
            Change Image
        </button>--}}
     {{--<textarea class="ckeditor  s1" name="editor1" ></textarea>--}}
 {{-- <textarea class="ckeditor editor1 s2" id="s2" name="editor2" ></textarea>
         <button type="button" onclick="getCkval();">
         Change Image
     </button>--}}


<input type="hidden" name="fileimages" id="fileimages"/>

        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="z-index:1200">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Choose image</h4>
                    </div>
                    <div class="modal-body" style="height: 500px;
    overflow-y: auto;">
                        @foreach ($files1 as $key=>$chres)
                            @if($key!=0 && $key!=1 && strpos($chres, 'original') !== false)
                                <div class="dirimg"  >

                                    <img src="{{URL::asset('mighty/images/template/')}}/{{$chres}}" alt=""  />
                                    <input type="button" data-val="{{$chres}}"   class=" btn selectImage" value="Select" />

                                </div>
                            @endif
                        @endforeach
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        {{-- <button type="button" class="btn btn-primary">Save changes</button>--}}
                    </div>
                </div>
            </div>
        </div>

        <input type="hidden" name="texteditId" id="texteditId"/>
        <input type="hidden" name="rowsId" id="rowsId"/>

        {{--<button type="button" class="btn btn-default" data-toggle="modal" data-target="#myEditor">
            Edit
        </button>--}}
        <div class="modal fade" id="myEditor" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Raw Html</h4>
                    </div>
                    <div class="modal-body" style="height: 420px;
    overflow-y: auto;">
                        <textarea style="width: 100px;height: 168px;" maxlength="50" class="ckeditor  s1" name="editor1" id="editor1" ></textarea>
                        <p>
                            <div style="float:left;">
                            <button type="button" class="btn btn-default" onclick="getCkval();">
                                Done
                            </button>
                        </div>
                            <div style="float:left;margin-left: 6px;">
                                <button type="button" class="btn btn-default" onclick="cancelEditor();" >
                                    Cancel
                                </button>
                            </div>

                        </p>
                    </div>

                </div>
            </div>
        </div>
  <div id="page_content">
        <div id="page_content_inner">
            <div class="uk-grid" style="display: block;padding-left:0px !important"; data-uk-grid-margin data-uk-grid-match id="wizard_forms">
                <!--<div id="wizard_advanced">-->
                <!-- <h2>Design Form</h2>
                <section> -->
              <form class="uk-form-stacked" id="wizard_advanced_form" method="post" action ="" enctype="multipart/form-data" >
                <div class="uk-width-large-2-10"  id="sidebar" style="float: left;width:20%;">
                    <div class="uk-width-1-1">
                        <div class="parsley-row">
                            <div class="md-card  form-desc ">
                                <label class="fn">Name your form<span class="req">*</span></label>
                                <input type="text" class="md-input fn-field " id="form_name" name="form_name" value="" data-parsley-trigger="change" required  />
                                <label class="fd">Short description about your form </label>
                                <textarea name="form_desc"  class="md-input" id="form_desc" style=""></textarea>
                            </div>
                        </div>
                        <div class="parsley-row">
                            <div class="md-card  form-desc ">
                                <label class="fn">Box Type</label>
                                <div style="margin-left: 20px;">
                                <div class="radio">
                                    <label>
                                        <input name="imageTypes" id="imageType1" class="imageType" value="0" checked  type="radio">Circle
                                    </label>
                                </div>
                                <div class="radio">
                                    <label>
                                        <input name="imageTypes" id="imageType2" class="imageType" value="1"  type="radio">Square
                                    </label>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="md-card dragdrop-panel">
                        <div class="md-card-content">
                           <div class="uk-panel">
                                <div class="heading">Drag and drop for build new form</div>
                                <div class="uk-accordion" data-uk-accordion>
                                    <h3 class="uk-accordion-title uk-accordion-title-primary">Basic</h3>
                                    <div class="uk-accordion-content">
                                        <ul id="basic">
                                            <li><div class="singleline-icon" ></div><span value="heading">Heading</span></li>
                                            <li><div class="singleline-icon" ></div><span value="text">Single Line Text</span></li>
                                           <!--
                                            <li><div class="email-icon"></div><span value="email">Email</span></li>
                                            <li><div class="multiline-icon"></div><span value="textarea">Multi Line Text</span></li>
                                            <li><div class="multiline-icon"></div><span value="number">Number</span></li>
                                            <li><div class="radio-icon"></div><span value="radio">Radio</span></li>
                                            <li><div class="select-icon"></div><span value="select">Select</span></li>
                                            <li><div class="date-icon"></div><span value="date">Date</span></li>
                                            <li><div class="time-icon"></div><span value="time">Time</span></li>
                                            -->
                                          {{--  <li><div class="checkbox-icon"></div><span value="checkbox">Checkbox</span></li>--}}

                                            <li><div class="file-icon"></div><span value="file">File</span></li>
                                            <li><div class="singleline-icon" ></div><span value="emptyspace">Empty space</span></li>
                                            <li><div class="singleline-icon" ></div><span value="line">Line</span></li>
                                            <li><div class="singleline-icon" ></div><span value="textwithline">Text with Line</span></li>
                                           {{-- <li><div class="singleline-icon" ></div><span value="condition">Condition CheckBox</span></li>
                                            <li><div class="singleline-icon" ></div><span value="condition2">Condition</span></li>
                                            <li><div class="singleline-icon" ></div><span value="tablehead">Item and Content (Table)</span></li>
                                            <!-- <li><div class="singleline-icon" ></div><span value="tablerow">Table Row</span></li>-->
                                            <li><div class="singleline-icon" ></div><span value="component2">INTERIOR/EXTERIOR</span></li>
                                            <li><div class="singleline-icon" ></div><span value="component1">UNDER VEHICLE </span></li>
                                            <li><div class="singleline-icon" ></div><span value="component3">UNDERHOOD</span></li>
                                            <li><div class="singleline-icon" ></div><span value="component4">TIRES</span></li>
                                            <li><div class="singleline-icon" ></div><span value="component5">BRAKES</span></li>
                                            <li><div class="singleline-icon" ></div><span value="component7">BATTERY</span></li>--}}
                                            <li><div class="singleline-icon" ></div><span value="component6">COMMENTS</span></li>
                                            <li><div class="singleline-icon" ></div><span value="component8">User Profile</span></li>
                                            <li><div class="singleline-icon" ></div><span value="component9">Wysiwyg</span></li>
                                            <!--<li><span value="reset">Reset</span></li>
                                            <li><span value="submit">Submit</span></li>-->
                                        </ul>
                                    </div>
                                    <!--
                                        <h3 class="uk-accordion-title uk-accordion-title-primary">Advanced</h3>
                                        <div class="uk-accordion-content">
                                            <ul id="advanced">
                                                <li><div class="sign-icon"></div><span value="signature">Signature</span></li>
                                                <li>
                                                    <span value="placepicker">Place Picker</span>
                                                </li>
                                            </ul>
                                        </div>-->
                                    </div>
                               <div class="uk-accordion" data-uk-accordion>
                                   <h3 class="uk-accordion-title uk-accordion-title-primary">Mighty Components</h3>
                                   <div class="uk-accordion-content">
                                       <ul id="basic">
                                           <!-- <li><div class="singleline-icon" ></div><span value="heading">Heading</span></li>
                                        <li><div class="singleline-icon" ></div><span value="text">Single Line Text</span></li>

                                         <li><div class="email-icon"></div><span value="email">Email</span></li>
                                         <li><div class="multiline-icon"></div><span value="textarea">Multi Line Text</span></li>
                                         <li><div class="multiline-icon"></div><span value="number">Number</span></li>
                                         <li><div class="radio-icon"></div><span value="radio">Radio</span></li>
                                         <li><div class="select-icon"></div><span value="select">Select</span></li>
                                         <li><div class="date-icon"></div><span value="date">Date</span></li>
                                         <li><div class="time-icon"></div><span value="time">Time</span></li>
                                         -->
                                           <li><div class="checkbox-icon"></div><span value="checkbox">Checkbox</span></li>


                                           <li><div class="singleline-icon" ></div><span value="condition">Condition CheckBox</span></li>
                                           <li><div class="singleline-icon" ></div><span value="condition2">Condition</span></li>
                                           <li><div class="singleline-icon" ></div><span value="tablehead">Item and Content (Table)</span></li>
                                           <!-- <li><div class="singleline-icon" ></div><span value="tablerow">Table Row</span></li>-->
                                           <li><div class="singleline-icon" ></div><span value="component2">INTERIOR/EXTERIOR</span></li>
                                           <li><div class="singleline-icon" ></div><span value="component1">UNDER VEHICLE </span></li>
                                           <li><div class="singleline-icon" ></div><span value="component3">UNDERHOOD</span></li>
                                           <li><div class="singleline-icon" ></div><span value="component4">TIRES</span></li>
                                           <li><div class="singleline-icon" ></div><span value="component5">BRAKES</span></li>
                                           <li><div class="singleline-icon" ></div><span value="component7">BATTERY</span></li>

                                           <!--<li><span value="reset">Reset</span></li>
                                           <li><span value="submit">Submit</span></li>-->
                                       </ul>
                                   </div>
                                   <!--
                                       <h3 class="uk-accordion-title uk-accordion-title-primary">Advanced</h3>
                                       <div class="uk-accordion-content">
                                           <ul id="advanced">
                                               <li><div class="sign-icon"></div><span value="signature">Signature</span></li>
                                               <li>
                                                   <span value="placepicker">Place Picker</span>
                                               </li>
                                           </ul>
                                       </div>-->
                               </div>
                                 </div>
                            </div>
                        </div>
                    </div>
                    <div class="uk-width-large-8-10"  id="content_right" style="float:left;height: 100%;padding-left:12px;width:80%;">
                        <div class="md-card">
                            <div class="md-card-content" style="">
                                <div id="forms" data-form_id ="1" style="width:100%;height: 100%;">
                                        <ul id="pages" style="height: 100%;">
                                           <!--<li class="rows" id="rows_1"></li>-->
                                    </ul>
                            </div>
                        </div>
<div class="submitPage" style="
"><a style="margin-top: 15px;" class="btn btn-primary publish" data-vals="0">Save and Preview this template</a>
</div>
                    </div>
                </div>
              {{ csrf_field() }}
                    <input type="hidden" name="formToken" class="form_token" value ="" />
                    <input type="hidden" name="form_name" class="form_name" value = " "/>
                    <input type="hidden" name="form_desc" class="form_desc" value = " "/>
                    <input type="hidden" id="org_id" name="org_id" value="1" />
                     <input type="hidden" name="uuid" id="uuid" value="0" />
                    <input type="hidden" class="imagecount" id="imagecount" name="imagecount" value="0" />

            <div class="buildform">
                      <input type="hidden" name="imageType" id="imageType" value="0" />
            </div>

                  {{-- <p><img id="testImg" onclick="callImageFunction();" alt="" src="http://localhost/mighty/public/mighty/images/template/bbb-logo_member-original.png"  ></p>
--}}
                     </form>
            @include('mighty.layout.template')
         <!-- </form> -->
        </div>
</div>
</section>
<!--
<style>
.content {
    min-height: 1811px;
}
#div1 {
    width: 350px;
    height: 70px;
    padding: 10px;
    border: 1px solid #aaaaaa;
}
#div2 {
    width: 650px;
    height: 270px;
    padding: 10px;
    border: 1px solid #aaaaaa;
}
#makeMeDraggable { width: 100px; height: 100px; background: red; }
#draggable { width: 150px; height: 150px; padding: 0.5em; }
</style>
   <section class="content">
<div id="draggable" class="ui-widget-content">
  <p>Drag me around</p>
</div>

    <div id="content" style="height: 400px;">
  </div>

    <p>Drag the W3Schools image into the rectangle:</p>

<div id="div1" style="float:right;" ondrop="drop(event)" ondragover="allowDrop(event)"></div>
<div id="div2"   ondrop="drop(event)" ondragover="allowDrop(event)"></div>
<br>
<div id="drag1" draggable="true" ondragstart="drag(event)" width="336" height="69">
  <input type="text" name="header" value="Header"/>
</div>
<div id="drag2" draggable="true" ondragstart="drag(event)" width="336" height="69">
  <input type="file" name="file1" />
</div>
<div id="makeMeDraggable"> </div>



    </section>
    -->


@endsection

@section('customJs')


<script>

var rowid = 1;
var form_rows = 1;
var colid = 1;
var comptField = 1;

</script>

{{--<script src="{{URL::asset('mighty/plugins/jquery.min.js')}}"></script>--}}
<script src="{{URL::asset('mighty/plugins/jquery.validate.min.js')}}"></script>
<!--
<script src="{{URL::asset('mighty/plugins/jquery-ui.min.js')}}"></script>
-->
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
<script>
// just for the demos, avoids form submit
/*
jQuery.validator.setDefaults({
  debug: true,
  success: "valid"
});
*/
$(document).ready(function () {
    $("#cke_81_textInput").change(function(){
        alert("The text has been changed.");
    });

$( "#wizard_advanced_form" ).validate({
  rules: {
    'file_name[]': {
     // required: true,
      extension: "png|jpg"
    }
  }
});
});

function callImageFunction(){
    $('#testImg').each(function() {
        var maxWidth = 395; // Max width for the image
        var minHeight = 254;    // Max height for the image
        var ratio = 0;  // Used for aspect ratio
        var width = $(this).width();    // Current image width
        var height = $(this).height();  // Current image height

        if(width > maxWidth){
            ratio = maxWidth / width;   // get ratio for scaling image
            $(this).css("width", maxWidth); // Set new width
            $(this).css("height", height * ratio);  // Scale height based on ratio
            height = height * ratio;    // Reset height to match scaled image
            width = width * ratio;    // Reset width to match scaled image
        }

        // Check if current height is larger than max
        if(height < minHeight){
            ratio = minHeight / height; // get ratio for scaling image
            $(this).css("height", minHeight);   // Set new height
            $(this).css("width", width * ratio);    // Scale width based on ratio
            width = width * ratio;    // Reset width to match scaled image
        }

        var $img = $(this),
                css = {
                    position: 'absolute',
                    marginLeft: '-' + ( parseInt( $img.css('width') ) / 2 ) + 'px',
                    left: '50%',
                    top: '50%',
                    marginTop: '-' + ( parseInt( $img.css('height') ) / 2 ) + 'px'
                };

        $img.css( css );
    });

}
/*
jQuery(function ($) {
    $('#wizard_advanced_form').validate({
        rules: {},
        messages: {},
        submitHandler: function () {
            return false
        }
    });
    $('input[name^="imagefiles_"]').rules('add', {
        required: true,
        accept: "image/jpeg, image/pjpeg"
    })
})
    */
</script>

<script src="{{URL::asset('mighty/plugins/jquery-1.12.4.js')}}"></script>
<script src="{{URL::asset('mighty/plugins/jquery-ui.js')}}"></script>
<script type="text/javascript">jQuery.noConflict();</script>

<!--<script src="{{URL::asset('mighty/plugins/form-builder.min.js')}}"></script>-->
   {{-- <script src="https://cdn.ckeditor.com/4.4.1/standard/ckeditor.js"></script>--}}
<script src="{{URL::asset('mighty/plugins/ckeditor/ckeditor.js')}}"></script>
<script src="{{URL::asset('mighty/plugins/form.js')}}"></script>
<script src="{{URL::asset('mighty/plugins/uikit_custom.min.js')}}"></script>
<script src="{{URL::asset('mighty/plugins/datatables_uikit.min.js')}}"></script>




<!-- Bootstrap WYSIHTML5 -->
 <script src="../../plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script>
    $(function(){

        $(".textarea").wysihtml5({
            toolbar: {
                "font-styles": true
                ,"emphasis": true
                ,"lists": true
                ,"html": true
                ,"link": true
                ,"image": true
                ,"color": true
                ,"blockquote": true
                ,"font-size": true
                ,"outdent": true
                ,"indent": true
                ,"size": 'sm'
                ,"fa": true
            }
        });
    });

    $(function () {
        /*var that = this
        $(document).on('focusin.modal', function (e) {
            if (that.$element[0] !== e.target && !that.$element.has(e.target).length) {
                that.$element.focus()
            }
        })*/

        CKEDITOR.bootstrapModalFix = function (modal, $) {
            modal.on('shown', function () {
                var that = $(this).data('modal');
                $(document)
                        .off('focusin.modal')
                        .on('focusin.modal', function (e) {
                            // Add this line
                            if( e.target.className && e.target.className.indexOf('cke_') == 0 ) return;

                            // Original
                            if (that.$element[0] !== e.target && !that.$element.has(e.target).length) {
                                that.$element.focus()
                            }
                        });
            });
        };

        CKEDITOR.replace( 'editor1', {
            filebrowserBrowseUrl: "{{URL::to('/cvif/browse')}}",
            filebrowserUploadUrl: "{{URL::to('/cvif/template-image/upload')}}"
          /*  filebrowserWindowWidth : '640',
            filebrowserWindowHeight : '480'*/
        } );
        CKEDITOR.on('dialogDefinition', function (ev) {

            var dialogName = ev.data.name,
                    dialogDefinition = ev.data.definition;

            if (dialogName == 'image') {
                var onOk = dialogDefinition.onOk;

                dialogDefinition.onOk = function (e) {
                    var width = this.getContentElement('info', 'txtWidth');
                    width.setValue('200');//Set Default Width

                    var height = this.getContentElement('info', 'txtHeight');
                    height.setValue('200');//Set Default height

                    onOk && onOk.apply(this, e);
                };
            }
        });
      /*  CKEDITOR.replace( 'editor1', {
            toolbarGroups: [
                { name: 'document',	   groups: [ 'mode', 'document' ] },			// Displays document group with its two subgroups.
                { name: 'clipboard',   groups: [ 'clipboard', 'undo' ] },			// Group's name will be used to create voice label.
                '/',
                { name: 'paragraph',   groups: [ 'list', 'indent', 'blocks', 'align' ] },
                // Line break - next group will be placed in new line.
                { name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
                { name: 'links' },
                { name: 'styles' },
                { name: 'colors' },
                { name: 'tools' }
            ]

            // NOTE: Remember to leave 'toolbar' property with the default value (null).
        });*/

        /*CKEDITOR.config.extraPlugins = 'justify';
        // Replace the <textarea id="editor1"> with a CKEditor
        // instance, using default configuration.
       // CKEDITOR.replace('editor1');
      /*   CKEDITOR.replaceClass = 'editor1';*/
        //bootstrap WYSIHTML5 - text editor
      /* $(".textarea").wysihtml5();*/



    });

    /*function richTextBox($fieldname, $value = "") {


        $CKEditor = new CKEditor();
        $config['toolbar’] = array(
                array( 'Bold’, ‘Italic’, ‘Underline’, ‘Strike’),
        array('JustifyLeft’, ‘JustifyCenter’, ‘JustifyRight’, ‘JustifyBlock’),
        array('Format’),
        array( 'Font’, ‘FontSize’, ‘FontColor’, ‘TextColor’),
        array('Cut’, ‘Copy’, ‘Paste’, ‘PasteText’, ‘PasteFromWord’ ),
        array('Image’, ‘Table’, ‘NumberedList’, ‘BulletedList’, ‘-‘, ‘Outdent’, ‘Indent’, ‘Blockquote’),
        array('Subscript’,’Superscript’),
        array( 'Link’, ‘Unlink’ ),
        array('Source’)
    );
        $CKEditor->basePath = '/ckeditor/’;
        $CKEditor->config['width’] = 975;
        $CKEditor->config['height’] = 400;

        $CKEditor->editor($fieldname, $value, $config);
    }*/

    function getCkval(){
         for ( instance in CKEDITOR.instances ) {

            CKEDITOR.instances[instance].updateElement();
        }
        title = $('.s1').val();
        var texteditId =$('#texteditId').val();
        $('#'+texteditId).html(title);
        $('#myEditor').modal('toggle');


        var col =$('#rowsId').val();



        var ro = $('ul#'+col+' '+'li.columns');

        var maxHeight ="";

        ro.each(function(){
            //	console.log("maxheight"+maxHeight);
            //	console.log("colheight"+$(this).height());
            $(this).parent().css('height','');
            $(this).css('height','');
            maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height();
            console.log(maxHeight);
            //console.log($(this));

        });
        //console.log(ro);
        ro.each(function(){
            $('ul#'+col).css('height',maxHeight);
            $(this).css('height',maxHeight);

        });

    }
    function ckeditor_fileUrl(file, win){
        var cfunc = win.location.href.split('&');

        for (var x in cfunc) {
            if (cfunc[x].match(/^CKEditorFuncNum=\d+$/)) {
                cfunc = cfunc[x].split('=');
                break;
            }
        }
        alert(file.width); //here is the correct value
        CKEDITOR.tools.callFunction(cfunc[1], file.url);
        win.close();
    }
    function showEditor(a,col){
     $('#myEditor').modal('toggle');
        var data=$('#'+a).html();

        CKEDITOR.instances['editor1'].setData(data);
         $('#texteditId').val(a);
         $('#rowsId').val(col);

    }
    function showTxtEditor(a,col){
        type = $(col).parent().parent().parent().parent().parent().parent().parent().attr('id');
        $('#myEditor').modal('toggle');
        var data=$('#'+a).html();

        CKEDITOR.instances['editor1'].setData(data);
        $('#texteditId').val(a);
        $('#rowsId').val(type);

    }

    function cancelEditor(){
        var data="";
        CKEDITOR.instances['editor1'].setData(data);
        $('#myEditor').modal('toggle');

    }
</script>


<script>
    function readURL(input,imgdiv,removeicon) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                 var src=e.target.result;
               // $('#'+img).attr('src', e.target.result);


                var img='<img src="'+src+'" alt="" style="width: 90px;height: 90px;display: block;" />';
                $('#'+imgdiv+"").html(img);
                $('#'+removeicon+"").css("display","block");


                var show = $('#'+imgdiv+"").data('show');
                $('.'+show).attr('src',src);


            }

            reader.readAsDataURL(input.files[0]);
        }
    }


</script>
<script>
    var id=1;
function addMorerow(a){
        var vals = $(a).data('vals');
    var imageType=$('#imageType').val();
        var data='';
    if(imageType==1) {
        data+='<tr id="cnt_'+id+'s" class="odd gradeX"><td class="th" ><div class="title_tablehead select"><input type="text" class="form-control title_value"  data-optionid="0" name="tables[]" style="height: 34px;width:100%"  /></div></td><td class="th"><span><b style="border-radius:0px" class="green_checkbox"></b><b style="border-radius:0px" class="yellow_checkbox"></b><b style="border-radius:0px" class="red_checkbox"></b></span><button class="btn btn-danger btn-xs remove_content"  type="button"  data-remove="'+id+'s"><i class="fa fa-fw fa-remove"></i></button></td></tr>';
    }else{
        data+='<tr id="cnt_'+id+'s" class="odd gradeX"><td class="th" ><div class="title_tablehead select"><input type="text" class="form-control title_value"  data-optionid="0" name="tables[]" style="height: 34px;width:100%"  /></div></td><td class="th"><span><b style="border-radius:100%" class="green_checkbox"></b><b style="border-radius:100%" class="yellow_checkbox"></b><b style="border-radius:100%" class="red_checkbox"></b></span><button class="btn btn-danger btn-xs remove_content"  type="button"  data-remove="'+id+'s"><i class="fa fa-fw fa-remove"></i></button></td></tr>';
    }
    $("."+vals+"").append(data);
    var ulheight = $("."+vals+"").height();
    var liheight = $(a).closest("li").height();

    if(liheight<ulheight){
        $(a).closest("li").css('height',ulheight);
        $(a).closest("ul").css('height',ulheight);
    }


        id++;
    $(".remove_content").on('click',function(){
        var id=$(this).attr('data-remove');
        $("#cnt_"+id).remove();
    });
}

function removeRow(a){

}
function submitform(){
//return false;
if ($("#wizard_advanced_form").valid()) {
     document.getElementById("wizard_advanced_form").submit();
}
}
$(document).ready(function () {

    $('body').addClass('sidebar-collapse');

});
</script>
<script>
    function setShowimage(a){
        $('#fileimages').val(a);

    }
    function removeFile(a,b,c){
        var res=$('.'+a+'').val();
         $('.'+a+'').val('');
        $(b).css("display","none");
        $('#'+c+'').html("");

        var show = $('#'+c+"").data('show');
        $('.'+show).attr('src', '');

    }

$(document).ready(function(){

  $('body').addClass('sidebar-collapse');
    //add content(start )
    var id=1;
    $(".add_morerow").click(function(){
        var vals = $(this).data('vals');
        var data='';
        data+='<tr id="cnt_'+id+'" class="odd gradeX"><td class="th" ><input type="text" class="form-control" name="tables[]" style="height: 34px;"  /></td><td> <span><b class="green"></b><b class="yellow"></b><b class="red"></b></span><button class="btn btn-danger btn-xs remove_content" type="button"  data-remove="'+id+'"><i class="fa fa-fw fa-remove"></i></button></td></tr>';
        $("."+vals+"").append(data);
        id++;



    });
    $(".selectImage").click(function(){
        var vals = $(this).data('val');
        $('#showimg').append("");



        var img='<img src="{{URL::asset('mighty/images/template/')}}/'+vals+'" alt="" style="width: 90px;height: 90px;display: block;" />';
        var fileimages =$('#fileimages').val();

        var fname = $('#'+fileimages+"").data('fname');
        var remov = $('#'+fileimages+"").data('remov');

        $('#'+remov+"").css("display","none");
        $('.'+fname+"").val("");


        $('#'+fileimages+"").html(img);
        $('.'+fileimages+"").val(vals);
        $('#myModal').modal('toggle');

        var show = $('#'+fileimages+"").data('show');
        $('.'+show).attr('src','{{URL::asset('mighty/images/template/')}}/'+vals+'');


    });
    $(".removeFile").click(function(){



    });


    //add content(end)

});
</script>
<script>
/*
jQuery(document).ready(function($) {
  $(document.getElementById('build-wrap')).formBuilder();
});
*/
jQuery(document).ready(function($) {
var $fbEditor = $(document.getElementById('build-wrap'));
var formBuilder = $fbEditor.formBuilder().data('formBuilder');

$(".form-builder-save").click(function(e) {
e.preventDefault();
 // alert(formBuilder.formData);
  $("#design-tpl").val(formBuilder.formData);
});
});
</script>


<!--
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/jquery-ui.min.js"></script>

<script>
function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
      ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
}
$( init );

function init() {
  $('#makeMeDraggable').draggable( {
    containment: '#content',
    cursor: 'move',
    snap: '#content'
  } );


}
$( function() {
    $( "#draggable" ).draggable();
  } );
</script>
-->
<script type="text/javascript">

     var $kUI_multiselect_basic = $('#multiselect');
        if($kUI_multiselect_basic.length) {
            $kUI_multiselect_basic.kendoMultiSelect();
        }
        var multiselect_location= $('#multiselect_location');
        if(multiselect_location.length) {
            multiselect_location.kendoMultiSelect();
        }
        var multiselect_size = $('.multiselect_size');
        if(multiselect_size.length) {
            multiselect_size.kendoMultiSelect();
        }
        var location_country = $('.location_country');
        location_country.kendoDropDownList();
        var $kUI_multiselect_domain = $('#multiselect_domain');
        if($kUI_multiselect_domain.length) {
            var required = $kUI_multiselect_domain.kendoMultiSelect().data("kendoMultiSelect");
            $(".domain_select #select").click(function() {
            var values = $.map(required.dataSource.data(), function(dataItem) {
                //if(dataItem.value){
                  return dataItem.value;
            });
            required.value(values);

            $('.domain_select #select').hide();
            $('.domain_select #deselect').show();
          });

          $(".domain_select #deselect").click(function() {
            required.value([]);
            $('.domain_select #deselect').hide();
            $('.domain_select #select').show();
          });
        }
    var org_location = $("#org_location");
    if(org_location.length){
        org_location.kendoDropDownList();
    }
    var org_forms = $("#org_forms");
    if(org_forms.length){
        org_forms.kendoDropDownList();
    }
    var org_users = $("#org_users");
    if(org_users.length){
        org_users.kendoDropDownList();
    }
    var $kUI_multiselect_department = $('#multiselect_department');
        if($kUI_multiselect_department.length) {
     $kUI_multiselect_department.kendoMultiSelect();
  }
  /*  var $kUI_multiselect_department = $('#multiselect_department');
        if($kUI_multiselect_department.length) {
     $kUI_multiselect_department.kendoMultiSelect();
  }    */
    var $kUI_multiselect_category = $('#multiselect_category');
        if($kUI_multiselect_category.length) {
       $kUI_multiselect_category.kendoMultiSelect();
    }
    var $kUI_multiselect_role = $('#multiselect_role');
        if($kUI_multiselect_role.length) {
       $kUI_multiselect_role.kendoMultiSelect();
    }
     var multiselect_users = $('#multiselect_users');
        if(multiselect_users.length) {
            multiselect_users.kendoMultiSelect();
        }


    </script>
    <script type="text/javascript">
         if($('body').hasClass('sidebar_main_active')){
            $('body').removeClass('sidebar_main_active');
        }
        if($('body').hasClass('sidebar_main_open')){
            $('body').removeClass('sidebar_main_open');
        }
    </script>



    <script>
        $(function() {
            // enable hires images

            altair_helpers.retina_images();
            // fastClick (touch devices)
            if(Modernizr.touch) {
                FastClick.attach(document.body);
            }

        });

    </script>
    <script>
    $(function() {
        var $switcher = $('#style_switcher'),
            $switcher_toggle = $('#style_switcher_toggle'),
            $theme_switcher = $('#theme_switcher'),
            $mini_sidebar_toggle = $('#style_sidebar_mini');

        $switcher_toggle.click(function(e) {
            e.preventDefault();
            $switcher.toggleClass('switcher_active');
        });

        $theme_switcher.children('li').click(function(e) {
            e.preventDefault();
            var $this = $(this),
                this_theme = $this.attr('data-app-theme');

            $theme_switcher.children('li').removeClass('active_theme');
            $(this).addClass('active_theme');
            $('body')
                .removeClass('app_theme_a app_theme_b app_theme_c app_theme_d app_theme_e app_theme_f app_theme_g')
                .addClass(this_theme);

            if(this_theme == '') {
                localStorage.removeItem('altair_theme');
            } else {
                localStorage.setItem("altair_theme", this_theme);
            }

        });

        // change input's state to checked if mini sidebar is active
        if((localStorage.getItem("altair_sidebar_mini") !== null && localStorage.getItem("altair_sidebar_mini") == '1') || $('body').hasClass('sidebar_mini')) {
            $mini_sidebar_toggle.iCheck('check');
        }

        // toggle mini sidebar
        $mini_sidebar_toggle
            .on('ifChecked', function(event){
                $switcher.removeClass('switcher_active');
                localStorage.setItem("altair_sidebar_mini", '1');
                location.reload(true);
            })
            .on('ifUnchecked', function(event){
                $switcher.removeClass('switcher_active');
                localStorage.removeItem('altair_sidebar_mini');
                location.reload(true);
            });

        // hide style switcher
        $document.on('click keyup', function(e) {
            if( $switcher.hasClass('switcher_active') ) {
                if (
                    ( !$(e.target).closest($switcher).length )
                    || ( e.keyCode == 27 )
                ) {
                    $switcher.removeClass('switcher_active');
                }
            }
        });

        if(localStorage.getItem("altair_theme") !== null) {
            $theme_switcher.children('li[data-app-theme='+localStorage.getItem("altair_theme")+']').click();
        }
    });
</script>


<script type="text/javascript">
$(document).ready(function() {
    var wrapper         = $(".location_container"); //Fields wrapper
    var add_button      = $(".add_location_button"); //Add button ID

    var cont = '<div><div class="uk-grid" data-uk-grid-margin><div class="uk-width-medium-1-2"><label>Location Name</label><input type="text" class="md-input" name="location_name[]" value="" /></div><div class="uk-width-medium-1-2"><label>Address</label><input type="text" class="md-input" name="address[]" value="" /></div></div><div class="uk-grid" data-uk-grid-margin><div class="uk-width-medium-1-2"><label>City</label><input type="text" class="md-input" name="city[]" value="" /></div><div class="uk-width-medium-1-2"><label>Country</label><input type="text" class="md-input" name="country[]" value="" /></div></div><div class="uk-grid" data-uk-grid-margin><div class="uk-width-medium-1-2"><label>state</label><input type="text" class="md-input" name="state[]" value="" /></div><div class="uk-width-medium-1-2"><label>Zip Code</label><input type="text" class="md-input" name="zip[]" value="" /></div></div><div class="remove_field" style="text-align: right;width: 92%;">+ Remove Location</div><hr style="border-top:1px #000 solid;"></div>';

    var x = 1; //initlal text box count

    $(add_button).click(function(e){ //on add input button click

        e.preventDefault();

            x++; //text box increment
            $(wrapper).append(cont); //add input box

           datepick();
    });

    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
      var x = confirm("Are you sure, you want to delete Location?");
      if (x){
          e.preventDefault(); $(this).parent().remove(); x--;
      }
    });

});
</script>
@endsection


